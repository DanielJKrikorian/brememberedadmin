import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js';
import { Resend } from 'npm:resend';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

const resend = new Resend('re_789QctLP_NyajHL6uJJ9HAk2WQVHdWx9E');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { 
      bookingId, 
      email, 
      paymentLink, 
      rentalItemName, 
      customerName,
      amount,
      isSubscription,
      durationType
    } = await req.json();

    if (!email || !paymentLink) {
      throw new Error('Email and payment link are required');
    }

    // Format duration type for display
    const formatDurationType = (type: string) => {
      switch (type) {
        case 'hourly': return 'hour';
        case 'daily': return 'day';
        case 'weekly': return 'week';
        case 'monthly': return 'month';
        case 'yearly': return 'year';
        default: return type;
      }
    };

    // Send email using Resend
    const { data, error } = await resend.emails.send({
      from: 'B. Remembered Weddings <noreply@b-remembered.com>',
      to: email,
      subject: 'Complete Your Rental Payment - B. Remembered Weddings',
      html: `
        <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #333333;">
          <div style="text-align: center; margin-bottom: 30px;">
            <img src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png" alt="B. Remembered Logo" style="max-width: 200px; height: auto;">
          </div>
          <h1 style="color: #333333; font-size: 24px; margin-bottom: 20px;">Hello, ${customerName || 'there'}!</h1>
          <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">Thank you for your rental booking. Please complete your payment to confirm your reservation.</p>
          
          <div style="background-color: #f8f8f8; padding: 20px; border-radius: 5px; margin-bottom: 20px;">
            <h2 style="font-size: 18px; margin-bottom: 15px;">Booking Details</h2>
            <p style="margin-bottom: 10px; font-size: 16px;"><strong>Item:</strong> ${rentalItemName}</p>
            <p style="margin-bottom: 10px; font-size: 16px;"><strong>Amount:</strong> $${amount.toFixed(2)}</p>
            ${isSubscription ? `<p style="margin-bottom: 10px; font-size: 16px;"><strong>Billing:</strong> ${formatDurationType(durationType)}ly subscription</p>` : ''}
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${paymentLink}" style="display: inline-block; background-color: #9e8a78; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-size: 16px;">Complete Payment</a>
          </div>
          
          <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">If you have any questions, please don't hesitate to contact us.</p>
          
          <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eeeeee;">
            <p style="font-size: 14px; color: #777777;">© 2025 B. Remembered Weddings. All rights reserved.</p>
          </div>
        </div>
      `,
    });

    if (error) throw error;
    
    // Create a record of the email in the database
    const { error: dbError } = await supabase
      .from('message_responses')
      .insert({
        message_id: null, // No associated inbox message
        type: 'email',
        content: `Payment link for rental booking of ${rentalItemName} sent to ${email}. Amount: $${amount}${
          isSubscription ? ` (${formatDurationType(durationType)}ly subscription)` : ''
        }`,
        status: 'sent',
        sent_at: new Date().toISOString(),
        created_by: null, // System generated
      });

    if (dbError) throw dbError;

    // Update the booking to record that a payment link was sent
    await supabase
      .from('rental_bookings')
      .update({
        payment_link: paymentLink,
        payment_status: 'unpaid',
      })
      .eq('id', bookingId);

    return new Response(
      JSON.stringify({ success: true }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      },
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      },
    );
  }
});