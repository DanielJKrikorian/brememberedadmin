import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js';
import { Resend } from 'npm:resend';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

const resend = new Resend('re_789QctLP_NyajHL6uJJ9HAk2WQVHdWx9E');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { campaignId } = await req.json();

    // Get campaign details
    const { data: campaign, error: campaignError } = await supabase
      .from('newsletter_campaigns')
      .select('*')
      .eq('id', campaignId)
      .single();

    if (campaignError) throw campaignError;

    // Get pending sends
    const { data: sends, error: sendsError } = await supabase
      .from('newsletter_sends')
      .select(`
        *,
        subscriber:newsletter_subscribers(*)
      `)
      .eq('campaign_id', campaignId)
      .eq('status', 'pending');

    if (sendsError) throw sendsError;

    // Process each send
    for (const send of sends || []) {
      try {
        // Generate tracking links
        const content = await processTrackingLinks(campaign.content, campaignId, send.id);
        
        // Generate unsubscribe token
        const unsubscribeToken = await generateUnsubscribeToken(send.subscriber.email);
        
        // Replace placeholders
        const personalizedContent = content
          .replace(/{{name}}/g, send.subscriber.name || 'there')
          .replace(/{{unsubscribe_url}}/g, `${req.headers.get('origin')}/newsletter/unsubscribe/${unsubscribeToken}`);
        
        // Send email using Resend
        const { data, error } = await resend.emails.send({
          from: 'B. Remembered Weddings <noreply@b-remembered.com>',
          to: send.subscriber.email,
          subject: campaign.subject,
          html: personalizedContent,
        });
        
        if (error) throw error;
        
        // Update send status
        await supabase
          .from('newsletter_sends')
          .update({
            status: 'sent',
            sent_at: new Date().toISOString()
          })
          .eq('id', send.id);
      } catch (err) {
        console.error(`Error processing send ${send.id}:`, err);
        
        // Update send status to failed
        await supabase
          .from('newsletter_sends')
          .update({
            status: 'failed',
            error: err.message
          })
          .eq('id', send.id);
      }
    }

    return new Response(
      JSON.stringify({ success: true, processed: sends?.length || 0 }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

async function processTrackingLinks(content: string, campaignId: string, sendId: string): Promise<string> {
  // Find all links in the content
  const linkRegex = /<a\s+(?:[^>]*?\s+)?href="([^"]*)"[^>]*>(.*?)<\/a>/g;
  let match;
  let processedContent = content;
  
  while ((match = linkRegex.exec(content)) !== null) {
    const [fullMatch, url, linkText] = match;
    
    // Skip unsubscribe links
    if (url.includes('{{unsubscribe_url}}')) {
      continue;
    }
    
    // Generate tracking ID
    const trackingId = crypto.randomUUID();
    
    // Store link in database
    const { error } = await supabase
      .from('newsletter_links')
      .insert({
        campaign_id: campaignId,
        original_url: url,
        tracking_id: trackingId
      });
      
    if (error) throw error;
    
    // Replace link with tracking link
    const trackingUrl = `${Deno.env.get('SUPABASE_URL')}/functions/v1/track-newsletter-click?tid=${trackingId}&sid=${sendId}`;
    const newLink = `<a href="${trackingUrl}" target="_blank">${linkText}</a>`;
    
    processedContent = processedContent.replace(fullMatch, newLink);
  }
  
  // Add tracking pixel
  const trackingPixel = `<img src="${Deno.env.get('SUPABASE_URL')}/functions/v1/track-newsletter-open?sid=${sendId}" width="1" height="1" alt="" style="display:none;" />`;
  processedContent = processedContent.replace('</body>', `${trackingPixel}</body>`);
  
  return processedContent;
}

async function generateUnsubscribeToken(email: string): Promise<string> {
  // Create a simple token by encoding the email and a timestamp
  const data = {
    email,
    timestamp: Date.now(),
    // In a real implementation, you would add a secret key here
  };
  
  // Convert to base64
  const token = btoa(JSON.stringify(data));
  
  return token;
}