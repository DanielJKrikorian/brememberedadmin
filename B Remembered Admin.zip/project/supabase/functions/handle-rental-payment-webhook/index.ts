import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js';
import Stripe from 'npm:stripe';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
  apiVersion: '2023-10-16',
});

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

const endpointSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');

serve(async (req) => {
  const signature = req.headers.get('stripe-signature');
  
  if (!signature || !endpointSecret) {
    return new Response('Webhook Error: No signature', { status: 400 });
  }

  try {
    const body = await req.text();
    const event = stripe.webhooks.constructEvent(body, signature, endpointSecret);

    // Handle checkout session completed event
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const bookingId = session.metadata.bookingId;
      const isSubscription = session.metadata.isSubscription === 'true';

      if (!bookingId) {
        throw new Error('No booking ID in metadata');
      }

      // Update booking payment status
      await supabase
        .from('rental_bookings')
        .update({
          payment_status: 'paid',
          payment_id: session.payment_intent || session.subscription,
          subscription_id: isSubscription ? session.subscription : null,
          status: 'confirmed', // Auto-confirm booking on payment
        })
        .eq('id', bookingId);

      // If this is a subscription, store the subscription ID
      if (isSubscription && session.subscription) {
        // Additional subscription-specific logic could go here
      }
    }
    
    // Handle subscription payment succeeded
    else if (event.type === 'invoice.payment_succeeded') {
      const invoice = event.data.object;
      
      // Only process subscription invoices
      if (invoice.subscription) {
        // Find the booking with this subscription ID
        const { data: booking } = await supabase
          .from('rental_bookings')
          .select('id')
          .eq('subscription_id', invoice.subscription)
          .single();
          
        if (booking) {
          // Update the booking to reflect the latest payment
          await supabase
            .from('rental_bookings')
            .update({
              payment_status: 'paid',
              status: 'active', // Keep the booking active
            })
            .eq('id', booking.id);
        }
      }
    }
    
    // Handle subscription cancelled
    else if (event.type === 'customer.subscription.deleted') {
      const subscription = event.data.object;
      
      // Find the booking with this subscription ID
      const { data: booking } = await supabase
        .from('rental_bookings')
        .select('id, rental_item_id')
        .eq('subscription_id', subscription.id)
        .single();
        
      if (booking) {
        // Update the booking to reflect cancellation
        await supabase
          .from('rental_bookings')
          .update({
            status: 'completed',
          })
          .eq('id', booking.id);
          
        // Update the rental item status back to available
        await supabase
          .from('rental_items')
          .update({
            status: 'available',
          })
          .eq('id', booking.rental_item_id);
      }
    }

    return new Response(JSON.stringify({ received: true }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err) {
    return new Response(
      JSON.stringify({ error: `Webhook Error: ${err.message}` }),
      { status: 400, headers: { 'Content-Type': 'application/json' } }
    );
  }
});