import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Get all leads from leads_list table
    const { data: leadsListData, error: leadsListError } = await supabase
      .from('leads_list')
      .select('*');

    if (leadsListError) throw leadsListError;

    if (!leadsListData || leadsListData.length === 0) {
      return new Response(
        JSON.stringify({ message: 'No leads found in leads_list table' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Transform leads_list data to match leads table structure
    const transformedLeads = leadsListData.map(lead => ({
      name: lead.inquiry_name || 'Unknown',
      email: lead.email || null,
      phone: lead.phone_number || null,
      source: 'imported',
      status: 'new',
      partner_name: lead.partner_name || null,
      wedding_date: lead.wedding_date || null,
      venue_name: lead.venue_address || null, // Using venue_address as venue_name since that's what's available
      venue_address: lead.venue_address || null,
      notes: lead.additional_details || null,
      lead_date: lead.created_at ? new Date(lead.created_at).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]
    }));

    // Insert transformed leads into leads table
    const { data: insertedLeads, error: insertError } = await supabase
      .from('leads')
      .insert(transformedLeads)
      .select();

    if (insertError) throw insertError;

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Successfully imported ${insertedLeads.length} leads from leads_list table`,
        imported: insertedLeads.length
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});