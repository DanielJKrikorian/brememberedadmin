import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js';
import Stripe from 'npm:stripe';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
  apiVersion: '2023-10-16',
});

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { 
      leadId, 
      shareId,
      customerEmail,
      customerName
    } = await req.json();

    // Get share details
    const { data: share, error: shareError } = await supabase
      .from('folder_shares')
      .select(`
        *,
        folder:storage_folders(
          name,
          vendor:vendors(name)
        )
      `)
      .eq('id', shareId)
      .single();

    if (shareError) throw shareError;

    // Create or get Stripe customer
    let customer;
    const { data: existingCustomers } = await stripe.customers.list({
      email: customerEmail,
      limit: 1,
    });

    if (existingCustomers && existingCustomers.data.length > 0) {
      customer = existingCustomers.data[0];
    } else {
      customer = await stripe.customers.create({
        email: customerEmail,
        name: customerName,
        metadata: {
          leadId,
        },
      });
    }

    // Create a product for the shared folder
    const product = await stripe.products.create({
      name: `Access to ${share.folder.name}`,
      description: `Shared by ${share.folder.vendor.name}`,
      metadata: {
        shareId,
      },
    });

    // Create a price for the subscription
    const price = await stripe.prices.create({
      product: product.id,
      unit_amount: Math.round(share.price_monthly * 100),
      currency: 'usd',
      recurring: {
        interval: 'month',
      },
      metadata: {
        shareId,
      },
    });

    // Create a checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customer.id,
      payment_method_types: ['card'],
      line_items: [
        {
          price: price.id,
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: `${req.headers.get('origin')}/couple-storage?success=true`,
      cancel_url: `${req.headers.get('origin')}/couple-storage?canceled=true`,
      metadata: {
        leadId,
        shareId,
      },
    });

    return new Response(
      JSON.stringify({ url: session.url }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      },
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      },
    );
  }
});