import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

serve(async (req) => {
  try {
    const url = new URL(req.url);
    const trackingId = url.searchParams.get('tid');
    const sendId = url.searchParams.get('sid');

    if (!trackingId || !sendId) {
      throw new Error('Missing tracking ID or send ID');
    }

    // Get the original URL
    const { data: link, error: linkError } = await supabase
      .from('newsletter_links')
      .select('original_url')
      .eq('tracking_id', trackingId)
      .single();

    if (linkError) throw linkError;

    // Record the click
    await supabase
      .from('newsletter_link_clicks')
      .insert({
        link_id: link.id,
        send_id: sendId,
        clicked_at: new Date().toISOString()
      });

    // Update send status to clicked
    await supabase
      .from('newsletter_sends')
      .update({
        status: 'clicked',
        clicked_at: new Date().toISOString()
      })
      .eq('id', sendId);

    // Redirect to the original URL
    return new Response(null, {
      status: 302,
      headers: {
        'Location': link.original_url
      }
    });
  } catch (error) {
    console.error('Error tracking click:', error);
    
    // Redirect to homepage if there's an error
    return new Response(null, {
      status: 302,
      headers: {
        'Location': '/'
      }
    });
  }
});