import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { token } = await req.json();

    // Decode token
    let decodedToken;
    try {
      decodedToken = JSON.parse(atob(token));
    } catch (err) {
      throw new Error('Invalid token format');
    }

    // Validate token
    if (!decodedToken.email || !decodedToken.timestamp) {
      throw new Error('Invalid token data');
    }

    // Check if token is expired (24 hours)
    const tokenAge = Date.now() - decodedToken.timestamp;
    if (tokenAge > 24 * 60 * 60 * 1000) {
      throw new Error('Token has expired');
    }

    // Check if subscriber exists
    const { data: subscriber, error: subscriberError } = await supabase
      .from('newsletter_subscribers')
      .select('*')
      .eq('email', decodedToken.email)
      .single();

    if (subscriberError) {
      throw new Error('Subscriber not found');
    }

    return new Response(
      JSON.stringify({ email: decodedToken.email }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});