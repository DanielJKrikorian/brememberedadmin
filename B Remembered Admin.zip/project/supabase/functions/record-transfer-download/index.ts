import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { transferId, fileId } = await req.json();

    // Get transfer details
    const { data: transfer, error: transferError } = await supabase
      .from('content_transfers')
      .select('*')
      .eq('id', transferId)
      .single();

    if (transferError) throw transferError;

    // Check if transfer is active
    if (transfer.status !== 'active') {
      return new Response(
        JSON.stringify({ 
          error: transfer.status === 'expired' 
            ? 'This transfer has expired' 
            : 'This transfer is no longer available'
        }),
        {
          status: 403,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Check if transfer has expired
    if (new Date(transfer.expiration_date) < new Date()) {
      // Update transfer status to expired
      await supabase
        .from('content_transfers')
        .update({ status: 'expired' })
        .eq('id', transferId);
        
      return new Response(
        JSON.stringify({ error: 'This transfer has expired' }),
        {
          status: 403,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Increment download count
    await supabase
      .from('content_transfers')
      .update({ downloads: transfer.downloads + 1 })
      .eq('id', transferId);

    // Get file details
    const { data: file, error: fileError } = await supabase
      .from('transfer_files')
      .select('*')
      .eq('id', fileId)
      .eq('transfer_id', transferId)
      .single();

    if (fileError) throw fileError;

    return new Response(
      JSON.stringify({ success: true, file }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});