import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { orderId, notificationTypes } = await req.json();

    // Get order details
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .select(`
        *,
        vendor:vendors(name, email, phone),
        notifications:order_notifications(*)
      `)
      .eq('id', orderId)
      .single();

    if (orderError) throw orderError;
    if (!order) throw new Error('Order not found');
    if (!order.tracking_number) throw new Error('Order has no tracking number');

    // Get pending notifications
    const { data: notifications, error: notificationsError } = await supabase
      .from('order_notifications')
      .select('*')
      .eq('order_id', orderId)
      .eq('status', 'pending');

    if (notificationsError) throw notificationsError;

    // Process each notification
    const results = [];
    for (const notification of notifications || []) {
      try {
        // Here you would integrate with your email/SMS provider
        // For this example, we'll just simulate successful sending
        
        // For email notifications
        if (notification.type === 'email' && order.vendor.email) {
          console.log(`Sending email to ${order.vendor.email} about tracking ${order.tracking_number}`);
          // In a real implementation, you would call your email service here
          
          results.push({
            id: notification.id,
            type: 'email',
            success: true
          });
        }
        
        // For SMS notifications
        else if (notification.type === 'sms' && order.vendor.phone) {
          console.log(`Sending SMS to ${order.vendor.phone} about tracking ${order.tracking_number}`);
          // In a real implementation, you would call your SMS service here
          
          results.push({
            id: notification.id,
            type: 'sms',
            success: true
          });
        }
        
        // For in-app notifications
        else if (notification.type === 'in_app') {
          console.log(`Creating in-app notification for vendor ${order.vendor_id}`);
          // In a real implementation, you would create an in-app notification record
          
          results.push({
            id: notification.id,
            type: 'in_app',
            success: true
          });
        }
        
        // Update notification status
        await supabase
          .from('order_notifications')
          .update({
            status: 'sent',
            sent_at: new Date().toISOString()
          })
          .eq('id', notification.id);
      } catch (err) {
        console.error(`Error sending notification ${notification.id}:`, err);
        
        // Update notification status to failed
        await supabase
          .from('order_notifications')
          .update({
            status: 'failed'
          })
          .eq('id', notification.id);
        
        results.push({
          id: notification.id,
          type: notification.type,
          success: false,
          error: err.message
        });
      }
    }

    return new Response(
      JSON.stringify({ success: true, results }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});