import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js';
import { Resend } from 'npm:resend';

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

// Initialize Resend client
const resend = new Resend(Deno.env.get('RESEND_API_KEY') || '');

// Twilio credentials
const TWILIO_SID = 'SKf09347962c409780b81070056c79be99';
const TWILIO_SECRET = 'QtMM8VqLABO0Yjz0SEDIZvh4CJOrP9tv';
const TWILIO_PHONE_NUMBER = '+18665747943'; // Updated Twilio phone number

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { templateId, recipient, variables, type } = await req.json();

    if (!templateId || !recipient) {
      throw new Error('Template ID and recipient are required');
    }

    // Get template from database
    const { data: template, error: templateError } = await supabase
      .from('email_templates')
      .select('*')
      .eq('id', templateId)
      .single();

    if (templateError) throw templateError;
    if (!template) throw new Error('Template not found');

    // Replace variables in content
    let content = template.content;
    let subject = template.subject || '';

    for (const [key, value] of Object.entries(variables)) {
      const regex = new RegExp(`{{${key}}}`, 'g');
      content = content.replace(regex, value || `{{${key}}}`);
      subject = subject.replace(regex, value || `{{${key}}}`);
    }

    // Send message based on type
    if (type === 'email') {
      // Send email using Resend
      const { data, error } = await resend.emails.send({
        from: 'B. Remembered Weddings <noreply@b-remembered.com>',
        to: recipient,
        subject,
        html: content,
      });

      if (error) throw error;

      return new Response(
        JSON.stringify({ success: true, data }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    } else if (type === 'sms') {
      // Send SMS using Twilio
      const url = `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_SID}/Messages.json`;
      
      const formData = new URLSearchParams();
      formData.append('To', recipient);
      formData.append('From', TWILIO_PHONE_NUMBER);
      formData.append('Body', content);
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': 'Basic ' + btoa(`${TWILIO_SID}:${TWILIO_SECRET}`)
        },
        body: formData
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to send SMS');
      }
      
      const data = await response.json();

      return new Response(
        JSON.stringify({ success: true, data }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    } else {
      throw new Error(`Unsupported message type: ${type}`);
    }
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});