import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js';
import Stripe from 'npm:stripe';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
  apiVersion: '2023-10-16',
});

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

const endpointSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');

serve(async (req) => {
  const signature = req.headers.get('stripe-signature');
  
  if (!signature || !endpointSecret) {
    return new Response('Webhook Error: No signature', { status: 400 });
  }

  try {
    const body = await req.text();
    const event = stripe.webhooks.constructEvent(body, signature, endpointSecret);

    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const quoteId = session.metadata.quoteId;
      const serviceFee = parseFloat(session.metadata.serviceFee || '0');

      // Get quote details
      const { data: quote } = await supabase
        .from('quotes')
        .select('*, vendor:vendors(*)')
        .eq('id', quoteId)
        .single();

      if (!quote) {
        throw new Error('Quote not found');
      }

      // Update quote status to paid
      await supabase
        .from('quotes')
        .update({
          status: 'paid',
          stripe_payment_id: session.payment_intent
        })
        .eq('id', quoteId);

      // Create booking
      await supabase
        .from('bookings')
        .insert({
          lead_id: quote.lead_id,
          vendor_id: quote.vendor_id,
          amount: quote.amount,
          status: 'confirmed',
          start_date: new Date().toISOString(),
          end_date: new Date().toISOString()
        });

      // Record service fee as revenue
      if (serviceFee > 0) {
        await supabase
          .from('revenues')
          .insert({
            amount: serviceFee,
            date: new Date().toISOString().split('T')[0],
            description: `Service fee for Quote #${quoteId}`,
            source: 'service_fee',
            account_number: 'SRV-FEE'
          });
      }

      // If vendor has Stripe connected, create automatic payout
      if (quote.vendor?.stripe_account_id) {
        // Calculate vendor payout amount (e.g., 90% of payment)
        const payoutAmount = Math.round(quote.amount * 0.9 * 100); // Convert to cents

        // Create Stripe transfer
        const transfer = await stripe.transfers.create({
          amount: payoutAmount,
          currency: 'usd',
          destination: quote.vendor.stripe_account_id,
          description: `Automatic payout for quote #${quote.id}`,
          transfer_group: quote.id,
        });

        // Record payout in database
        await supabase
          .from('payouts')
          .insert({
            vendor_id: quote.vendor_id,
            quote_id: quote.id,
            amount: payoutAmount / 100, // Convert back to dollars
            status: 'completed',
            stripe_transfer_id: transfer.id,
            description: `Automatic payout for quote #${quote.id}`,
          });
      }
    }

    return new Response(JSON.stringify({ received: true }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err) {
    return new Response(
      JSON.stringify({ error: `Webhook Error: ${err.message}` }),
      { status: 400, headers: { 'Content-Type': 'application/json' } }
    );
  }
});