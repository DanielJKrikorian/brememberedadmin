import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js';
import { Resend } from 'npm:resend';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

const resend = new Resend('re_789QctLP_NyajHL6uJJ9HAk2WQVHdWx9E');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { messageId, content, type } = await req.json();

    // Get message details
    const { data: message, error: messageError } = await supabase
      .from('inbox_messages')
      .select('*')
      .eq('id', messageId)
      .single();

    if (messageError) throw messageError;

    // Get current user's team member ID
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) throw new Error('No authorization header');

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    if (userError) throw userError;

    const { data: teamMember, error: teamError } = await supabase
      .from('team_members')
      .select('id, name')
      .eq('user_id', user.id)
      .single();

    if (teamError) throw teamError;

    // Record the response
    const { data: response, error: responseError } = await supabase
      .from('message_responses')
      .insert({
        message_id: messageId,
        content,
        type,
        created_by: teamMember.id,
      })
      .select()
      .single();

    if (responseError) throw responseError;

    // Send the message based on type
    let success = false;
    let errorMessage = null;

    try {
      switch (type) {
        case 'email':
          // Send email using Resend
          const { data: emailData } = await resend.emails.send({
            from: 'B. Remembered Weddings <noreply@b-remembered.com>',
            to: message.email,
            subject: `Re: ${message.subject}`,
            html: `
              <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #333333;">
                <div style="text-align: center; margin-bottom: 30px;">
                  <img src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png" alt="B. Remembered Logo" style="max-width: 200px; height: auto;">
                </div>
                <h1 style="color: #333333; font-size: 24px; margin-bottom: 20px;">Hello, ${message.name}!</h1>
                <div style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">
                  ${content.replace(/\n/g, '<br>')}
                </div>
                <div style="margin-top: 30px; font-size: 14px; color: #777777; border-top: 1px solid #eeeeee; padding-top: 20px;">
                  <p>Best regards,<br>${teamMember.name}<br>B. Remembered Weddings</p>
                </div>
              </div>
            `,
          });
          
          success = true;
          break;

        case 'sms':
          // TODO: Implement SMS sending with Twilio
          // For now, simulate success
          success = true;
          break;

        case 'in_app':
          // TODO: Implement in-app messaging
          // For now, simulate success
          success = true;
          break;

        default:
          throw new Error(`Unsupported message type: ${type}`);
      }
    } catch (err) {
      success = false;
      errorMessage = err instanceof Error ? err.message : 'Failed to send message';
    }

    // Update response status
    const { error: updateError } = await supabase
      .from('message_responses')
      .update({
        status: success ? 'sent' : 'failed',
        sent_at: success ? new Date().toISOString() : null,
        error: errorMessage,
      })
      .eq('id', response.id);

    if (updateError) throw updateError;

    return new Response(
      JSON.stringify({ success, error: errorMessage }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});