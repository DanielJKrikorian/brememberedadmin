import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js';
import { Resend } from 'npm:resend';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

const resend = new Resend('re_789QctLP_NyajHL6uJJ9HAk2WQVHdWx9E');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { transferId, notificationType } = await req.json();

    // Get transfer details
    const { data: transfer, error: transferError } = await supabase
      .from('content_transfers')
      .select('*')
      .eq('id', transferId)
      .single();

    if (transferError) throw transferError;

    // Get transfer files
    const { data: files, error: filesError } = await supabase
      .from('transfer_files')
      .select('*')
      .eq('transfer_id', transferId);

    if (filesError) throw filesError;

    // Generate transfer link
    const transferLink = `${req.headers.get('origin')}/transfer/${transferId}`;

    // Send notifications based on type
    if (notificationType === 'email' || notificationType === 'both') {
      await sendEmailNotification(transfer, files, transferLink);
    }

    if ((notificationType === 'sms' || notificationType === 'both') && transfer.recipient_phone) {
      await sendSmsNotification(transfer, transferLink);
    }

    return new Response(
      JSON.stringify({ success: true }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      },
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      },
    );
  }
});

async function sendEmailNotification(transfer: any, files: any[], transferLink: string) {
  try {
    // Format file list for email
    const fileList = files.map(file => 
      `<li style="margin-bottom: 5px;">${file.name} (${formatBytes(file.size)})</li>`
    ).join('');
    
    // Send email using Resend
    const { data, error } = await resend.emails.send({
      from: 'B. Remembered Weddings <noreply@b-remembered.com>',
      to: transfer.recipient_email,
      subject: transfer.subject,
      html: `
        <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #333333;">
          <div style="text-align: center; margin-bottom: 30px;">
            <img src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png" alt="B. Remembered Logo" style="max-width: 200px; height: auto;">
          </div>
          <h1 style="color: #333333; font-size: 24px; margin-bottom: 20px;">Files Shared with You</h1>
          
          ${transfer.message ? `<p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">${transfer.message}</p>` : ''}
          
          <div style="background-color: #f8f8f8; padding: 20px; border-radius: 5px; margin-bottom: 20px;">
            <h2 style="font-size: 18px; margin-bottom: 15px;">Access Information</h2>
            <p style="margin-bottom: 10px; font-size: 16px;"><strong>Access Code:</strong> ${transfer.access_code}</p>
            <p style="font-size: 14px; color: #666;">You'll need this code to access your files.</p>
          </div>
          
          <div style="margin-bottom: 20px;">
            <h2 style="font-size: 18px; margin-bottom: 15px;">Files (${files.length})</h2>
            <ul style="padding-left: 20px;">
              ${fileList}
            </ul>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${transferLink}" style="display: inline-block; background-color: #9e8a78; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-size: 16px;">Access Your Files</a>
          </div>
          
          <p style="margin-bottom: 10px; font-size: 14px; color: #666;">Files will be available until ${new Date(transfer.expiration_date).toLocaleDateString()}</p>
          
          <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eeeeee;">
            <p style="font-size: 14px; color: #777777;">© 2025 B. Remembered Weddings. All rights reserved.</p>
          </div>
        </div>
      `,
    });
    
    if (error) throw error;
    
    // Record notification in database
    const { error: dbError } = await supabase
      .from('transfer_notifications')
      .insert({
        transfer_id: transfer.id,
        type: 'email',
        status: 'sent',
        sent_at: new Date().toISOString()
      });
      
    if (dbError) throw dbError;
    
    return true;
  } catch (err) {
    console.error('Error sending email notification:', err);
    
    // Record failure
    await supabase
      .from('transfer_notifications')
      .insert({
        transfer_id: transfer.id,
        type: 'email',
        status: 'failed',
        error: err.message
      });
      
    throw err;
  }
}

async function sendSmsNotification(transfer: any, transferLink: string) {
  try {
    // In a real implementation, you would use an SMS service like Twilio
    // For this example, we'll just record the notification in the database
    
    const { error } = await supabase
      .from('transfer_notifications')
      .insert({
        transfer_id: transfer.id,
        type: 'sms',
        status: 'sent',
        sent_at: new Date().toISOString()
      });
      
    if (error) throw error;
    
    // Return success
    return true;
  } catch (err) {
    console.error('Error sending SMS notification:', err);
    
    // Record failure
    await supabase
      .from('transfer_notifications')
      .insert({
        transfer_id: transfer.id,
        type: 'sms',
        status: 'failed',
        error: err.message
      });
      
    throw err;
  }
}

function formatBytes(bytes: number, decimals = 2) {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}