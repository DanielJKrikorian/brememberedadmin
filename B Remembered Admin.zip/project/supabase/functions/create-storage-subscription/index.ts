import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js';
import Stripe from 'npm:stripe';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
  apiVersion: '2023-10-16',
});

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { 
      vendorId, 
      planId, 
      billingCycle,
      customerEmail,
      customerName
    } = await req.json();

    // Get plan details
    const { data: plan, error: planError } = await supabase
      .from('storage_plans')
      .select('*')
      .eq('id', planId)
      .single();

    if (planError) throw planError;

    // Create or get Stripe customer
    let customer;
    const { data: existingCustomers } = await stripe.customers.list({
      email: customerEmail,
      limit: 1,
    });

    if (existingCustomers && existingCustomers.data.length > 0) {
      customer = existingCustomers.data[0];
    } else {
      customer = await stripe.customers.create({
        email: customerEmail,
        name: customerName,
        metadata: {
          vendorId,
        },
      });
    }

    // Create a product for the plan
    const product = await stripe.products.create({
      name: `${plan.name} Storage Plan`,
      description: plan.description || `${plan.name} storage plan for vendors`,
      metadata: {
        planId,
      },
    });

    // Create a price for the plan
    const price = await stripe.prices.create({
      product: product.id,
      unit_amount: Math.round((billingCycle === 'monthly' ? plan.price_monthly : plan.price_yearly) * 100),
      currency: 'usd',
      recurring: {
        interval: billingCycle === 'monthly' ? 'month' : 'year',
      },
      metadata: {
        planId,
      },
    });

    // Create a checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customer.id,
      payment_method_types: ['card'],
      line_items: [
        {
          price: price.id,
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: `${req.headers.get('origin')}/vendor-storage?success=true`,
      cancel_url: `${req.headers.get('origin')}/vendor-storage?canceled=true`,
      metadata: {
        vendorId,
        planId,
        billingCycle,
      },
    });

    return new Response(
      JSON.stringify({ url: session.url }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      },
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      },
    );
  }
});