import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js';
import Stripe from 'npm:stripe';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
  apiVersion: '2023-10-16',
});

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

const endpointSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');

serve(async (req) => {
  const signature = req.headers.get('stripe-signature');
  
  if (!signature || !endpointSecret) {
    return new Response('Webhook Error: No signature', { status: 400 });
  }

  try {
    const body = await req.text();
    const event = stripe.webhooks.constructEvent(body, signature, endpointSecret);

    // Handle checkout session completed event
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      
      // Check if this is a vendor storage subscription
      if (session.metadata.vendorId && session.metadata.planId) {
        await handleVendorStorageSubscription(session);
      }
      
      // Check if this is a folder share subscription
      else if (session.metadata.leadId && session.metadata.shareId) {
        await handleFolderShareSubscription(session);
      }
    }
    
    // Handle subscription updated event
    else if (event.type === 'customer.subscription.updated') {
      const subscription = event.data.object;
      await handleSubscriptionUpdate(subscription);
    }
    
    // Handle subscription deleted event
    else if (event.type === 'customer.subscription.deleted') {
      const subscription = event.data.object;
      await handleSubscriptionCancellation(subscription);
    }

    return new Response(JSON.stringify({ received: true }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err) {
    return new Response(
      JSON.stringify({ error: `Webhook Error: ${err.message}` }),
      { status: 400, headers: { 'Content-Type': 'application/json' } }
    );
  }
});

async function handleVendorStorageSubscription(session: any) {
  const vendorId = session.metadata.vendorId;
  const planId = session.metadata.planId;
  const billingCycle = session.metadata.billingCycle || 'monthly';
  
  // Calculate period end date
  const now = new Date();
  const periodEnd = new Date(now);
  if (billingCycle === 'monthly') {
    periodEnd.setMonth(periodEnd.getMonth() + 1);
  } else {
    periodEnd.setFullYear(periodEnd.getFullYear() + 1);
  }
  
  // Check if vendor already has a subscription
  const { data: existingSubscription } = await supabase
    .from('vendor_storage_subscriptions')
    .select('id')
    .eq('vendor_id', vendorId)
    .eq('status', 'active')
    .maybeSingle();
  
  if (existingSubscription) {
    // Update existing subscription
    await supabase
      .from('vendor_storage_subscriptions')
      .update({
        plan_id: planId,
        status: 'active',
        billing_cycle: billingCycle,
        current_period_start: now.toISOString(),
        current_period_end: periodEnd.toISOString(),
        stripe_subscription_id: session.subscription
      })
      .eq('id', existingSubscription.id);
  } else {
    // Create new subscription
    await supabase
      .from('vendor_storage_subscriptions')
      .insert({
        vendor_id: vendorId,
        plan_id: planId,
        status: 'active',
        storage_used: 0,
        billing_cycle: billingCycle,
        current_period_start: now.toISOString(),
        current_period_end: periodEnd.toISOString(),
        stripe_subscription_id: session.subscription
      });
    
    // Enable storage for vendor
    await supabase
      .from('vendors')
      .update({ storage_enabled: true })
      .eq('id', vendorId);
  }
}

async function handleFolderShareSubscription(session: any) {
  const leadId = session.metadata.leadId;
  const shareId = session.metadata.shareId;
  
  // Calculate period end date (1 month from now)
  const now = new Date();
  const periodEnd = new Date(now);
  periodEnd.setMonth(periodEnd.getMonth() + 1);
  
  // Create subscription
  await supabase
    .from('couple_storage_subscriptions')
    .insert({
      lead_id: leadId,
      folder_share_id: shareId,
      status: 'active',
      billing_cycle: 'monthly',
      current_period_start: now.toISOString(),
      current_period_end: periodEnd.toISOString(),
      stripe_subscription_id: session.subscription
    });
  
  // Update share status
  await supabase
    .from('folder_shares')
    .update({ status: 'active' })
    .eq('id', shareId);
}

async function handleSubscriptionUpdate(subscription: any) {
  // Get the subscription item's price
  const subscriptionItem = subscription.items.data[0];
  const price = subscriptionItem.price;
  
  // Check if this is a vendor storage subscription
  const { data: vendorSubscription } = await supabase
    .from('vendor_storage_subscriptions')
    .select('id')
    .eq('stripe_subscription_id', subscription.id)
    .maybeSingle();
  
  if (vendorSubscription) {
    // Update vendor subscription
    await supabase
      .from('vendor_storage_subscriptions')
      .update({
        status: subscription.status === 'active' ? 'active' : 'canceled',
        current_period_end: new Date(subscription.current_period_end * 1000).toISOString()
      })
      .eq('id', vendorSubscription.id);
  }
  
  // Check if this is a folder share subscription
  const { data: coupleSubscription } = await supabase
    .from('couple_storage_subscriptions')
    .select('id, folder_share_id')
    .eq('stripe_subscription_id', subscription.id)
    .maybeSingle();
  
  if (coupleSubscription) {
    // Update couple subscription
    await supabase
      .from('couple_storage_subscriptions')
      .update({
        status: subscription.status === 'active' ? 'active' : 'canceled',
        current_period_end: new Date(subscription.current_period_end * 1000).toISOString()
      })
      .eq('id', coupleSubscription.id);
    
    // If subscription is no longer active, update folder share status
    if (subscription.status !== 'active') {
      await supabase
        .from('folder_shares')
        .update({ status: 'expired' })
        .eq('id', coupleSubscription.folder_share_id);
    }
  }
}

async function handleSubscriptionCancellation(subscription: any) {
  // Check if this is a vendor storage subscription
  const { data: vendorSubscription } = await supabase
    .from('vendor_storage_subscriptions')
    .select('id, vendor_id')
    .eq('stripe_subscription_id', subscription.id)
    .maybeSingle();
  
  if (vendorSubscription) {
    // Update vendor subscription
    await supabase
      .from('vendor_storage_subscriptions')
      .update({
        status: 'expired'
      })
      .eq('id', vendorSubscription.id);
    
    // Disable storage for vendor
    await supabase
      .from('vendors')
      .update({ storage_enabled: false })
      .eq('id', vendorSubscription.vendor_id);
  }
  
  // Check if this is a folder share subscription
  const { data: coupleSubscription } = await supabase
    .from('couple_storage_subscriptions')
    .select('id, folder_share_id')
    .eq('stripe_subscription_id', subscription.id)
    .maybeSingle();
  
  if (coupleSubscription) {
    // Update couple subscription
    await supabase
      .from('couple_storage_subscriptions')
      .update({
        status: 'expired'
      })
      .eq('id', coupleSubscription.id);
    
    // Update folder share status
    await supabase
      .from('folder_shares')
      .update({ status: 'expired' })
      .eq('id', coupleSubscription.folder_share_id);
  }
}