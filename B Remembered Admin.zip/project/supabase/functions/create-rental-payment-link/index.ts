import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js';
import Stripe from 'npm:stripe';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
  apiVersion: '2023-10-16',
});

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { 
      bookingId, 
      rentalItemId, 
      amount, 
      isSubscription, 
      durationType,
      customerEmail,
      customerName
    } = await req.json();

    // Get rental item details
    const { data: rentalItem, error: rentalError } = await supabase
      .from('rental_items')
      .select('name, description')
      .eq('id', rentalItemId)
      .single();

    if (rentalError) throw rentalError;

    // Format duration type for display
    const formatDurationType = (type: string) => {
      switch (type) {
        case 'hourly': return 'hour';
        case 'daily': return 'day';
        case 'weekly': return 'week';
        case 'monthly': return 'month';
        case 'yearly': return 'year';
        default: return type;
      }
    };

    let paymentLink;

    if (isSubscription) {
      // For subscriptions, create a Stripe product and price first
      const product = await stripe.products.create({
        name: `Rental: ${rentalItem.name}`,
        description: rentalItem.description || `Rental subscription for ${rentalItem.name}`,
        metadata: {
          bookingId,
          rentalItemId,
        },
      });

      // Convert duration type to Stripe interval
      let interval;
      switch (durationType) {
        case 'hourly':
          // Stripe doesn't support hourly, so we'll use daily
          interval = 'day';
          break;
        case 'daily':
          interval = 'day';
          break;
        case 'weekly':
          interval = 'week';
          break;
        case 'monthly':
          interval = 'month';
          break;
        case 'yearly':
          interval = 'year';
          break;
        default:
          interval = 'month';
      }

      // Create a price for the subscription
      const price = await stripe.prices.create({
        product: product.id,
        unit_amount: Math.round(amount * 100), // Convert to cents
        currency: 'usd',
        recurring: {
          interval,
        },
        metadata: {
          bookingId,
          rentalItemId,
        },
      });

      // Create a subscription checkout session
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [
          {
            price: price.id,
            quantity: 1,
          },
        ],
        mode: 'subscription',
        success_url: `${req.headers.get('origin')}/rentals/booking/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${req.headers.get('origin')}/rentals/booking/cancel`,
        metadata: {
          bookingId,
          rentalItemId,
          isSubscription: 'true',
        },
        customer_email: customerEmail,
      });

      paymentLink = session.url;
    } else {
      // For one-time payments, create a regular checkout session
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [
          {
            price_data: {
              currency: 'usd',
              product_data: {
                name: `Rental: ${rentalItem.name}`,
                description: rentalItem.description || `Rental for ${rentalItem.name}`,
              },
              unit_amount: Math.round(amount * 100), // Convert to cents
            },
            quantity: 1,
          },
        ],
        mode: 'payment',
        success_url: `${req.headers.get('origin')}/rentals/booking/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${req.headers.get('origin')}/rentals/booking/cancel`,
        metadata: {
          bookingId,
          rentalItemId,
          isSubscription: 'false',
        },
        customer_email: customerEmail,
      });

      paymentLink = session.url;
    }

    return new Response(
      JSON.stringify({ paymentLink }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      },
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      },
    );
  }
});