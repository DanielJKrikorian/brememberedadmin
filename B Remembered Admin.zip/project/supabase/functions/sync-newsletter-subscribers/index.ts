import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Sync leads
    await syncLeads();
    
    // Sync vendors
    await syncVendors();
    
    // Sync venues
    await syncVenues();

    return new Response(
      JSON.stringify({ success: true }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

async function syncLeads() {
  // Get all leads with email
  const { data: leads, error: leadsError } = await supabase
    .from('leads')
    .select('id, name, email')
    .not('email', 'is', null);
    
  if (leadsError) throw leadsError;
  
  // Get existing lead subscribers
  const { data: existingSubscribers, error: subscribersError } = await supabase
    .from('newsletter_subscribers')
    .select('email, lead_id')
    .eq('type', 'lead');
    
  if (subscribersError) throw subscribersError;
  
  // Create a map of existing subscribers by email
  const existingSubscribersByEmail = new Map();
  existingSubscribers?.forEach(sub => {
    existingSubscribersByEmail.set(sub.email, sub.lead_id);
  });
  
  // Find leads that need to be added or updated
  const leadsToSync = leads?.filter(lead => 
    lead.email && (!existingSubscribersByEmail.has(lead.email) || existingSubscribersByEmail.get(lead.email) !== lead.id)
  );
  
  // Insert or update subscribers
  for (const lead of leadsToSync || []) {
    if (existingSubscribersByEmail.has(lead.email)) {
      // Update existing subscriber
      await supabase
        .from('newsletter_subscribers')
        .update({
          name: lead.name,
          lead_id: lead.id
        })
        .eq('email', lead.email)
        .eq('type', 'lead');
    } else {
      // Insert new subscriber
      await supabase
        .from('newsletter_subscribers')
        .insert({
          email: lead.email,
          name: lead.name,
          type: 'lead',
          lead_id: lead.id,
          status: 'subscribed'
        });
    }
  }
}

async function syncVendors() {
  // Get all vendors with email
  const { data: vendors, error: vendorsError } = await supabase
    .from('vendors')
    .select('id, name, email')
    .not('email', 'is', null);
    
  if (vendorsError) throw vendorsError;
  
  // Get existing vendor subscribers
  const { data: existingSubscribers, error: subscribersError } = await supabase
    .from('newsletter_subscribers')
    .select('email, vendor_id')
    .eq('type', 'vendor');
    
  if (subscribersError) throw subscribersError;
  
  // Create a map of existing subscribers by email
  const existingSubscribersByEmail = new Map();
  existingSubscribers?.forEach(sub => {
    existingSubscribersByEmail.set(sub.email, sub.vendor_id);
  });
  
  // Find vendors that need to be added or updated
  const vendorsToSync = vendors?.filter(vendor => 
    vendor.email && (!existingSubscribersByEmail.has(vendor.email) || existingSubscribersByEmail.get(vendor.email) !== vendor.id)
  );
  
  // Insert or update subscribers
  for (const vendor of vendorsToSync || []) {
    if (existingSubscribersByEmail.has(vendor.email)) {
      // Update existing subscriber
      await supabase
        .from('newsletter_subscribers')
        .update({
          name: vendor.name,
          vendor_id: vendor.id
        })
        .eq('email', vendor.email)
        .eq('type', 'vendor');
    } else {
      // Insert new subscriber
      await supabase
        .from('newsletter_subscribers')
        .insert({
          email: vendor.email,
          name: vendor.name,
          type: 'vendor',
          vendor_id: vendor.id,
          status: 'subscribed'
        });
    }
  }
}

async function syncVenues() {
  // Get all venues with email
  const { data: venues, error: venuesError } = await supabase
    .from('venues')
    .select('id, name, contact_email')
    .not('contact_email', 'is', null);
    
  if (venuesError) throw venuesError;
  
  // Get existing venue subscribers
  const { data: existingSubscribers, error: subscribersError } = await supabase
    .from('newsletter_subscribers')
    .select('email, venue_id')
    .eq('type', 'venue');
    
  if (subscribersError) throw subscribersError;
  
  // Create a map of existing subscribers by email
  const existingSubscribersByEmail = new Map();
  existingSubscribers?.forEach(sub => {
    existingSubscribersByEmail.set(sub.email, sub.venue_id);
  });
  
  // Find venues that need to be added or updated
  const venuesToSync = venues?.filter(venue => 
    venue.contact_email && (!existingSubscribersByEmail.has(venue.contact_email) || existingSubscribersByEmail.get(venue.contact_email) !== venue.id)
  );
  
  // Insert or update subscribers
  for (const venue of venuesToSync || []) {
    if (existingSubscribersByEmail.has(venue.contact_email)) {
      // Update existing subscriber
      await supabase
        .from('newsletter_subscribers')
        .update({
          name: venue.name,
          venue_id: venue.id
        })
        .eq('email', venue.contact_email)
        .eq('type', 'venue');
    } else {
      // Insert new subscriber
      await supabase
        .from('newsletter_subscribers')
        .insert({
          email: venue.contact_email,
          name: venue.name,
          type: 'venue',
          venue_id: venue.id,
          status: 'subscribed'
        });
    }
  }
}