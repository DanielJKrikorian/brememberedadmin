/*
  # Add hourly pricing tiers to services

  1. New Tables
    - `service_hourly_rates`
      - `id` (uuid, primary key)
      - `service_id` (uuid, references services)
      - `hour` (integer)
      - `price` (numeric)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

CREATE TABLE service_hourly_rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id uuid REFERENCES services(id) ON DELETE CASCADE NOT NULL,
  hour integer NOT NULL CHECK (hour > 0),
  price numeric NOT NULL CHECK (price >= 0),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE (service_id, hour)
);

ALTER TABLE service_hourly_rates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Team members can manage hourly rates"
  ON service_hourly_rates
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE TRIGGER update_service_hourly_rates_updated_at
  BEFORE UPDATE ON service_hourly_rates
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();