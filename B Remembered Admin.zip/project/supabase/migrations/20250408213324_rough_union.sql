/*
  # Cloud Storage System for Vendors and Couples

  1. New Tables
    - `storage_plans` - Defines different storage tiers with pricing
    - `vendor_storage_subscriptions` - Tracks vendor subscriptions to storage plans
    - `storage_folders` - Stores folder information
    - `storage_files` - Stores file metadata
    - `folder_shares` - Manages folder sharing between vendors and couples
    - `couple_storage_subscriptions` - Tracks couple subscriptions to shared folders

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data

  3. Changes
    - Add storage-related fields to vendors table
*/

-- Create storage plans table
CREATE TABLE IF NOT EXISTS storage_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  storage_limit bigint NOT NULL, -- in bytes
  price_monthly numeric NOT NULL CHECK (price_monthly >= 0),
  price_yearly numeric NOT NULL CHECK (price_yearly >= 0),
  is_active boolean DEFAULT true,
  features jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create vendor storage subscriptions table
CREATE TABLE IF NOT EXISTS vendor_storage_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id uuid NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
  plan_id uuid NOT NULL REFERENCES storage_plans(id),
  status text NOT NULL CHECK (status IN ('active', 'canceled', 'expired')),
  storage_used bigint DEFAULT 0, -- in bytes
  billing_cycle text NOT NULL CHECK (billing_cycle IN ('monthly', 'yearly')),
  current_period_start timestamptz NOT NULL,
  current_period_end timestamptz NOT NULL,
  stripe_subscription_id text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create storage folders table
CREATE TABLE IF NOT EXISTS storage_folders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id uuid NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  parent_folder_id uuid REFERENCES storage_folders(id) ON DELETE CASCADE,
  path text NOT NULL,
  is_shared boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create storage files table
CREATE TABLE IF NOT EXISTS storage_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  folder_id uuid NOT NULL REFERENCES storage_folders(id) ON DELETE CASCADE,
  vendor_id uuid NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  file_type text NOT NULL,
  file_size bigint NOT NULL, -- in bytes
  storage_path text NOT NULL,
  public_url text,
  uploaded_by uuid REFERENCES team_members(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create folder shares table
CREATE TABLE IF NOT EXISTS folder_shares (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  folder_id uuid NOT NULL REFERENCES storage_folders(id) ON DELETE CASCADE,
  lead_id uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  access_level text NOT NULL CHECK (access_level IN ('view', 'download', 'upload')),
  status text NOT NULL CHECK (status IN ('pending', 'active', 'expired')),
  expiration_date timestamptz,
  access_code text,
  price_monthly numeric DEFAULT 0 CHECK (price_monthly >= 0),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(folder_id, lead_id)
);

-- Create couple storage subscriptions table
CREATE TABLE IF NOT EXISTS couple_storage_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  folder_share_id uuid NOT NULL REFERENCES folder_shares(id) ON DELETE CASCADE,
  status text NOT NULL CHECK (status IN ('active', 'canceled', 'expired')),
  billing_cycle text NOT NULL CHECK (billing_cycle IN ('monthly', 'yearly')),
  current_period_start timestamptz NOT NULL,
  current_period_end timestamptz NOT NULL,
  stripe_subscription_id text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add storage-related fields to vendors table
ALTER TABLE vendors ADD COLUMN IF NOT EXISTS storage_enabled boolean DEFAULT false;

-- Enable RLS on all tables
ALTER TABLE storage_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE vendor_storage_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE storage_folders ENABLE ROW LEVEL SECURITY;
ALTER TABLE storage_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE folder_shares ENABLE ROW LEVEL SECURITY;
ALTER TABLE couple_storage_subscriptions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Team members can manage storage plans"
  ON storage_plans
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage vendor storage subscriptions"
  ON vendor_storage_subscriptions
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage storage folders"
  ON storage_folders
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage storage files"
  ON storage_files
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage folder shares"
  ON folder_shares
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage couple storage subscriptions"
  ON couple_storage_subscriptions
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create triggers for updated_at
CREATE TRIGGER update_storage_plans_updated_at
BEFORE UPDATE ON storage_plans
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_vendor_storage_subscriptions_updated_at
BEFORE UPDATE ON vendor_storage_subscriptions
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_storage_folders_updated_at
BEFORE UPDATE ON storage_folders
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_storage_files_updated_at
BEFORE UPDATE ON storage_files
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_folder_shares_updated_at
BEFORE UPDATE ON folder_shares
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_couple_storage_subscriptions_updated_at
BEFORE UPDATE ON couple_storage_subscriptions
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS vendor_storage_subscriptions_vendor_id_idx ON vendor_storage_subscriptions(vendor_id);
CREATE INDEX IF NOT EXISTS storage_folders_vendor_id_idx ON storage_folders(vendor_id);
CREATE INDEX IF NOT EXISTS storage_folders_parent_folder_id_idx ON storage_folders(parent_folder_id);
CREATE INDEX IF NOT EXISTS storage_files_folder_id_idx ON storage_files(folder_id);
CREATE INDEX IF NOT EXISTS storage_files_vendor_id_idx ON storage_files(vendor_id);
CREATE INDEX IF NOT EXISTS folder_shares_folder_id_idx ON folder_shares(folder_id);
CREATE INDEX IF NOT EXISTS folder_shares_lead_id_idx ON folder_shares(lead_id);
CREATE INDEX IF NOT EXISTS couple_storage_subscriptions_lead_id_idx ON couple_storage_subscriptions(lead_id);
CREATE INDEX IF NOT EXISTS couple_storage_subscriptions_folder_share_id_idx ON couple_storage_subscriptions(folder_share_id);

-- Insert default storage plans
INSERT INTO storage_plans (name, description, storage_limit, price_monthly, price_yearly, features)
VALUES 
  ('Basic', '5GB storage for small vendors', 5368709120, 9.99, 99.99, '{"max_folders": 10, "max_shares": 5}'),
  ('Professional', '25GB storage for growing businesses', 26843545600, 19.99, 199.99, '{"max_folders": 50, "max_shares": 20}'),
  ('Enterprise', '100GB storage for established studios', 107374182400, 49.99, 499.99, '{"max_folders": 100, "max_shares": 50}');