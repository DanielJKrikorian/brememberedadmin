-- Add payment-related fields to rental_bookings table
DO $$ 
BEGIN
  -- Add payment_link column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'rental_bookings' 
    AND column_name = 'payment_link'
  ) THEN
    ALTER TABLE rental_bookings ADD COLUMN payment_link text;
  END IF;

  -- Add payment_status column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'rental_bookings' 
    AND column_name = 'payment_status'
  ) THEN
    ALTER TABLE rental_bookings ADD COLUMN payment_status text CHECK (payment_status IN ('unpaid', 'paid', 'partial'));
  END IF;

  -- Add payment_id column if it doesn't exist (for Stripe payment ID)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'rental_bookings' 
    AND column_name = 'payment_id'
  ) THEN
    ALTER TABLE rental_bookings ADD COLUMN payment_id text;
  END IF;

  -- Add subscription_id column if it doesn't exist (for Stripe subscription ID)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'rental_bookings' 
    AND column_name = 'subscription_id'
  ) THEN
    ALTER TABLE rental_bookings ADD COLUMN subscription_id text;
  END IF;
END $$;