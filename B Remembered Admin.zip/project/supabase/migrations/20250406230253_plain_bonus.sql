/*
  # Create storage bucket for user assets

  1. New Storage Bucket
    - `user-assets` bucket for storing user-related files
      - Profile images
      - Other user uploads
  
  2. Security
    - Enable public access for reading files
    - Restrict uploads to authenticated users
    - Users can only update/delete their own files
*/

-- Enable storage by creating the storage schema if it doesn't exist
create schema if not exists storage;

-- Create the storage bucket
insert into storage.buckets (id, name, public)
values ('user-assets', 'user-assets', true)
on conflict (id) do nothing;

-- Set up security policies
create policy "Public profiles are viewable by everyone"
on storage.objects for select
using ( bucket_id = 'user-assets' );

create policy "Users can upload their own profile images"
on storage.objects for insert
with check (
  bucket_id = 'user-assets'
  and auth.role() = 'authenticated'
  and (storage.foldername(name))[1] = 'profile-images'
  and (storage.foldername(name))[2] = auth.uid()::text
);

create policy "Users can update their own profile images"
on storage.objects for update
using (
  bucket_id = 'user-assets'
  and auth.role() = 'authenticated'
  and (storage.foldername(name))[1] = 'profile-images'
  and (storage.foldername(name))[2] = auth.uid()::text
)
with check (
  bucket_id = 'user-assets'
  and auth.role() = 'authenticated'
  and (storage.foldername(name))[1] = 'profile-images'
  and (storage.foldername(name))[2] = auth.uid()::text
);

create policy "Users can delete their own profile images"
on storage.objects for delete
using (
  bucket_id = 'user-assets'
  and auth.role() = 'authenticated'
  and (storage.foldername(name))[1] = 'profile-images'
  and (storage.foldername(name))[2] = auth.uid()::text
);