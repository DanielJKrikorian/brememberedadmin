/*
  # Add venue_id to bookings table

  1. Changes
    - Add venue_id column to bookings table
    - Add foreign key constraint to venues table

  2. Security
    - No changes to RLS policies needed
*/

ALTER TABLE bookings
ADD COLUMN venue_id uuid REFERENCES venues(id);