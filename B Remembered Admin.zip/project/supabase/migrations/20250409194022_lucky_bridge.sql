/*
  # Email and SMS Templates System

  1. New Tables
    - `email_templates` - Stores email and SMS templates
      - `id` (uuid, primary key)
      - `name` (text, not null)
      - `subject` (text)
      - `content` (text, not null)
      - `type` (text, not null) - 'email' or 'sms'
      - `category` (text, not null)
      - `variables` (text[], not null)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
  
  2. Security
    - Enable RLS on `email_templates` table
    - Add policy for authenticated users to manage templates
*/

-- Create email_templates table
CREATE TABLE IF NOT EXISTS email_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  subject text,
  content text NOT NULL,
  type text NOT NULL CHECK (type IN ('email', 'sms')),
  category text NOT NULL DEFAULT 'general',
  variables text[] DEFAULT '{}'::text[],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE email_templates ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Team members can manage email templates"
  ON email_templates
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create trigger for updated_at
CREATE TRIGGER update_email_templates_updated_at
  BEFORE UPDATE ON email_templates
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Insert default templates
INSERT INTO email_templates (name, subject, content, type, category, variables)
VALUES 
  ('Welcome Email', 'Welcome to B. Remembered Weddings', 
   '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="text-align: center; margin-bottom: 30px;">
        <img src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png" alt="B. Remembered Logo" style="max-width: 200px; height: auto;">
      </div>
      <h1 style="color: #333333; font-size: 24px; margin-bottom: 20px;">Welcome, {{name}}!</h1>
      <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">Thank you for joining B. Remembered Weddings. We''re excited to help make your special day unforgettable.</p>
      <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">If you have any questions, please don''t hesitate to reach out to our team.</p>
      <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eeeeee;">
        <p style="font-size: 14px; color: #777777;">© 2025 B. Remembered Weddings. All rights reserved.</p>
      </div>
    </div>', 
   'email', 'welcome', ARRAY['name']),
   
  ('Quote Notification', 'Your Quote from B. Remembered Weddings', 
   '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="text-align: center; margin-bottom: 30px;">
        <img src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png" alt="B. Remembered Logo" style="max-width: 200px; height: auto;">
      </div>
      <h1 style="color: #333333; font-size: 24px; margin-bottom: 20px;">Hello, {{name}}!</h1>
      <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">Your quote from B. Remembered Weddings is ready to view.</p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="{{quote_link}}" style="display: inline-block; background-color: #9e8a78; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-size: 16px;">View Your Quote</a>
      </div>
      <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">If you have any questions, please don''t hesitate to contact us.</p>
      <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eeeeee;">
        <p style="font-size: 14px; color: #777777;">© 2025 B. Remembered Weddings. All rights reserved.</p>
      </div>
    </div>', 
   'email', 'quote', ARRAY['name', 'quote_link']),
   
  ('Booking Confirmation', 'Your Booking Confirmation', 
   '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="text-align: center; margin-bottom: 30px;">
        <img src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png" alt="B. Remembered Logo" style="max-width: 200px; height: auto;">
      </div>
      <h1 style="color: #333333; font-size: 24px; margin-bottom: 20px;">Booking Confirmation</h1>
      <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">Dear {{name}},</p>
      <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">Your booking for {{service_name}} on {{event_date}} has been confirmed.</p>
      <div style="background-color: #f8f8f8; padding: 20px; border-radius: 5px; margin-bottom: 20px;">
        <h2 style="font-size: 18px; margin-bottom: 15px;">Booking Details</h2>
        <p style="margin-bottom: 10px; font-size: 16px;"><strong>Service:</strong> {{service_name}}</p>
        <p style="margin-bottom: 10px; font-size: 16px;"><strong>Date:</strong> {{event_date}}</p>
        <p style="margin-bottom: 10px; font-size: 16px;"><strong>Venue:</strong> {{venue_name}}</p>
      </div>
      <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">If you have any questions or need to make changes, please contact us.</p>
      <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eeeeee;">
        <p style="font-size: 14px; color: #777777;">© 2025 B. Remembered Weddings. All rights reserved.</p>
      </div>
    </div>', 
   'email', 'booking', ARRAY['name', 'service_name', 'event_date', 'venue_name']),
   
  ('Appointment Reminder', 'Reminder: Your Upcoming Appointment', 
   '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="text-align: center; margin-bottom: 30px;">
        <img src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png" alt="B. Remembered Logo" style="max-width: 200px; height: auto;">
      </div>
      <h1 style="color: #333333; font-size: 24px; margin-bottom: 20px;">Appointment Reminder</h1>
      <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">Hello {{name}},</p>
      <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">This is a friendly reminder about your upcoming appointment on {{appointment_date}} at {{appointment_time}}.</p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="{{calendar_link}}" style="display: inline-block; background-color: #9e8a78; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-size: 16px;">Add to Calendar</a>
      </div>
      <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">If you need to reschedule, please contact us as soon as possible.</p>
      <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eeeeee;">
        <p style="font-size: 14px; color: #777777;">© 2025 B. Remembered Weddings. All rights reserved.</p>
      </div>
    </div>', 
   'email', 'reminder', ARRAY['name', 'appointment_date', 'appointment_time', 'calendar_link']);

-- Insert SMS templates separately to avoid column count mismatch
INSERT INTO email_templates (name, subject, content, type, category, variables)
VALUES
  ('Booking Reminder SMS', NULL, 'Reminder: Your appointment with B. Remembered Weddings is tomorrow at {{time}}. Reply Y to confirm or call us to reschedule.', 
   'sms', 'reminder', ARRAY['time']),
   
  ('Quote Follow-up SMS', NULL, 'Hi {{name}}, just following up on the quote we sent for your {{event_type}}. Let us know if you have any questions!', 
   'sms', 'follow-up', ARRAY['name', 'event_type']);