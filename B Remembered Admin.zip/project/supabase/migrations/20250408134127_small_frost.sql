/*
  # Create revenues table

  1. New Tables
    - `revenues`
      - `id` (uuid, primary key)
      - `amount` (numeric, not null)
      - `date` (date, not null)
      - `description` (text)
      - `source` (text, not null)
      - `created_at` (timestamptz, default now())
  2. Security
    - Enable RLS on `revenues` table
    - Add policy for authenticated users to manage revenues
*/

CREATE TABLE IF NOT EXISTS revenues (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  amount numeric NOT NULL CHECK (amount >= 0),
  date date NOT NULL,
  description text,
  source text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE revenues ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Team members can manage revenues"
  ON revenues
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Add trigger to update finance metrics when revenues change
CREATE OR REPLACE FUNCTION update_finance_metrics()
RETURNS TRIGGER AS $$
BEGIN
  -- Logic to update finance metrics could be added here
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_finance_metrics_on_revenue_change
AFTER INSERT OR UPDATE OR DELETE ON revenues
FOR EACH STATEMENT
EXECUTE FUNCTION update_finance_metrics();