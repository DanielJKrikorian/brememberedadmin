-- Create message_responses table
CREATE TABLE message_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid REFERENCES inbox_messages(id) NOT NULL,
  content text NOT NULL,
  type text NOT NULL CHECK (type IN ('email', 'sms', 'in_app')),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'failed')),
  sent_at timestamptz,
  error text,
  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES team_members(id) NOT NULL
);

-- Create indexes
CREATE INDEX message_responses_message_id_idx ON message_responses(message_id);
CREATE INDEX message_responses_created_by_idx ON message_responses(created_by);
CREATE INDEX message_responses_status_idx ON message_responses(status);
CREATE INDEX message_responses_type_idx ON message_responses(type);

-- Enable RLS
ALTER TABLE message_responses ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Team members can manage message responses"
  ON message_responses
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);