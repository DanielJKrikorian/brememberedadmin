/*
  # Add vendor media support

  1. New Tables
    - vendor_media
      - id (uuid, primary key)
      - vendor_id (uuid, references vendors)
      - type (text) - 'image' or 'video'
      - url (text)
      - thumbnail_url (text)
      - title (text)
      - description (text)
      - created_at (timestamptz)

  2. Security
    - Enable RLS on vendor_media table
    - Add policy for authenticated users to manage vendor media
*/

-- Create vendor media table
CREATE TABLE IF NOT EXISTS vendor_media (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id uuid REFERENCES vendors(id) ON DELETE CASCADE NOT NULL,
  type text NOT NULL CHECK (type IN ('image', 'video')),
  url text NOT NULL,
  thumbnail_url text,
  title text,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE vendor_media ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Team members can manage vendor media"
  ON vendor_media
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);