/*
  # Create service media storage bucket

  1. Changes
    - Create storage bucket for service media
    - Add storage policy for authenticated users
*/

-- Create the storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('service-media', 'service-media', true);

-- Allow authenticated users to upload files
CREATE POLICY "Authenticated users can upload service media"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'service-media'
);

-- Allow authenticated users to update files
CREATE POLICY "Authenticated users can update service media"
ON storage.objects
FOR UPDATE
TO authenticated
WITH CHECK (
  bucket_id = 'service-media'
);

-- Allow authenticated users to delete files
CREATE POLICY "Authenticated users can delete service media"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'service-media'
);

-- Allow public read access to files
CREATE POLICY "Public read access for service media"
ON storage.objects
FOR SELECT
TO public
USING (
  bucket_id = 'service-media'
);