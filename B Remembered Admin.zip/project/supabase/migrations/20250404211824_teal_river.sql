/*
  # Add Vendor Services and Variants Support

  1. New Tables
    - `vendor_services`
      - `id` (uuid, primary key)
      - `vendor_id` (uuid, references vendors)
      - `service_id` (uuid, references services)
      - `created_at` (timestamptz)

    - `vendor_service_variants`
      - `id` (uuid, primary key)
      - `vendor_id` (uuid, references vendors)
      - `variant_id` (uuid, references service_variants)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users
*/

-- Create vendor services table
CREATE TABLE vendor_services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id uuid REFERENCES vendors(id) ON DELETE CASCADE NOT NULL,
  service_id uuid REFERENCES services(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(vendor_id, service_id)
);

-- Create vendor service variants table
CREATE TABLE vendor_service_variants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id uuid REFERENCES vendors(id) ON DELETE CASCADE NOT NULL,
  variant_id uuid REFERENCES service_variants(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(vendor_id, variant_id)
);

-- Enable RLS
ALTER TABLE vendor_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE vendor_service_variants ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Team members can manage vendor services"
  ON vendor_services
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage vendor service variants"
  ON vendor_service_variants
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);