/*
  # Content Transfer System

  1. New Tables
    - `content_transfers`
      - `id` (uuid, primary key)
      - `recipient_email` (text, not null)
      - `recipient_phone` (text)
      - `subject` (text, not null)
      - `message` (text)
      - `expiration_date` (timestamptz, not null)
      - `access_code` (text, not null)
      - `notification_type` (text, not null)
      - `status` (text, not null)
      - `created_at` (timestamptz)
      - `created_by` (uuid, references team_members)
      - `views` (integer)
      - `downloads` (integer)
    
    - `transfer_files`
      - `id` (uuid, primary key)
      - `transfer_id` (uuid, references content_transfers)
      - `name` (text, not null)
      - `size` (bigint, not null)
      - `type` (text, not null)
      - `storage_path` (text, not null)
      - `public_url` (text)
      - `created_at` (timestamptz)
    
    - `transfer_notifications`
      - `id` (uuid, primary key)
      - `transfer_id` (uuid, references content_transfers)
      - `type` (text, not null)
      - `status` (text, not null)
      - `sent_at` (timestamptz)
      - `error` (text)
      - `created_at` (timestamptz)
  
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create content_transfers table
CREATE TABLE IF NOT EXISTS content_transfers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_email text NOT NULL,
  recipient_phone text,
  subject text NOT NULL,
  message text,
  expiration_date timestamptz NOT NULL,
  access_code text NOT NULL,
  notification_type text NOT NULL CHECK (notification_type IN ('email', 'sms', 'both')),
  status text NOT NULL CHECK (status IN ('active', 'expired', 'revoked')),
  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES team_members(id),
  views integer DEFAULT 0,
  downloads integer DEFAULT 0
);

-- Create transfer_files table
CREATE TABLE IF NOT EXISTS transfer_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transfer_id uuid NOT NULL REFERENCES content_transfers(id) ON DELETE CASCADE,
  name text NOT NULL,
  size bigint NOT NULL,
  type text NOT NULL,
  storage_path text NOT NULL,
  public_url text,
  created_at timestamptz DEFAULT now()
);

-- Create transfer_notifications table
CREATE TABLE IF NOT EXISTS transfer_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transfer_id uuid NOT NULL REFERENCES content_transfers(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('email', 'sms')),
  status text NOT NULL CHECK (status IN ('pending', 'sent', 'failed')),
  sent_at timestamptz,
  error text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE content_transfers ENABLE ROW LEVEL SECURITY;
ALTER TABLE transfer_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE transfer_notifications ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Team members can manage content transfers"
  ON content_transfers
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage transfer files"
  ON transfer_files
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage transfer notifications"
  ON transfer_notifications
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS content_transfers_created_by_idx ON content_transfers(created_by);
CREATE INDEX IF NOT EXISTS content_transfers_status_idx ON content_transfers(status);
CREATE INDEX IF NOT EXISTS content_transfers_expiration_date_idx ON content_transfers(expiration_date);
CREATE INDEX IF NOT EXISTS transfer_files_transfer_id_idx ON transfer_files(transfer_id);
CREATE INDEX IF NOT EXISTS transfer_notifications_transfer_id_idx ON transfer_notifications(transfer_id);
CREATE INDEX IF NOT EXISTS transfer_notifications_status_idx ON transfer_notifications(status);

-- Create function to automatically expire transfers
CREATE OR REPLACE FUNCTION expire_content_transfers()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE content_transfers
  SET status = 'expired'
  WHERE expiration_date < NOW()
  AND status = 'active';
  
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to run the function periodically
CREATE OR REPLACE TRIGGER check_expired_transfers
AFTER INSERT OR UPDATE ON content_transfers
FOR EACH STATEMENT
EXECUTE FUNCTION expire_content_transfers();