/*
  # Add product images support

  1. New Tables
    - `product_images` - Stores multiple images for each product
      - `id` (uuid, primary key)
      - `product_id` (uuid, foreign key to products)
      - `url` (text)
      - `alt_text` (text)
      - `display_order` (integer)
      - `is_primary` (boolean)
      - `created_at` (timestamptz)
  
  2. Security
    - Enable RLS on `product_images` table
    - Add policy for authenticated users to manage product images
*/

-- Create product_images table
CREATE TABLE IF NOT EXISTS product_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  url text NOT NULL,
  alt_text text,
  display_order integer NOT NULL DEFAULT 0,
  is_primary boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create index on product_id for faster lookups
CREATE INDEX IF NOT EXISTS product_images_product_id_idx ON product_images(product_id);

-- Create index on is_primary for faster lookups
CREATE INDEX IF NOT EXISTS product_images_is_primary_idx ON product_images(is_primary);

-- Enable RLS
ALTER TABLE product_images ENABLE ROW LEVEL SECURITY;

-- Create policy for authenticated users
CREATE POLICY "Team members can manage product images"
  ON product_images
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create storage bucket for product images if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('product-images', 'product-images', true)
ON CONFLICT (id) DO NOTHING;

-- Set up security policies for product images bucket
CREATE POLICY "Public product images are viewable by everyone"
ON storage.objects FOR SELECT
USING (bucket_id = 'product-images');

CREATE POLICY "Team members can upload product images"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'product-images'
  AND auth.role() = 'authenticated'
);

CREATE POLICY "Team members can update product images"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'product-images'
  AND auth.role() = 'authenticated'
)
WITH CHECK (
  bucket_id = 'product-images'
  AND auth.role() = 'authenticated'
);

CREATE POLICY "Team members can delete product images"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'product-images'
  AND auth.role() = 'authenticated'
);