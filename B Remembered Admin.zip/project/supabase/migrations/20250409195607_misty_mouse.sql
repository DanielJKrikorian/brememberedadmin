/*
  # Add message logs table

  1. New Tables
    - `message_logs` - Stores logs of all sent messages
      - `id` (uuid, primary key)
      - `template_id` (uuid, references email_templates)
      - `recipient` (text, not null)
      - `type` (text, not null) - 'email' or 'sms'
      - `status` (text, not null) - 'sent' or 'failed'
      - `error_message` (text)
      - `external_message_id` (text)
      - `lead_id` (uuid, references leads)
      - `vendor_id` (uuid, references vendors)
      - `venue_id` (uuid, references venues)
      - `created_at` (timestamptz)
  
  2. Security
    - Enable RLS on `message_logs` table
    - Add policy for authenticated users to manage logs
*/

-- Create message_logs table
CREATE TABLE IF NOT EXISTS message_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id uuid REFERENCES email_templates(id),
  recipient text NOT NULL,
  type text NOT NULL CHECK (type IN ('email', 'sms')),
  status text NOT NULL CHECK (status IN ('sent', 'failed')),
  error_message text,
  external_message_id text,
  lead_id uuid REFERENCES leads(id),
  vendor_id uuid REFERENCES vendors(id),
  venue_id uuid REFERENCES venues(id),
  created_at timestamptz DEFAULT now()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS message_logs_template_id_idx ON message_logs(template_id);
CREATE INDEX IF NOT EXISTS message_logs_type_idx ON message_logs(type);
CREATE INDEX IF NOT EXISTS message_logs_status_idx ON message_logs(status);
CREATE INDEX IF NOT EXISTS message_logs_lead_id_idx ON message_logs(lead_id);
CREATE INDEX IF NOT EXISTS message_logs_vendor_id_idx ON message_logs(vendor_id);
CREATE INDEX IF NOT EXISTS message_logs_venue_id_idx ON message_logs(venue_id);
CREATE INDEX IF NOT EXISTS message_logs_created_at_idx ON message_logs(created_at);

-- Enable RLS
ALTER TABLE message_logs ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Team members can manage message logs"
  ON message_logs
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);