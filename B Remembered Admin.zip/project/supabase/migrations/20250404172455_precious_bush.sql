/*
  # Add services management tables

  1. New Tables
    - `services`
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text)
      - `base_price` (numeric)
      - `type` (text) - 'hourly' or 'package'
      - `min_hours` (integer) - for hourly services
      - `max_hours` (integer) - for hourly services
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `quote_services`
      - `id` (uuid, primary key)
      - `quote_id` (uuid, references quotes)
      - `service_id` (uuid, references services)
      - `quantity` (integer) - hours or packages
      - `start_time` (timestamptz)
      - `price` (numeric)
      - `notes` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users
*/

-- Create services table
CREATE TABLE services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  base_price numeric NOT NULL CHECK (base_price >= 0),
  type text NOT NULL CHECK (type IN ('hourly', 'package')),
  min_hours integer,
  max_hours integer,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_hours CHECK (
    (type = 'package' AND min_hours IS NULL AND max_hours IS NULL) OR
    (type = 'hourly' AND min_hours > 0 AND (max_hours IS NULL OR max_hours >= min_hours))
  )
);

-- Create quote services table
CREATE TABLE quote_services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  quote_id uuid REFERENCES quotes(id) NOT NULL,
  service_id uuid REFERENCES services(id) NOT NULL,
  quantity integer NOT NULL CHECK (quantity > 0),
  start_time timestamptz NOT NULL,
  price numeric NOT NULL CHECK (price >= 0),
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE quote_services ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Team members can manage services"
  ON services
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage quote services"
  ON quote_services
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create triggers for updated_at
CREATE TRIGGER update_services_updated_at
  BEFORE UPDATE ON services
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_quote_services_updated_at
  BEFORE UPDATE ON quote_services
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();