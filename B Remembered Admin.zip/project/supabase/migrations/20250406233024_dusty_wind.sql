/*
  # Add product categories support

  1. New Tables
    - `product_categories` - Stores product categories
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `description` (text)
      - `slug` (text, unique)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
  
  2. Security
    - Enable RLS on `product_categories` table
    - Add policy for authenticated users to manage product categories
*/

-- Create product_categories table
CREATE TABLE IF NOT EXISTS product_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  slug text UNIQUE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE product_categories ENABLE ROW LEVEL SECURITY;

-- Create policy for authenticated users
CREATE POLICY "Team members can manage product categories"
  ON product_categories
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Add updated_at trigger
CREATE TRIGGER update_product_categories_updated_at
  BEFORE UPDATE ON product_categories
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Insert some default categories
INSERT INTO product_categories (name, description, slug)
VALUES 
  ('Photography', 'Photography equipment and services', 'photography'),
  ('Decorations', 'Wedding and event decorations', 'decorations'),
  ('Attire', 'Wedding and formal attire', 'attire'),
  ('Stationery', 'Invitations and printed materials', 'stationery'),
  ('Gifts', 'Wedding gifts and favors', 'gifts'),
  ('Equipment', 'Event equipment and rentals', 'equipment'),
  ('Accessories', 'Wedding and event accessories', 'accessories'),
  ('Software', 'Digital tools and software', 'software')
ON CONFLICT (name) DO NOTHING;