/*
  # Add booking notes table

  1. New Tables
    - `booking_notes`
      - `id` (uuid, primary key)
      - `booking_id` (uuid, references bookings)
      - `content` (text)
      - `created_at` (timestamptz)
      - `created_by` (uuid, references team_members)

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

CREATE TABLE booking_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid REFERENCES bookings(id) ON DELETE CASCADE NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES team_members(id) NOT NULL
);

ALTER TABLE booking_notes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Team members can manage booking notes"
  ON booking_notes
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);