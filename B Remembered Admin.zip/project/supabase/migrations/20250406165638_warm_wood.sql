/*
  # Add visibility column to services

  1. Changes
    - Add visibility column to services table with default 'visible'
    - Add check constraint to ensure valid values
    - Update existing services to have 'visible' status

  2. Security
    - No changes to RLS policies needed
*/

-- Add visibility column with check constraint
ALTER TABLE services 
ADD COLUMN visibility text NOT NULL DEFAULT 'visible'
CHECK (visibility IN ('visible', 'hidden'));