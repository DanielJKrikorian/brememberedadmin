/*
  # Add Contracts System

  1. New Tables
    - `contracts`
      - `id` (uuid, primary key)
      - `name` (text)
      - `content` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `contract_templates`
      - `id` (uuid, primary key)
      - `name` (text)
      - `content` (text)
      - `service_id` (uuid, references services)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `signed_contracts`
      - `id` (uuid, primary key)
      - `contract_id` (uuid, references contracts)
      - `lead_id` (uuid, references leads)
      - `quote_id` (uuid, references quotes)
      - `signed_at` (timestamptz)
      - `signature` (text)
      - `ip_address` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create contracts table
CREATE TABLE contracts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create contract templates table
CREATE TABLE contract_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  content text NOT NULL,
  service_id uuid REFERENCES services(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create signed contracts table
CREATE TABLE signed_contracts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid REFERENCES contracts(id) NOT NULL,
  lead_id uuid REFERENCES leads(id) NOT NULL,
  quote_id uuid REFERENCES quotes(id) NOT NULL,
  signed_at timestamptz NOT NULL,
  signature text NOT NULL,
  ip_address text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE contract_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE signed_contracts ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Team members can manage contracts"
  ON contracts
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage contract templates"
  ON contract_templates
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage signed contracts"
  ON signed_contracts
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create triggers for updated_at
CREATE TRIGGER update_contracts_updated_at
  BEFORE UPDATE ON contracts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_contract_templates_updated_at
  BEFORE UPDATE ON contract_templates
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_signed_contracts_updated_at
  BEFORE UPDATE ON signed_contracts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();