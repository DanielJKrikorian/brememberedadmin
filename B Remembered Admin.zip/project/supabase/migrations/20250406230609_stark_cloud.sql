/*
  # Add profile image URL to team members

  1. Changes
    - Add `profile_image_url` column to `team_members` table to store profile image URLs
    
  2. Notes
    - Column is nullable since not all team members will have profile images
    - No default value is set as images are optional
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'team_members' 
    AND column_name = 'profile_image_url'
  ) THEN
    ALTER TABLE team_members ADD COLUMN profile_image_url text;
  END IF;
END $$;