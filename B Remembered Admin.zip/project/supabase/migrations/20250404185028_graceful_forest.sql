/*
  # Add job status automation

  1. Changes
    - Add trigger to automatically approve jobs when quote is paid and signed
    - Add function to handle job approval automation
*/

-- Create function to handle job approval
CREATE OR REPLACE FUNCTION handle_job_approval()
RETURNS TRIGGER AS $$
BEGIN
  -- Check if the quote has both payment and signature
  IF EXISTS (
    SELECT 1 FROM quotes q
    LEFT JOIN signed_contracts sc ON sc.quote_id = q.id
    WHERE q.id = NEW.quote_id
    AND q.status = 'paid'
    AND sc.id IS NOT NULL
  ) THEN
    -- Update any associated jobs to approved status
    UPDATE jobs
    SET status = 'approved'
    WHERE id IN (
      SELECT j.id
      FROM jobs j
      WHERE j.vendor_id = NEW.vendor_id
      AND j.status = 'pending'
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for signed contracts
CREATE TRIGGER job_approval_on_sign
AFTER INSERT ON signed_contracts
FOR EACH ROW
EXECUTE FUNCTION handle_job_approval();

-- Create trigger for quote payment
CREATE TRIGGER job_approval_on_payment
AFTER UPDATE OF status ON quotes
FOR EACH ROW
WHEN (NEW.status = 'paid')
EXECUTE FUNCTION handle_job_approval();