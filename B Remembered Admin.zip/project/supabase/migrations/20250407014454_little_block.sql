/*
  # Create community board tables

  1. New Tables
    - `community_boards` - Stores different community boards (couples, vendors)
    - `community_posts` - Stores posts made to community boards
    - `community_comments` - Stores comments on posts
    - `community_reactions` - Stores reactions to posts and comments
    - `community_attachments` - Stores files attached to posts and comments
  
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create community_boards table
CREATE TABLE IF NOT EXISTS community_boards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  type text NOT NULL CHECK (type IN ('couples', 'vendors', 'general')),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create community_posts table
CREATE TABLE IF NOT EXISTS community_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  board_id uuid NOT NULL REFERENCES community_boards(id) ON DELETE CASCADE,
  author_id uuid NOT NULL REFERENCES team_members(id),
  title text NOT NULL,
  content text NOT NULL,
  is_pinned boolean NOT NULL DEFAULT false,
  is_announcement boolean NOT NULL DEFAULT false,
  view_count integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create community_comments table
CREATE TABLE IF NOT EXISTS community_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES community_posts(id) ON DELETE CASCADE,
  parent_id uuid REFERENCES community_comments(id) ON DELETE CASCADE,
  author_id uuid NOT NULL REFERENCES team_members(id),
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create community_reactions table
CREATE TABLE IF NOT EXISTS community_reactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid REFERENCES community_posts(id) ON DELETE CASCADE,
  comment_id uuid REFERENCES community_comments(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES team_members(id),
  reaction_type text NOT NULL CHECK (reaction_type IN ('like', 'love', 'haha', 'wow', 'sad', 'angry')),
  created_at timestamptz DEFAULT now(),
  CONSTRAINT reactions_target_check CHECK (
    (post_id IS NULL AND comment_id IS NOT NULL) OR
    (post_id IS NOT NULL AND comment_id IS NULL)
  ),
  UNIQUE (post_id, user_id, reaction_type),
  UNIQUE (comment_id, user_id, reaction_type)
);

-- Create community_attachments table
CREATE TABLE IF NOT EXISTS community_attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid REFERENCES community_posts(id) ON DELETE CASCADE,
  comment_id uuid REFERENCES community_comments(id) ON DELETE CASCADE,
  file_name text NOT NULL,
  file_type text NOT NULL,
  file_size integer NOT NULL,
  url text NOT NULL,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT attachments_target_check CHECK (
    (post_id IS NULL AND comment_id IS NOT NULL) OR
    (post_id IS NOT NULL AND comment_id IS NULL)
  )
);

-- Enable RLS on all tables
ALTER TABLE community_boards ENABLE ROW LEVEL SECURITY;
ALTER TABLE community_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE community_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE community_reactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE community_attachments ENABLE ROW LEVEL SECURITY;

-- Create policies for authenticated users
CREATE POLICY "Team members can read community boards"
  ON community_boards
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Team members can manage community boards"
  ON community_boards
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can read community posts"
  ON community_posts
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Team members can manage community posts"
  ON community_posts
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can read community comments"
  ON community_comments
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Team members can manage community comments"
  ON community_comments
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can read community reactions"
  ON community_reactions
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Team members can manage community reactions"
  ON community_reactions
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can read community attachments"
  ON community_attachments
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Team members can manage community attachments"
  ON community_attachments
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Add updated_at triggers
CREATE TRIGGER update_community_boards_updated_at
  BEFORE UPDATE ON community_boards
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_community_posts_updated_at
  BEFORE UPDATE ON community_posts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_community_comments_updated_at
  BEFORE UPDATE ON community_comments
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create storage bucket for community attachments
INSERT INTO storage.buckets (id, name, public)
VALUES ('community-attachments', 'community-attachments', true)
ON CONFLICT (id) DO NOTHING;

-- Set up security policies for community attachments bucket
CREATE POLICY "Public community attachments are viewable by everyone"
ON storage.objects FOR SELECT
USING (bucket_id = 'community-attachments');

CREATE POLICY "Team members can upload community attachments"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'community-attachments'
  AND auth.role() = 'authenticated'
);

CREATE POLICY "Team members can update community attachments"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'community-attachments'
  AND auth.role() = 'authenticated'
)
WITH CHECK (
  bucket_id = 'community-attachments'
  AND auth.role() = 'authenticated'
);

CREATE POLICY "Team members can delete community attachments"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'community-attachments'
  AND auth.role() = 'authenticated'
);

-- Insert default community boards
INSERT INTO community_boards (name, description, type)
VALUES 
  ('Couples Community', 'A place for couples to connect, share ideas, and ask questions', 'couples'),
  ('Vendor Network', 'A community for vendors to collaborate and share industry insights', 'vendors'),
  ('General Discussions', 'Open discussions for everyone', 'general')
ON CONFLICT DO NOTHING;