/*
  # Add Stripe Connect fields to vendors table

  1. Changes
    - Add Stripe Connect related fields to vendors table:
      - `stripe_account_id` (text)
      - `stripe_onboarding_complete` (boolean)
      - `stripe_onboarding_url` (text)

  2. Security
    - Maintain existing RLS policies
*/

ALTER TABLE vendors
ADD COLUMN stripe_account_id text,
ADD COLUMN stripe_onboarding_complete boolean DEFAULT false,
ADD COLUMN stripe_onboarding_url text;