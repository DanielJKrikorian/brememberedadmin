/*
  # Add attachments support for booking notes

  1. Changes
    - Create storage bucket for booking attachments
    - Add attachments table to track files
    - Add policies for authenticated users

  2. Security
    - Enable RLS on attachments table
    - Add storage policies for authenticated users
*/

-- Create the storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('booking-attachments', 'booking-attachments', true);

-- Create attachments table
CREATE TABLE booking_note_attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  note_id uuid REFERENCES booking_notes(id) ON DELETE CASCADE NOT NULL,
  file_name text NOT NULL,
  file_type text NOT NULL,
  file_size integer NOT NULL,
  url text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE booking_note_attachments ENABLE ROW LEVEL SECURITY;

-- Create policies for attachments table
CREATE POLICY "Team members can manage note attachments"
  ON booking_note_attachments
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Allow authenticated users to upload files
CREATE POLICY "Authenticated users can upload booking attachments"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'booking-attachments'
);

-- Allow authenticated users to update files
CREATE POLICY "Authenticated users can update booking attachments"
ON storage.objects
FOR UPDATE
TO authenticated
WITH CHECK (
  bucket_id = 'booking-attachments'
);

-- Allow authenticated users to delete files
CREATE POLICY "Authenticated users can delete booking attachments"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'booking-attachments'
);

-- Allow public read access to files
CREATE POLICY "Public read access for booking attachments"
ON storage.objects
FOR SELECT
TO public
USING (
  bucket_id = 'booking-attachments'
);