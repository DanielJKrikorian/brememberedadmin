/*
  # Initial Schema for B. Remembered Admin Dashboard

  1. New Tables
    - leads
      - id (uuid, primary key)
      - name (text)
      - email (text)
      - phone (text)
      - source (text)
      - status (text)
      - notes (text)
      - assigned_to (uuid, references team_members)
      - created_at (timestamptz)
      - updated_at (timestamptz)

    - bookings
      - id (uuid, primary key)
      - lead_id (uuid, references leads)
      - amount (numeric)
      - start_date (date)
      - end_date (date)
      - vendor_id (uuid, references vendors)
      - status (text)
      - created_at (timestamptz)
      - updated_at (timestamptz)

    - vendors
      - id (uuid, primary key)
      - name (text)
      - email (text)
      - phone (text)
      - status (text)
      - onboarding_notes (text)
      - rating (numeric)
      - approved (boolean)
      - created_at (timestamptz)
      - updated_at (timestamptz)

    - venues
      - id (uuid, primary key)
      - name (text)
      - address (text)
      - coi_url (text)
      - contact_name (text)
      - contact_email (text)
      - contact_phone (text)
      - created_at (timestamptz)
      - updated_at (timestamptz)

    - jobs
      - id (uuid, primary key)
      - title (text)
      - description (text)
      - requirements (text)
      - status (text)
      - venue_id (uuid, references venues)
      - date (date)
      - budget (numeric)
      - created_at (timestamptz)
      - updated_at (timestamptz)

    - team_members
      - id (uuid, primary key)
      - user_id (uuid, references auth.users)
      - name (text)
      - role (text)
      - created_at (timestamptz)
      - updated_at (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create tables
CREATE TABLE IF NOT EXISTS team_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  name text NOT NULL,
  role text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text,
  phone text,
  source text NOT NULL,
  status text NOT NULL DEFAULT 'new',
  notes text,
  assigned_to uuid REFERENCES team_members,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS vendors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text,
  status text NOT NULL DEFAULT 'pending',
  onboarding_notes text,
  rating numeric CHECK (rating >= 0 AND rating <= 5),
  approved boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS venues (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  address text NOT NULL,
  coi_url text,
  contact_name text,
  contact_email text,
  contact_phone text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid REFERENCES leads NOT NULL,
  amount numeric NOT NULL CHECK (amount >= 0),
  start_date date NOT NULL,
  end_date date NOT NULL,
  vendor_id uuid REFERENCES vendors,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  requirements text,
  status text NOT NULL DEFAULT 'open',
  venue_id uuid REFERENCES venues,
  date date NOT NULL,
  budget numeric CHECK (budget >= 0),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE team_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE vendors ENABLE ROW LEVEL SECURITY;
ALTER TABLE venues ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Team members can read all data" ON team_members
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Team members can read all leads" ON leads
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Team members can manage leads" ON leads
  FOR ALL TO authenticated USING (true);

CREATE POLICY "Team members can read all vendors" ON vendors
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Team members can manage vendors" ON vendors
  FOR ALL TO authenticated USING (true);

CREATE POLICY "Team members can read all venues" ON venues
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Team members can manage venues" ON venues
  FOR ALL TO authenticated USING (true);

CREATE POLICY "Team members can read all bookings" ON bookings
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Team members can manage bookings" ON bookings
  FOR ALL TO authenticated USING (true);

CREATE POLICY "Team members can read all jobs" ON jobs
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Team members can manage jobs" ON jobs
  FOR ALL TO authenticated USING (true);

-- Create functions for updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_team_members_updated_at
  BEFORE UPDATE ON team_members
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_leads_updated_at
  BEFORE UPDATE ON leads
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_vendors_updated_at
  BEFORE UPDATE ON vendors
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_venues_updated_at
  BEFORE UPDATE ON venues
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_bookings_updated_at
  BEFORE UPDATE ON bookings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_jobs_updated_at
  BEFORE UPDATE ON jobs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();