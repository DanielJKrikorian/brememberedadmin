/*
  # Add venue documents storage bucket

  1. Changes
    - Create storage bucket for venue documents
    - Add storage policies for authenticated users

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

-- Create the storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('venue-documents', 'venue-documents', true);

-- Allow authenticated users to upload files
CREATE POLICY "Authenticated users can upload venue documents"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'venue-documents'
);

-- Allow authenticated users to update files
CREATE POLICY "Authenticated users can update venue documents"
ON storage.objects
FOR UPDATE
TO authenticated
WITH CHECK (
  bucket_id = 'venue-documents'
);

-- Allow authenticated users to delete files
CREATE POLICY "Authenticated users can delete venue documents"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'venue-documents'
);

-- Allow public read access to files
CREATE POLICY "Public read access for venue documents"
ON storage.objects
FOR SELECT
TO public
USING (
  bucket_id = 'venue-documents'
);