/*
  # Add lead_date to leads table

  1. Changes
    - Add lead_date column to leads table
    - Default to created_at date for existing records
    - Make lead_date not nullable for future records
    - Add index for better query performance

  2. Security
    - No changes to RLS policies needed
*/

-- Add lead_date column
ALTER TABLE leads
ADD COLUMN IF NOT EXISTS lead_date date;

-- Update existing records to use created_at date
UPDATE leads
SET lead_date = created_at::date
WHERE lead_date IS NULL;

-- Make lead_date not nullable for future records
-- Split into two separate statements to avoid syntax error
ALTER TABLE leads
ALTER COLUMN lead_date SET NOT NULL;

ALTER TABLE leads
ALTER COLUMN lead_date SET DEFAULT CURRENT_DATE;

-- Add index for better performance
CREATE INDEX IF NOT EXISTS leads_lead_date_idx ON leads(lead_date);