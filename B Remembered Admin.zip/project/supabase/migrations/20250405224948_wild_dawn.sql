/*
  # Add booking_id to jobs table

  1. Changes
    - Add booking_id column to jobs table
    - Add foreign key constraint to bookings table
    - Add index for better query performance

  2. Security
    - No changes to RLS policies needed
*/

-- Add booking_id column
ALTER TABLE jobs
ADD COLUMN IF NOT EXISTS booking_id uuid REFERENCES bookings(id);

-- Add index for better performance
CREATE INDEX IF NOT EXISTS jobs_booking_id_idx ON jobs(booking_id);