/*
  # Add Vendor Background Check System

  1. New Tables
    - `vendor_background_checks`
      - `id` (uuid, primary key)
      - `vendor_id` (uuid, references vendors)
      - `status` (text, check: 'pending', 'approved', 'rejected')
      - `document_url` (text)
      - `notes` (text)
      - `submitted_at` (timestamptz)
      - `reviewed_at` (timestamptz)
      - `reviewed_by` (uuid, references team_members)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
  
  2. Security
    - Enable RLS on `vendor_background_checks` table
    - Add policy for authenticated users to manage background checks
*/

-- Create vendor background checks table
CREATE TABLE IF NOT EXISTS vendor_background_checks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id uuid NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
  status text NOT NULL CHECK (status IN ('pending', 'approved', 'rejected')),
  document_url text,
  notes text,
  submitted_at timestamptz DEFAULT now(),
  reviewed_at timestamptz,
  reviewed_by uuid REFERENCES team_members(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS vendor_background_checks_vendor_id_idx ON vendor_background_checks(vendor_id);
CREATE INDEX IF NOT EXISTS vendor_background_checks_status_idx ON vendor_background_checks(status);

-- Enable RLS
ALTER TABLE vendor_background_checks ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Team members can manage background checks"
  ON vendor_background_checks
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create trigger for updated_at
CREATE TRIGGER update_vendor_background_checks_updated_at
BEFORE UPDATE ON vendor_background_checks
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Add background_check_required column to vendors
ALTER TABLE vendors ADD COLUMN IF NOT EXISTS background_check_required boolean DEFAULT false;
ALTER TABLE vendors ADD COLUMN IF NOT EXISTS background_check_status text;