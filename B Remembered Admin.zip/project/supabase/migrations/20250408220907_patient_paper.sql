/*
  # Rental Shipping and Pickup Options

  1. New Columns
    - `rental_bookings`
      - `delivery_method` (text, not null) - Either 'pickup' or 'shipping'
      - `pickup_date` (timestamptz) - Date and time for pickup
      - `pickup_location` (text) - Location for pickup
      - `shipping_address` (text) - Address for shipping
      - `shipping_method` (text) - Method of shipping
      - `tracking_number` (text) - Tracking number for shipment
      - `tracking_url` (text) - URL to track shipment
      - `shipping_notes` (text) - Additional notes for shipping
  
  2. Security
    - Update constraints to validate delivery method
*/

-- Add new columns to rental_bookings table
ALTER TABLE rental_bookings ADD COLUMN IF NOT EXISTS delivery_method text DEFAULT 'pickup' NOT NULL;
ALTER TABLE rental_bookings ADD COLUMN IF NOT EXISTS pickup_date timestamptz;
ALTER TABLE rental_bookings ADD COLUMN IF NOT EXISTS pickup_location text;
ALTER TABLE rental_bookings ADD COLUMN IF NOT EXISTS shipping_address text;
ALTER TABLE rental_bookings ADD COLUMN IF NOT EXISTS shipping_method text;
ALTER TABLE rental_bookings ADD COLUMN IF NOT EXISTS tracking_number text;
ALTER TABLE rental_bookings ADD COLUMN IF NOT EXISTS tracking_url text;
ALTER TABLE rental_bookings ADD COLUMN IF NOT EXISTS shipping_notes text;

-- Add constraint to validate delivery method
ALTER TABLE rental_bookings ADD CONSTRAINT rental_bookings_delivery_method_check 
  CHECK (delivery_method IN ('pickup', 'shipping'));

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS rental_bookings_delivery_method_idx ON rental_bookings(delivery_method);
CREATE INDEX IF NOT EXISTS rental_bookings_pickup_date_idx ON rental_bookings(pickup_date);
CREATE INDEX IF NOT EXISTS rental_bookings_tracking_number_idx ON rental_bookings(tracking_number);

-- Add validation constraints
-- Pickup requires a date and location
ALTER TABLE rental_bookings ADD CONSTRAINT rental_bookings_pickup_validation
  CHECK (
    (delivery_method != 'pickup') OR 
    (delivery_method = 'pickup' AND pickup_date IS NOT NULL AND pickup_location IS NOT NULL)
  );

-- Shipping requires an address
ALTER TABLE rental_bookings ADD CONSTRAINT rental_bookings_shipping_validation
  CHECK (
    (delivery_method != 'shipping') OR 
    (delivery_method = 'shipping' AND shipping_address IS NOT NULL)
  );