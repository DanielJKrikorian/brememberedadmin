/*
  # Add partner name and wedding date to leads

  1. Changes
    - Add partner_name column to leads table
    - Add wedding_date column to leads table

  2. Security
    - Maintain existing RLS policies
*/

ALTER TABLE leads
ADD COLUMN partner_name text,
ADD COLUMN wedding_date date;