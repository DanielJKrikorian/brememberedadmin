/*
  # Add gallery feature to services

  1. New Tables
    - `service_media`
      - `id` (uuid, primary key)
      - `service_id` (uuid, references services)
      - `type` (text) - 'image' or 'video'
      - `url` (text)
      - `thumbnail_url` (text)
      - `title` (text)
      - `description` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

CREATE TABLE service_media (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id uuid REFERENCES services(id) ON DELETE CASCADE NOT NULL,
  type text NOT NULL CHECK (type IN ('image', 'video')),
  url text NOT NULL,
  thumbnail_url text,
  title text,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE service_media ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Team members can manage service media"
  ON service_media
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE TRIGGER update_service_media_updated_at
  BEFORE UPDATE ON service_media
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();