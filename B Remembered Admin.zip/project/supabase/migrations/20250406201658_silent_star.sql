/*
  # Create Discounts Schema

  1. New Tables
    - `discounts`
      - `id` (uuid, primary key)
      - `name` (text)
      - `code` (text, unique)
      - `type` ('percentage' | 'fixed')
      - `value` (numeric)
      - `description` (text)
      - `valid_from` (timestamptz)
      - `valid_until` (timestamptz)
      - `max_uses` (integer)
      - `used_count` (integer)
      - `status` ('active' | 'inactive')
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `discount_services`
      - Links discounts to specific services and variants
      - Null service_id means applies to all services

    - `discount_products`
      - Links discounts to specific products (for future use)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create updated_at trigger function if it doesn't exist
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create discounts table
CREATE TABLE IF NOT EXISTS discounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text UNIQUE NOT NULL,
  type text NOT NULL CHECK (type IN ('percentage', 'fixed')),
  value numeric NOT NULL CHECK (
    (type = 'percentage' AND value > 0 AND value <= 100) OR
    (type = 'fixed' AND value > 0)
  ),
  description text,
  valid_from timestamptz NOT NULL DEFAULT now(),
  valid_until timestamptz,
  max_uses integer,
  used_count integer DEFAULT 0,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create discount_services table
CREATE TABLE IF NOT EXISTS discount_services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  discount_id uuid NOT NULL REFERENCES discounts(id) ON DELETE CASCADE,
  service_id uuid REFERENCES services(id) ON DELETE CASCADE,
  variant_id uuid REFERENCES service_variants(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE (discount_id, service_id, variant_id)
);

-- Create discount_products table (for future use)
CREATE TABLE IF NOT EXISTS discount_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  discount_id uuid NOT NULL REFERENCES discounts(id) ON DELETE CASCADE,
  product_id uuid NOT NULL, -- Reference to future products table
  created_at timestamptz DEFAULT now(),
  UNIQUE (discount_id, product_id)
);

-- Enable RLS
ALTER TABLE discounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE discount_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE discount_products ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Team members can manage discounts"
  ON discounts
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage discount services"
  ON discount_services
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage discount products"
  ON discount_products
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Add updated_at triggers
CREATE TRIGGER update_discounts_updated_at
  BEFORE UPDATE ON discounts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();