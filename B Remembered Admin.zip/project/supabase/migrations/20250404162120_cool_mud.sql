/*
  # Add venue support to leads

  1. Changes
    - Add venue_id column to leads table (references venues)
    - Add venue_name and venue_address columns for cases where venue isn't in system yet

  2. Security
    - Maintain existing RLS policies
*/

ALTER TABLE leads
ADD COLUMN venue_id uuid REFERENCES venues(id),
ADD COLUMN venue_name text,
ADD COLUMN venue_address text;