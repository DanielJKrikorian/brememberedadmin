/*
  # Add display options to products table

  1. Changes
    - Add display_on_landing_page (boolean) to products table
    - Add display_on_couple_site (boolean) to products table
    - Add display_on_vendor_site (boolean) to products table
*/

DO $$ 
BEGIN
  -- Add display_on_landing_page column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'products' 
    AND column_name = 'display_on_landing_page'
  ) THEN
    ALTER TABLE products ADD COLUMN display_on_landing_page boolean DEFAULT false;
  END IF;

  -- Add display_on_couple_site column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'products' 
    AND column_name = 'display_on_couple_site'
  ) THEN
    ALTER TABLE products ADD COLUMN display_on_couple_site boolean DEFAULT false;
  END IF;

  -- Add display_on_vendor_site column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'products' 
    AND column_name = 'display_on_vendor_site'
  ) THEN
    ALTER TABLE products ADD COLUMN display_on_vendor_site boolean DEFAULT false;
  END IF;
END $$;