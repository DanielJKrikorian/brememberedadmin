/*
  # Create store tables for vendor products

  1. New Tables
    - `products` - Stores product information for the vendor store
      - `id` (uuid, primary key)
      - `name` (text, required)
      - `description` (text)
      - `price` (numeric, required)
      - `image_url` (text)
      - `stock` (integer, required)
      - `category` (text, required)
      - `status` (text, required) - 'active' or 'inactive'
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `orders` - Stores order information
      - `id` (uuid, primary key)
      - `vendor_id` (uuid, references vendors)
      - `status` (text, required) - 'pending', 'processing', 'shipped', 'delivered', 'cancelled'
      - `total_amount` (numeric, required)
      - `shipping_address` (text, required)
      - `tracking_number` (text)
      - `tracking_url` (text)
      - `notes` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `order_items` - Stores items in each order
      - `id` (uuid, primary key)
      - `order_id` (uuid, references orders)
      - `product_id` (uuid, references products)
      - `quantity` (integer, required)
      - `price` (numeric, required)
      - `created_at` (timestamptz)
    
    - `order_notifications` - Stores notifications sent for orders
      - `id` (uuid, primary key)
      - `order_id` (uuid, references orders)
      - `type` (text, required) - 'email', 'sms', 'in_app'
      - `content` (text, required)
      - `status` (text, required) - 'pending', 'sent', 'failed'
      - `sent_at` (timestamptz)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage all tables
*/

-- Create products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price numeric NOT NULL CHECK (price >= 0),
  image_url text,
  stock integer NOT NULL DEFAULT 0 CHECK (stock >= 0),
  category text NOT NULL,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id uuid NOT NULL REFERENCES vendors(id),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'shipped', 'delivered', 'cancelled')),
  total_amount numeric NOT NULL CHECK (total_amount >= 0),
  shipping_address text NOT NULL,
  tracking_number text,
  tracking_url text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create order_items table
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id),
  quantity integer NOT NULL CHECK (quantity > 0),
  price numeric NOT NULL CHECK (price >= 0),
  created_at timestamptz DEFAULT now()
);

-- Create order_notifications table
CREATE TABLE IF NOT EXISTS order_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('email', 'sms', 'in_app')),
  content text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'failed')),
  sent_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_notifications ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Team members can manage products"
  ON products
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage orders"
  ON orders
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage order items"
  ON order_items
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage order notifications"
  ON order_notifications
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Add updated_at triggers
CREATE TRIGGER update_products_updated_at
  BEFORE UPDATE ON products
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_orders_updated_at
  BEFORE UPDATE ON orders
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();