/*
  # Create rental equipment tables

  1. New Tables
    - `rental_items` - Stores rental equipment information
    - `rental_categories` - Categories for rental items
    - `rental_images` - Images for rental items
    - `rental_bookings` - Tracks rental bookings
    - `rental_rates` - Pricing for different rental durations

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create rental_categories table
CREATE TABLE IF NOT EXISTS rental_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  slug text UNIQUE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create rental_items table
CREATE TABLE IF NOT EXISTS rental_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  category_id uuid REFERENCES rental_categories(id),
  condition text NOT NULL DEFAULT 'good',
  status text NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'rented', 'maintenance', 'retired')),
  replacement_value numeric NOT NULL DEFAULT 0 CHECK (replacement_value >= 0),
  serial_number text,
  notes text,
  display_on_landing_page boolean DEFAULT false,
  display_on_couple_site boolean DEFAULT false,
  display_on_vendor_site boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create rental_rates table
CREATE TABLE IF NOT EXISTS rental_rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rental_item_id uuid NOT NULL REFERENCES rental_items(id) ON DELETE CASCADE,
  duration_type text NOT NULL CHECK (duration_type IN ('hourly', 'daily', 'weekly', 'monthly', 'yearly')),
  rate numeric NOT NULL CHECK (rate >= 0),
  minimum_duration integer NOT NULL DEFAULT 1 CHECK (minimum_duration >= 1),
  is_subscription boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE (rental_item_id, duration_type)
);

-- Create rental_images table
CREATE TABLE IF NOT EXISTS rental_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rental_item_id uuid NOT NULL REFERENCES rental_items(id) ON DELETE CASCADE,
  url text NOT NULL,
  alt_text text,
  display_order integer NOT NULL DEFAULT 0,
  is_primary boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create rental_bookings table
CREATE TABLE IF NOT EXISTS rental_bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rental_item_id uuid NOT NULL REFERENCES rental_items(id),
  lead_id uuid REFERENCES leads(id),
  vendor_id uuid REFERENCES vendors(id),
  start_date timestamptz NOT NULL,
  end_date timestamptz NOT NULL,
  duration_type text NOT NULL CHECK (duration_type IN ('hourly', 'daily', 'weekly', 'monthly', 'yearly')),
  rate numeric NOT NULL CHECK (rate >= 0),
  total_amount numeric NOT NULL CHECK (total_amount >= 0),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'active', 'completed', 'cancelled')),
  is_subscription boolean DEFAULT false,
  subscription_end_date timestamptz,
  deposit_amount numeric DEFAULT 0 CHECK (deposit_amount >= 0),
  deposit_paid boolean DEFAULT false,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create rental_booking_extensions table
CREATE TABLE IF NOT EXISTS rental_booking_extensions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rental_booking_id uuid NOT NULL REFERENCES rental_bookings(id) ON DELETE CASCADE,
  original_end_date timestamptz NOT NULL,
  new_end_date timestamptz NOT NULL,
  additional_amount numeric NOT NULL CHECK (additional_amount >= 0),
  reason text,
  created_at timestamptz DEFAULT now()
);

-- Create rental_damages table
CREATE TABLE IF NOT EXISTS rental_damages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rental_booking_id uuid NOT NULL REFERENCES rental_bookings(id) ON DELETE CASCADE,
  description text NOT NULL,
  repair_cost numeric CHECK (repair_cost >= 0),
  is_charged_to_customer boolean DEFAULT false,
  resolved boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create rental_maintenance table
CREATE TABLE IF NOT EXISTS rental_maintenance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rental_item_id uuid NOT NULL REFERENCES rental_items(id) ON DELETE CASCADE,
  maintenance_type text NOT NULL,
  description text NOT NULL,
  cost numeric DEFAULT 0 CHECK (cost >= 0),
  performed_by text,
  scheduled_date date,
  completed_date date,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE rental_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE rental_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE rental_rates ENABLE ROW LEVEL SECURITY;
ALTER TABLE rental_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE rental_bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE rental_booking_extensions ENABLE ROW LEVEL SECURITY;
ALTER TABLE rental_damages ENABLE ROW LEVEL SECURITY;
ALTER TABLE rental_maintenance ENABLE ROW LEVEL SECURITY;

-- Create policies for authenticated users
CREATE POLICY "Team members can manage rental categories"
  ON rental_categories
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage rental items"
  ON rental_items
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage rental rates"
  ON rental_rates
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage rental images"
  ON rental_images
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage rental bookings"
  ON rental_bookings
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage rental booking extensions"
  ON rental_booking_extensions
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage rental damages"
  ON rental_damages
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage rental maintenance"
  ON rental_maintenance
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Add updated_at triggers
CREATE TRIGGER update_rental_categories_updated_at
  BEFORE UPDATE ON rental_categories
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_rental_items_updated_at
  BEFORE UPDATE ON rental_items
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_rental_rates_updated_at
  BEFORE UPDATE ON rental_rates
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_rental_bookings_updated_at
  BEFORE UPDATE ON rental_bookings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_rental_damages_updated_at
  BEFORE UPDATE ON rental_damages
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_rental_maintenance_updated_at
  BEFORE UPDATE ON rental_maintenance
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create storage bucket for rental images
INSERT INTO storage.buckets (id, name, public)
VALUES ('rental-images', 'rental-images', true)
ON CONFLICT (id) DO NOTHING;

-- Set up security policies for rental images bucket
CREATE POLICY "Public rental images are viewable by everyone"
ON storage.objects FOR SELECT
USING (bucket_id = 'rental-images');

CREATE POLICY "Team members can upload rental images"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'rental-images'
  AND auth.role() = 'authenticated'
);

CREATE POLICY "Team members can update rental images"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'rental-images'
  AND auth.role() = 'authenticated'
)
WITH CHECK (
  bucket_id = 'rental-images'
  AND auth.role() = 'authenticated'
);

CREATE POLICY "Team members can delete rental images"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'rental-images'
  AND auth.role() = 'authenticated'
);

-- Insert some default rental categories
INSERT INTO rental_categories (name, description, slug)
VALUES 
  ('Audio Equipment', 'Speakers, microphones, and sound systems', 'audio-equipment'),
  ('Lighting', 'Event lighting and effects', 'lighting'),
  ('Furniture', 'Tables, chairs, and decor items', 'furniture'),
  ('Photography', 'Cameras, lenses, and photography equipment', 'photography'),
  ('Videography', 'Video cameras and recording equipment', 'videography'),
  ('Tents & Structures', 'Tents, canopies, and outdoor structures', 'tents-structures'),
  ('Decor', 'Decorative items and props', 'decor'),
  ('Transportation', 'Vehicles and transportation equipment', 'transportation')
ON CONFLICT (name) DO NOTHING;