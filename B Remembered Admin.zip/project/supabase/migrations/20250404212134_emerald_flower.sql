/*
  # Add vendor profile fields and media storage

  1. Changes
    - Add profile fields to vendors table:
      - `profile_image_url` (text)
      - `bio` (text)
      - `website` (text)
      - `instagram` (text)
      - `facebook` (text)

  2. Storage
    - Create vendor-media bucket for profile images and gallery
    - Add storage policies for authenticated users
*/

-- Add profile fields to vendors table
ALTER TABLE vendors
ADD COLUMN profile_image_url text,
ADD COLUMN bio text,
ADD COLUMN website text,
ADD COLUMN instagram text,
ADD COLUMN facebook text;

-- Create the storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('vendor-media', 'vendor-media', true);

-- Allow authenticated users to upload files
CREATE POLICY "Authenticated users can upload vendor media"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'vendor-media'
);

-- Allow authenticated users to update files
CREATE POLICY "Authenticated users can update vendor media"
ON storage.objects
FOR UPDATE
TO authenticated
WITH CHECK (
  bucket_id = 'vendor-media'
);

-- Allow authenticated users to delete files
CREATE POLICY "Authenticated users can delete vendor media"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'vendor-media'
);

-- Allow public read access to files
CREATE POLICY "Public read access for vendor media"
ON storage.objects
FOR SELECT
TO public
USING (
  bucket_id = 'vendor-media'
);