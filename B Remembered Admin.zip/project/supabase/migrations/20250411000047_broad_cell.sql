/*
  # Add custom packages flag to services table

  1. Changes
    - Add `allows_custom_packages` column to services table
    - Default to false for existing services

  2. Security
    - No changes to RLS policies needed
*/

-- Add allows_custom_packages column to services table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'services' 
    AND column_name = 'allows_custom_packages'
  ) THEN
    ALTER TABLE services ADD COLUMN allows_custom_packages boolean DEFAULT false;
  END IF;
END $$;