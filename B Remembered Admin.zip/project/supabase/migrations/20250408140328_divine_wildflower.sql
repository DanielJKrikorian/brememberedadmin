/*
  # Add account numbers to revenue sources and expense categories

  1. Changes
    - Add `account_number` column to `expense_categories` table
    - Add `account_number` column to `revenues` table
  2. Security
    - Maintain existing RLS policies
*/

-- Add account_number to expense_categories
ALTER TABLE expense_categories 
ADD COLUMN IF NOT EXISTS account_number text;

-- Add account_number to revenues
ALTER TABLE revenues 
ADD COLUMN IF NOT EXISTS account_number text;

-- Add index for faster lookups
CREATE INDEX IF NOT EXISTS expense_categories_account_number_idx 
ON expense_categories(account_number);

CREATE INDEX IF NOT EXISTS revenues_account_number_idx 
ON revenues(account_number);