/*
  # Add subscription frequency tracking
  
  1. Changes
    - Add subscription_frequency column to expenses table
    - Add subscription_next_date column to expenses table
    - Add check constraint to ensure valid frequency values
    - Add trigger to automatically update next_date based on frequency
  
  2. Notes
    - Frequencies: monthly, yearly
    - Next date is automatically calculated based on the date and frequency
    - Trigger maintains the next_date field
*/

-- Add subscription frequency columns
ALTER TABLE expenses
ADD COLUMN subscription_frequency text,
ADD COLUMN subscription_next_date date;

-- Add check constraint for valid frequencies
ALTER TABLE expenses
ADD CONSTRAINT valid_subscription_frequency
CHECK (subscription_frequency IN ('monthly', 'yearly'));

-- Create function to calculate next subscription date
CREATE OR REPLACE FUNCTION calculate_next_subscription_date()
RETURNS TRIGGER AS $$
BEGIN
  -- Only calculate next date for subscriptions
  IF NEW.is_subscription THEN
    -- Set initial next date if not set
    IF NEW.subscription_next_date IS NULL THEN
      CASE NEW.subscription_frequency
        WHEN 'monthly' THEN
          NEW.subscription_next_date := NEW.date + INTERVAL '1 month';
        WHEN 'yearly' THEN
          NEW.subscription_next_date := NEW.date + INTERVAL '1 year';
      END CASE;
    -- Update next date if frequency changes
    ELSIF NEW.subscription_frequency != OLD.subscription_frequency THEN
      CASE NEW.subscription_frequency
        WHEN 'monthly' THEN
          NEW.subscription_next_date := NEW.date + INTERVAL '1 month';
        WHEN 'yearly' THEN
          NEW.subscription_next_date := NEW.date + INTERVAL '1 year';
      END CASE;
    END IF;
  ELSE
    -- Clear next date if not a subscription
    NEW.subscription_next_date := NULL;
    NEW.subscription_frequency := NULL;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to maintain next_date
CREATE TRIGGER update_subscription_next_date
  BEFORE INSERT OR UPDATE ON expenses
  FOR EACH ROW
  EXECUTE FUNCTION calculate_next_subscription_date();