/*
  # Create quotes table and related functions

  1. New Tables
    - `quotes`
      - `id` (uuid, primary key)
      - `lead_id` (uuid, references leads)
      - `vendor_id` (uuid, references vendors)
      - `amount` (numeric)
      - `description` (text)
      - `status` (text)
      - `payment_link` (text)
      - `stripe_payment_id` (text)
      - `expires_at` (timestamptz)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `quotes` table
    - Add policies for authenticated users
*/

CREATE TABLE quotes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid REFERENCES leads(id) NOT NULL,
  vendor_id uuid REFERENCES vendors(id),
  amount numeric CHECK (amount >= 0) NOT NULL,
  description text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  payment_link text,
  stripe_payment_id text,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE quotes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Team members can manage quotes"
  ON quotes
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Update trigger for updated_at
CREATE TRIGGER update_quotes_updated_at
  BEFORE UPDATE ON quotes
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();