/*
  # Add Contract Reference to Quotes

  1. Changes
    - Add contract_id column to quotes table
    - Add foreign key constraint to contracts table

  2. Security
    - No changes to RLS policies needed
*/

ALTER TABLE quotes
ADD COLUMN contract_id uuid REFERENCES contracts(id);