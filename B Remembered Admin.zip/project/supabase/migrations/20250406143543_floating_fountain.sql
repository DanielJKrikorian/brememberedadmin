/*
  # Add service columns to jobs table

  1. Changes
    - Add service_id and variant_id columns to jobs table
    - Add foreign key constraints to services and service_variants tables
    - Add indexes for better performance

  2. Security
    - No changes to RLS policies
*/

-- Add service_id and variant_id columns
ALTER TABLE jobs
ADD COLUMN IF NOT EXISTS service_id uuid REFERENCES services(id),
ADD COLUMN IF NOT EXISTS variant_id uuid REFERENCES service_variants(id);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS jobs_service_id_idx ON jobs(service_id);
CREATE INDEX IF NOT EXISTS jobs_variant_id_idx ON jobs(variant_id);