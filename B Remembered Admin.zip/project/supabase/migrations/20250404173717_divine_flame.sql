/*
  # Add service variants support

  1. Changes
    - Remove hourly-specific fields from services table
    - Create new service_variants table
      - id (uuid, primary key)
      - service_id (uuid, references services)
      - name (text)
      - price (numeric)
      - hours (integer, optional)
      - description (text)
      - created_at (timestamptz)
      - updated_at (timestamptz)

  2. Security
    - Enable RLS on service_variants table
    - Add policy for authenticated users
*/

-- Remove hourly-specific fields from services table
ALTER TABLE services
DROP COLUMN type,
DROP COLUMN min_hours,
DROP COLUMN max_hours;

-- Drop hourly rates table since we're moving to variants
DROP TABLE service_hourly_rates;

-- Create service variants table
CREATE TABLE service_variants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id uuid REFERENCES services(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  price numeric NOT NULL CHECK (price >= 0),
  hours integer CHECK (hours > 0),
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE service_variants ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Team members can manage service variants"
  ON service_variants
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create trigger for updated_at
CREATE TRIGGER update_service_variants_updated_at
  BEFORE UPDATE ON service_variants
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Update quote_services table to reference variants
ALTER TABLE quote_services
ADD COLUMN variant_id uuid REFERENCES service_variants(id);