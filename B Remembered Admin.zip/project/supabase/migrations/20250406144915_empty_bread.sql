/*
  # Add expenses tracking

  1. New Tables
    - `expense_categories` - Stores expense category definitions
      - `id` (uuid, primary key)
      - `name` (text) - Category name
      - `description` (text) - Optional description
      - `is_subscription` (boolean) - Whether this is a recurring subscription
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `expenses` - Stores individual expenses
      - `id` (uuid, primary key)
      - `category_id` (uuid) - Reference to expense_categories
      - `amount` (numeric) - Expense amount
      - `date` (date) - When the expense occurred
      - `description` (text) - Optional description
      - `is_subscription` (boolean) - Whether this is a subscription payment
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users
*/

-- Create expense_categories table
CREATE TABLE expense_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  is_subscription boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create expenses table
CREATE TABLE expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES expense_categories(id) NOT NULL,
  amount numeric NOT NULL CHECK (amount >= 0),
  date date NOT NULL,
  description text,
  is_subscription boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add indexes
CREATE INDEX expenses_category_id_idx ON expenses(category_id);
CREATE INDEX expenses_date_idx ON expenses(date);

-- Enable RLS
ALTER TABLE expense_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Team members can manage expense categories"
  ON expense_categories
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage expenses"
  ON expenses
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Add update triggers for updated_at
CREATE TRIGGER update_expense_categories_updated_at
  BEFORE UPDATE ON expense_categories
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_expenses_updated_at
  BEFORE UPDATE ON expenses
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Insert default categories
INSERT INTO expense_categories (name, description, is_subscription) VALUES
  ('Marketing', 'Marketing and advertising expenses', false),
  ('Salary', 'Employee and contractor salaries', false),
  ('Taxes', 'Tax payments and related expenses', false),
  ('IT Software', 'Software subscriptions and licenses', true),
  ('IT Hardware', 'Computer hardware and equipment', false),
  ('Development', 'Software development costs', false),
  ('Other', 'Miscellaneous expenses', false);