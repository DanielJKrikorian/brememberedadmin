/*
  # Custom Service Packages

  1. New Tables
    - `custom_package_options` - Stores available options for custom packages
    - `custom_package_templates` - Predefined templates for custom packages
    - `custom_packages` - Stores customer-created custom packages
    - `custom_package_selections` - Stores the options selected for each custom package

  2. Changes
    - Add `accepts_custom_packages` flag to vendors table
    - Add `custom_package_id` to quotes table

  3. Security
    - Enable RLS on all new tables
    - Add policies for authenticated users
*/

-- Create table for custom package options
CREATE TABLE IF NOT EXISTS custom_package_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id uuid REFERENCES services(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  type text NOT NULL CHECK (type IN ('hour', 'addon', 'feature')),
  price numeric NOT NULL CHECK (price >= 0),
  is_required boolean DEFAULT false,
  min_quantity integer DEFAULT 1,
  max_quantity integer,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create table for custom package templates
CREATE TABLE IF NOT EXISTS custom_package_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id uuid REFERENCES services(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  base_price numeric NOT NULL CHECK (base_price >= 0),
  min_hours integer DEFAULT 1,
  max_hours integer,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create table for template options
CREATE TABLE IF NOT EXISTS custom_package_template_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id uuid REFERENCES custom_package_templates(id) ON DELETE CASCADE,
  option_id uuid REFERENCES custom_package_options(id) ON DELETE CASCADE,
  default_quantity integer DEFAULT 1,
  created_at timestamptz DEFAULT now()
);

-- Create table for custom packages
CREATE TABLE IF NOT EXISTS custom_packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid REFERENCES leads(id) ON DELETE CASCADE,
  service_id uuid REFERENCES services(id) ON DELETE CASCADE,
  template_id uuid REFERENCES custom_package_templates(id),
  name text NOT NULL,
  description text,
  hours integer NOT NULL,
  total_price numeric NOT NULL CHECK (total_price >= 0),
  status text NOT NULL CHECK (status IN ('draft', 'submitted', 'approved', 'rejected')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create table for custom package selections
CREATE TABLE IF NOT EXISTS custom_package_selections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  package_id uuid REFERENCES custom_packages(id) ON DELETE CASCADE,
  option_id uuid REFERENCES custom_package_options(id) ON DELETE CASCADE,
  quantity integer NOT NULL DEFAULT 1,
  price numeric NOT NULL CHECK (price >= 0),
  created_at timestamptz DEFAULT now()
);

-- Add accepts_custom_packages to vendors
ALTER TABLE vendors ADD COLUMN IF NOT EXISTS accepts_custom_packages boolean DEFAULT false;

-- Add custom_package_id to quotes
ALTER TABLE quotes ADD COLUMN IF NOT EXISTS custom_package_id uuid REFERENCES custom_packages(id);

-- Enable RLS on all tables
ALTER TABLE custom_package_options ENABLE ROW LEVEL SECURITY;
ALTER TABLE custom_package_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE custom_package_template_options ENABLE ROW LEVEL SECURITY;
ALTER TABLE custom_packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE custom_package_selections ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Team members can manage custom package options"
  ON custom_package_options
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage custom package templates"
  ON custom_package_templates
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage custom package template options"
  ON custom_package_template_options
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage custom packages"
  ON custom_packages
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage custom package selections"
  ON custom_package_selections
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create triggers for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_custom_package_options_updated_at
BEFORE UPDATE ON custom_package_options
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_custom_package_templates_updated_at
BEFORE UPDATE ON custom_package_templates
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_custom_packages_updated_at
BEFORE UPDATE ON custom_packages
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS custom_package_options_service_id_idx ON custom_package_options(service_id);
CREATE INDEX IF NOT EXISTS custom_package_templates_service_id_idx ON custom_package_templates(service_id);
CREATE INDEX IF NOT EXISTS custom_packages_lead_id_idx ON custom_packages(lead_id);
CREATE INDEX IF NOT EXISTS custom_packages_service_id_idx ON custom_packages(service_id);
CREATE INDEX IF NOT EXISTS custom_package_selections_package_id_idx ON custom_package_selections(package_id);