/*
  # Add payouts tracking

  1. New Tables
    - `payouts`
      - `id` (uuid, primary key)
      - `vendor_id` (uuid, references vendors)
      - `quote_id` (uuid, references quotes)
      - `amount` (numeric)
      - `status` (text)
      - `stripe_transfer_id` (text)
      - `description` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on payouts table
    - Add policy for authenticated users
*/

CREATE TABLE payouts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id uuid REFERENCES vendors(id) NOT NULL,
  quote_id uuid REFERENCES quotes(id),
  amount numeric CHECK (amount >= 0) NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  stripe_transfer_id text,
  description text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE payouts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Team members can manage payouts"
  ON payouts
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Update trigger for updated_at
CREATE TRIGGER update_payouts_updated_at
  BEFORE UPDATE ON payouts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();