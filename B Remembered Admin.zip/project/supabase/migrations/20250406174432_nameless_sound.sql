/*
  # Create inbox table for contact form submissions

  1. New Tables
    - `inbox_messages`
      - `id` (uuid, primary key)
      - `name` (text)
      - `email` (text)
      - `phone` (text)
      - `event_type` (text) - Wedding or Event
      - `event_date` (date)
      - `subject` (text)
      - `category` (text) - Service Question, Service Issue, Technical Question, Technical Issue, Inquiry, Other
      - `venue_id` (uuid, references venues)
      - `venue_name` (text)
      - `venue_address` (text)
      - `service_id` (uuid, references services)
      - `variant_id` (uuid, references service_variants)
      - `message` (text)
      - `status` (text) - New, Read, Archived
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
      - `converted_to_lead` (boolean)
      - `lead_id` (uuid, references leads)

  2. Security
    - Enable RLS on `inbox_messages` table
    - Add policy for authenticated users to manage messages

  3. Changes
    - Add indexes for better performance
    - Add check constraints for valid categories and status values
*/

-- Create inbox_messages table
CREATE TABLE inbox_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text,
  event_type text NOT NULL CHECK (event_type IN ('Wedding', 'Event')),
  event_date date,
  subject text NOT NULL,
  category text NOT NULL CHECK (
    category IN (
      'Service Question',
      'Service Issue',
      'Technical Question',
      'Technical Issue',
      'Inquiry',
      'Other'
    )
  ),
  venue_id uuid REFERENCES venues(id),
  venue_name text,
  venue_address text,
  service_id uuid REFERENCES services(id),
  variant_id uuid REFERENCES service_variants(id),
  message text NOT NULL,
  status text NOT NULL DEFAULT 'New' CHECK (
    status IN ('New', 'Read', 'Archived')
  ),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  converted_to_lead boolean DEFAULT false,
  lead_id uuid REFERENCES leads(id)
);

-- Create indexes
CREATE INDEX inbox_messages_status_idx ON inbox_messages(status);
CREATE INDEX inbox_messages_created_at_idx ON inbox_messages(created_at);
CREATE INDEX inbox_messages_event_date_idx ON inbox_messages(event_date);
CREATE INDEX inbox_messages_category_idx ON inbox_messages(category);
CREATE INDEX inbox_messages_venue_id_idx ON inbox_messages(venue_id);
CREATE INDEX inbox_messages_service_id_idx ON inbox_messages(service_id);
CREATE INDEX inbox_messages_variant_id_idx ON inbox_messages(variant_id);
CREATE INDEX inbox_messages_lead_id_idx ON inbox_messages(lead_id);

-- Enable RLS
ALTER TABLE inbox_messages ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Team members can manage inbox messages"
  ON inbox_messages
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Add update trigger for updated_at
CREATE TRIGGER update_inbox_messages_updated_at
  BEFORE UPDATE ON inbox_messages
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();