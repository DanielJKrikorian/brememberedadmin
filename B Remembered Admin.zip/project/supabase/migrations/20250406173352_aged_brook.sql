/*
  # Update blog posts status and scheduling

  1. Changes
    - Update status check constraint to include 'scheduled'
    - Add trigger for handling scheduled posts

  2. Security
    - No changes to RLS policies needed
*/

-- Update status check constraint to include 'scheduled'
DO $$ BEGIN
  ALTER TABLE blog_posts
  DROP CONSTRAINT blog_posts_status_check;
  EXCEPTION
    WHEN undefined_object THEN NULL;
END $$;

ALTER TABLE blog_posts
ADD CONSTRAINT blog_posts_status_check
  CHECK (status IN ('draft', 'scheduled', 'published', 'archived'));

-- Create function to handle scheduled publishing
CREATE OR REPLACE FUNCTION handle_scheduled_posts() RETURNS void AS $$
BEGIN
  -- Update posts that have reached their scheduled time
  UPDATE blog_posts
  SET 
    status = 'published',
    published_at = scheduled_for,
    scheduled_for = NULL
  WHERE 
    status = 'scheduled' 
    AND scheduled_for IS NOT NULL 
    AND scheduled_for <= CURRENT_TIMESTAMP;
END;
$$ LANGUAGE plpgsql;

-- Create a trigger to check scheduled posts on any blog_posts update
CREATE OR REPLACE FUNCTION check_scheduled_posts_trigger() RETURNS trigger AS $$
BEGIN
  PERFORM handle_scheduled_posts();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS check_scheduled_posts ON blog_posts;
CREATE TRIGGER check_scheduled_posts
  AFTER INSERT OR UPDATE ON blog_posts
  FOR EACH STATEMENT
  EXECUTE FUNCTION check_scheduled_posts_trigger();