/*
  # Add RLS policies for team members table

  1. Security Changes
    - Add policy to allow authenticated users to insert team members
    - Add policy to allow authenticated users to update their own team member records
    - Add policy to allow authenticated users to delete their own team member records

  Note: The select policy already exists from previous migrations
*/

-- Policy to allow authenticated users to insert team members
CREATE POLICY "Team members can create team member records"
ON public.team_members
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Policy to allow authenticated users to update their own team member records
CREATE POLICY "Team members can update own records"
ON public.team_members
FOR UPDATE
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Policy to allow authenticated users to delete their own team member records
CREATE POLICY "Team members can delete own records"
ON public.team_members
FOR DELETE
TO authenticated
USING (auth.uid() = user_id);