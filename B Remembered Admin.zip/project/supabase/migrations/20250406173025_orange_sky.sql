/*
  # Add Blog Post Scheduling

  1. Changes
    - Add `scheduled_for` column to blog_posts table
    - Add function to handle scheduled publishing
    - Add index for better performance

  2. Security
    - No changes to RLS policies needed
*/

-- Add scheduled_for column
ALTER TABLE blog_posts
ADD COLUMN scheduled_for timestamptz;

-- Create function to handle scheduled publishing
CREATE OR REPLACE FUNCTION handle_scheduled_posts() RETURNS void AS $$
BEGIN
  -- Update posts that have reached their scheduled time
  UPDATE blog_posts
  SET 
    status = 'published',
    published_at = scheduled_for,
    scheduled_for = NULL
  WHERE 
    status = 'draft' 
    AND scheduled_for IS NOT NULL 
    AND scheduled_for <= CURRENT_TIMESTAMP;
END;
$$ LANGUAGE plpgsql;

-- Add index for better performance
CREATE INDEX blog_posts_scheduled_for_idx ON blog_posts(scheduled_for);

-- Create a trigger to check scheduled posts on any blog_posts update
CREATE OR REPLACE FUNCTION check_scheduled_posts_trigger() RETURNS trigger AS $$
BEGIN
  PERFORM handle_scheduled_posts();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER check_scheduled_posts
  AFTER INSERT OR UPDATE ON blog_posts
  FOR EACH STATEMENT
  EXECUTE FUNCTION check_scheduled_posts_trigger();