/*
  # Add service and variant references to bookings

  1. Changes
    - Add service_id and variant_id columns to bookings table
    - Add notes column to bookings table
    - Add foreign key constraints
*/

ALTER TABLE bookings
ADD COLUMN service_id uuid REFERENCES services(id),
ADD COLUMN variant_id uuid REFERENCES service_variants(id),
ADD COLUMN notes text;