/*
  # Add Signed Contracts Table

  1. New Tables
    - signed_contracts
      - id (uuid, primary key)
      - contract_id (uuid, references contracts)
      - lead_id (uuid, references leads)
      - quote_id (uuid, references quotes)
      - signed_at (timestamp)
      - signature (text)
      - ip_address (text)
      - created_at (timestamp)
      - updated_at (timestamp)

  2. Security
    - Enable RLS
    - Add policy for authenticated users to manage signed contracts
*/

-- Create the table if it doesn't exist
CREATE TABLE IF NOT EXISTS signed_contracts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid REFERENCES contracts(id) NOT NULL,
  lead_id uuid REFERENCES leads(id) NOT NULL,
  quote_id uuid REFERENCES quotes(id) NOT NULL,
  signed_at timestamptz NOT NULL,
  signature text NOT NULL,
  ip_address text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE signed_contracts ENABLE ROW LEVEL SECURITY;

-- Create policy if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'signed_contracts' 
    AND policyname = 'Team members can manage signed contracts'
  ) THEN
    CREATE POLICY "Team members can manage signed contracts"
      ON signed_contracts
      FOR ALL
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END $$;

-- Create trigger if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'update_signed_contracts_updated_at'
  ) THEN
    CREATE TRIGGER update_signed_contracts_updated_at
      BEFORE UPDATE ON signed_contracts
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;