/*
  # Newsletter System

  1. New Tables
    - `newsletter_templates` - Stores newsletter templates
      - `id` (uuid, primary key)
      - `name` (text, not null)
      - `subject` (text, not null)
      - `content` (text, not null)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `newsletter_campaigns` - Stores newsletter campaigns
      - `id` (uuid, primary key)
      - `name` (text, not null)
      - `template_id` (uuid, references newsletter_templates)
      - `subject` (text, not null)
      - `content` (text, not null)
      - `status` (text, not null) - draft, scheduled, sent, cancelled
      - `scheduled_for` (timestamptz)
      - `sent_at` (timestamptz)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `newsletter_subscribers` - Stores newsletter subscribers
      - `id` (uuid, primary key)
      - `email` (text, not null, unique)
      - `name` (text)
      - `type` (text, not null) - lead, vendor, venue
      - `lead_id` (uuid, references leads)
      - `vendor_id` (uuid, references vendors)
      - `venue_id` (uuid, references venues)
      - `status` (text, not null) - subscribed, unsubscribed
      - `unsubscribed_at` (timestamptz)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `newsletter_sends` - Stores newsletter send records
      - `id` (uuid, primary key)
      - `campaign_id` (uuid, references newsletter_campaigns)
      - `subscriber_id` (uuid, references newsletter_subscribers)
      - `status` (text, not null) - pending, sent, failed, opened, clicked
      - `sent_at` (timestamptz)
      - `opened_at` (timestamptz)
      - `clicked_at` (timestamptz)
      - `error` (text)
      - `created_at` (timestamptz)
    
    - `newsletter_links` - Stores links in newsletters for tracking
      - `id` (uuid, primary key)
      - `campaign_id` (uuid, references newsletter_campaigns)
      - `original_url` (text, not null)
      - `tracking_id` (text, not null)
      - `created_at` (timestamptz)
    
    - `newsletter_link_clicks` - Stores link click events
      - `id` (uuid, primary key)
      - `link_id` (uuid, references newsletter_links)
      - `send_id` (uuid, references newsletter_sends)
      - `clicked_at` (timestamptz)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create newsletter_templates table
CREATE TABLE IF NOT EXISTS newsletter_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  subject text NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create newsletter_campaigns table
CREATE TABLE IF NOT EXISTS newsletter_campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  template_id uuid REFERENCES newsletter_templates(id),
  subject text NOT NULL,
  content text NOT NULL,
  status text NOT NULL CHECK (status IN ('draft', 'scheduled', 'sent', 'cancelled')),
  scheduled_for timestamptz,
  sent_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create newsletter_subscribers table
CREATE TABLE IF NOT EXISTS newsletter_subscribers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  name text,
  type text NOT NULL CHECK (type IN ('lead', 'vendor', 'venue')),
  lead_id uuid REFERENCES leads(id),
  vendor_id uuid REFERENCES vendors(id),
  venue_id uuid REFERENCES venues(id),
  status text NOT NULL CHECK (status IN ('subscribed', 'unsubscribed')),
  unsubscribed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_reference CHECK (
    (type = 'lead' AND lead_id IS NOT NULL AND vendor_id IS NULL AND venue_id IS NULL) OR
    (type = 'vendor' AND vendor_id IS NOT NULL AND lead_id IS NULL AND venue_id IS NULL) OR
    (type = 'venue' AND venue_id IS NOT NULL AND lead_id IS NULL AND vendor_id IS NULL)
  )
);

-- Create newsletter_sends table
CREATE TABLE IF NOT EXISTS newsletter_sends (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid NOT NULL REFERENCES newsletter_campaigns(id) ON DELETE CASCADE,
  subscriber_id uuid NOT NULL REFERENCES newsletter_subscribers(id) ON DELETE CASCADE,
  status text NOT NULL CHECK (status IN ('pending', 'sent', 'failed', 'opened', 'clicked')),
  sent_at timestamptz,
  opened_at timestamptz,
  clicked_at timestamptz,
  error text,
  created_at timestamptz DEFAULT now()
);

-- Create newsletter_links table
CREATE TABLE IF NOT EXISTS newsletter_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid NOT NULL REFERENCES newsletter_campaigns(id) ON DELETE CASCADE,
  original_url text NOT NULL,
  tracking_id text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create newsletter_link_clicks table
CREATE TABLE IF NOT EXISTS newsletter_link_clicks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  link_id uuid NOT NULL REFERENCES newsletter_links(id) ON DELETE CASCADE,
  send_id uuid NOT NULL REFERENCES newsletter_sends(id) ON DELETE CASCADE,
  clicked_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE newsletter_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE newsletter_campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE newsletter_subscribers ENABLE ROW LEVEL SECURITY;
ALTER TABLE newsletter_sends ENABLE ROW LEVEL SECURITY;
ALTER TABLE newsletter_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE newsletter_link_clicks ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Team members can manage newsletter templates"
  ON newsletter_templates
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage newsletter campaigns"
  ON newsletter_campaigns
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage newsletter subscribers"
  ON newsletter_subscribers
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage newsletter sends"
  ON newsletter_sends
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage newsletter links"
  ON newsletter_links
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Team members can manage newsletter link clicks"
  ON newsletter_link_clicks
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create triggers for updated_at
CREATE TRIGGER update_newsletter_templates_updated_at
BEFORE UPDATE ON newsletter_templates
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_newsletter_campaigns_updated_at
BEFORE UPDATE ON newsletter_campaigns
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_newsletter_subscribers_updated_at
BEFORE UPDATE ON newsletter_subscribers
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS newsletter_campaigns_status_idx ON newsletter_campaigns(status);
CREATE INDEX IF NOT EXISTS newsletter_campaigns_scheduled_for_idx ON newsletter_campaigns(scheduled_for);
CREATE INDEX IF NOT EXISTS newsletter_subscribers_email_idx ON newsletter_subscribers(email);
CREATE INDEX IF NOT EXISTS newsletter_subscribers_type_idx ON newsletter_subscribers(type);
CREATE INDEX IF NOT EXISTS newsletter_subscribers_status_idx ON newsletter_subscribers(status);
CREATE INDEX IF NOT EXISTS newsletter_subscribers_lead_id_idx ON newsletter_subscribers(lead_id);
CREATE INDEX IF NOT EXISTS newsletter_subscribers_vendor_id_idx ON newsletter_subscribers(vendor_id);
CREATE INDEX IF NOT EXISTS newsletter_subscribers_venue_id_idx ON newsletter_subscribers(venue_id);
CREATE INDEX IF NOT EXISTS newsletter_sends_campaign_id_idx ON newsletter_sends(campaign_id);
CREATE INDEX IF NOT EXISTS newsletter_sends_subscriber_id_idx ON newsletter_sends(subscriber_id);
CREATE INDEX IF NOT EXISTS newsletter_sends_status_idx ON newsletter_sends(status);
CREATE INDEX IF NOT EXISTS newsletter_links_campaign_id_idx ON newsletter_links(campaign_id);
CREATE INDEX IF NOT EXISTS newsletter_links_tracking_id_idx ON newsletter_links(tracking_id);
CREATE INDEX IF NOT EXISTS newsletter_link_clicks_link_id_idx ON newsletter_link_clicks(link_id);
CREATE INDEX IF NOT EXISTS newsletter_link_clicks_send_id_idx ON newsletter_link_clicks(send_id);

-- Create function to check scheduled newsletters
CREATE OR REPLACE FUNCTION check_scheduled_newsletters()
RETURNS TRIGGER AS $$
BEGIN
  -- Update status of campaigns that are scheduled and past their scheduled time
  UPDATE newsletter_campaigns
  SET status = 'sent', sent_at = now()
  WHERE status = 'scheduled' 
  AND scheduled_for <= now();
  
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to run the function periodically
CREATE TRIGGER check_scheduled_newsletters_trigger
AFTER INSERT OR UPDATE ON newsletter_campaigns
FOR EACH STATEMENT
EXECUTE FUNCTION check_scheduled_newsletters();