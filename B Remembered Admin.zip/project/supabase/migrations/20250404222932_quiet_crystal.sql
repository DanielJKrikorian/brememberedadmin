/*
  # Add additional fields to venues table

  1. Changes
    - Add rating column (numeric, 0-5 scale)
    - Add service_type column (text)
    - Add phone_number column (text)
    - Add website column (text)
    - Add state column (text)
    - Add region column (text)

  2. Security
    - Maintain existing RLS policies
*/

ALTER TABLE venues
ADD COLUMN rating numeric CHECK (rating >= 0 AND rating <= 5),
ADD COLUMN service_type text,
ADD COLUMN phone_number text,
ADD COLUMN website text,
ADD COLUMN state text,
ADD COLUMN region text;