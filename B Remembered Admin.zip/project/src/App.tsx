import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';
import { ThemeProvider } from './contexts/ThemeContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import PublicQuote from './pages/PublicQuote';

// Lazy load pages
const Dashboard = React.lazy(() => import('./pages/Dashboard'));
const Leads = React.lazy(() => import('./pages/Leads'));
const LeadEdit = React.lazy(() => import('./pages/LeadEdit'));
const Bookings = React.lazy(() => import('./pages/Bookings'));
const BookingEdit = React.lazy(() => import('./pages/BookingEdit'));
const Vendors = React.lazy(() => import('./pages/Vendors'));
const VendorEdit = React.lazy(() => import('./pages/VendorEdit'));
const VendorBackgroundChecks = React.lazy(() => import('./pages/VendorBackgroundChecks'));
const Venues = React.lazy(() => import('./pages/Venues'));
const VenueEdit = React.lazy(() => import('./pages/VenueEdit'));
const Jobs = React.lazy(() => import('./pages/Jobs'));
const JobEdit = React.lazy(() => import('./pages/JobEdit'));
const Blog = React.lazy(() => import('./pages/Blog'));
const BlogEdit = React.lazy(() => import('./pages/BlogEdit'));
const Finance = React.lazy(() => import('./pages/Finance'));
const Payouts = React.lazy(() => import('./pages/Payouts'));
const Quotes = React.lazy(() => import('./pages/Quotes'));
const QuoteEdit = React.lazy(() => import('./pages/QuoteEdit'));
const Services = React.lazy(() => import('./pages/Services'));
const ServiceEdit = React.lazy(() => import('./pages/ServiceEdit'));
const Contracts = React.lazy(() => import('./pages/Contracts'));
const ContractEdit = React.lazy(() => import('./pages/ContractEdit'));
const Inbox = React.lazy(() => import('./pages/Inbox'));
const Discounts = React.lazy(() => import('./pages/Discounts'));
const DiscountEdit = React.lazy(() => import('./pages/DiscountEdit'));
const Settings = React.lazy(() => import('./pages/Settings'));
const Store = React.lazy(() => import('./pages/Store'));
const Rentals = React.lazy(() => import('./pages/Rentals'));
const RentalEdit = React.lazy(() => import('./pages/RentalEdit'));
const RentalItemDetails = React.lazy(() => import('./pages/RentalItemDetails'));
const RentalBookingEdit = React.lazy(() => import('./pages/RentalBookingEdit'));
const RentalMaintenanceEdit = React.lazy(() => import('./pages/RentalMaintenanceEdit'));
const RentalBookingSuccess = React.lazy(() => import('./pages/RentalBookingSuccess'));
const CommunityBoard = React.lazy(() => import('./pages/CommunityBoard'));
const CommunityPostEdit = React.lazy(() => import('./pages/CommunityPostEdit'));
const CustomPackageBuilder = React.lazy(() => import('./pages/CustomPackageBuilder'));
const CustomPackages = React.lazy(() => import('./pages/CustomPackages'));
const CustomPackageDetails = React.lazy(() => import('./pages/CustomPackageDetails'));
const VendorStorage = React.lazy(() => import('./pages/VendorStorage'));
const CoupleStorage = React.lazy(() => import('./pages/CoupleStorage'));
const ContentTransfer = React.lazy(() => import('./pages/ContentTransfer'));
const StoragePlans = React.lazy(() => import('./pages/StoragePlans'));
const PublicTransfer = React.lazy(() => import('./pages/PublicTransfer'));
const Newsletters = React.lazy(() => import('./pages/Newsletters'));
const NewsletterEdit = React.lazy(() => import('./pages/NewsletterEdit'));
const NewsletterCampaign = React.lazy(() => import('./pages/NewsletterCampaign'));
const NewsletterSubscribers = React.lazy(() => import('./pages/NewsletterSubscribers'));
const NewsletterUnsubscribe = React.lazy(() => import('./pages/NewsletterUnsubscribe'));
const EmailTemplates = React.lazy(() => import('./pages/EmailTemplates'));

function App() {
  const initialize = useAuthStore(state => state.initialize);

  useEffect(() => {
    initialize();
  }, [initialize]);

  return (
    <ThemeProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/quote/:id" element={<PublicQuote />} />
          <Route path="/transfer/:id" element={<PublicTransfer />} />
          <Route path="/newsletter/unsubscribe/:token" element={<NewsletterUnsubscribe />} />
          <Route path="/rentals/booking/success" element={<RentalBookingSuccess />} />
          <Route path="/rentals/booking/cancel" element={<Navigate to="/rentals" replace />} />
          <Route path="/" element={<Layout />}>
            <Route index element={<Navigate to="/dashboard" replace />} />
            <Route
              path="dashboard"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Dashboard />
                </React.Suspense>
              }
            />
            <Route
              path="inbox"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Inbox />
                </React.Suspense>
              }
            />
            <Route
              path="content-transfer"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <ContentTransfer />
                </React.Suspense>
              }
            />
            <Route
              path="leads"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Leads />
                </React.Suspense>
              }
            />
            <Route
              path="leads/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <LeadEdit />
                </React.Suspense>
              }
            />
            <Route
              path="quotes"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Quotes />
                </React.Suspense>
              }
            />
            <Route
              path="quotes/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <QuoteEdit />
                </React.Suspense>
              }
            />
            <Route
              path="discounts"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Discounts />
                </React.Suspense>
              }
            />
            <Route
              path="discounts/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <DiscountEdit />
                </React.Suspense>
              }
            />
            <Route
              path="services"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Services />
                </React.Suspense>
              }
            />
            <Route
              path="services/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <ServiceEdit />
                </React.Suspense>
              }
            />
            <Route
              path="contracts"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Contracts />
                </React.Suspense>
              }
            />
            <Route
              path="contracts/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <ContractEdit />
                </React.Suspense>
              }
            />
            <Route
              path="bookings"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Bookings />
                </React.Suspense>
              }
            />
            <Route
              path="bookings/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <BookingEdit />
                </React.Suspense>
              }
            />
            <Route
              path="vendors"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Vendors />
                </React.Suspense>
              }
            />
            <Route
              path="vendors/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <VendorEdit />
                </React.Suspense>
              }
            />
            <Route
              path="vendor-background-checks"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <VendorBackgroundChecks />
                </React.Suspense>
              }
            />
            <Route
              path="venues"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Venues />
                </React.Suspense>
              }
            />
            <Route
              path="venues/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <VenueEdit />
                </React.Suspense>
              }
            />
            <Route
              path="jobs"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Jobs />
                </React.Suspense>
              }
            />
            <Route
              path="jobs/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <JobEdit />
                </React.Suspense>
              }
            />
            <Route
              path="blog"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Blog />
                </React.Suspense>
              }
            />
            <Route
              path="blog/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <BlogEdit />
                </React.Suspense>
              }
            />
            <Route
              path="newsletters"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Newsletters />
                </React.Suspense>
              }
            />
            <Route
              path="newsletters/templates/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <NewsletterEdit />
                </React.Suspense>
              }
            />
            <Route
              path="newsletters/campaigns/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <NewsletterCampaign />
                </React.Suspense>
              }
            />
            <Route
              path="newsletters/subscribers"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <NewsletterSubscribers />
                </React.Suspense>
              }
            />
            <Route
              path="email-templates"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <EmailTemplates />
                </React.Suspense>
              }
            />
            <Route
              path="finance"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Finance />
                </React.Suspense>
              }
            />
            <Route
              path="payouts"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Payouts />
                </React.Suspense>
              }
            />
            <Route
              path="settings"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Settings />
                </React.Suspense>
              }
            />
            <Route
              path="store"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Store />
                </React.Suspense>
              }
            />
            <Route
              path="rentals"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <Rentals />
                </React.Suspense>
              }
            />
            <Route
              path="rentals/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <RentalEdit />
                </React.Suspense>
              }
            />
            <Route
              path="rentals/item/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <RentalItemDetails />
                </React.Suspense>
              }
            />
            <Route
              path="rentals/booking/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <RentalBookingEdit />
                </React.Suspense>
              }
            />
            <Route
              path="rentals/maintenance/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <RentalMaintenanceEdit />
                </React.Suspense>
              }
            />
            <Route
              path="community"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <CommunityBoard />
                </React.Suspense>
              }
            />
            <Route
              path="community/post/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <CommunityPostEdit />
                </React.Suspense>
              }
            />
            <Route
              path="custom-packages/build/:serviceId/:leadId"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <CustomPackageBuilder />
                </React.Suspense>
              }
            />
            <Route
              path="custom-packages"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <CustomPackages />
                </React.Suspense>
              }
            />
            <Route
              path="custom-packages/:id"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <CustomPackageDetails />
                </React.Suspense>
              }
            />
            <Route
              path="vendor-storage"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <VendorStorage />
                </React.Suspense>
              }
            />
            <Route
              path="couple-storage"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <CoupleStorage />
                </React.Suspense>
              }
            />
            <Route
              path="storage-plans"
              element={
                <React.Suspense fallback={<div>Loading...</div>}>
                  <StoragePlans />
                </React.Suspense>
              }
            />
          </Route>
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  );
}

export default App;