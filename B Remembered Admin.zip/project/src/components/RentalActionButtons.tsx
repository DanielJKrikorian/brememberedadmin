import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, Wrench, Eye, Edit, Truck } from 'lucide-react';

interface RentalActionButtonsProps {
  itemId: string;
  status: string;
  onView?: () => void;
  onEdit?: () => void;
  onBook?: () => void;
  onMaintain?: () => void;
}

export default function RentalActionButtons({ 
  itemId, 
  status, 
  onView, 
  onEdit, 
  onBook, 
  onMaintain 
}: RentalActionButtonsProps) {
  const navigate = useNavigate();
  
  const handleView = () => {
    if (onView) {
      onView();
    } else {
      navigate(`/rentals/item/${itemId}`);
    }
  };
  
  const handleEdit = () => {
    if (onEdit) {
      onEdit();
    } else {
      navigate(`/rentals/${itemId}`);
    }
  };
  
  const handleBook = () => {
    if (onBook) {
      onBook();
    } else {
      navigate(`/rentals/booking/new?itemId=${itemId}`);
    }
  };
  
  const handleMaintain = () => {
    if (onMaintain) {
      onMaintain();
    } else {
      navigate(`/rentals/maintenance/new?itemId=${itemId}`);
    }
  };
  
  return (
    <div className="flex flex-wrap gap-2">
      <button
        onClick={handleView}
        className="flex items-center gap-1 px-2 py-1 text-xs bg-gray-100 text-gray-700 rounded hover:bg-gray-200"
      >
        <Eye className="w-3 h-3" />
        View
      </button>
      
      <button
        onClick={handleEdit}
        className="flex items-center gap-1 px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded hover:bg-blue-200"
      >
        <Edit className="w-3 h-3" />
        Edit
      </button>
      
      <button
        onClick={handleBook}
        className="flex items-center gap-1 px-2 py-1 text-xs bg-green-100 text-green-700 rounded hover:bg-green-200"
        disabled={status !== 'available'}
      >
        <Calendar className="w-3 h-3" />
        Book
      </button>
      
      <button
        onClick={handleMaintain}
        className="flex items-center gap-1 px-2 py-1 text-xs bg-yellow-100 text-yellow-700 rounded hover:bg-yellow-200"
      >
        <Wrench className="w-3 h-3" />
        Maintain
      </button>
    </div>
  );
}