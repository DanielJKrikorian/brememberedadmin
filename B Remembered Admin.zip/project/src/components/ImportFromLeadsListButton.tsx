import React, { useState } from 'react';
import { Database, AlertCircle, CheckCircle } from 'lucide-react';

interface ImportFromLeadsListButtonProps {
  onImportComplete: () => void;
}

export default function ImportFromLeadsListButton({ onImportComplete }: ImportFromLeadsListButtonProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleImport = async () => {
    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const response = await fetch('/functions/v1/import-leads-from-list', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to import leads');
      }

      const data = await response.json();
      setSuccess(`${data.imported} leads imported successfully`);
      onImportComplete();
    } catch (err) {
      console.error('Error importing leads:', err);
      setError(err instanceof Error ? err.message : 'Failed to import leads');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <button
        onClick={handleImport}
        disabled={loading}
        className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 disabled:opacity-50"
      >
        {loading ? (
          <div className="animate-spin rounded-full h-4 w-4 border-2 border-gray-500 border-t-transparent"></div>
        ) : (
          <Database className="w-5 h-5" />
        )}
        Import from Leads List
      </button>

      {error && (
        <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700 flex items-center gap-1">
          <AlertCircle className="w-4 h-4" />
          {error}
        </div>
      )}

      {success && (
        <div className="mt-2 p-2 bg-green-50 border border-green-200 rounded-lg text-sm text-green-700 flex items-center gap-1">
          <CheckCircle className="w-4 h-4" />
          {success}
        </div>
      )}
    </div>
  );
}