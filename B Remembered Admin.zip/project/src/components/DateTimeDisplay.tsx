import React from 'react';
import { formatDateTimeToEST, formatToEST, formatTimeToEST } from '../utils/timezone';

interface DateTimeDisplayProps {
  date: string | Date;
  format?: 'date' | 'time' | 'datetime';
  className?: string;
}

export default function DateTimeDisplay({ 
  date, 
  format = 'datetime',
  className = ''
}: DateTimeDisplayProps) {
  if (!date) return null;

  let formattedDate: string;
  switch (format) {
    case 'date':
      formattedDate = formatToEST(date);
      break;
    case 'time':
      formattedDate = formatTimeToEST(date);
      break;
    default:
      formattedDate = formatDateTimeToEST(date);
  }

  return (
    <time dateTime={new Date(date).toISOString()} className={className}>
      {formattedDate}
    </time>
  );
}