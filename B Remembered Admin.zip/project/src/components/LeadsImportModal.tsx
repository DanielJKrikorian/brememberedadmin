import React, { useState, useRef } from 'react';
import { X, Upload, Download, CheckCircle, AlertCircle } from 'lucide-react';
import * as Papa from 'papaparse';

interface LeadsImportModalProps {
  onClose: () => void;
  onImportSuccess: () => void;
}

export default function LeadsImportModal({ onClose, onImportSuccess }: LeadsImportModalProps) {
  const [file, setFile] = useState<File | null>(null);
  const [importing, setImporting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [importProgress, setImportProgress] = useState<number | null>(null);
  const [showTemplateOptions, setShowTemplateOptions] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.type !== 'text/csv' && !selectedFile.name.endsWith('.csv')) {
        setError('Please select a CSV file');
        return;
      }
      setFile(selectedFile);
      setError(null);
    }
  };

  const handleImport = () => {
    if (!file) {
      setError('Please select a file to import');
      return;
    }

    setImporting(true);
    setImportProgress(0);
    setError(null);

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        try {
          const totalRows = results.data.length;
          let processedRows = 0;

          // Process in batches of 10 to avoid overwhelming the database
          const batchSize = 10;
          for (let i = 0; i < results.data.length; i += batchSize) {
            const batch = results.data.slice(i, i + batchSize);
            
            // Map CSV data to leads table structure
            const leads = batch.map((row: any) => ({
              name: row.Name || row.name || '',
              email: row.Email || row.email || '',
              phone: row.Phone || row.phone || '',
              source: row.Source || row.source || 'Import',
              status: row.Status || row.status || 'new',
              notes: row.Notes || row.notes || '',
              partner_name: row['Partner Name'] || row.partner_name || '',
              wedding_date: row['Wedding Date'] || row.wedding_date || null,
              venue_name: row['Venue Name'] || row.venue_name || '',
              venue_address: row['Venue Address'] || row.venue_address || '',
              lead_date: row['Lead Date'] || row.lead_date || new Date().toISOString().split('T')[0]
            }));

            // Insert leads into the leads table
            const { error } = await supabase.from('leads').insert(leads);
            if (error) throw error;

            // Update progress
            processedRows += batch.length;
            setImportProgress(Math.round((processedRows / totalRows) * 100));
          }

          setSuccess(`Successfully imported ${totalRows} leads`);
          onImportSuccess();
          
          // Reset file input after 3 seconds
          setTimeout(() => {
            if (fileInputRef.current) {
              fileInputRef.current.value = '';
            }
            setFile(null);
            setImportProgress(null);
          }, 3000);
        } catch (error) {
          console.error('Error importing leads:', error);
          setError('Failed to import leads. Please try again.');
          setImportProgress(null);
        } finally {
          setImporting(false);
        }
      },
      error: (err) => {
        console.error('Error parsing CSV:', err);
        setError('Failed to parse CSV file. Please check the file format.');
        setImporting(false);
        setImportProgress(null);
      }
    });
  };

  const handleDownloadTemplate = (type: 'basic' | 'full') => {
    // Define CSV headers and sample data based on template type
    let headers: string[];
    let sampleData: string[][];

    if (type === 'basic') {
      headers = ['Name', 'Email', 'Phone', 'Source', 'Lead Date'];
      sampleData = [
        ['John Doe', 'john@example.com', '555-123-4567', 'Website', new Date().toISOString().split('T')[0]]
      ];
    } else {
      headers = [
        'Name', 'Email', 'Phone', 'Source', 'Status', 'Partner Name', 
        'Wedding Date', 'Venue Name', 'Venue Address', 'Lead Date', 'Notes'
      ];
      sampleData = [
        [
          'John Doe', 'john@example.com', '555-123-4567', 'Website', 'new',
          'Jane Smith', '2025-06-15', 'Grand Hotel', '123 Main St, Anytown, USA',
          new Date().toISOString().split('T')[0], 'Initial inquiry via contact form'
        ]
      ];
    }

    // Create CSV content
    const csvContent = [
      headers.join(','),
      ...sampleData.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    // Create download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `leads_import_template_${type}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
        <div className="flex justify-between items-center p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">Import Leads</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-6">
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}
          
          {success && (
            <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700">
              <CheckCircle className="w-5 h-5 flex-shrink-0" />
              <span>{success}</span>
            </div>
          )}
          
          <div className="mb-6">
            <p className="text-gray-600 mb-4">
              Upload a CSV file with lead information. The file should include columns for name, email, phone, etc.
            </p>
            
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-500">Need a template?</span>
              <button
                onClick={() => setShowTemplateOptions(!showTemplateOptions)}
                className="text-sm text-blue-600 hover:text-blue-800"
              >
                Download template
              </button>
            </div>
            
            {showTemplateOptions && (
              <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-sm text-blue-700 mb-2">Choose a template format:</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleDownloadTemplate('basic')}
                    className="px-3 py-1 bg-white text-blue-600 border border-blue-300 rounded hover:bg-blue-50 text-sm"
                  >
                    Basic Template
                  </button>
                  <button
                    onClick={() => handleDownloadTemplate('full')}
                    className="px-3 py-1 bg-white text-blue-600 border border-blue-300 rounded hover:bg-blue-50 text-sm"
                  >
                    Full Template
                  </button>
                </div>
              </div>
            )}
            
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept=".csv"
                className="hidden"
                id="file-upload"
              />
              <label
                htmlFor="file-upload"
                className="cursor-pointer flex flex-col items-center justify-center"
              >
                <Upload className="w-12 h-12 text-gray-400 mb-2" />
                <p className="text-gray-700 font-medium mb-1">
                  {file ? file.name : 'Click to upload or drag and drop'}
                </p>
                <p className="text-sm text-gray-500">CSV files only</p>
              </label>
            </div>
          </div>
          
          {importProgress !== null && (
            <div className="mb-4">
              <div className="flex justify-between text-sm text-gray-600 mb-1">
                <span>Importing...</span>
                <span>{importProgress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${importProgress}%` }}
                />
              </div>
            </div>
          )}
          
          <div className="flex justify-end gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleImport}
              disabled={!file || importing}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              {importing ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                  Importing...
                </>
              ) : (
                <>
                  <Upload className="w-5 h-5" />
                  Import Leads
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}