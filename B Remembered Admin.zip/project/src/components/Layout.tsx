import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { useTheme } from '../contexts/ThemeContext';
import Sidebar from './Sidebar';

const Layout = () => {
  const { user, adminData, loading } = useAuthStore();
  const { theme } = useTheme();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!user || !adminData) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="flex min-h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar />
      <main className="flex-1 p-8 max-w-full overflow-x-auto dark:bg-gray-900">
        <div className="container mx-auto max-w-full">
          <Outlet />
        </div>
      </main>
    </div>
  );
};

export default Layout;