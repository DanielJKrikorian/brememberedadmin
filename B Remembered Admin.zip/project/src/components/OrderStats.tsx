import React from 'react';
import { 
  ShoppingBag, TrendingUp, Clock, Truck, CheckCircle, 
  XCircle, DollarSign, Calendar, BarChart2
} from 'lucide-react';

interface OrderStatsProps {
  stats: {
    total: number;
    pending: number;
    processing: number;
    shipped: number;
    delivered: number;
    cancelled: number;
    totalValue: number;
    avgValue: number;
    recentOrders: number;
  };
}

export default function OrderStats({ stats }: OrderStatsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-medium text-gray-700">Total Orders</h3>
          <ShoppingBag className="w-5 h-5 text-blue-500" />
        </div>
        <div className="flex items-end justify-between">
          <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
          <div className="flex items-center text-sm text-green-600">
            <TrendingUp className="w-4 h-4 mr-1" />
            <span>{stats.recentOrders} new this week</span>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-medium text-gray-700">Order Status</h3>
          <Clock className="w-5 h-5 text-purple-500" />
        </div>
        <div className="grid grid-cols-3 gap-2 text-center">
          <div>
            <div className="text-yellow-600 font-semibold">{stats.pending}</div>
            <div className="text-xs text-gray-500">Pending</div>
          </div>
          <div>
            <div className="text-blue-600 font-semibold">{stats.processing}</div>
            <div className="text-xs text-gray-500">Processing</div>
          </div>
          <div>
            <div className="text-purple-600 font-semibold">{stats.shipped}</div>
            <div className="text-xs text-gray-500">Shipped</div>
          </div>
          <div>
            <div className="text-green-600 font-semibold">{stats.delivered}</div>
            <div className="text-xs text-gray-500">Delivered</div>
          </div>
          <div>
            <div className="text-red-600 font-semibold">{stats.cancelled}</div>
            <div className="text-xs text-gray-500">Cancelled</div>
          </div>
          <div>
            <div className="text-gray-600 font-semibold">
              {Math.round((stats.delivered / (stats.total || 1)) * 100)}%
            </div>
            <div className="text-xs text-gray-500">Completion</div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-medium text-gray-700">Revenue</h3>
          <DollarSign className="w-5 h-5 text-green-500" />
        </div>
        <div className="flex items-end justify-between">
          <p className="text-2xl font-bold text-gray-900">${stats.totalValue.toFixed(2)}</p>
          <div className="text-sm text-gray-600">
            Avg: ${stats.avgValue.toFixed(2)}
          </div>
        </div>
      </div>
    </div>
  );
}