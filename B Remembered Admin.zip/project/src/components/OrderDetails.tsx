import React from 'react';
import { Package, User, Mail, Phone, MapPin } from 'lucide-react';
import DateTimeDisplay from './DateTimeDisplay';

interface OrderItem {
  id: string;
  product_id: string;
  quantity: number;
  price: number;
  product: {
    name: string;
    image_url: string | null;
    category: string;
  };
}

interface OrderDetailsProps {
  id: string;
  created_at: string;
  shipping_address: string;
  notes: string | null;
  total_amount: number;
  items: OrderItem[];
  vendor: {
    name: string;
    email: string;
    phone: string | null;
  };
}

export default function OrderDetails({
  id,
  created_at,
  shipping_address,
  notes,
  total_amount,
  items,
  vendor
}: OrderDetailsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div>
        <h4 className="text-sm font-medium text-gray-900 mb-2">Order Information</h4>
        <div className="bg-white p-3 rounded-lg border border-gray-200">
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-sm text-gray-500">Order ID:</span>
              <span className="text-sm font-medium text-gray-900">#{id.substring(0, 8)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-500">Date:</span>
              <span className="text-sm text-gray-900">
                <DateTimeDisplay date={created_at} format="datetime" />
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-500">Total:</span>
              <span className="text-sm font-medium text-gray-900">${total_amount.toFixed(2)}</span>
            </div>
          </div>
        </div>
        
        <h4 className="text-sm font-medium text-gray-900 mt-4 mb-2">Shipping Address</h4>
        <div className="bg-white p-3 rounded-lg border border-gray-200">
          <div className="text-sm text-gray-700 whitespace-pre-line">
            {shipping_address}
          </div>
        </div>
        
        {notes && (
          <>
            <h4 className="text-sm font-medium text-gray-900 mt-4 mb-2">Order Notes</h4>
            <div className="bg-white p-3 rounded-lg border border-gray-200">
              <div className="text-sm text-gray-700 whitespace-pre-line">
                {notes}
              </div>
            </div>
          </>
        )}
        
        <h4 className="text-sm font-medium text-gray-900 mt-4 mb-2">Vendor Contact</h4>
        <div className="bg-white p-3 rounded-lg border border-gray-200 space-y-2">
          <div className="flex items-center text-sm text-gray-700">
            <User className="w-4 h-4 mr-2 text-gray-500" />
            {vendor.name}
          </div>
          <div className="flex items-center text-sm text-gray-700">
            <Mail className="w-4 h-4 mr-2 text-gray-500" />
            <a href={`mailto:${vendor.email}`} className="text-blue-600 hover:text-blue-800">
              {vendor.email}
            </a>
          </div>
          {vendor.phone && (
            <div className="flex items-center text-sm text-gray-700">
              <Phone className="w-4 h-4 mr-2 text-gray-500" />
              <a href={`tel:${vendor.phone}`} className="text-blue-600 hover:text-blue-800">
                {vendor.phone}
              </a>
            </div>
          )}
        </div>
      </div>
      
      <div>
        <h4 className="text-sm font-medium text-gray-900 mb-2">Order Items</h4>
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Item</th>
                <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Qty</th>
                <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Price</th>
                <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {items.map((item) => (
                <tr key={item.id}>
                  <td className="px-3 py-2">
                    <div className="flex items-center">
                      {item.product.image_url ? (
                        <img 
                          src={item.product.image_url} 
                          alt={item.product.name}
                          className="w-8 h-8 rounded object-cover mr-2"
                        />
                      ) : (
                        <div className="w-8 h-8 bg-gray-100 rounded flex items-center justify-center mr-2">
                          <Package className="w-4 h-4 text-gray-400" />
                        </div>
                      )}
                      <div className="text-xs">
                        <div className="font-medium text-gray-900">{item.product.name}</div>
                        <div className="text-gray-500">{item.product.category}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-3 py-2 text-xs text-gray-900">{item.quantity}</td>
                  <td className="px-3 py-2 text-xs text-gray-900">${item.price.toFixed(2)}</td>
                  <td className="px-3 py-2 text-xs font-medium text-gray-900">
                    ${(item.quantity * item.price).toFixed(2)}
                  </td>
                </tr>
              ))}
              <tr className="bg-gray-50">
                <td colSpan={3} className="px-3 py-2 text-xs font-medium text-gray-900 text-right">
                  Total:
                </td>
                <td className="px-3 py-2 text-xs font-medium text-gray-900">
                  ${total_amount.toFixed(2)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}