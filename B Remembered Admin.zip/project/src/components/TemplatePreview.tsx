import React from 'react';
import { Mail, MessageSquare, Calendar, User } from 'lucide-react';

interface TemplatePreviewProps {
  type: 'email' | 'sms';
  subject?: string;
  content: string;
  onClose: () => void;
  variables?: Record<string, string>;
}

export default function TemplatePreview({ 
  type, 
  subject, 
  content, 
  onClose,
  variables = {
    name: 'John Doe',
    email: 'john@example.com',
    date: new Date().toLocaleDateString(),
    time: new Date().toLocaleTimeString(),
    event_type: 'Wedding',
    service_name: 'Photography Package',
    venue_name: 'Grand Hotel',
    quote_link: 'https://example.com/quote/123',
    calendar_link: 'https://example.com/calendar/123',
    appointment_date: new Date().toLocaleDateString(),
    appointment_time: '3:00 PM'
  }
}: TemplatePreviewProps) {
  // Replace variables in content
  const processedContent = Object.entries(variables).reduce(
    (content, [key, value]) => content.replace(new RegExp(`{{${key}}}`, 'g'), value),
    content
  );
  
  // Replace variables in subject
  const processedSubject = subject ? Object.entries(variables).reduce(
    (subject, [key, value]) => subject.replace(new RegExp(`{{${key}}}`, 'g'), value),
    subject
  ) : '';
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">Template Preview</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <span className="sr-only">Close</span>
            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <div className="p-6">
          {type === 'email' ? (
            <div className="border border-gray-200 rounded-lg p-4">
              <div className="mb-4 pb-4 border-b border-gray-200">
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <Mail className="w-4 h-4" />
                  <span>From: B. Remembered Weddings &lt;noreply@b-remembered.com&gt;</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-500 mt-1">
                  <User className="w-4 h-4" />
                  <span>To: {variables.name} &lt;{variables.email}&gt;</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-500 mt-1">
                  <Calendar className="w-4 h-4" />
                  <span>Date: {new Date().toLocaleString()}</span>
                </div>
                <div className="text-sm font-medium text-gray-700 mt-2">
                  Subject: {processedSubject}
                </div>
              </div>
              <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: processedContent }} />
            </div>
          ) : (
            <div className="border border-gray-200 rounded-lg p-4">
              <div className="mb-4 pb-4 border-b border-gray-200">
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <MessageSquare className="w-4 h-4" />
                  <span>From: B. Remembered Weddings</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-500 mt-1">
                  <User className="w-4 h-4" />
                  <span>To: {variables.name} ({variables.phone || '555-123-4567'})</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-500 mt-1">
                  <Calendar className="w-4 h-4" />
                  <span>Date: {new Date().toLocaleString()}</span>
                </div>
              </div>
              <div className="bg-gray-100 p-4 rounded-lg max-w-xs mx-auto">
                <p className="text-gray-800 whitespace-pre-wrap">{processedContent}</p>
                <div className="text-xs text-gray-500 text-right mt-1">
                  {processedContent.length > 160 ? 
                    `${Math.ceil(processedContent.length / 160)} messages` : 
                    '1 message'}
                </div>
              </div>
            </div>
          )}
          
          <div className="mt-6 flex justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Close Preview
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}