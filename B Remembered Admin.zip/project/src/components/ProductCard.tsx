import React, { useState } from 'react';
import { Package, DollarSign, ShoppingCart, Eye, EyeOff } from 'lucide-react';
import ProductImageGallery from './ProductImageGallery';

interface ProductImage {
  id: string;
  url: string;
  alt_text: string | null;
  display_order: number;
  is_primary: boolean;
}

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image_url: string | null;
  stock: number;
  category: string;
  status: 'active' | 'inactive';
  images?: ProductImage[];
}

interface ProductCardProps {
  product: Product;
  onEdit: (product: Product) => void;
  onDelete: (id: string) => void;
}

export default function ProductCard({ product, onEdit, onDelete }: ProductCardProps) {
  const [showGallery, setShowGallery] = useState(false);
  
  // Get primary image or first image
  const primaryImage = product.images?.find(img => img.is_primary) || 
                      (product.images && product.images.length > 0 ? product.images[0] : null);
  
  const imageUrl = primaryImage?.url || product.image_url;
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative aspect-square">
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={product.name}
            className="w-full h-full object-cover cursor-pointer"
            onClick={() => product.images && product.images.length > 0 && setShowGallery(true)}
          />
        ) : (
          <div className="w-full h-full bg-gray-100 flex items-center justify-center">
            <Package className="w-12 h-12 text-gray-400" />
          </div>
        )}
        
        {product.images && product.images.length > 1 && (
          <div className="absolute bottom-2 right-2 bg-black bg-opacity-60 text-white text-xs px-2 py-1 rounded-full">
            {product.images.length} images
          </div>
        )}
        
        <div className="absolute top-2 right-2">
          <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
            product.status === 'active' 
              ? 'bg-green-100 text-green-800' 
              : 'bg-gray-100 text-gray-800'
          }`}>
            {product.status === 'active' ? (
              <Eye className="w-3 h-3 mr-1" />
            ) : (
              <EyeOff className="w-3 h-3 mr-1" />
            )}
            {product.status}
          </span>
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-medium text-gray-900">{product.name}</h3>
            <p className="text-sm text-gray-500 line-clamp-2 mt-1">{product.description}</p>
          </div>
          <span className="flex items-center text-lg font-bold text-gray-900">
            <DollarSign className="w-4 h-4" />
            {product.price.toFixed(2)}
          </span>
        </div>
        
        <div className="mt-4 flex items-center justify-between">
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            {product.category}
          </span>
          <span className="text-sm text-gray-600">
            Stock: {product.stock}
          </span>
        </div>
        
        <div className="mt-4 flex justify-between">
          <button
            onClick={() => onEdit(product)}
            className="px-3 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm"
          >
            Edit
          </button>
          <button
            onClick={() => onDelete(product.id)}
            className="px-3 py-1.5 border border-red-300 text-red-600 rounded hover:bg-red-50 text-sm"
          >
            Delete
          </button>
        </div>
      </div>
      
      {showGallery && product.images && (
        <ProductImageGallery 
          images={product.images} 
          onClose={() => setShowGallery(false)} 
        />
      )}
    </div>
  );
}