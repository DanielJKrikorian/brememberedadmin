import React, { useState, useRef } from 'react';
import { useDropzone } from 'react-dropzone';
import { supabase } from '../lib/supabase';
import { Send, Paperclip, X, File, Image as ImageIcon } from 'lucide-react';

interface CommunityAttachment {
  id: string;
  file_name: string;
  file_type: string;
  file_size: number;
  url: string;
}

interface CommunityCommentFormProps {
  postId: string;
  parentId?: string | null;
  teamMemberId: string;
  onSubmit: (content: string, attachments: CommunityAttachment[]) => Promise<void>;
  onCancel?: () => void;
  placeholder?: string;
  buttonText?: string;
  initialContent?: string;
}

export default function CommunityCommentForm({
  postId,
  parentId,
  teamMemberId,
  onSubmit,
  onCancel,
  placeholder = 'Write a comment...',
  buttonText = 'Post Comment',
  initialContent = ''
}: CommunityCommentFormProps) {
  const [content, setContent] = useState(initialContent);
  const [attachments, setAttachments] = useState<CommunityAttachment[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({});
  const [error, setError] = useState<string | null>(null);
  
  const { getRootProps, getInputProps, open } = useDropzone({
    onDrop: handleFileDrop,
    noClick: true,
    noKeyboard: true,
    multiple: true
  });
  
  async function handleFileDrop(acceptedFiles: File[]) {
    if (!teamMemberId) return;
    
    setUploading(true);
    
    for (const file of acceptedFiles) {
      const fileId = Math.random().toString(36).substring(7);
      setUploadProgress(prev => ({ ...prev, [fileId]: 0 }));
      
      try {
        // Create a unique file path
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
        const filePath = `${postId}/comments/${fileName}`;
        
        // Upload the file
        const { error: uploadError } = await supabase.storage
          .from('community-attachments')
          .upload(filePath, file, {
            onUploadProgress: (progress) => {
              const percent = (progress.loaded / progress.total) * 100;
              setUploadProgress(prev => ({ ...prev, [fileId]: percent }));
            }
          });
          
        if (uploadError) throw uploadError;
        
        // Get the public URL
        const { data: { publicUrl } } = supabase.storage
          .from('community-attachments')
          .getPublicUrl(filePath);
          
        // Add the file to attachments
        setAttachments(prev => [
          ...prev,
          {
            id: fileId,
            file_name: file.name,
            file_type: file.type,
            file_size: file.size,
            url: publicUrl
          }
        ]);
        
        // Clean up progress indicator
        setUploadProgress(prev => {
          const newProgress = { ...prev };
          delete newProgress[fileId];
          return newProgress;
        });
      } catch (err) {
        console.error('Error uploading file:', err);
        setError('Failed to upload file');
        setUploadProgress(prev => {
          const newProgress = { ...prev };
          delete newProgress[fileId];
          return newProgress;
        });
      }
    }
    
    setUploading(false);
  }
  
  function removeAttachment(attachmentId: string) {
    setAttachments(attachments.filter(a => a.id !== attachmentId));
  }
  
  function getFileIcon(fileType: string) {
    if (fileType.startsWith('image/')) {
      return <ImageIcon className="w-4 h-4 text-blue-500" />;
    }
    return <File className="w-4 h-4 text-gray-500" />;
  }
  
  function formatFileSize(bytes: number) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }
  
  async function handleSubmit() {
    if (!content.trim() && attachments.length === 0) return;
    
    try {
      await onSubmit(content, attachments);
      setContent('');
      setAttachments([]);
      setError(null);
    } catch (err) {
      console.error('Error submitting comment:', err);
      setError('Failed to post comment');
    }
  }
  
  return (
    <div {...getRootProps()} className="space-y-3">
      <textarea
        className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        rows={3}
        placeholder={placeholder}
        value={content}
        onChange={(e) => setContent(e.target.value)}
      />
      
      {/* Attachment List */}
      {attachments.length > 0 && (
        <div className="space-y-2">
          {attachments.map(attachment => (
            <div key={attachment.id} className="flex items-center justify-between bg-gray-50 p-2 rounded-lg">
              <div className="flex items-center">
                {getFileIcon(attachment.file_type)}
                <span className="ml-2 text-sm text-gray-900">{attachment.file_name}</span>
                <span className="ml-2 text-xs text-gray-500">({formatFileSize(attachment.file_size)})</span>
              </div>
              <button
                type="button"
                onClick={() => removeAttachment(attachment.id)}
                className="text-red-600 hover:text-red-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
      
      {/* Upload Progress */}
      {Object.entries(uploadProgress).map(([fileId, progress]) => (
        <div key={fileId}>
          <div className="flex justify-between text-sm text-gray-600 mb-1">
            <span>Uploading file...</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      ))}
      
      {error && (
        <div className="text-sm text-red-600">
          {error}
        </div>
      )}
      
      <div className="flex justify-between items-center">
        <button
          type="button"
          onClick={open}
          className="flex items-center gap-1 text-gray-600 hover:text-gray-800"
        >
          <Paperclip className="w-4 h-4" />
          <span>Attach Files</span>
          <input {...getInputProps()} />
        </button>
        
        <div className="flex gap-2">
          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="px-3 py-1 text-gray-600 hover:text-gray-800"
            >
              Cancel
            </button>
          )}
          
          <button
            type="button"
            onClick={handleSubmit}
            disabled={(!content.trim() && attachments.length === 0) || uploading}
            className="flex items-center gap-1 px-3 py-1 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
            {buttonText}
          </button>
        </div>
      </div>
    </div>
  );
}