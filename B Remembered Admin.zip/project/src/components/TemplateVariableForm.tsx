import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';

interface TemplateVariableFormProps {
  variables: string[];
  onAddVariable: (variable: string) => void;
  onRemoveVariable: (variable: string) => void;
  onInsertVariable: (variable: string) => void;
}

export default function TemplateVariableForm({
  variables,
  onAddVariable,
  onRemoveVariable,
  onInsertVariable
}: TemplateVariableFormProps) {
  const [variableInput, setVariableInput] = useState('');
  
  const handleAddVariable = () => {
    if (!variableInput.trim()) return;
    
    // Format variable name (remove spaces, special chars)
    const formattedVariable = variableInput.trim()
      .toLowerCase()
      .replace(/[^a-z0-9_]/g, '_');
    
    onAddVariable(formattedVariable);
    setVariableInput('');
  };
  
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        Template Variables
      </label>
      <div className="flex gap-2 mb-2">
        <input
          type="text"
          className="flex-1 border border-gray-300 rounded-lg px-3 py-2"
          value={variableInput}
          onChange={(e) => setVariableInput(e.target.value)}
          placeholder="Add a variable (e.g. name, date)"
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              handleAddVariable();
            }
          }}
        />
        <button
          type="button"
          onClick={handleAddVariable}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>
      
      <div className="flex flex-wrap gap-2 mb-4">
        {variables.map(variable => (
          <div 
            key={variable} 
            className="flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-800 rounded-full"
          >
            <span>{`{{${variable}}}`}</span>
            <button
              type="button"
              onClick={() => onRemoveVariable(variable)}
              className="text-blue-600 hover:text-blue-800"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>
      
      {variables.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-2">
          {variables.map(variable => (
            <button
              key={variable}
              type="button"
              onClick={() => onInsertVariable(variable)}
              className="px-3 py-1 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
            >
              Insert {`{{${variable}}}`}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}