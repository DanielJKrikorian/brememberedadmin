import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  MessageCircle, Heart, Calendar, User, Pin, 
  Megaphone, Eye, MessageSquare, Paperclip
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface CommunityPost {
  id: string;
  title: string;
  content: string;
  is_pinned: boolean;
  is_announcement: boolean;
  view_count: number;
  created_at: string;
  author: {
    name: string;
    profile_image_url: string | null;
  };
  board: {
    name: string;
    type: string;
  };
  comments_count: number;
  reactions_count: number;
  attachments_count: number;
}

interface CommunityPostCardProps {
  post: CommunityPost;
  onClick?: () => void;
}

export default function CommunityPostCard({ post, onClick }: CommunityPostCardProps) {
  const navigate = useNavigate();
  
  const handleClick = () => {
    if (onClick) {
      onClick();
    } else {
      navigate(`/community/post/${post.id}`);
    }
  };
  
  return (
    <div 
      className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow cursor-pointer"
      onClick={handleClick}
    >
      <div className="flex items-start justify-between mb-2">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            {post.is_pinned && (
              <Pin className="w-4 h-4 text-blue-600" />
            )}
            {post.is_announcement && (
              <Megaphone className="w-4 h-4 text-red-600" />
            )}
            <h3 className="text-lg font-medium text-gray-900 line-clamp-1">{post.title}</h3>
          </div>
          
          <div className="flex items-center text-xs text-gray-500 mt-1">
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 mr-2">
              {post.board.name}
            </span>
            <div className="flex items-center">
              {post.author.profile_image_url ? (
                <img 
                  src={post.author.profile_image_url} 
                  alt={post.author.name}
                  className="w-4 h-4 rounded-full mr-1"
                />
              ) : (
                <User className="w-3 h-3 mr-1" />
              )}
              <span className="mr-2">{post.author.name}</span>
            </div>
            <Calendar className="w-3 h-3 mr-1" />
            <span>{formatDistanceToNow(new Date(post.created_at), { addSuffix: true })}</span>
          </div>
        </div>
      </div>
      
      <p className="text-gray-600 text-sm line-clamp-2 mb-3">{post.content}</p>
      
      <div className="flex items-center justify-between text-xs text-gray-500">
        <div className="flex items-center gap-3">
          <div className="flex items-center">
            <MessageSquare className="w-3 h-3 mr-1" />
            <span>{post.comments_count}</span>
          </div>
          <div className="flex items-center">
            <Heart className="w-3 h-3 mr-1" />
            <span>{post.reactions_count}</span>
          </div>
          <div className="flex items-center">
            <Eye className="w-3 h-3 mr-1" />
            <span>{post.view_count}</span>
          </div>
          {post.attachments_count > 0 && (
            <div className="flex items-center">
              <Paperclip className="w-3 h-3 mr-1" />
              <span>{post.attachments_count}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}