import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  Bell, User, MessageSquare, Calendar, Package, Building2, 
  ShoppingBag, Truck, FileText, DollarSign, ChevronRight, 
  RefreshCw, Shield, Clock
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface Notification {
  id: string;
  type: 'lead' | 'message' | 'post' | 'booking' | 'vendor' | 'background_check' | 'sale' | 'rental' | 'quote';
  title: string;
  description: string;
  timestamp: string;
  link: string;
  icon: React.ReactNode;
}

export default function DashboardNotifications() {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchNotifications();
  }, []);

  async function fetchNotifications() {
    setRefreshing(true);
    try {
      // Fetch the latest leads
      const { data: leads } = await supabase
        .from('leads')
        .select('id, name, created_at')
        .order('created_at', { ascending: false })
        .limit(5);

      // Fetch the latest inbox messages
      const { data: messages } = await supabase
        .from('inbox_messages')
        .select('id, name, subject, created_at')
        .order('created_at', { ascending: false })
        .limit(5);

      // Fetch the latest community posts
      const { data: posts } = await supabase
        .from('community_posts')
        .select(`
          id, 
          title, 
          created_at,
          author:team_members(name)
        `)
        .order('created_at', { ascending: false })
        .limit(5);

      // Fetch the latest bookings
      const { data: bookings } = await supabase
        .from('bookings')
        .select(`
          id, 
          created_at,
          lead:leads(name)
        `)
        .order('created_at', { ascending: false })
        .limit(5);

      // Fetch the latest vendors
      const { data: vendors } = await supabase
        .from('vendors')
        .select('id, name, created_at')
        .order('created_at', { ascending: false })
        .limit(5);

      // Fetch the latest background checks
      const { data: backgroundChecks } = await supabase
        .from('vendor_background_checks')
        .select(`
          id, 
          status,
          submitted_at,
          vendor:vendors(id, name)
        `)
        .order('submitted_at', { ascending: false })
        .limit(5);

      // Fetch the latest orders (sales)
      const { data: orders } = await supabase
        .from('orders')
        .select(`
          id, 
          created_at,
          vendor:vendors(name)
        `)
        .order('created_at', { ascending: false })
        .limit(5);

      // Fetch the latest rental bookings
      const { data: rentalBookings } = await supabase
        .from('rental_bookings')
        .select(`
          id, 
          created_at,
          rental_item:rental_items(name),
          lead:leads(name),
          vendor:vendors(name)
        `)
        .order('created_at', { ascending: false })
        .limit(5);

      // Fetch the latest quotes
      const { data: quotes } = await supabase
        .from('quotes')
        .select(`
          id, 
          created_at,
          lead:leads(name)
        `)
        .order('created_at', { ascending: false })
        .limit(5);

      // Combine all notifications
      const allNotifications: Notification[] = [
        ...(leads || []).map(lead => ({
          id: `lead-${lead.id}`,
          type: 'lead' as const,
          title: 'New Lead',
          description: `${lead.name} was added as a new lead`,
          timestamp: lead.created_at,
          link: `/leads/${lead.id}`,
          icon: <User className="w-5 h-5 text-blue-500" />
        })),
        ...(messages || []).map(message => ({
          id: `message-${message.id}`,
          type: 'message' as const,
          title: 'New Message',
          description: `${message.name}: ${message.subject}`,
          timestamp: message.created_at,
          link: `/inbox`,
          icon: <MessageSquare className="w-5 h-5 text-purple-500" />
        })),
        ...(posts || []).map(post => ({
          id: `post-${post.id}`,
          type: 'post' as const,
          title: 'New Community Post',
          description: `${post.author?.name || 'Someone'} posted: ${post.title}`,
          timestamp: post.created_at,
          link: `/community/post/${post.id}`,
          icon: <MessageSquare className="w-5 h-5 text-green-500" />
        })),
        ...(bookings || []).map(booking => ({
          id: `booking-${booking.id}`,
          type: 'booking' as const,
          title: 'New Booking',
          description: `New booking created for ${booking.lead?.name || 'a client'}`,
          timestamp: booking.created_at,
          link: `/bookings/${booking.id}`,
          icon: <Calendar className="w-5 h-5 text-indigo-500" />
        })),
        ...(vendors || []).map(vendor => ({
          id: `vendor-${vendor.id}`,
          type: 'vendor' as const,
          title: 'New Vendor',
          description: `${vendor.name} was added as a new vendor`,
          timestamp: vendor.created_at,
          link: `/vendors/${vendor.id}`,
          icon: <Building2 className="w-5 h-5 text-orange-500" />
        })),
        ...(backgroundChecks || []).map(check => ({
          id: `background-check-${check.id}`,
          type: 'background_check' as const,
          title: 'Background Check',
          description: `${check.vendor?.name || 'A vendor'} submitted a background check (${check.status})`,
          timestamp: check.submitted_at,
          link: `/vendor-background-checks`,
          icon: <Shield className="w-5 h-5 text-red-500" />
        })),
        ...(orders || []).map(order => ({
          id: `order-${order.id}`,
          type: 'sale' as const,
          title: 'New Sale',
          description: `New order from ${order.vendor?.name || 'a vendor'}`,
          timestamp: order.created_at,
          link: `/store`,
          icon: <ShoppingBag className="w-5 h-5 text-emerald-500" />
        })),
        ...(rentalBookings || []).map(booking => ({
          id: `rental-${booking.id}`,
          type: 'rental' as const,
          title: 'New Rental',
          description: `${booking.lead?.name || booking.vendor?.name || 'Someone'} rented ${booking.rental_item?.name || 'an item'}`,
          timestamp: booking.created_at,
          link: `/rentals/booking/${booking.id}`,
          icon: <Truck className="w-5 h-5 text-cyan-500" />
        })),
        ...(quotes || []).map(quote => ({
          id: `quote-${quote.id}`,
          type: 'quote' as const,
          title: 'New Quote',
          description: `Quote created for ${quote.lead?.name || 'a client'}`,
          timestamp: quote.created_at,
          link: `/quotes/${quote.id}`,
          icon: <FileText className="w-5 h-5 text-yellow-500" />
        }))
      ];

      // Sort by timestamp (newest first)
      allNotifications.sort((a, b) => 
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );

      setNotifications(allNotifications);
    } catch (error) {
      console.error('Error fetching notifications:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden dark:bg-gray-800">
      <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center">
          <Bell className="w-5 h-5 text-gray-500 mr-2 dark:text-gray-400" />
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Recent Activity</h2>
        </div>
        <button 
          onClick={fetchNotifications}
          className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
          disabled={refreshing}
        >
          <RefreshCw className={`w-5 h-5 ${refreshing ? 'animate-spin' : ''}`} />
        </button>
      </div>

      <div className="divide-y divide-gray-200 dark:divide-gray-700">
        {loading ? (
          <div className="flex justify-center items-center py-8">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
          </div>
        ) : notifications.length === 0 ? (
          <div className="py-8 text-center text-gray-500 dark:text-gray-400">
            <p>No recent activity found</p>
          </div>
        ) : (
          notifications.slice(0, 5).map((notification) => (
            <div 
              key={notification.id}
              className="px-6 py-4 hover:bg-gray-50 cursor-pointer dark:hover:bg-gray-700"
              onClick={() => navigate(notification.link)}
            >
              <div className="flex items-start">
                <div className="flex-shrink-0 mt-1">
                  {notification.icon}
                </div>
                <div className="ml-3 flex-1">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">{notification.title}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {formatDistanceToNow(new Date(notification.timestamp), { addSuffix: true })}
                    </p>
                  </div>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{notification.description}</p>
                </div>
                <div className="ml-2">
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="px-6 py-3 bg-gray-50 dark:bg-gray-700">
        <button 
          onClick={() => navigate('/inbox')}
          className="text-sm text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 font-medium"
        >
          View all activity
        </button>
      </div>
    </div>
  );
}