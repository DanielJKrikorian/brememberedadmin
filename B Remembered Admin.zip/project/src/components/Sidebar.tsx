import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, Users, Briefcase, Building2, MapPin, 
  ClipboardList, DollarSign, Wallet, LogOut, FileText, Package, 
  FileSignature, Newspaper, Inbox, Tag, Settings, ShoppingBag, Truck,
  MessageCircle, Settings as SettingsIcon, Shield, ChevronDown, ChevronRight,
  HardDrive, FolderOpen, Send, Database, Mail
} from 'lucide-react';
import { useAuthStore } from '../store/authStore';

// Define sidebar categories and their items
const sidebarCategories = [
  {
    name: 'Dashboard',
    icon: LayoutDashboard,
    items: [
      { to: '/dashboard', label: 'Overview', icon: LayoutDashboard }
    ]
  },
  {
    name: 'Communication',
    icon: Inbox,
    items: [
      { to: '/inbox', label: 'Inbox', icon: Inbox },
      { to: '/newsletters', label: 'Newsletters', icon: Mail },
      { to: '/email-templates', label: 'Message Templates', icon: FileText },
      { to: '/community', label: 'Community', icon: MessageCircle },
      { to: '/content-transfer', label: 'Content Transfer', icon: Send }
    ]
  },
  {
    name: 'Customers',
    icon: Users,
    items: [
      { to: '/leads', label: 'Leads', icon: Users },
      { to: '/quotes', label: 'Quotes', icon: FileText },
      { to: '/bookings', label: 'Bookings', icon: Briefcase }
    ]
  },
  {
    name: 'Services',
    icon: Package,
    items: [
      { to: '/services', label: 'Services', icon: Package },
      { to: '/contracts', label: 'Contracts', icon: FileSignature },
      { to: '/discounts', label: 'Discounts', icon: Tag },
      { to: '/custom-packages', label: 'Custom Packages', icon: SettingsIcon }
    ]
  },
  {
    name: 'Partners',
    icon: Building2,
    items: [
      { to: '/vendors', label: 'Vendors', icon: Building2 },
      { to: '/vendor-background-checks', label: 'Background Checks', icon: Shield },
      { to: '/venues', label: 'Venues', icon: MapPin },
      { to: '/jobs', label: 'Job Board', icon: ClipboardList }
    ]
  },
  {
    name: 'Products',
    icon: ShoppingBag,
    items: [
      { to: '/store', label: 'Store', icon: ShoppingBag },
      { to: '/rentals', label: 'Rentals', icon: Truck }
    ]
  },
  {
    name: 'Storage',
    icon: HardDrive,
    items: [
      { to: '/vendor-storage', label: 'Vendor Storage', icon: HardDrive },
      { to: '/couple-storage', label: 'Couple Storage', icon: FolderOpen },
      { to: '/storage-plans', label: 'Storage Plans', icon: Database }
    ]
  },
  {
    name: 'Content',
    icon: Newspaper,
    items: [
      { to: '/blog', label: 'Blog', icon: Newspaper }
    ]
  },
  {
    name: 'Finance',
    icon: DollarSign,
    items: [
      { to: '/finance', label: 'Finance', icon: DollarSign },
      { to: '/payouts', label: 'Payouts', icon: Wallet }
    ]
  },
  {
    name: 'Settings',
    icon: Settings,
    items: [
      { to: '/settings', label: 'Settings', icon: Settings }
    ]
  }
];

const Sidebar = () => {
  const signOut = useAuthStore(state => state.signOut);
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({
    Dashboard: true,
    Communication: true,
    Customers: true,
    Services: true,
    Partners: true,
    Products: true,
    Storage: true,
    Content: true,
    Finance: true,
    Settings: true
  });

  const toggleCategory = (categoryName: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [categoryName]: !prev[categoryName]
    }));
  };

  return (
    <div className="h-screen w-56 bg-white border-r border-gray-200 flex flex-col dark:bg-gray-800 dark:border-gray-700 flex-shrink-0">
      <div className="p-6 border-b border-gray-200 flex justify-center dark:border-gray-700">
        <div className="w-40">
          <img 
            src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png" 
            alt="B. Remembered Logo" 
            className="w-full h-auto object-contain"
          />
        </div>
      </div>
      
      <nav className="flex-1 overflow-y-auto hover:overflow-y-scroll px-4 py-6">
        <div className="space-y-1">
          {sidebarCategories.map((category) => (
            <div key={category.name} className="mb-2">
              <button
                onClick={() => toggleCategory(category.name)}
                className="w-full flex items-center justify-between px-4 py-2 text-sm font-medium text-gray-700 rounded-lg hover:bg-gray-50 dark:text-gray-200 dark:hover:bg-gray-700"
              >
                <div className="flex items-center">
                  <category.icon size={18} className="mr-3" />
                  <span>{category.name}</span>
                </div>
                {expandedCategories[category.name] ? (
                  <ChevronDown size={16} />
                ) : (
                  <ChevronRight size={16} />
                )}
              </button>
              
              {expandedCategories[category.name] && (
                <div className="mt-1 ml-6 space-y-1">
                  {category.items.map((item) => (
                    <NavLink
                      key={item.to}
                      to={item.to}
                      className={({ isActive }) =>
                        `flex items-center px-4 py-2 text-sm rounded-lg mb-1 transition-colors ${
                          isActive
                            ? 'bg-blue-50 text-blue-600 dark:bg-blue-900 dark:text-blue-200'
                            : 'text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-700'
                        }`
                      }
                    >
                      <item.icon size={16} className="mr-3" />
                      <span>{item.label}</span>
                    </NavLink>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </nav>

      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
        <button
          onClick={() => signOut()}
          className="flex items-center space-x-3 px-4 py-3 w-full text-gray-600 hover:bg-gray-50 rounded-lg transition-colors dark:text-gray-300 dark:hover:bg-gray-700"
        >
          <LogOut size={20} />
          <span>Sign Out</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;