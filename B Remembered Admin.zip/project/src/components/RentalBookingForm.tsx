import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Calendar, Clock, DollarSign, User, Building2, Repeat, AlertCircle, MapPin, Truck } from 'lucide-react';

interface RentalRate {
  id: string;
  duration_type: 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly';
  rate: number;
  minimum_duration: number;
  is_subscription: boolean;
}

interface RentalItem {
  id: string;
  name: string;
  rates: RentalRate[];
}

interface Lead {
  id: string;
  name: string;
  email: string;
}

interface Vendor {
  id: string;
  name: string;
  email: string;
}

interface RentalBookingFormProps {
  rentalItemId?: string;
  onSubmit: (bookingData: any) => Promise<void>;
  onCancel: () => void;
}

export default function RentalBookingForm({ rentalItemId, onSubmit, onCancel }: RentalBookingFormProps) {
  const [rentalItems, setRentalItems] = useState<RentalItem[]>([]);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [calculating, setCalculating] = useState(false);
  
  const [formData, setFormData] = useState({
    rental_item_id: rentalItemId || '',
    customer_type: 'lead' as 'lead' | 'vendor',
    lead_id: '',
    vendor_id: '',
    start_date: new Date().toISOString().split('T')[0],
    end_date: '',
    duration_type: '' as 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly',
    rate: 0,
    total_amount: 0,
    is_subscription: false,
    subscription_end_date: '',
    deposit_amount: 0,
    deposit_paid: false,
    notes: '',
    delivery_method: 'pickup' as 'pickup' | 'shipping',
    pickup_date: new Date().toISOString().split('T')[0],
    pickup_time: '10:00',
    pickup_location: '',
    shipping_address: '',
    shipping_method: '',
    shipping_notes: ''
  });
  
  const [selectedRate, setSelectedRate] = useState<RentalRate | null>(null);
  const [duration, setDuration] = useState(1);
  
  useEffect(() => {
    Promise.all([
      fetchRentalItems(),
      fetchLeads(),
      fetchVendors()
    ]).then(() => setLoading(false));
  }, []);
  
  useEffect(() => {
    if (rentalItemId) {
      setFormData(prev => ({ ...prev, rental_item_id: rentalItemId }));
    }
  }, [rentalItemId]);
  
  useEffect(() => {
    // When rental item changes, reset rate-related fields
    if (formData.rental_item_id) {
      const item = rentalItems.find(item => item.id === formData.rental_item_id);
      if (item && item.rates.length > 0) {
        // Default to the first rate
        const firstRate = item.rates[0];
        setFormData(prev => ({
          ...prev,
          duration_type: firstRate.duration_type,
          rate: firstRate.rate,
          is_subscription: firstRate.is_subscription
        }));
        setSelectedRate(firstRate);
      }
    }
  }, [formData.rental_item_id, rentalItems]);
  
  useEffect(() => {
    // Calculate total amount when duration, rate, or subscription status changes
    calculateTotalAmount();
  }, [duration, selectedRate, formData.is_subscription, formData.subscription_end_date]);
  
  async function fetchRentalItems() {
    try {
      const { data, error } = await supabase
        .from('rental_items')
        .select(`
          id,
          name,
          rates:rental_rates(*)
        `)
        .eq('status', 'available')
        .order('name');

      if (error) throw error;
      setRentalItems(data || []);
    } catch (err) {
      console.error('Error fetching rental items:', err);
      setError('Failed to load rental items');
    }
  }
  
  async function fetchLeads() {
    try {
      const { data, error } = await supabase
        .from('leads')
        .select('id, name, email')
        .order('name');

      if (error) throw error;
      setLeads(data || []);
    } catch (err) {
      console.error('Error fetching leads:', err);
      setError('Failed to load leads');
    }
  }
  
  async function fetchVendors() {
    try {
      const { data, error } = await supabase
        .from('vendors')
        .select('id, name, email')
        .eq('approved', true)
        .order('name');

      if (error) throw error;
      setVendors(data || []);
    } catch (err) {
      console.error('Error fetching vendors:', err);
      setError('Failed to load vendors');
    }
  }
  
  function calculateTotalAmount() {
    setCalculating(true);
    
    try {
      if (!selectedRate) return;
      
      let total = selectedRate.rate * duration;
      
      // For subscriptions, calculate based on subscription end date
      if (formData.is_subscription && formData.subscription_end_date) {
        const startDate = new Date(formData.start_date);
        const endDate = new Date(formData.subscription_end_date);
        
        if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) return;
        
        let periods = 0;
        
        switch (selectedRate.duration_type) {
          case 'hourly':
            // Calculate hours between dates
            periods = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60));
            break;
          case 'daily':
            // Calculate days between dates
            periods = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
            break;
          case 'weekly':
            // Calculate weeks between dates
            periods = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24 * 7));
            break;
          case 'monthly':
            // Calculate months between dates (approximate)
            periods = (endDate.getFullYear() - startDate.getFullYear()) * 12 + 
                     (endDate.getMonth() - startDate.getMonth());
            if (endDate.getDate() > startDate.getDate()) periods += 1;
            break;
          case 'yearly':
            // Calculate years between dates
            periods = endDate.getFullYear() - startDate.getFullYear();
            if (endDate.getMonth() > startDate.getMonth() || 
                (endDate.getMonth() === startDate.getMonth() && endDate.getDate() > startDate.getDate())) {
              periods += 1;
            }
            break;
        }
        
        total = selectedRate.rate * Math.max(periods, 1);
      }
      
      setFormData(prev => ({
        ...prev,
        total_amount: total,
        deposit_amount: 0 // No deposit needed as we're collecting full payment upfront
      }));
    } catch (err) {
      console.error('Error calculating total:', err);
    } finally {
      setCalculating(false);
    }
  }
  
  function handleRateChange(rateId: string) {
    const item = rentalItems.find(item => item.id === formData.rental_item_id);
    if (!item) return;
    
    const rate = item.rates.find(r => r.id === rateId);
    if (!rate) return;
    
    setSelectedRate(rate);
    setFormData(prev => ({
      ...prev,
      duration_type: rate.duration_type,
      rate: rate.rate,
      is_subscription: rate.is_subscription
    }));
  }
  
  function calculateEndDate() {
    if (!formData.start_date || !selectedRate) return;
    
    const startDate = new Date(formData.start_date);
    let endDate = new Date(startDate);
    
    switch (selectedRate.duration_type) {
      case 'hourly':
        endDate.setHours(endDate.getHours() + duration);
        break;
      case 'daily':
        endDate.setDate(endDate.getDate() + duration);
        break;
      case 'weekly':
        endDate.setDate(endDate.getDate() + (duration * 7));
        break;
      case 'monthly':
        endDate.setMonth(endDate.getMonth() + duration);
        break;
      case 'yearly':
        endDate.setFullYear(endDate.getFullYear() + duration);
        break;
    }
    
    return endDate.toISOString().split('T')[0];
  }
  
  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    
    try {
      // Validate form
      if (!formData.rental_item_id) {
        throw new Error('Please select a rental item');
      }
      
      if (formData.customer_type === 'lead' && !formData.lead_id) {
        throw new Error('Please select a lead');
      }
      
      if (formData.customer_type === 'vendor' && !formData.vendor_id) {
        throw new Error('Please select a vendor');
      }
      
      if (!formData.start_date) {
        throw new Error('Please select a start date');
      }
      
      if (!selectedRate) {
        throw new Error('Please select a rate');
      }
      
      if (duration < (selectedRate?.minimum_duration || 1)) {
        throw new Error(`Minimum duration is ${selectedRate?.minimum_duration} ${selectedRate?.duration_type}`);
      }
      
      if (formData.is_subscription && !formData.subscription_end_date) {
        throw new Error('Please select a subscription end date');
      }
      
      // Validate delivery method
      if (formData.delivery_method === 'pickup') {
        if (!formData.pickup_date) {
          throw new Error('Please select a pickup date');
        }
        if (!formData.pickup_location) {
          throw new Error('Please enter a pickup location');
        }
      } else if (formData.delivery_method === 'shipping') {
        if (!formData.shipping_address) {
          throw new Error('Please enter a shipping address');
        }
      }
      
      // Calculate end date if not a subscription
      const endDate = formData.is_subscription 
        ? formData.start_date // For subscriptions, end_date is same as start_date
        : calculateEndDate();
      
      if (!endDate) {
        throw new Error('Failed to calculate end date');
      }
      
      // Get customer email for payment link
      let customerEmail = '';
      let customerName = '';
      
      if (formData.customer_type === 'lead' && formData.lead_id) {
        const lead = leads.find(l => l.id === formData.lead_id);
        if (lead) {
          customerEmail = lead.email;
          customerName = lead.name;
        }
      } else if (formData.customer_type === 'vendor' && formData.vendor_id) {
        const vendor = vendors.find(v => v.id === formData.vendor_id);
        if (vendor) {
          customerEmail = vendor.email;
          customerName = vendor.name;
        }
      }
      
      // Format pickup date and time
      let pickupDateTime = null;
      if (formData.delivery_method === 'pickup' && formData.pickup_date && formData.pickup_time) {
        pickupDateTime = new Date(`${formData.pickup_date}T${formData.pickup_time}`).toISOString();
      }
      
      // Prepare booking data
      const bookingData = {
        rental_item_id: formData.rental_item_id,
        lead_id: formData.customer_type === 'lead' ? formData.lead_id : null,
        vendor_id: formData.customer_type === 'vendor' ? formData.vendor_id : null,
        start_date: new Date(formData.start_date).toISOString(),
        end_date: new Date(endDate).toISOString(),
        duration_type: formData.duration_type,
        rate: formData.rate,
        total_amount: formData.total_amount,
        status: 'pending',
        is_subscription: formData.is_subscription,
        subscription_end_date: formData.is_subscription ? new Date(formData.subscription_end_date).toISOString() : null,
        deposit_amount: 0, // No deposit needed as we're collecting full payment upfront
        deposit_paid: false,
        notes: formData.notes,
        payment_status: 'unpaid',
        
        // Delivery method details
        delivery_method: formData.delivery_method,
        pickup_date: pickupDateTime,
        pickup_location: formData.delivery_method === 'pickup' ? formData.pickup_location : null,
        shipping_address: formData.delivery_method === 'shipping' ? formData.shipping_address : null,
        shipping_method: formData.delivery_method === 'shipping' ? formData.shipping_method : null,
        shipping_notes: formData.delivery_method === 'shipping' ? formData.shipping_notes : null,
        
        // Include customer info for UI
        lead: formData.customer_type === 'lead' ? leads.find(l => l.id === formData.lead_id) : null,
        vendor: formData.customer_type === 'vendor' ? vendors.find(v => v.id === formData.vendor_id) : null
      };
      
      onSubmit(bookingData);
    } catch (err) {
      console.error('Error submitting form:', err);
      setError(err instanceof Error ? err.message : 'Failed to create booking');
    }
  }
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Rental Item *
        </label>
        <select
          className="w-full border border-gray-300 rounded-lg px-3 py-2"
          value={formData.rental_item_id}
          onChange={(e) => setFormData({ ...formData, rental_item_id: e.target.value })}
          disabled={!!rentalItemId}
          required
        >
          <option value="">Select a rental item</option>
          {rentalItems.map(item => (
            <option key={item.id} value={item.id}>{item.name}</option>
          ))}
        </select>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Customer Type *
        </label>
        <div className="flex gap-4">
          <label className="flex items-center">
            <input
              type="radio"
              checked={formData.customer_type === 'lead'}
              onChange={() => setFormData({ ...formData, customer_type: 'lead', vendor_id: '' })}
              className="text-blue-600 focus:ring-blue-500"
            />
            <span className="ml-2">Lead</span>
          </label>
          <label className="flex items-center">
            <input
              type="radio"
              checked={formData.customer_type === 'vendor'}
              onChange={() => setFormData({ ...formData, customer_type: 'vendor', lead_id: '' })}
              className="text-blue-600 focus:ring-blue-500"
            />
            <span className="ml-2">Vendor</span>
          </label>
        </div>
      </div>
      
      {formData.customer_type === 'lead' && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Lead *
          </label>
          <select
            className="w-full border border-gray-300 rounded-lg px-3 py-2"
            value={formData.lead_id}
            onChange={(e) => setFormData({ ...formData, lead_id: e.target.value })}
            required
          >
            <option value="">Select a lead</option>
            {leads.map(lead => (
              <option key={lead.id} value={lead.id}>{lead.name} ({lead.email})</option>
            ))}
          </select>
        </div>
      )}
      
      {formData.customer_type === 'vendor' && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Vendor *
          </label>
          <select
            className="w-full border border-gray-300 rounded-lg px-3 py-2"
            value={formData.vendor_id}
            onChange={(e) => setFormData({ ...formData, vendor_id: e.target.value })}
            required
          >
            <option value="">Select a vendor</option>
            {vendors.map(vendor => (
              <option key={vendor.id} value={vendor.id}>{vendor.name} ({vendor.email})</option>
            ))}
          </select>
        </div>
      )}
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Start Date *
        </label>
        <div className="relative">
          <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="date"
            className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg"
            value={formData.start_date}
            onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
            min={new Date().toISOString().split('T')[0]}
            required
          />
        </div>
      </div>
      
      {formData.rental_item_id && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Rate *
          </label>
          <div className="space-y-3">
            {rentalItems.find(item => item.id === formData.rental_item_id)?.rates.map(rate => (
              <label key={rate.id} className="flex items-center p-3 border rounded-lg hover:bg-gray-50 cursor-pointer">
                <input
                  type="radio"
                  checked={selectedRate?.id === rate.id}
                  onChange={() => handleRateChange(rate.id)}
                  className="text-blue-600 focus:ring-blue-500"
                />
                <div className="ml-3 flex-1">
                  <div className="flex items-center">
                    <span className="font-medium">${rate.rate}</span>
                    <span className="mx-1">per</span>
                    <span>{rate.duration_type}</span>
                    {rate.minimum_duration > 1 && (
                      <span className="ml-1 text-sm text-gray-500">
                        (min. {rate.minimum_duration})
                      </span>
                    )}
                  </div>
                  {rate.is_subscription && (
                    <div className="text-sm text-blue-600 flex items-center mt-1">
                      <Repeat className="w-4 h-4 mr-1" />
                      Available as subscription
                    </div>
                  )}
                </div>
              </label>
            ))}
            
            {(!rentalItems.find(item => item.id === formData.rental_item_id)?.rates.length) && (
              <div className="text-center py-4 text-gray-500">
                No rates available for this item
              </div>
            )}
          </div>
        </div>
      )}
      
      {selectedRate && (
        <>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Duration *
            </label>
            <div className="flex items-center">
              <input
                type="number"
                className="w-24 border border-gray-300 rounded-lg px-3 py-2"
                value={duration}
                onChange={(e) => setDuration(parseInt(e.target.value) || 1)}
                min={selectedRate.minimum_duration}
                required
                disabled={formData.is_subscription}
              />
              <span className="ml-2 text-gray-700">
                {selectedRate.duration_type}
                {duration !== 1 && 's'}
              </span>
            </div>
          </div>
          
          {selectedRate.is_subscription && (
            <div>
              <label className="flex items-center mb-2">
                <input
                  type="checkbox"
                  checked={formData.is_subscription}
                  onChange={(e) => setFormData({ ...formData, is_subscription: e.target.checked })}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="ml-2 text-sm text-gray-700">Book as subscription</span>
              </label>
              
              {formData.is_subscription && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Subscription End Date *
                  </label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      type="date"
                      className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg"
                      value={formData.subscription_end_date}
                      onChange={(e) => setFormData({ ...formData, subscription_end_date: e.target.value })}
                      min={formData.start_date}
                      required
                    />
                  </div>
                </div>
              )}
            </div>
          )}
          
          {/* Delivery Method Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Delivery Method *
            </label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <label className={`flex items-center p-4 border rounded-lg cursor-pointer ${
                formData.delivery_method === 'pickup' ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'
              }`}>
                <input
                  type="radio"
                  checked={formData.delivery_method === 'pickup'}
                  onChange={() => setFormData({ ...formData, delivery_method: 'pickup' })}
                  className="text-blue-600 focus:ring-blue-500"
                />
                <div className="ml-3">
                  <div className="font-medium text-gray-900">Pickup</div>
                  <div className="text-sm text-gray-500">Customer will pick up the item</div>
                </div>
              </label>
              
              <label className={`flex items-center p-4 border rounded-lg cursor-pointer ${
                formData.delivery_method === 'shipping' ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'
              }`}>
                <input
                  type="radio"
                  checked={formData.delivery_method === 'shipping'}
                  onChange={() => setFormData({ ...formData, delivery_method: 'shipping' })}
                  className="text-blue-600 focus:ring-blue-500"
                />
                <div className="ml-3">
                  <div className="font-medium text-gray-900">Shipping</div>
                  <div className="text-sm text-gray-500">Item will be shipped to customer</div>
                </div>
              </label>
            </div>
          </div>
          
          {/* Pickup Details */}
          {formData.delivery_method === 'pickup' && (
            <div className="space-y-4 border border-gray-200 rounded-lg p-4">
              <h3 className="font-medium text-gray-900">Pickup Details</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Pickup Date *
                  </label>
                  <input
                    type="date"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={formData.pickup_date}
                    onChange={(e) => setFormData({ ...formData, pickup_date: e.target.value })}
                    min={new Date().toISOString().split('T')[0]}
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Pickup Time *
                  </label>
                  <input
                    type="time"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={formData.pickup_time}
                    onChange={(e) => setFormData({ ...formData, pickup_time: e.target.value })}
                    required
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Pickup Location *
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg"
                    value={formData.pickup_location}
                    onChange={(e) => setFormData({ ...formData, pickup_location: e.target.value })}
                    placeholder="Enter pickup location"
                    required
                  />
                </div>
              </div>
            </div>
          )}
          
          {/* Shipping Details */}
          {formData.delivery_method === 'shipping' && (
            <div className="space-y-4 border border-gray-200 rounded-lg p-4">
              <h3 className="font-medium text-gray-900">Shipping Details</h3>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Shipping Address *
                </label>
                <textarea
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  rows={3}
                  value={formData.shipping_address}
                  onChange={(e) => setFormData({ ...formData, shipping_address: e.target.value })}
                  placeholder="Enter full shipping address"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Shipping Method
                </label>
                <select
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  value={formData.shipping_method}
                  onChange={(e) => setFormData({ ...formData, shipping_method: e.target.value })}
                >
                  <option value="">Select shipping method</option>
                  <option value="Standard">Standard Shipping</option>
                  <option value="Express">Express Shipping</option>
                  <option value="Overnight">Overnight Shipping</option>
                  <option value="Local">Local Delivery</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Shipping Notes
                </label>
                <textarea
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  rows={2}
                  value={formData.shipping_notes}
                  onChange={(e) => setFormData({ ...formData, shipping_notes: e.target.value })}
                  placeholder="Special instructions for shipping"
                />
              </div>
            </div>
          )}
          
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="text-sm font-medium text-gray-700 mb-2">Booking Summary</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Rate:</span>
                <span className="font-medium">${selectedRate.rate}/{selectedRate.duration_type}</span>
              </div>
              
              {formData.is_subscription ? (
                <div className="flex justify-between">
                  <span className="text-gray-600">Subscription:</span>
                  <span className="font-medium">
                    {formData.start_date && formData.subscription_end_date ? (
                      `${formData.start_date} to ${formData.subscription_end_date}`
                    ) : (
                      'Dates not set'
                    )}
                  </span>
                </div>
              ) : (
                <div className="flex justify-between">
                  <span className="text-gray-600">Duration:</span>
                  <span className="font-medium">
                    {duration} {selectedRate.duration_type}
                    {duration !== 1 && 's'}
                  </span>
                </div>
              )}
              
              <div className="flex justify-between">
                <span className="text-gray-600">Delivery Method:</span>
                <span className="font-medium capitalize">{formData.delivery_method}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">Total Amount:</span>
                <span className="font-medium">${formData.total_amount.toFixed(2)}</span>
              </div>
              
              <div className="pt-2 text-sm text-blue-600">
                <p>A payment link will be generated after booking creation.</p>
                <p>Customer will pay the full amount upfront.</p>
                {formData.is_subscription && (
                  <p className="mt-1">For subscriptions, customer will be charged automatically on a {selectedRate.duration_type} basis.</p>
                )}
              </div>
            </div>
          </div>
        </>
      )}
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Notes
        </label>
        <textarea
          className="w-full border border-gray-300 rounded-lg px-3 py-2"
          rows={3}
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          placeholder="Add any special instructions or notes..."
        />
      </div>
      
      <div className="flex justify-end gap-3 pt-4">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          disabled={calculating}
        >
          {calculating ? 'Calculating...' : 'Create Booking'}
        </button>
      </div>
    </form>
  );
}