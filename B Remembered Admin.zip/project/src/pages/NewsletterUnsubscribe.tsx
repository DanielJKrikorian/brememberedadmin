import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { AlertCircle, CheckCircle, Mail, X } from 'lucide-react';

export default function NewsletterUnsubscribe() {
  const { token } = useParams();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [email, setEmail] = useState<string | null>(null);
  
  useEffect(() => {
    if (token) {
      verifyToken();
    }
  }, [token]);
  
  async function verifyToken() {
    try {
      // Call the edge function to verify the token
      const response = await fetch('/functions/v1/verify-unsubscribe-token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          token,
        }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Invalid or expired token');
      }
      
      setEmail(data.email);
    } catch (err) {
      console.error('Error verifying token:', err);
      setError(err instanceof Error ? err.message : 'Failed to verify token');
    } finally {
      setLoading(false);
    }
  }
  
  async function handleUnsubscribe() {
    try {
      if (!email) return;
      
      // Update subscriber status
      const { error } = await supabase
        .from('newsletter_subscribers')
        .update({
          status: 'unsubscribed',
          unsubscribed_at: new Date().toISOString()
        })
        .eq('email', email);
        
      if (error) throw error;
      
      setSuccess(true);
    } catch (err) {
      console.error('Error unsubscribing:', err);
      setError('Failed to unsubscribe. Please try again.');
    }
  }
  
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-lg shadow-md p-8 text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Error</h1>
          <p className="text-gray-600 mb-6">{error}</p>
          <p className="text-gray-500">
            If you're having trouble unsubscribing, please contact us directly.
          </p>
        </div>
      </div>
    );
  }
  
  if (success) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-lg shadow-md p-8 text-center">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Unsubscribed</h1>
          <p className="text-gray-600 mb-6">
            You have been successfully unsubscribed from our newsletter.
          </p>
          <p className="text-gray-500">
            We're sorry to see you go. If you change your mind, you can always subscribe again.
          </p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-lg shadow-md p-8">
        <div className="text-center mb-6">
          <img 
            src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png" 
            alt="B. Remembered Logo" 
            className="h-16 mx-auto mb-4"
          />
          <h1 className="text-2xl font-bold text-gray-900">Unsubscribe</h1>
          <p className="mt-2 text-gray-600">
            Are you sure you want to unsubscribe from our newsletter?
          </p>
        </div>
        
        <div className="mb-6 p-4 bg-gray-50 border border-gray-200 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Mail className="w-5 h-5 text-gray-400" />
            <span className="font-medium text-gray-900">{email}</span>
          </div>
          <p className="text-sm text-gray-500">
            You will no longer receive newsletters from B. Remembered Weddings.
          </p>
        </div>
        
        <div className="flex justify-between">
          <a
            href="/"
            className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
          >
            Cancel
          </a>
          <button
            onClick={handleUnsubscribe}
            className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
          >
            Unsubscribe
          </button>
        </div>
      </div>
    </div>
  );
}