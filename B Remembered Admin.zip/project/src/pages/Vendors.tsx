import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { PlusCircle, Search, X, Check, AlertCircle, Package, ChevronRight, Shield } from 'lucide-react';

interface ServiceVariant {
  id: string;
  name: string;
  price: number;
  hours: number | null;
  description: string | null;
}

interface Service {
  id: string;
  name: string;
  description: string;
  base_price: number;
  variants: ServiceVariant[];
}

interface Vendor {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  status: string;
  onboarding_notes: string | null;
  rating: number | null;
  approved: boolean;
  accepts_custom_packages: boolean;
  background_check_required: boolean;
  background_check_status: string | null;
  stripe_account_id: string | null;
  stripe_onboarding_complete: boolean;
  stripe_onboarding_url: string | null;
  created_at: string;
  updated_at: string;
  services: Service[];
  service_variants: string[];
}

interface NewVendor {
  name: string;
  email: string;
  phone: string;
  onboarding_notes: string;
  setup_stripe: boolean;
  background_check_required: boolean;
  services: string[];
  service_variants: string[];
}

export default function Vendors() {
  const navigate = useNavigate();
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [expandedServices, setExpandedServices] = useState<{ [key: string]: boolean }>({});
  const [newVendor, setNewVendor] = useState<NewVendor>({
    name: '',
    email: '',
    phone: '',
    onboarding_notes: '',
    setup_stripe: false,
    background_check_required: false,
    services: [],
    service_variants: [],
  });

  useEffect(() => {
    fetchVendors();
    fetchServices();
  }, []);

  async function fetchServices() {
    try {
      const { data, error } = await supabase
        .from('services')
        .select(`
          *,
          variants:service_variants(*)
        `)
        .order('name');

      if (error) throw error;
      setServices(data || []);
    } catch (error) {
      console.error('Error fetching services:', error);
    }
  }

  async function handleAddVendor(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    try {
      // First create the vendor
      const { data: vendor, error: vendorError } = await supabase
        .from('vendors')
        .insert({
          name: newVendor.name,
          email: newVendor.email,
          phone: newVendor.phone || null,
          onboarding_notes: newVendor.onboarding_notes || null,
          status: 'pending',
          approved: false,
          background_check_required: newVendor.background_check_required,
        })
        .select()
        .single();

      if (vendorError) throw vendorError;

      // Add vendor services
      if (newVendor.services.length > 0) {
        const { error: servicesError } = await supabase
          .from('vendor_services')
          .insert(
            newVendor.services.map(serviceId => ({
              vendor_id: vendor.id,
              service_id: serviceId,
            }))
          );

        if (servicesError) throw servicesError;
      }

      // Add vendor service variants
      if (newVendor.service_variants.length > 0) {
        const { error: variantsError } = await supabase
          .from('vendor_service_variants')
          .insert(
            newVendor.service_variants.map(variantId => ({
              vendor_id: vendor.id,
              variant_id: variantId,
            }))
          );

        if (variantsError) throw variantsError;
      }

      // Refresh vendors list
      fetchVendors();
      
      // Reset form
      setShowAddModal(false);
      setNewVendor({
        name: '',
        email: '',
        phone: '',
        onboarding_notes: '',
        setup_stripe: false,
        background_check_required: false,
        services: [],
        service_variants: [],
      });
    } catch (err) {
      console.error('Error adding vendor:', err);
      setError('Failed to add vendor. Please try again.');
    } finally {
      setSaving(false);
    }
  }

  async function fetchVendors() {
    try {
      const { data, error } = await supabase
        .from('vendors')
        .select(`
          *,
          services:vendor_services(
            service:services(
              id,
              name,
              description,
              base_price,
              variants:service_variants(*)
            )
          ),
          service_variants:vendor_service_variants(
            variant:service_variants(*)
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const processedVendors = (data || []).map(vendor => ({
        ...vendor,
        services: vendor.services.map((s: any) => s.service),
        service_variants: vendor.service_variants.map((v: any) => v.variant.id),
      }));

      setVendors(processedVendors);
    } catch (error) {
      console.error('Error fetching vendors:', error);
    } finally {
      setLoading(false);
    }
  }

  const toggleServiceExpansion = (vendorId: string) => {
    setExpandedServices(prev => ({
      ...prev,
      [vendorId]: !prev[vendorId]
    }));
  };

  const getBackgroundCheckStatusBadge = (status: string | null) => {
    if (!status) return null;
    
    switch (status) {
      case 'pending':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            <Shield className="w-3 h-3 mr-1" />
            Pending
          </span>
        );
      case 'approved':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <Shield className="w-3 h-3 mr-1" />
            Approved
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            <Shield className="w-3 h-3 mr-1" />
            Rejected
          </span>
        );
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Vendors</h1>
        <div className="flex gap-2">
          <button
            onClick={() => navigate('/vendor-background-checks')}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            <Shield className="w-5 h-5" />
            Background Checks
          </button>
          <button 
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <PlusCircle className="w-5 h-5" />
            Add New Vendor
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Services</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Variants</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Background Check</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {vendors.map((vendor) => (
              <tr key={vendor.id} className="hover:bg-gray-50">
                <td className="px-6 py-4">
                  <div className="text-sm font-medium text-gray-900">{vendor.name}</div>
                  {vendor.phone && (
                    <div className="text-sm text-gray-500">{vendor.phone}</div>
                  )}
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm text-gray-500">{vendor.email}</div>
                </td>
                <td className="px-6 py-4">
                  {vendor.services.length > 0 ? (
                    <div className="space-y-2">
                      {vendor.services.map((service) => (
                        <div key={service.id} className="flex items-center gap-2">
                          <Package className="w-4 h-4 text-gray-400" />
                          <span className="text-sm font-medium text-gray-900">
                            {service.name}
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <span className="text-sm text-gray-500">No services</span>
                  )}
                </td>
                <td className="px-6 py-4">
                  <span className="text-sm text-gray-900">
                    {vendor.service_variants.length} Variants
                  </span>
                </td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                    vendor.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                    vendor.status === 'approved' ? 'bg-green-100 text-green-800' : 
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {vendor.status.charAt(0).toUpperCase() + vendor.status.slice(1)}
                  </span>
                </td>
                <td className="px-6 py-4">
                  {vendor.background_check_required ? (
                    <div className="space-y-1">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        <Shield className="w-3 h-3 mr-1" />
                        Required
                      </span>
                      {getBackgroundCheckStatusBadge(vendor.background_check_status)}
                    </div>
                  ) : (
                    <span className="text-sm text-gray-500">Not required</span>
                  )}
                </td>
                <td className="px-6 py-4 text-sm font-medium">
                  <button
                    onClick={() => navigate(`/vendors/${vendor.id}`)}
                    className="text-gray-600 hover:text-gray-900"
                  >
                    Edit
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900">Add New Vendor</h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
                <AlertCircle className="w-5 h-5" />
                {error}
              </div>
            )}

            <form onSubmit={handleAddVendor} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Name *
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={newVendor.name}
                  onChange={(e) => setNewVendor({ ...newVendor, name: e.target.value })}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email *
                </label>
                <input
                  type="email"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={newVendor.email}
                  onChange={(e) => setNewVendor({ ...newVendor, email: e.target.value })}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Phone
                </label>
                <input
                  type="tel"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={newVendor.phone}
                  onChange={(e) => setNewVendor({ ...newVendor, phone: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Services & Variants
                </label>
                <div className="space-y-4">
                  {services.map((service) => (
                    <div key={service.id} className="border border-gray-200 rounded-lg p-4">
                      <label className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                          checked={newVendor.services.includes(service.id)}
                          onChange={(e) => {
                            const updatedServices = e.target.checked
                              ? [...newVendor.services, service.id]
                              : newVendor.services.filter(id => id !== service.id);
                            
                            // Remove variants of this service if unchecked
                            const updatedVariants = e.target.checked
                              ? newVendor.service_variants
                              : newVendor.service_variants.filter(variantId => 
                                  !service.variants.some(v => v.id === variantId)
                                );
                            
                            setNewVendor({
                              ...newVendor,
                              services: updatedServices,
                              service_variants: updatedVariants,
                            });
                          }}
                        />
                        <span className="text-sm font-medium text-gray-900">{service.name}</span>
                      </label>

                      {newVendor.services.includes(service.id) && service.variants.length > 0 && (
                        <div className="mt-2 ml-6 space-y-2">
                          {service.variants.map((variant) => (
                            <label key={variant.id} className="flex items-center gap-2">
                              <input
                                type="checkbox"
                                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                                checked={newVendor.service_variants.includes(variant.id)}
                                onChange={(e) => {
                                  const updatedVariants = e.target.checked
                                    ? [...newVendor.service_variants, variant.id]
                                    : newVendor.service_variants.filter(id => id !== variant.id);
                                  setNewVendor({
                                    ...newVendor,
                                    service_variants: updatedVariants,
                                  });
                                }}
                              />
                              <div className="text-sm">
                                <span className="text-gray-900">{variant.name}</span>
                                <span className="text-gray-500 ml-2">
                                  (${variant.price}{variant.hours && ` - ${variant.hours}h`})
                                </span>
                              </div>
                            </label>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Onboarding Notes
                </label>
                <textarea
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={3}
                  value={newVendor.onboarding_notes}
                  onChange={(e) => setNewVendor({ ...newVendor, onboarding_notes: e.target.value })}
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="background_check_required"
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  checked={newVendor.background_check_required}
                  onChange={(e) => setNewVendor({ ...newVendor, background_check_required: e.target.checked })}
                />
                <label htmlFor="background_check_required" className="text-sm text-gray-700 flex items-center gap-1">
                  <Shield className="w-4 h-4 text-gray-600" />
                  Require background check
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  disabled={saving}
                >
                  {saving ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      Add Vendor
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}