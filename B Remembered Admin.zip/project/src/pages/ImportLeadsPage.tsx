import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { ArrowLeft, Upload, Download, CheckCircle, AlertCircle, RefreshCw } from 'lucide-react';

interface LeadsList {
  id: number;
  inquiry_name: string;
  partner_name: string | null;
  wedding_date: string | null;
  email: string | null;
  phone_number: string | null;
  venue_address: string | null;
  additional_details: string | null;
  created_at: string;
}

export default function ImportLeadsPage() {
  const navigate = useNavigate();
  const [leadsListData, setLeadsListData] = useState<LeadsList[]>([]);
  const [loading, setLoading] = useState(true);
  const [importing, setImporting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [importedCount, setImportedCount] = useState(0);

  useEffect(() => {
    fetchLeadsList();
  }, []);

  async function fetchLeadsList() {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('leads_list')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setLeadsListData(data || []);
    } catch (err) {
      console.error('Error fetching leads list:', err);
      setError('Failed to load leads list');
    } finally {
      setLoading(false);
    }
  }

  async function handleImport() {
    try {
      setImporting(true);
      setError(null);
      setSuccess(null);

      const response = await fetch('/functions/v1/import-leads-from-list', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to import leads');
      }

      const data = await response.json();
      setImportedCount(data.imported);
      setSuccess(`${data.imported} leads imported successfully`);
    } catch (err) {
      console.error('Error importing leads:', err);
      setError(err instanceof Error ? err.message : 'Failed to import leads');
    } finally {
      setImporting(false);
    }
  }

  function handleExportCSV() {
    // Convert leads list to CSV
    const headers = ['Name', 'Partner Name', 'Wedding Date', 'Email', 'Phone', 'Venue Address', 'Additional Details', 'Created At'];
    const rows = leadsListData.map(lead => [
      lead.inquiry_name || '',
      lead.partner_name || '',
      lead.wedding_date || '',
      lead.email || '',
      lead.phone_number || '',
      lead.venue_address || '',
      lead.additional_details || '',
      lead.created_at || ''
    ]);

    // Create CSV content
    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    // Create download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `leads_list_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/leads')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Import Leads from Leads List</h1>
        </div>
        <div className="flex gap-2">
          <button
            onClick={fetchLeadsList}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
          >
            <RefreshCw className="w-5 h-5" />
            Refresh
          </button>
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
            disabled={leadsListData.length === 0}
          >
            <Download className="w-5 h-5" />
            Export CSV
          </button>
        </div>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}

      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Import Options</h2>
        <p className="text-gray-600 mb-4">
          This tool will import all leads from the <code>leads_list</code> table into the main <code>leads</code> table.
          The import process will map fields appropriately and set default values where needed.
        </p>

        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-700 font-medium">Available leads to import: {leadsListData.length}</p>
            {importedCount > 0 && (
              <p className="text-green-600 mt-1">Successfully imported: {importedCount}</p>
            )}
          </div>
          <button
            onClick={handleImport}
            disabled={importing || leadsListData.length === 0}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            {importing ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                Importing...
              </>
            ) : (
              <>
                <Upload className="w-5 h-5" />
                Import All Leads
              </>
            )}
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Leads List Preview</h2>
        </div>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        ) : leadsListData.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            No leads found in the leads_list table
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Partner</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Wedding Date</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Venue</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {leadsListData.slice(0, 10).map((lead) => (
                  <tr key={lead.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{lead.inquiry_name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{lead.partner_name || '-'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{lead.wedding_date || '-'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{lead.email || '-'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{lead.phone_number || '-'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{lead.venue_address || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {leadsListData.length > 10 && (
              <div className="px-6 py-3 bg-gray-50 text-center text-sm text-gray-500">
                Showing 10 of {leadsListData.length} leads
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}