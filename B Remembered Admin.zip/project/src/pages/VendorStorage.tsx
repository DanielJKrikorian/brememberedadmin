import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { supabase } from '../lib/supabase';
import { 
  Folder, File, Upload, Download, Share, Plus, Trash2, 
  Search, Filter, ArrowLeft, Edit, Save, X, AlertCircle, 
  CheckCircle, Info, MoreHorizontal, ExternalLink, Copy,
  HardDrive, CreditCard, Clock, Users, FolderPlus
} from 'lucide-react';

interface StoragePlan {
  id: string;
  name: string;
  description: string;
  storage_limit: number;
  price_monthly: number;
  price_yearly: number;
  is_active: boolean;
  features: {
    max_folders: number;
    max_shares: number;
  };
}

interface StorageSubscription {
  id: string;
  vendor_id: string;
  plan_id: string;
  status: 'active' | 'canceled' | 'expired';
  storage_used: number;
  billing_cycle: 'monthly' | 'yearly';
  current_period_start: string;
  current_period_end: string;
  stripe_subscription_id: string | null;
  plan: StoragePlan;
}

interface StorageFolder {
  id: string;
  vendor_id: string;
  name: string;
  description: string | null;
  parent_folder_id: string | null;
  path: string;
  is_shared: boolean;
  created_at: string;
  updated_at: string;
  files_count: number;
  total_size: number;
  shares: FolderShare[];
}

interface StorageFile {
  id: string;
  folder_id: string;
  vendor_id: string;
  name: string;
  description: string | null;
  file_type: string;
  file_size: number;
  storage_path: string;
  public_url: string | null;
  uploaded_by: string | null;
  created_at: string;
  updated_at: string;
}

interface FolderShare {
  id: string;
  folder_id: string;
  lead_id: string;
  access_level: 'view' | 'download' | 'upload';
  status: 'pending' | 'active' | 'expired';
  expiration_date: string | null;
  access_code: string | null;
  price_monthly: number;
  lead: {
    name: string;
    email: string;
  };
  subscription: {
    id: string;
    status: 'active' | 'canceled' | 'expired';
  } | null;
}

interface Lead {
  id: string;
  name: string;
  email: string;
}

export default function VendorStorage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  
  // Subscription state
  const [subscription, setSubscription] = useState<StorageSubscription | null>(null);
  const [availablePlans, setAvailablePlans] = useState<StoragePlan[]>([]);
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  
  // Folders and files state
  const [currentVendorId, setCurrentVendorId] = useState<string | null>(null);
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null);
  const [folderPath, setFolderPath] = useState<{id: string; name: string}[]>([]);
  const [folders, setFolders] = useState<StorageFolder[]>([]);
  const [files, setFiles] = useState<StorageFile[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  
  // New folder state
  const [showNewFolderModal, setShowNewFolderModal] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [newFolderDescription, setNewFolderDescription] = useState('');
  
  // File upload state
  const [uploadProgress, setUploadProgress] = useState<{[key: string]: number}>({});
  
  // Share folder state
  const [showShareModal, setShowShareModal] = useState(false);
  const [selectedFolder, setSelectedFolder] = useState<StorageFolder | null>(null);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [selectedLead, setSelectedLead] = useState<string | null>(null);
  const [accessLevel, setAccessLevel] = useState<'view' | 'download' | 'upload'>('view');
  const [sharePrice, setSharePrice] = useState<number>(0);
  const [expirationDate, setExpirationDate] = useState<string>('');
  
  // File actions
  const [selectedFile, setSelectedFile] = useState<StorageFile | null>(null);
  const [showFileMenu, setShowFileMenu] = useState<string | null>(null);
  
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: handleFileDrop,
    noClick: currentFolderId === null, // Disable click when not in a folder
  });
  
  useEffect(() => {
    fetchVendorId();
  }, []);
  
  useEffect(() => {
    if (currentVendorId) {
      fetchSubscription();
      fetchPlans();
      fetchRootFolders();
      fetchLeads();
    }
  }, [currentVendorId]);
  
  useEffect(() => {
    if (currentFolderId) {
      fetchFolderContents();
    }
  }, [currentFolderId]);
  
  async function fetchVendorId() {
    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');
      
      // Get team member
      const { data: teamMember, error: teamMemberError } = await supabase
        .from('team_members')
        .select('id')
        .eq('user_id', user.id)
        .single();
        
      if (teamMemberError) throw teamMemberError;
      
      // For this example, we'll just use the first vendor
      // In a real app, you'd have proper vendor selection or association
      const { data: vendors, error: vendorsError } = await supabase
        .from('vendors')
        .select('id')
        .limit(1);
        
      if (vendorsError) throw vendorsError;
      
      if (vendors && vendors.length > 0) {
        setCurrentVendorId(vendors[0].id);
      } else {
        throw new Error('No vendors found');
      }
    } catch (err) {
      console.error('Error fetching vendor ID:', err);
      setError('Failed to load vendor information');
    } finally {
      setLoading(false);
    }
  }
  
  async function fetchSubscription() {
    if (!currentVendorId) return;
    
    try {
      const { data, error } = await supabase
        .from('vendor_storage_subscriptions')
        .select(`
          *,
          plan:storage_plans(*)
        `)
        .eq('vendor_id', currentVendorId)
        .eq('status', 'active')
        .maybeSingle();
        
      if (error) throw error;
      setSubscription(data);
    } catch (err) {
      console.error('Error fetching subscription:', err);
      setError('Failed to load subscription information');
    }
  }
  
  async function fetchPlans() {
    try {
      const { data, error } = await supabase
        .from('storage_plans')
        .select('*')
        .eq('is_active', true)
        .order('price_monthly');
        
      if (error) throw error;
      setAvailablePlans(data || []);
    } catch (err) {
      console.error('Error fetching plans:', err);
      setError('Failed to load storage plans');
    }
  }
  
  async function fetchRootFolders() {
    if (!currentVendorId) return;
    
    try {
      // First fetch the folders with basic info and shares
      const { data: foldersData, error: foldersError } = await supabase
        .from('storage_folders')
        .select(`
          *,
          shares:folder_shares(
            id,
            lead_id,
            access_level,
            status,
            price_monthly,
            lead:leads(name, email),
            subscription:couple_storage_subscriptions(id, status)
          )
        `)
        .eq('vendor_id', currentVendorId)
        .is('parent_folder_id', null);
        
      if (foldersError) throw foldersError;

      // For each folder, fetch its files to calculate count and total size
      const processedFolders = await Promise.all((foldersData || []).map(async (folder) => {
        const { data: files, error: filesError } = await supabase
          .from('storage_files')
          .select('file_size')
          .eq('folder_id', folder.id);
          
        if (filesError) throw filesError;
        
        const totalSize = (files || []).reduce((sum, file) => sum + (file.file_size || 0), 0);
        
        return {
          ...folder,
          files_count: files?.length || 0,
          total_size: totalSize,
          shares: folder.shares || []
        };
      }));
      
      setFolders(processedFolders);
      setFolderPath([]);
      setCurrentFolderId(null);
      setFiles([]);
    } catch (err) {
      console.error('Error fetching root folders:', err);
      setError('Failed to load folders');
    }
  }

  async function fetchFolderContents() {
    if (!currentVendorId || !currentFolderId) return;
    
    try {
      // Fetch subfolders first
      const { data: subfoldersData, error: subfoldersError } = await supabase
        .from('storage_folders')
        .select(`
          *,
          shares:folder_shares(
            id,
            lead_id,
            access_level,
            status,
            price_monthly,
            lead:leads(name, email),
            subscription:couple_storage_subscriptions(id, status)
          )
        `)
        .eq('vendor_id', currentVendorId)
        .eq('parent_folder_id', currentFolderId);
        
      if (subfoldersError) throw subfoldersError;

      // For each subfolder, fetch its files to calculate count and total size
      const processedFolders = await Promise.all((subfoldersData || []).map(async (folder) => {
        const { data: files, error: filesError } = await supabase
          .from('storage_files')
          .select('file_size')
          .eq('folder_id', folder.id);
          
        if (filesError) throw filesError;
        
        const totalSize = (files || []).reduce((sum, file) => sum + (file.file_size || 0), 0);
        
        return {
          ...folder,
          files_count: files?.length || 0,
          total_size: totalSize,
          shares: folder.shares || []
        };
      }));
      
      setFolders(processedFolders);
      
      // Fetch files in current folder
      const { data: folderFiles, error: filesError } = await supabase
        .from('storage_files')
        .select('*')
        .eq('vendor_id', currentVendorId)
        .eq('folder_id', currentFolderId);
        
      if (filesError) throw filesError;
      setFiles(folderFiles || []);
      
      // Update folder path
      await updateFolderPath();
    } catch (err) {
      console.error('Error fetching folder contents:', err);
      setError('Failed to load folder contents');
    }
  }
  
  async function updateFolderPath() {
    if (!currentFolderId) {
      setFolderPath([]);
      return;
    }
    
    try {
      // Get current folder
      const { data: currentFolder, error: folderError } = await supabase
        .from('storage_folders')
        .select('id, name, parent_folder_id')
        .eq('id', currentFolderId)
        .single();
        
      if (folderError) throw folderError;
      
      // Build path recursively
      const path: {id: string; name: string}[] = [];
      let folder = currentFolder;
      
      path.unshift({ id: folder.id, name: folder.name });
      
      while (folder.parent_folder_id) {
        const { data: parentFolder, error: parentError } = await supabase
          .from('storage_folders')
          .select('id, name, parent_folder_id')
          .eq('id', folder.parent_folder_id)
          .single();
          
        if (parentError) throw parentError;
        
        path.unshift({ id: parentFolder.id, name: parentFolder.name });
        folder = parentFolder;
      }
      
      setFolderPath(path);
    } catch (err) {
      console.error('Error updating folder path:', err);
    }
  }
  
  async function fetchLeads() {
    try {
      const { data, error } = await supabase
        .from('leads')
        .select('id, name, email')
        .order('name');
        
      if (error) throw error;
      setLeads(data || []);
    } catch (err) {
      console.error('Error fetching leads:', err);
    }
  }
  
  async function handleSubscribe() {
    if (!currentVendorId || !selectedPlan) return;
    
    try {
      // In a real app, you would create a Stripe checkout session here
      // For this example, we'll just create the subscription directly
      
      const plan = availablePlans.find(p => p.id === selectedPlan);
      if (!plan) throw new Error('Selected plan not found');
      
      const price = billingCycle === 'monthly' ? plan.price_monthly : plan.price_yearly;
      
      // Calculate period end date
      const now = new Date();
      const periodEnd = new Date(now);
      if (billingCycle === 'monthly') {
        periodEnd.setMonth(periodEnd.getMonth() + 1);
      } else {
        periodEnd.setFullYear(periodEnd.getFullYear() + 1);
      }
      
      // Create or update subscription
      if (subscription) {
        // Update existing subscription
        const { error } = await supabase
          .from('vendor_storage_subscriptions')
          .update({
            plan_id: selectedPlan,
            billing_cycle: billingCycle,
            current_period_start: now.toISOString(),
            current_period_end: periodEnd.toISOString()
          })
          .eq('id', subscription.id);
          
        if (error) throw error;
      } else {
        // Create new subscription
        const { error } = await supabase
          .from('vendor_storage_subscriptions')
          .insert({
            vendor_id: currentVendorId,
            plan_id: selectedPlan,
            status: 'active',
            storage_used: 0,
            billing_cycle: billingCycle,
            current_period_start: now.toISOString(),
            current_period_end: periodEnd.toISOString()
          });
          
        if (error) throw error;
        
        // Enable storage for vendor
        await supabase
          .from('vendors')
          .update({ storage_enabled: true })
          .eq('id', currentVendorId);
      }
      
      // Refresh subscription data
      fetchSubscription();
      
      // Close modal
      setShowPlanModal(false);
      setSelectedPlan(null);
      
      setSuccess('Storage plan updated successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error subscribing to plan:', err);
      setError('Failed to subscribe to storage plan');
    }
  }
  
  async function handleCreateFolder() {
    if (!currentVendorId || !newFolderName.trim()) return;
    
    try {
      // Generate folder path
      let path = '';
      if (currentFolderId) {
        // Get current folder path
        const { data: currentFolder, error: folderError } = await supabase
          .from('storage_folders')
          .select('path')
          .eq('id', currentFolderId)
          .single();
          
        if (folderError) throw folderError;
        
        path = `${currentFolder.path}/${newFolderName}`;
      } else {
        path = `/${newFolderName}`;
      }
      
      // Create folder
      const { error } = await supabase
        .from('storage_folders')
        .insert({
          vendor_id: currentVendorId,
          name: newFolderName,
          description: newFolderDescription || null,
          parent_folder_id: currentFolderId,
          path: path,
          is_shared: false
        });
        
      if (error) throw error;
      
      // Refresh folder list
      if (currentFolderId) {
        fetchFolderContents();
      } else {
        fetchRootFolders();
      }
      
      // Reset form
      setShowNewFolderModal(false);
      setNewFolderName('');
      setNewFolderDescription('');
      
      setSuccess('Folder created successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error creating folder:', err);
      setError('Failed to create folder');
    }
  }
  
  async function handleFileDrop(acceptedFiles: File[]) {
    if (!currentVendorId || !currentFolderId || !subscription) return;
    
    // Check storage limit
    const totalSize = acceptedFiles.reduce((sum, file) => sum + file.size, 0);
    const newTotalUsed = (subscription.storage_used || 0) + totalSize;
    
    if (newTotalUsed > subscription.plan.storage_limit) {
      setError('Storage limit exceeded. Please upgrade your plan or free up space.');
      return;
    }
    
    // Upload files
    for (const file of acceptedFiles) {
      const fileId = Math.random().toString(36).substring(7);
      setUploadProgress(prev => ({ ...prev, [fileId]: 0 }));
      
      try {
        // Get folder path
        const { data: folder, error: folderError } = await supabase
          .from('storage_folders')
          .select('path')
          .eq('id', currentFolderId)
          .single();
          
        if (folderError) throw folderError;
        
        // Create storage path
        const storagePath = `vendors/${currentVendorId}${folder.path}/${file.name}`;
        
        // Upload file to storage
        const { error: uploadError } = await supabase.storage
          .from('vendor-storage')
          .upload(storagePath, file, {
            onUploadProgress: (progress) => {
              const percent = (progress.loaded / progress.total) * 100;
              setUploadProgress(prev => ({ ...prev, [fileId]: percent }));
            }
          });
          
        if (uploadError) throw uploadError;
        
        // Get public URL
        const { data: { publicUrl } } = supabase.storage
          .from('vendor-storage')
          .getPublicUrl(storagePath);
        
        // Get current user's team member ID
        const { data: { user } } = await supabase.auth.getUser();
        const { data: teamMember } = await supabase
          .from('team_members')
          .select('id')
          .eq('user_id', user?.id)
          .single();
        
        // Create file record
        const { error: fileError } = await supabase
          .from('storage_files')
          .insert({
            folder_id: currentFolderId,
            vendor_id: currentVendorId,
            name: file.name,
            file_type: file.type,
            file_size: file.size,
            storage_path: storagePath,
            public_url: publicUrl,
            uploaded_by: teamMember?.id || null
          });
          
        if (fileError) throw fileError;
        
        // Update storage used
        const { error: usageError } = await supabase
          .from('vendor_storage_subscriptions')
          .update({
            storage_used: supabase.rpc('increment', { x: file.size, y: subscription.storage_used })
          })
          .eq('id', subscription.id);
          
        if (usageError) throw usageError;
        
        // Clean up progress indicator
        setUploadProgress(prev => {
          const newProgress = { ...prev };
          delete newProgress[fileId];
          return newProgress;
        });
        
        // Refresh file list
        fetchFolderContents();
        // Refresh subscription to get updated storage usage
        fetchSubscription();
      } catch (err) {
        console.error('Error uploading file:', err);
        setError(`Failed to upload ${file.name}`);
        
        // Clean up progress indicator
        setUploadProgress(prev => {
          const newProgress = { ...prev };
          delete newProgress[fileId];
          return newProgress;
        });
      }
    }
  }
  
  async function handleShareFolder() {
    if (!selectedFolder || !selectedLead) return;
    
    try {
      // Generate random access code
      const accessCode = Math.random().toString(36).substring(2, 10).toUpperCase();
      
      // Create share
      const { error } = await supabase
        .from('folder_shares')
        .insert({
          folder_id: selectedFolder.id,
          lead_id: selectedLead,
          access_level: accessLevel,
          status: 'pending',
          expiration_date: expirationDate || null,
          access_code: accessCode,
          price_monthly: sharePrice
        });
        
      if (error) throw error;
      
      // Update folder
      const { error: folderError } = await supabase
        .from('storage_folders')
        .update({ is_shared: true })
        .eq('id', selectedFolder.id);
        
      if (folderError) throw folderError;
      
      // Refresh folder data
      if (currentFolderId) {
        fetchFolderContents();
      } else {
        fetchRootFolders();
      }
      
      // Reset form
      setShowShareModal(false);
      setSelectedFolder(null);
      setSelectedLead(null);
      setAccessLevel('view');
      setSharePrice(0);
      setExpirationDate('');
      
      setSuccess('Folder shared successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error sharing folder:', err);
      setError('Failed to share folder');
    }
  }
  
  async function handleDeleteFolder(folderId: string) {
    if (!currentVendorId) return;
    
    try {
      // Get all files in this folder and subfolders
      const { data: files, error: filesError } = await supabase
        .from('storage_files')
        .select('storage_path, file_size')
        .eq('vendor_id', currentVendorId)
        .eq('folder_id', folderId);
        
      if (filesError) throw filesError;
      
      // Delete files from storage
      for (const file of (files || [])) {
        await supabase.storage
          .from('vendor-storage')
          .remove([file.storage_path]);
      }
      
      // Calculate total size of deleted files
      const totalSize = (files || []).reduce((sum, file) => sum + file.file_size, 0);
      
      // Update storage used
      if (subscription && totalSize > 0) {
        await supabase
          .from('vendor_storage_subscriptions')
          .update({
            storage_used: Math.max(0, subscription.storage_used - totalSize)
          })
          .eq('id', subscription.id);
      }
      
      // Delete folder (this will cascade delete files and subfolders)
      const { error } = await supabase
        .from('storage_folders')
        .delete()
        .eq('id', folderId);
        
      if (error) throw error;
      
      // Refresh folder list
      if (currentFolderId) {
        fetchFolderContents();
      } else {
        fetchRootFolders();
      }
      
      // Refresh subscription to get updated storage usage
      fetchSubscription();
      
      setSuccess('Folder deleted successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error deleting folder:', err);
      setError('Failed to delete folder');
    }
  }
  
  async function handleDeleteFile(file: StorageFile) {
    if (!currentVendorId || !subscription) return;
    
    try {
      // Delete file from storage
      const { error: storageError } = await supabase.storage
        .from('vendor-storage')
        .remove([file.storage_path]);
        
      if (storageError) throw storageError;
      
      // Delete file record
      const { error } = await supabase
        .from('storage_files')
        .delete()
        .eq('id', file.id);
        
      if (error) throw error;
      
      // Update storage used
      const { error: usageError } = await supabase
        .from('vendor_storage_subscriptions')
        .update({
          storage_used: Math.max(0, subscription.storage_used - file.file_size)
        })
        .eq('id', subscription.id);
        
      if (usageError) throw usageError;
      
      // Refresh file list
      fetchFolderContents();
      // Refresh subscription to get updated storage usage
      fetchSubscription();
      
      setSuccess('File deleted successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error deleting file:', err);
      setError('Failed to delete file');
    }
  }
  
  function formatBytes(bytes: number, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }
  
  function getFileIcon(fileType: string) {
    if (fileType.startsWith('image/')) {
      return <img src="/icons/image.svg" alt="Image" className="w-10 h-10" />;
    } else if (fileType.startsWith('video/')) {
      return <img src="/icons/video.svg" alt="Video" className="w-10 h-10" />;
    } else if (fileType.startsWith('audio/')) {
      return <img src="/icons/audio.svg" alt="Audio" className="w-10 h-10" />;
    } else if (fileType === 'application/pdf') {
      return <img src="/icons/pdf.svg" alt="PDF" className="w-10 h-10" />;
    } else if (fileType.includes('word') || fileType.includes('document')) {
      return <img src="/icons/doc.svg" alt="Document" className="w-10 h-10" />;
    } else if (fileType.includes('excel') || fileType.includes('spreadsheet')) {
      return <img src="/icons/xls.svg" alt="Spreadsheet" className="w-10 h-10" />;
    } else if (fileType.includes('powerpoint') || fileType.includes('presentation')) {
      return <img src="/icons/ppt.svg" alt="Presentation" className="w-10 h-10" />;
    } else {
      return <File className="w-10 h-10 text-gray-400" />;
    }
  }
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Cloud Storage</h1>
        
        {subscription ? (
          <button
            onClick={() => {
              setSelectedPlan(subscription.plan_id);
              setBillingCycle(subscription.billing_cycle);
              setShowPlanModal(true);
            }}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <HardDrive className="w-5 h-5" />
            Manage Storage Plan
          </button>
        ) : (
          <button
            onClick={() => setShowPlanModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <CreditCard className="w-5 h-5" />
            Subscribe to Storage
          </button>
        )}
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}
      
      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}
      
      {/* Subscription Info */}
      {subscription && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-lg font-semibold text-gray-900 mb-2">Storage Subscription</h2>
              <div className="flex items-center gap-2 mb-1">
                <HardDrive className="w-5 h-5 text-blue-500" />
                <span className="font-medium text-gray-900">{subscription.plan.name} Plan</span>
                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full text-sm">
                  {subscription.billing_cycle === 'monthly' ? 'Monthly' : 'Yearly'}
                </span>
              </div>
              <div className="flex items-center gap-2 text-gray-600">
                <Clock className="w-4 h-4" />
                <span>Renews on {new Date(subscription.current_period_end).toLocaleDateString()}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-600 mb-1">Storage Used</div>
              <div className="text-2xl font-bold text-gray-900">
                {formatBytes(subscription.storage_used)} / {formatBytes(subscription.plan.storage_limit)}
              </div>
              <div className="w-48 h-2 bg-gray-200 rounded-full mt-2">
                <div
                  className="h-2 bg-blue-600 rounded-full"
                  style={{
                    width: `${Math.min(100, (subscription.storage_used / subscription.plan.storage_limit) * 100)}%`
                  }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Folder Navigation */}
      <div className="bg-white rounded-lg shadow-md">
        <div className="p-4 border-b">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {/* Breadcrumb */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setCurrentFolderId(null);
                    fetchRootFolders();
                  }}
                  className="text-gray-600 hover:text-gray-900"
                >
                  <Folder className="w-5 h-5" />
                </button>
                {folderPath.map((folder, index) => (
                  <React.Fragment key={folder.id}>
                    <span className="text-gray-400">/</span>
                    <button
                      onClick={() => {
                        setCurrentFolderId(folder.id);
                        fetchFolderContents();
                      }}
                      className="text-gray-600 hover:text-gray-900"
                    >
                      {folder.name}
                    </button>
                  </React.Fragment>
                ))}
              </div>
              
              {/* Search */}
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search files..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border rounded-lg w-64 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <Search className="w-5 h-5 text-gray-400 absolute left-3 top-2.5" />
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {/* New Folder Button */}
              <button
                onClick={() => setShowNewFolderModal(true)}
                className="flex items-center gap-2 px-3 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg"
              >
                <FolderPlus className="w-5 h-5" />
                New Folder
              </button>
              
              {/* Upload Button */}
              {currentFolderId && (
                <button
                  onClick={() => document.getElementById('fileInput')?.click()}
                  className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  <Upload className="w-5 h-5" />
                  Upload Files
                </button>
              )}
            </div>
          </div>
        </div>
        
        {/* Folders and Files */}
        <div
          {...getRootProps()}
          className={`p-4 min-h-[400px] ${isDragActive ? 'bg-blue-50 border-2 border-dashed border-blue-300' : ''}`}
        >
          <input {...getInputProps()} id="fileInput" />
          
          {/* Folders */}
          {folders.length > 0 && (
            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Folders</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {folders.map(folder => (
                  <div
                    key={folder.id}
                    className="bg-white border rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between">
                      <button
                        onClick={() => {
                          setCurrentFolderId(folder.id);
                          fetchFolderContents();
                        }}
                        className="flex items-center gap-3 flex-1"
                      >
                        <Folder className="w-10 h-10 text-blue-500" />
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-gray-900 truncate">{folder.name}</div>
                          <div className="text-sm text-gray-500">
                            {folder.files_count} files • {formatBytes(folder.total_size)}
                          </div>
                        </div>
                      </button>
                      
                      <div className="relative">
                        <button
                          onClick={() => setShowFileMenu(folder.id)}
                          className="p-1 hover:bg-gray-100 rounded-full"
                        >
                          <MoreHorizontal className="w-5 h-5 text-gray-500" />
                        </button>
                        
                        {showFileMenu === folder.id && (
                          <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border z-10">
                            <button
                              onClick={() => {
                                setSelectedFolder(folder);
                                setShowShareModal(true);
                                setShowFileMenu(null);
                              }}
                              className="flex items-center gap-2 w-full px-4 py-2 text-left text-gray-700 hover:bg-gray-100"
                            >
                              <Share className="w-4 h-4" />
                              Share
                            </button>
                            <button
                              onClick={() => {
                                handleDeleteFolder(folder.id);
                                setShowFileMenu(null);
                              }}
                              className="flex items-center gap-2 w-full px-4 py-2 text-left text-red-600 hover:bg-red-50"
                            >
                              <Trash2 className="w-4 h-4" />
                              Delete
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    {folder.shares.length > 0 && (
                      <div className="mt-3 pt-3 border-t">
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                          <Users className="w-4 h-4" />
                          Shared with {folder.shares.length} {folder.shares.length === 1 ? 'person' : 'people'}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Files */}
          {files.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Files</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {files.map(file => (
                  <div
                    key={file.id}
                    className="bg-white border rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3 flex-1">
                        {getFileIcon(file.file_type)}
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-gray-900 truncate">{file.name}</div>
                          <div className="text-sm text-gray-500">{formatBytes(file.file_size)}</div>
                        </div>
                      </div>
                      
                      <div className="relative">
                        <button
                          onClick={() => setShowFileMenu(file.id)}
                          className="p-1 hover:bg-gray-100 rounded-full"
                        >
                          <MoreHorizontal className="w-5 h-5 text-gray-500" />
                        </button>
                        
                        {showFileMenu === file.id && (
                          <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border z-10">
                            {file.public_url && (
                              <a
                                href={file.public_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-2 w-full px-4 py-2 text-left text-gray-700 hover:bg-gray-100"
                              >
                                <ExternalLink className="w-4 h-4" />
                                Open
                              </a>
                            )}
                            <button
                              onClick={() => {
                                if (file.public_url) {
                                  navigator.clipboard.writeText(file.public_url);
                                  setSuccess('Link copied to clipboard');
                                  setTimeout(() => setSuccess(null), 3000);
                                }
                                setShowFileMenu(null);
                              }}
                              className="flex items-center gap-2 w-full px-4 py-2 text-left text-gray-700 hover:bg-gray-100"
                            >
                              <Copy className="w-4 h-4" />
                              Copy Link
                            </button>
                            <button
                              onClick={() => {
                                handleDeleteFile(file);
                                setShowFileMenu(null);
                              }}
                              className="flex items-center gap-2 w-full px-4 py-2 text-left text-red-600 hover:bg-red-50"
                            >
                              <Trash2 className="w-4 h-4" />
                              Delete
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Empty State */}
          {folders.length === 0 && files.length === 0 && (
            <div className="flex flex-col items-center justify-center h-64 text-gray-500">
              <Folder className="w-16 h-16 mb-4" />
              <p className="text-lg mb-2">No files or folders</p>
              <p className="text-sm">
                {currentFolderId
                  ? 'Drop files here to upload or use the upload button'
                  : 'Create a folder to start uploading files'}
              </p>
            </div>
          )}
          
          {/* Upload Progress */}
          {Object.keys(uploadProgress).length > 0 && (
            <div className="fixed bottom-6 right-6 w-80 bg-white rounded-lg shadow-lg border p-4">
              <h4 className="text-sm font-medium text-gray-900 mb-3">Uploading Files</h4>
              {Object.entries(uploadProgress).map(([fileId, progress]) => (
                <div key={fileId} className="mb-2">
                  <div className="flex justify-between text-sm text-gray-600 mb-1">
                    <span>Uploading...</span>
                    <span>{Math.round(progress)}%</span>
                  </div>
                  <div className="w-full h-2 bg-gray-200 rounded-full">
                    <div
                      className="h-2 bg-blue-600 rounded-full"
                      style={{ width: `${progress}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      
      {/* New Folder Modal */}
      {showNewFolderModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-md">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Create New Folder</h3>
              <div className="space-y-4">
                <div>
                  <label htmlFor="folderName" className="block text-sm font-medium text-gray-700 mb-1">
                    Folder Name
                  </label>
                  <input
                    type="text"
                    id="folderName"
                    value={newFolderName}
                    onChange={(e) => setNewFolderName(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter folder name"
                  />
                </div>
                <div>
                  <label htmlFor="folderDescription" className="block text-sm font-medium text-gray-700 mb-1">
                    Description (optional)
                  </label>
                  <textarea
                    id="folderDescription"
                    value={newFolderDescription}
                    onChange={(e) => setNewFolderDescription(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter folder description"
                    rows={3}
                  />
                </div>
              </div>
            </div>
            <div className="px-6 py-4 bg-gray-50 rounded-b-lg flex justify-end gap-2">
              <button
                onClick={() => {
                  setShowNewFolderModal(false);
                  setNewFolderName('');
                  setNewFolderDescription('');
                }}
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateFolder}
                disabled={!newFolderName.trim()}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Create Folder
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Share Modal */}
      {showShareModal && selectedFolder && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-md">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Share Folder</h3>
              <div className="space-y-4">
                <div>
                  <label htmlFor="leadSelect" className="block text-sm font-medium text-gray-700 mb-1">
                    Share with
                  </label>
                  <select
                    id="leadSelect"
                    value={selectedLead || ''}
                    onChange={(e) => setSelectedLead(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select a lead</option>
                    {leads.map(lead => (
                      <option key={lead.id} value={lead.id}>
                        {lead.name} ({lead.email})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="accessLevel" className="block text-sm font-medium text-gray-700 mb-1">
                    Access Level
                  </label>
                  <select
                    id="accessLevel"
                    value={accessLevel}
                    onChange={(e) => setAccessLevel(e.target.value as 'view' | 'download' | 'upload')}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="view">View Only</option>
                    <option value="download">Download</option>
                    <option value="upload">Upload & Download</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="sharePrice" className="block text-sm font-medium text-gray-700 mb-1">
                    Monthly Price (optional)
                  </label>
                  <input
                    type="number"
                    id="sharePrice"
                    value={sharePrice}
                    onChange={(e) => setSharePrice(parseFloat(e.target.value) || 0)}
                    min="0"
                    step="0.01"
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter monthly price"
                  />
                </div>
                <div>
                  <label htmlFor="expirationDate" className="block text-sm font-medium text-gray-700 mb-1">
                    Expiration Date (optional)
                  </label>
                  <input
                    type="date"
                    id="expirationDate"
                    value={expirationDate}
                    onChange={(e) => setExpirationDate(e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>
            <div className="px-6 py-4 bg-gray-50 rounded-b-lg flex justify-end gap-2">
              <button
                onClick={() => {
                  setShowShareModal(false);
                  setSelectedFolder(null);
                  setSelectedLead(null);
                  setAccessLevel('view');
                  setSharePrice(0);
                  setExpirationDate('');
                }}
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={handleShareFolder}
                disabled={!selectedLead}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Share Folder
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Storage Plan Modal */}
      {showPlanModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-4xl">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Storage Plans</h3>
              
              {/* Billing Cycle Toggle */}
              <div className="flex justify-center mb-8">
                <div className="bg-gray-100 rounded-lg p-1">
                  <button
                    onClick={() => setBillingCycle('monthly')}
                    className={`px-4 py-2 rounded-lg ${
                      billingCycle === 'monthly'
                        ? 'bg-white text-blue-600 shadow'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    Monthly
                  </button>
                  <button
                    onClick={() => setBillingCycle('yearly')}
                    className={`px-4 py-2 rounded-lg ${
                      billingCycle === 'yearly'
                        ? 'bg-white text-blue-600 shadow'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    Yearly (Save 20%)
                  </button>
                </div>
              </div>
              
              {/* Plans Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {availablePlans.map(plan => {
                  const price = billingCycle === 'monthly' ? plan.price_monthly : plan.price_yearly;
                  const isSelected = selectedPlan === plan.id;
                  
                  return (
                    <div
                      key={plan.id}
                      className={`border rounded-lg p-6 ${
                        isSelected ? 'border-blue-500 ring-2 ring-blue-500' : 'hover:border-blue-300'
                      }`}
                    >
                      <h4 className="text-xl font-semibold text-gray-900 mb-2">{plan.name}</h4>
                      <p className="text-gray-600 mb-4">{plan.description}</p>
                      <div className="mb-6">
                        <div className="text-3xl font-bold text-gray-900">
                          ${price}
                          <span className="text-lg font-normal text-gray-600">
                            /{billingCycle === 'monthly' ? 'mo' : 'yr'}
                          </span>
                        </div>
                      </div>
                      <ul className="space-y-3 mb-6">
                        <li className="flex items-center gap-2 text-gray-700">
                          <HardDrive className="w-5 h-5 text-blue-500" />
                          {formatBytes(plan.storage_limit)} Storage
                        </li>
                        <li className="flex items-center gap-2 text-gray-700">
                          <Folder className="w-5 h-5 text-blue-500" />
                          {plan.features.max_folders} Folders
                        </li>
                        <li className="flex items-center gap-2 text-gray-700">
                          <Share className="w-5 h-5 text-blue-500" />
                          {plan.features.max_shares} Shared Folders
                        </li>
                      </ul>
                      <button
                        onClick={() => setSelectedPlan(plan.id)}
                        className={`w-full py-2 rounded-lg ${
                          isSelected
                            ? 'bg-blue-600 text-white hover:bg-blue-700'
                            : 'border border-blue-600 text-blue-600 hover:bg-blue-50'
                        }`}
                      >
                        {isSelected ? 'Selected' : 'Select Plan'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="px-6 py-4 bg-gray-50 rounded-b-lg flex justify-end gap-2">
              <button
                onClick={() => {
                  setShowPlanModal(false);
                  setSelectedPlan(null);
                  setBillingCycle('monthly');
                }}
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={handleSubscribe}
                disabled={!selectedPlan}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {subscription ? 'Update Plan' : 'Subscribe'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}