import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { supabase } from '../lib/supabase';
import { ArrowLeft, Save, Plus, Minus, Trash2, X, Upload, FileText, Eye, EyeOff, Package, DollarSign, Clock, Settings } from 'lucide-react';

interface ServiceVariant {
  id?: string;
  name: string;
  price: number;
  hours: number | null;
  description: string | null;
}

interface ServiceMedia {
  id: string;
  type: 'image' | 'video';
  url: string;
  thumbnail_url?: string;
  title?: string;
  description?: string;
}

interface Service {
  id: string;
  name: string;
  description: string;
  base_price: number;
  visibility: 'visible' | 'hidden';
  allows_custom_packages: boolean;
  variants: ServiceVariant[];
  media?: ServiceMedia[];
}

export default function ServiceEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [service, setService] = useState<Service>({
    id: '',
    name: '',
    description: '',
    base_price: 0,
    visibility: 'visible',
    allows_custom_packages: false,
    variants: [],
    media: []
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({});

  const isNew = id === 'new';

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.gif', '.webp'],
      'video/*': ['.mp4', '.webm', '.ogg']
    },
    onDrop: handleFileDrop
  });

  useEffect(() => {
    if (!isNew) {
      fetchService();
    } else {
      setLoading(false);
    }
  }, [id]);

  async function fetchService() {
    try {
      const { data, error } = await supabase
        .from('services')
        .select(`
          *,
          variants:service_variants(*),
          media:service_media(*)
        `)
        .eq('id', id)
        .single();

      if (error) throw error;
      setService(data);
    } catch (err) {
      console.error('Error fetching service:', err);
      setError('Failed to load service');
    } finally {
      setLoading(false);
    }
  }

  async function handleFileDrop(acceptedFiles: File[]) {
    if (!service.id && isNew) {
      setError('Please save the service first before uploading media');
      return;
    }

    for (const file of acceptedFiles) {
      const fileId = Math.random().toString(36).substring(7);
      setUploadProgress(prev => ({ ...prev, [fileId]: 0 }));

      try {
        // Create a unique file path
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
        const filePath = `${service.id}/${fileName}`;

        // Upload the file
        const { error: uploadError } = await supabase.storage
          .from('service-media')
          .upload(filePath, file, {
            onUploadProgress: (progress) => {
              const percent = (progress.loaded / progress.total) * 100;
              setUploadProgress(prev => ({ ...prev, [fileId]: percent }));
            }
          });

        if (uploadError) throw uploadError;

        // Get the public URL
        const { data: { publicUrl } } = supabase.storage
          .from('service-media')
          .getPublicUrl(filePath);

        // Determine media type
        const type = file.type.startsWith('image/') ? 'image' : 'video';

        // Add the media to the database
        const { data: mediaData, error: mediaError } = await supabase
          .from('service_media')
          .insert({
            service_id: service.id,
            type,
            url: publicUrl,
            title: file.name,
          })
          .select()
          .single();

        if (mediaError) throw mediaError;

        // Update the service state
        setService(prev => ({
          ...prev,
          media: [...(prev.media || []), mediaData]
        }));

        // Clean up progress indicator
        setUploadProgress(prev => {
          const newProgress = { ...prev };
          delete newProgress[fileId];
          return newProgress;
        });
      } catch (err) {
        console.error('Error uploading file:', err);
        setError('Failed to upload media');
        setUploadProgress(prev => {
          const newProgress = { ...prev };
          delete newProgress[fileId];
          return newProgress;
        });
      }
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    try {
      if (id === 'new') {
        const { data, error } = await supabase
          .from('services')
          .insert({
            name: service.name,
            description: service.description,
            base_price: service.base_price,
            visibility: service.visibility,
            allows_custom_packages: service.allows_custom_packages
          })
          .select()
          .single();

        if (error) throw error;

        // Insert variants without IDs to let the database generate them
        if (service.variants.length > 0) {
          const { error: variantsError } = await supabase
            .from('service_variants')
            .insert(
              service.variants.map(variant => ({
                name: variant.name,
                price: variant.price,
                hours: variant.hours,
                description: variant.description,
                service_id: data.id,
              }))
            );

          if (variantsError) throw variantsError;
        }
      } else {
        // First check if any variants are referenced by bookings
        const { data: existingVariants } = await supabase
          .from('service_variants')
          .select('id')
          .eq('service_id', id);

        const existingIds = existingVariants?.map(v => v.id) || [];

        // Check for bookings using these variants
        const { data: bookings, error: bookingsError } = await supabase
          .from('bookings')
          .select('id, variant_id')
          .in('variant_id', existingIds);

        if (bookingsError) throw bookingsError;

        if (bookings && bookings.length > 0) {
          // Some variants are in use - we need to handle this carefully
          const usedVariantIds = new Set(bookings.map(b => b.variant_id));
          
          // Update existing variants that are in use instead of deleting them
          for (const variant of service.variants) {
            if (variant.id && usedVariantIds.has(variant.id)) {
              const { error: updateError } = await supabase
                .from('service_variants')
                .update({
                  name: variant.name,
                  price: variant.price,
                  hours: variant.hours,
                  description: variant.description,
                })
                .eq('id', variant.id);

              if (updateError) throw updateError;
            }
          }

          // Delete variants that aren't in use
          const unusedIds = existingIds.filter(id => !usedVariantIds.has(id));
          if (unusedIds.length > 0) {
            const { error: deleteError } = await supabase
              .from('service_variants')
              .delete()
              .in('id', unusedIds);

            if (deleteError) throw deleteError;
          }

          // Insert new variants
          const newVariants = service.variants.filter(v => !v.id);
          if (newVariants.length > 0) {
            const { error: insertError } = await supabase
              .from('service_variants')
              .insert(
                newVariants.map(variant => ({
                  name: variant.name,
                  price: variant.price,
                  hours: variant.hours,
                  description: variant.description,
                  service_id: id,
                }))
              );

            if (insertError) throw insertError;
          }
        } else {
          // No bookings exist - we can safely delete and recreate all variants
          const { error: deleteError } = await supabase
            .from('service_variants')
            .delete()
            .eq('service_id', id);

          if (deleteError) throw deleteError;

          if (service.variants.length > 0) {
            const { error: insertError } = await supabase
              .from('service_variants')
              .insert(
                service.variants.map(variant => ({
                  name: variant.name,
                  price: variant.price,
                  hours: variant.hours,
                  description: variant.description,
                  service_id: id,
                }))
              );

            if (insertError) throw insertError;
          }
        }

        // Update the service itself
        const { error } = await supabase
          .from('services')
          .update({
            name: service.name,
            description: service.description,
            base_price: service.base_price,
            visibility: service.visibility,
            allows_custom_packages: service.allows_custom_packages
          })
          .eq('id', id);

        if (error) throw error;
      }

      navigate('/services');
    } catch (error: any) {
      console.error('Error saving service:', error);
      
      // Handle specific error cases
      if (error.code === '23503') {
        setError('Cannot delete service variants that are being used by existing bookings. Please update the bookings first.');
      } else if (error.code === '23505') {
        setError('A duplicate service variant was detected. Please try again.');
      } else {
        setError(error.message || 'Failed to save service');
      }
      setSaving(false);
    }
  }

  async function handleDelete() {
    try {
      // Check if service is used in any bookings
      const { count: bookingsCount, error: bookingsError } = await supabase
        .from('bookings')
        .select('id', { count: 'exact', head: true })
        .eq('service_id', id);

      if (bookingsError) throw bookingsError;

      if (bookingsCount && bookingsCount > 0) {
        throw new Error('Cannot delete service that is used in bookings');
      }

      // Delete service (this will cascade delete variants and media)
      const { error } = await supabase
        .from('services')
        .delete()
        .eq('id', id);

      if (error) throw error;

      navigate('/services');
    } catch (err: any) {
      console.error('Error deleting service:', err);
      setError(err.message || 'Failed to delete service');
    }
  }

  function addVariant() {
    setService({
      ...service,
      variants: [
        ...service.variants,
        {
          name: '',
          price: 0,
          hours: null,
          description: null
        }
      ]
    });
  }

  function removeVariant(index: number) {
    setService({
      ...service,
      variants: service.variants.filter((_, i) => i !== index)
    });
  }

  function updateVariant(index: number, field: keyof ServiceVariant, value: any) {
    const updatedVariants = [...service.variants];
    updatedVariants[index] = {
      ...updatedVariants[index],
      [field]: value
    };
    setService({
      ...service,
      variants: updatedVariants
    });
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/services')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">
            {isNew ? 'New Service' : 'Edit Service'}
          </h1>
        </div>
        {!isNew && (
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="flex items-center gap-2 px-4 py-2 text-red-600 hover:text-red-700"
          >
            <Trash2 className="w-5 h-5" />
            Delete Service
          </button>
        )}
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <div className="flex-shrink-0">
            <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
            </svg>
          </div>
          <div>{error}</div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6 space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Name
              </label>
              <input
                type="text"
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
                value={service.name}
                onChange={(e) => setService({ ...service, name: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
                rows={4}
                value={service.description}
                onChange={(e) => setService({ ...service, description: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Base Price
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                  $
                </span>
                <input
                  type="number"
                  className="w-full pl-7 pr-3 py-2 border border-gray-300 rounded-lg"
                  value={service.base_price}
                  onChange={(e) => setService({ ...service, base_price: parseFloat(e.target.value) || 0 })}
                  min="0"
                  step="0.01"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Visibility
              </label>
              <div className="flex gap-4">
                <label className="flex items-center">
                  <input
                    type="radio"
                    checked={service.visibility === 'visible'}
                    onChange={() => setService({ ...service, visibility: 'visible' })}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <div className="ml-2 flex items-center">
                    <Eye className="w-4 h-4 mr-1" />
                    <span>Visible</span>
                  </div>
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    checked={service.visibility === 'hidden'}
                    onChange={() => setService({ ...service, visibility: 'hidden' })}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <div className="ml-2 flex items-center">
                    <EyeOff className="w-4 h-4 mr-1" />
                    <span>Hidden</span>
                  </div>
                </label>
              </div>
            </div>

            <div>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={service.allows_custom_packages}
                  onChange={(e) => setService({ ...service, allows_custom_packages: e.target.checked })}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <div className="ml-2 flex items-center">
                  <Settings className="w-4 h-4 mr-1" />
                  <span>Allow custom packages</span>
                </div>
              </label>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Service Variants
              </label>
              <div className="space-y-4">
                {service.variants.map((variant, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="text-sm font-medium text-gray-700">Variant {index + 1}</h3>
                      <button
                        type="button"
                        onClick={() => removeVariant(index)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="space-y-3">
                      <input
                        type="text"
                        placeholder="Name"
                        className="w-full border border-gray-300 rounded-lg px-3 py-2"
                        value={variant.name}
                        onChange={(e) => updateVariant(index, 'name', e.target.value)}
                        required
                      />

                      <div className="grid grid-cols-2 gap-3">
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                            $
                          </span>
                          <input
                            type="number"
                            placeholder="Price"
                            className="w-full pl-7 pr-3 py-2 border border-gray-300 rounded-lg"
                            value={variant.price}
                            onChange={(e) => updateVariant(index, 'price', parseFloat(e.target.value) || 0)}
                            min="0"
                            step="0.01"
                            required
                          />
                        </div>

                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                            <Clock className="w-4 h-4" />
                          </span>
                          <input
                            type="number"
                            placeholder="Hours (optional)"
                            className="w-full pl-7 pr-3 py-2 border border-gray-300 rounded-lg"
                            value={variant.hours || ''}
                            onChange={(e) => updateVariant(index, 'hours', e.target.value ? parseInt(e.target.value) : null)}
                            min="1"
                          />
                        </div>
                      </div>

                      <textarea
                        placeholder="Description (optional)"
                        className="w-full border border-gray-300 rounded-lg px-3 py-2"
                        rows={2}
                        value={variant.description || ''}
                        onChange={(e) => updateVariant(index, 'description', e.target.value)}
                      />
                    </div>
                  </div>
                ))}

                <button
                  type="button"
                  onClick={addVariant}
                  className="w-full py-2 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-gray-400 hover:text-gray-700 transition-colors flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Add Variant
                </button>
              </div>
            </div>

            <div className="pt-6 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => navigate('/services')}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                disabled={saving}
              >
                <Save className="w-5 h-5" />
                {saving ? 'Saving...' : (isNew ? 'Create Service' : 'Save Changes')}
              </button>
            </div>
          </form>
        </div>

        <div>
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Media Gallery</h2>
            
            <div {...getRootProps()} className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer mb-6">
              <input {...getInputProps()} />
              <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-600">
                {isDragActive ? 'Drop media here' : 'Drag & drop media here, or click to select'}
              </p>
              <p className="text-sm text-gray-500 mt-1">
                Supported formats: JPEG, PNG, GIF, MP4, WebM
              </p>
            </div>

            {/* Upload Progress */}
            {Object.entries(uploadProgress).map(([fileId, progress]) => (
              <div key={fileId} className="mb-4">
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>Uploading media...</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            ))}

            {/* Media Gallery */}
            <div className="grid grid-cols-2 gap-4">
              {service.media && service.media.map((media) => (
                <div key={media.id} className="relative group">
                  {media.type === 'image' ? (
                    <img
                      src={media.url}
                      alt={media.title || 'Service image'}
                      className="w-full h-32 object-cover rounded-lg"
                    />
                  ) : (
                    <div className="w-full h-32 bg-gray-100 rounded-lg flex items-center justify-center">
                      <FileText className="w-8 h-8 text-gray-400" />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-opacity rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <button
                      type="button"
                      onClick={() => window.open(media.url, '_blank')}
                      className="p-1 bg-white rounded-full text-gray-700 hover:text-gray-900 mx-1"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          await supabase
                            .from('service_media')
                            .delete()
                            .eq('id', media.id);
                          
                          setService({
                            ...service,
                            media: service.media?.filter(m => m.id !== media.id) || []
                          });
                        } catch (err) {
                          console.error('Error deleting media:', err);
                          setError('Failed to delete media');
                        }
                      }}
                      className="p-1 bg-white rounded-full text-red-600 hover:text-red-700 mx-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {(!service.media || service.media.length === 0) && (
              <div className="text-center py-4 text-gray-500">
                No media uploaded yet
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Delete Service</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this service? This action cannot be undone and will remove all associated variants and media.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Delete Service
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}