import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { 
  Search, Filter, PlusCircle, Mail, MessageSquare, Calendar, User, 
  Phone, MapPin, Package, Building2, X, Send, AlertCircle, Archive,
  ChevronRight, Eye, EyeOff, ArrowRight
} from 'lucide-react';
import DateTimeDisplay from '../components/DateTimeDisplay';

interface Message {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  event_type: 'Wedding' | 'Event';
  event_date: string | null;
  subject: string;
  category: string;
  venue_id: string | null;
  venue_name: string | null;
  venue_address: string | null;
  service_id: string | null;
  variant_id: string | null;
  message: string;
  status: 'New' | 'Read' | 'Archived';
  created_at: string;
  converted_to_lead: boolean;
  lead_id: string | null;
  service?: {
    name: string;
    variant?: {
      name: string;
    };
  };
  responses: Array<{
    id: string;
    type: 'email' | 'sms' | 'in_app';
    content: string;
    status: 'pending' | 'sent' | 'failed';
    sent_at: string | null;
    created_at: string;
    created_by: {
      name: string;
    };
  }>;
}

interface Lead {
  id: string;
  name: string;
  email: string;
  phone: string | null;
}

interface Vendor {
  id: string;
  name: string;
  email: string;
  phone: string | null;
}

export default function Inbox() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null);
  const [showNewMessageModal, setShowNewMessageModal] = useState(false);
  const [showReplyModal, setShowReplyModal] = useState(false);
  const [replyType, setReplyType] = useState<'email' | 'sms' | 'in_app'>('email');
  const [replyContent, setReplyContent] = useState('');
  const [sending, setSending] = useState(false);
  
  // New message form state
  const [newMessage, setNewMessage] = useState({
    type: 'select_lead' as 'select_lead' | 'select_vendor' | 'direct_input',
    lead_id: '',
    vendor_id: '',
    name: '',
    email: '',
    phone: '',
    message_type: 'email' as 'email' | 'sms' | 'in_app',
    subject: '',
    message: ''
  });

  useEffect(() => {
    fetchMessages();
    fetchLeads();
    fetchVendors();
  }, []);

  async function fetchLeads() {
    try {
      const { data, error } = await supabase
        .from('leads')
        .select('id, name, email, phone')
        .order('name');

      if (error) throw error;
      setLeads(data || []);
    } catch (err) {
      console.error('Error fetching leads:', err);
    }
  }

  async function fetchVendors() {
    try {
      const { data, error } = await supabase
        .from('vendors')
        .select('id, name, email, phone')
        .order('name');

      if (error) throw error;
      setVendors(data || []);
    } catch (err) {
      console.error('Error fetching vendors:', err);
    }
  }

  async function fetchMessages() {
    try {
      const { data, error } = await supabase
        .from('inbox_messages')
        .select(`
          *,
          service:services (
            name,
            variant:service_variants (
              name
            )
          ),
          responses:message_responses (
            id,
            type,
            content,
            status,
            sent_at,
            created_at,
            created_by:team_members (
              name
            )
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setMessages(data || []);
    } catch (err) {
      console.error('Error fetching messages:', err);
      setError('Failed to load messages');
    } finally {
      setLoading(false);
    }
  }

  async function handleSendReply() {
    if (!selectedMessage || !replyContent.trim()) return;
    
    setSending(true);
    setError(null);

    try {
      const response = await fetch('/functions/v1/send-message', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
        },
        body: JSON.stringify({
          messageId: selectedMessage.id,
          content: replyContent,
          type: replyType,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to send message');
      }

      // Update message status to Read if it's New
      if (selectedMessage.status === 'New') {
        await supabase
          .from('inbox_messages')
          .update({ status: 'Read' })
          .eq('id', selectedMessage.id);
      }

      setShowReplyModal(false);
      setReplyContent('');
      fetchMessages();
    } catch (err) {
      console.error('Error sending reply:', err);
      setError(err instanceof Error ? err.message : 'Failed to send reply');
    } finally {
      setSending(false);
    }
  }

  async function handleCreateMessage(e: React.FormEvent) {
    e.preventDefault();
    setSending(true);
    setError(null);

    try {
      let messageData;

      if (newMessage.type === 'select_lead') {
        const selectedLead = leads.find(lead => lead.id === newMessage.lead_id);
        if (!selectedLead) throw new Error('Selected lead not found');

        messageData = {
          name: selectedLead.name,
          email: selectedLead.email,
          phone: selectedLead.phone,
          lead_id: selectedLead.id,
        };
      } else if (newMessage.type === 'select_vendor') {
        const selectedVendor = vendors.find(vendor => vendor.id === newMessage.vendor_id);
        if (!selectedVendor) throw new Error('Selected vendor not found');

        messageData = {
          name: selectedVendor.name,
          email: selectedVendor.email,
          phone: selectedVendor.phone,
          vendor_id: selectedVendor.id,
        };
      } else {
        messageData = {
          name: newMessage.name,
          email: newMessage.email,
          phone: newMessage.phone || null,
        };
      }

      const { error: messageError } = await supabase
        .from('inbox_messages')
        .insert({
          ...messageData,
          subject: newMessage.subject,
          message: newMessage.message,
          status: 'New',
          category: 'Other',
          event_type: 'Event'
        });

      if (messageError) throw messageError;

      // Reset form and close modal
      setNewMessage({
        type: 'select_lead',
        lead_id: '',
        vendor_id: '',
        name: '',
        email: '',
        phone: '',
        message_type: 'email',
        subject: '',
        message: ''
      });
      setShowNewMessageModal(false);
      
      // Refresh messages
      fetchMessages();
    } catch (err) {
      console.error('Error creating message:', err);
      setError(err instanceof Error ? err.message : 'Failed to create message');
    } finally {
      setSending(false);
    }
  }

  async function handleArchive(messageId: string) {
    try {
      const { error } = await supabase
        .from('inbox_messages')
        .update({ status: 'Archived' })
        .eq('id', messageId);

      if (error) throw error;
      
      if (selectedMessage?.id === messageId) {
        setSelectedMessage(null);
      }
      
      fetchMessages();
    } catch (err) {
      console.error('Error archiving message:', err);
      setError('Failed to archive message');
    }
  }

  const filteredMessages = messages.filter(message => {
    const matchesSearch = 
      message.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      message.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      message.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      message.message.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory = categoryFilter === 'all' || message.category === categoryFilter;
    const matchesStatus = statusFilter === 'all' || message.status === statusFilter;

    return matchesSearch && matchesCategory && matchesStatus;
  });

  // Get contact info based on selected recipient
  const selectedContact = 
    newMessage.type === 'select_lead' && newMessage.lead_id
      ? leads.find(lead => lead.id === newMessage.lead_id)
      : newMessage.type === 'select_vendor' && newMessage.vendor_id
        ? vendors.find(vendor => vendor.id === newMessage.vendor_id)
        : null;

  // Determine which message types are available based on contact info
  const availableMessageTypes = {
    email: newMessage.type === 'direct_input' 
      ? !!newMessage.email 
      : !!selectedContact?.email,
    sms: newMessage.type === 'direct_input' 
      ? !!newMessage.phone 
      : !!selectedContact?.phone,
    in_app: newMessage.type === 'select_lead' && !!selectedContact,
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Inbox</h1>
        <button
          onClick={() => setShowNewMessageModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <PlusCircle className="w-5 h-5" />
          New Message
        </button>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      <div className="grid grid-cols-12 gap-6">
        {/* Message List */}
        <div className="col-span-12 lg:col-span-5 xl:col-span-4">
          <div className="bg-white rounded-lg shadow-md">
            <div className="p-4 border-b border-gray-200">
              <div className="flex flex-col gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    placeholder="Search messages..."
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <select
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                >
                  <option value="all">All Categories</option>
                  <option value="Service Question">Service Question</option>
                  <option value="Service Issue">Service Issue</option>
                  <option value="Technical Question">Technical Question</option>
                  <option value="Technical Issue">Technical Issue</option>
                  <option value="Inquiry">Inquiry</option>
                  <option value="Other">Other</option>
                </select>
                <select
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                >
                  <option value="all">All Status</option>
                  <option value="New">New</option>
                  <option value="Read">Read</option>
                  <option value="Archived">Archived</option>
                </select>
              </div>
            </div>

            <div className="divide-y divide-gray-200">
              {loading ? (
                <div className="p-4 text-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                </div>
              ) : filteredMessages.length === 0 ? (
                <div className="p-8 text-center">
                  <p className="text-gray-500">No messages found</p>
                </div>
              ) : (
                filteredMessages.map((message) => (
                  <div
                    key={message.id}
                    className={`p-4 cursor-pointer transition-colors ${
                      selectedMessage?.id === message.id
                        ? 'bg-blue-50'
                        : 'hover:bg-gray-50'
                    }`}
                    onClick={() => setSelectedMessage(message)}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900 line-clamp-1">
                          {message.subject}
                        </h3>
                        <p className="text-sm text-gray-600">{message.name}</p>
                      </div>
                      <span className={`ml-4 px-2 py-1 text-xs font-medium rounded-full ${
                        message.status === 'New'
                          ? 'bg-blue-100 text-blue-800'
                          : message.status === 'Read'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {message.status}
                      </span>
                    </div>
                    <p className="text-sm text-gray-500 line-clamp-2">
                      {message.message}
                    </p>
                    <div className="mt-2 flex items-center gap-2 text-xs text-gray-500">
                      <Calendar className="w-4 h-4" />
                      <DateTimeDisplay date={message.created_at} format="datetime" />
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Message Details */}
        <div className="col-span-12 lg:col-span-7 xl:col-span-8">
          {selectedMessage ? (
            <div className="bg-white rounded-lg shadow-md">
              <div className="p-6 border-b border-gray-200">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-2">
                      {selectedMessage.subject}
                    </h2>
                    <div className="flex items-center gap-4 text-gray-600">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        selectedMessage.category === 'Service Question' || selectedMessage.category === 'Service Issue'
                          ? 'bg-purple-100 text-purple-800'
                          : selectedMessage.category === 'Technical Question' || selectedMessage.category === 'Technical Issue'
                          ? 'bg-orange-100 text-orange-800'
                          : selectedMessage.category === 'Inquiry'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {selectedMessage.category}
                      </span>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        selectedMessage.event_type === 'Wedding'
                          ? 'bg-pink-100 text-pink-800'
                          : 'bg-green-100 text-green-800'
                      }`}>
                        {selectedMessage.event_type}
                      </span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setShowReplyModal(true)}
                      className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                    >
                      <Send className="w-4 h-4" />
                      Reply
                    </button>
                    <button
                      onClick={() => handleArchive(selectedMessage.id)}
                      className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                    >
                      <Archive className="w-4 h-4" />
                      Archive
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-700 mb-2">Contact Information</h3>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-gray-600">
                        <User className="w-4 h-4" />
                        <span>{selectedMessage.name}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <Mail className="w-4 h-4" />
                        <a href={`mailto:${selectedMessage.email}`} className="text-blue-600 hover:text-blue-800">
                          {selectedMessage.email}
                        </a>
                      </div>
                      {selectedMessage.phone && (
                        <div className="flex items-center gap-2 text-gray-600">
                          <Phone className="w-4 h-4" />
                          <a href={`tel:${selectedMessage.phone}`} className="text-blue-600 hover:text-blue-800">
                            {selectedMessage.phone}
                          </a>
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-gray-700 mb-2">Event Details</h3>
                    <div className="space-y-2">
                      {selectedMessage.event_date && (
                        <div className="flex items-center gap-2 text-gray-600">
                          <Calendar className="w-4 h-4" />
                          <DateTimeDisplay date={selectedMessage.event_date} format="date" />
                        </div>
                      )}
                      {(selectedMessage.venue_name || selectedMessage.venue_address) && (
                        <div className="flex items-start gap-2 text-gray-600">
                          <MapPin className="w-4 h-4 mt-1" />
                          <div>
                            {selectedMessage.venue_name && (
                              <div className="font-medium">{selectedMessage.venue_name}</div>
                            )}
                            {selectedMessage.venue_address && (
                              <div>{selectedMessage.venue_address}</div>
                            )}
                          </div>
                        </div>
                      )}
                      {selectedMessage.service && (
                        <div className="flex items-start gap-2 text-gray-600">
                          <Package className="w-4 h-4 mt-1" />
                          <div>
                            <div className="font-medium">{selectedMessage.service.name}</div>
                            {selectedMessage.service.variant && (
                              <div>{selectedMessage.service.variant.name}</div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 border-b border-gray-200">
                <h3 className="text-sm font-medium text-gray-700 mb-4">Message</h3>
                <p className="text-gray-600 whitespace-pre-wrap">{selectedMessage.message}</p>
              </div>

              {selectedMessage.responses.length > 0 && (
                <div className="p-6">
                  <h3 className="text-sm font-medium text-gray-700 mb-4">Responses</h3>
                  <div className="space-y-4">
                    {selectedMessage.responses.map((response) => (
                      <div key={response.id} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            {response.type === 'email' ? (
                              <Mail className="w-4 h-4 text-blue-500" />
                            ) : response.type === 'sms' ? (
                              <MessageSquare className="w-4 h-4 text-green-500" />
                            ) : (
                              <Building2 className="w-4 h-4 text-purple-500" />
                            )}
                            <span className="font-medium text-gray-900">
                              {response.created_by.name}
                            </span>
                          </div>
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                            response.status === 'sent'
                              ? 'bg-green-100 text-green-800'
                              : response.status === 'pending'
                              ? 'bg-yellow-100 text-yellow-800'
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {response.status.charAt(0).toUpperCase() + response.status.slice(1)}
                          </span>
                        </div>
                        <p className="text-gray-600 whitespace-pre-wrap">{response.content}</p>
                        <div className="mt-2 text-sm text-gray-500">
                          <DateTimeDisplay date={response.created_at} format="datetime" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <h3 className="text-lg font-medium text-gray-900 mb-2">No message selected</h3>
              <p className="text-gray-600">Select a message from the list to view its details</p>
            </div>
          )}
        </div>
      </div>

      {/* New Message Modal */}
      {showNewMessageModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-lg max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6 sticky top-0 bg-white pt-2">
              <h2 className="text-xl font-bold text-gray-900">New Message</h2>
              <button
                onClick={() => setShowNewMessageModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateMessage} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Recipient Type
                </label>
                <div className="flex flex-wrap gap-4">
                  <label className="flex items-center gap-2">
                    <input
                      type="radio"
                      checked={newMessage.type === 'select_lead'}
                      onChange={() => setNewMessage({ 
                        ...newMessage, 
                        type: 'select_lead',
                        vendor_id: '',
                        lead_id: '',
                        name: '',
                        email: '',
                        phone: ''
                      })}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <span>Lead</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="radio"
                      checked={newMessage.type === 'select_vendor'}
                      onChange={() => setNewMessage({ 
                        ...newMessage, 
                        type: 'select_vendor',
                        lead_id: '',
                        vendor_id: '',
                        name: '',
                        email: '',
                        phone: ''
                      })}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <span>Vendor</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="radio"
                      checked={newMessage.type === 'direct_input'}
                      onChange={() => setNewMessage({ 
                        ...newMessage, 
                        type: 'direct_input',
                        lead_id: '',
                        vendor_id: '',
                        name: '',
                        email: '',
                        phone: ''
                      })}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <span>Direct Input</span>
                  </label>
                </div>
              </div>

              {newMessage.type === 'select_lead' ? (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Select Lead *
                  </label>
                  <select
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newMessage.lead_id}
                    onChange={(e) => setNewMessage({ ...newMessage, lead_id: e.target.value })}
                    required
                  >
                    <option value="">Choose a lead...</option>
                    {leads.map(lead => (
                      <option key={lead.id} value={lead.id}>
                        {lead.name} {lead.email ? `(${lead.email})` : ''}
                      </option>
                    ))}
                  </select>
                </div>
              ) : newMessage.type === 'select_vendor' ? (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Select Vendor *
                  </label>
                  <select
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newMessage.vendor_id}
                    onChange={(e) => setNewMessage({ ...newMessage, vendor_id: e.target.value })}
                    required
                  >
                    <option value="">Choose a vendor...</option>
                    {vendors.map(vendor => (
                      <option key={vendor.id} value={vendor.id}>
                        {vendor.name} {vendor.email ? `(${vendor.email})` : ''}
                      </option>
                    ))}
                  </select>
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Name *
                    </label>
                    <input
                      type="text"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      value={newMessage.name}
                      onChange={(e) => setNewMessage({ ...newMessage, name: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      value={newMessage.email}
                      onChange={(e) => setNewMessage({ ...newMessage, email: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Phone
                    </label>
                    <input
                      type="tel"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      value={newMessage.phone}
                      onChange={(e) => setNewMessage({ ...newMessage, phone: e.target.value })}
                    />
                  </div>
                </div>
              )}

              {/* Show contact details if a lead or vendor is selected */}
              {selectedContact && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Contact Details</h3>
                  <div className="space-y-1">
                    {selectedContact.email && (
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Mail className="w-4 h-4" />
                        <span>{selectedContact.email}</span>
                      </div>
                    )}
                    {selectedContact.phone && (
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Phone className="w-4 h-4" />
                        <span>{selectedContact.phone}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Message Type *
                </label>
                <div className="flex gap-4">
                  <label className={`flex items-center gap-2 ${!availableMessageTypes.email && 'opacity-50'}`}>
                    <input
                      type="radio"
                      checked={newMessage.message_type === 'email'}
                      onChange={() => setNewMessage({ ...newMessage, message_type: 'email' })}
                      disabled={!availableMessageTypes.email}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <Mail className="w-4 h-4" />
                    <span>Email</span>
                  </label>
                  <label className={`flex items-center gap-2 ${!availableMessageTypes.sms && 'opacity-50'}`}>
                    <input
                      type="radio"
                      checked={newMessage.message_type === 'sms'}
                      onChange={() => setNewMessage({ ...newMessage, message_type: 'sms' })}
                      disabled={!availableMessageTypes.sms}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <MessageSquare className="w-4 h-4" />
                    <span>SMS</span>
                  </label>
                  <label className={`flex items-center gap-2 ${!availableMessageTypes.in_app && 'opacity-50'}`}>
                    <input
                      type="radio"
                      checked={newMessage.message_type === 'in_app'}
                      onChange={() => setNewMessage({ ...newMessage, message_type: 'in_app' })}
                      disabled={!availableMessageTypes.in_app}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <Building2 className="w-4 h-4" />
                    <span>In-App</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Subject *
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  value={newMessage.subject}
                  onChange={(e) => setNewMessage({ ...newMessage, subject: e.target.value })}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Message *
                </label>
                <textarea
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  rows={6}
                  value={newMessage.message}
                  onChange={(e) => setNewMessage({ ...newMessage, message: e.target.value })}
                  required
                />
              </div>

              <div className="flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowNewMessageModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  disabled={sending}
                >
                  {sending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      Send Message
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reply Modal */}
      {showReplyModal && selectedMessage && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-lg">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-gray-900">Reply to Message</h2>
              <button
                onClick={() => setShowReplyModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Reply Type
              </label>
              <div className="flex gap-4">
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    checked={replyType === 'email'}
                    onChange={() => setReplyType('email')}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <Mail className="w-4 h-4" />
                  <span>Email</span>
                </label>
                {selectedMessage.phone && (
                  <label className="flex items-center gap-2">
                    <input
                      type="radio"
                      checked={replyType === 'sms'}
                      onChange={() => setReplyType('sms')}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <MessageSquare className="w-4 h-4" />
                    <span>SMS</span>
                  </label>
                )}
                {selectedMessage.lead_id && (
                  <label className="flex items-center gap-2">
                    <input
                      type="radio"
                      checked={replyType === 'in_app'}
                      onChange={() => setReplyType('in_app')}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <Building2 className="w-4 h-4" />
                    <span>In-App</span>
                  </label>
                )}
              </div>
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Message
              </label>
              <textarea
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
                rows={6}
                value={replyContent}
                onChange={(e) => setReplyContent(e.target.value)}
                placeholder="Type your reply..."
              />
            </div>

            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowReplyModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleSendReply}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                disabled={!replyContent.trim() || sending}
              >
                {sending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    Send Reply
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}