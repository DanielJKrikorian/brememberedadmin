import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { 
  Search, Filter, Truck, DollarSign, Calendar, 
  AlertCircle, X, Check, Trash2, Eye, Package, 
  ShoppingBag, User, MapPin, Phone, Mail, ExternalLink
} from 'lucide-react';
import DateTimeDisplay from '../components/DateTimeDisplay';

interface Order {
  id: string;
  vendor_id: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  total_amount: number;
  shipping_address: string;
  tracking_number: string | null;
  tracking_url: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
  vendor: {
    name: string;
    email: string;
    phone: string | null;
  };
  items: Array<{
    id: string;
    product_id: string;
    quantity: number;
    price: number;
    product: {
      name: string;
      image_url: string | null;
      category: string;
    };
  }>;
}

interface OrdersTableProps {
  onAddTracking: (order: Order) => void;
  onDeleteOrder: (orderId: string) => void;
}

export default function OrdersTable({ onAddTracking, onDeleteOrder }: OrdersTableProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState('all');
  const [showOrderDetails, setShowOrderDetails] = useState<string | null>(null);

  useEffect(() => {
    fetchOrders();
  }, []);

  async function fetchOrders() {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          vendor:vendors(name, email, phone),
          items:order_items(
            id,
            product_id,
            quantity,
            price,
            product:products(name, image_url, category)
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setOrders(data || []);
    } catch (err) {
      console.error('Error fetching orders:', err);
      setError('Failed to load orders');
    } finally {
      setLoading(false);
    }
  }

  // Filter orders based on search term, status, and date
  const filteredOrders = orders.filter(order => {
    const matchesSearch = 
      order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.vendor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.shipping_address.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.tracking_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.items.some(item => item.product.name.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    
    // Date filtering
    const orderDate = new Date(order.created_at);
    const now = new Date();
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    const lastWeek = new Date(now);
    lastWeek.setDate(lastWeek.getDate() - 7);
    const lastMonth = new Date(now);
    lastMonth.setMonth(lastMonth.getMonth() - 1);
    
    const matchesDate = 
      dateFilter === 'all' ||
      (dateFilter === 'today' && orderDate.toDateString() === now.toDateString()) ||
      (dateFilter === 'yesterday' && orderDate.toDateString() === yesterday.toDateString()) ||
      (dateFilter === 'week' && orderDate >= lastWeek) ||
      (dateFilter === 'month' && orderDate >= lastMonth);
    
    return matchesSearch && matchesStatus && matchesDate;
  });

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'shipped':
        return 'bg-purple-100 text-purple-800';
      case 'delivered':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search orders by ID, vendor, product..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <div className="flex flex-wrap gap-4">
          <select
            className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="processing">Processing</option>
            <option value="shipped">Shipped</option>
            <option value="delivered">Delivered</option>
            <option value="cancelled">Cancelled</option>
          </select>
          <select
            className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
          >
            <option value="all">All Time</option>
            <option value="today">Today</option>
            <option value="yesterday">Yesterday</option>
            <option value="week">Last 7 Days</option>
            <option value="month">Last 30 Days</option>
          </select>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : filteredOrders.length === 0 ? (
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <ShoppingBag className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No orders found</h3>
          <p className="text-gray-500">
            {searchTerm || statusFilter !== 'all' || dateFilter !== 'all'
              ? 'Try adjusting your filters to see more results'
              : 'When vendors place orders, they will appear here'}
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Order Details</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Vendor</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Items</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tracking</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredOrders.map((order) => (
                  <React.Fragment key={order.id}>
                    <tr className={`hover:bg-gray-50 ${showOrderDetails === order.id ? 'bg-blue-50' : ''}`}>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <button 
                            onClick={() => setShowOrderDetails(showOrderDetails === order.id ? null : order.id)}
                            className="mr-3 text-gray-400 hover:text-gray-600"
                          >
                            {showOrderDetails === order.id ? (
                              <ChevronDown className="w-5 h-5" />
                            ) : (
                              <ChevronRight className="w-5 h-5" />
                            )}
                          </button>
                          <div>
                            <div className="text-sm font-medium text-gray-900">
                              #{order.id.substring(0, 8)}
                            </div>
                            <div className="text-xs text-gray-500 flex items-center">
                              <Calendar className="w-3 h-3 mr-1" />
                              <DateTimeDisplay date={order.created_at} format="datetime" />
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-gray-900">{order.vendor.name}</div>
                        <div className="text-xs text-gray-500">{order.vendor.email}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900">
                          {order.items.length} {order.items.length === 1 ? 'item' : 'items'}
                        </div>
                        <div className="text-xs text-gray-500 line-clamp-1">
                          {order.items.map(item => item.product.name).join(', ')}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-gray-900">
                          ${order.total_amount.toFixed(2)}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeColor(order.status)}`}>
                          {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        {order.tracking_number ? (
                          <div>
                            <div className="text-sm text-gray-900 flex items-center">
                              <Truck className="w-4 h-4 mr-1 text-gray-500" />
                              {order.tracking_number}
                            </div>
                            {order.tracking_url && (
                              <a 
                                href={order.tracking_url} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-xs text-blue-600 hover:text-blue-800 flex items-center mt-1"
                              >
                                <ExternalLink className="w-3 h-3 mr-1" />
                                Track
                              </a>
                            )}
                          </div>
                        ) : (
                          <span className="text-sm text-gray-500">Not available</span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-sm font-medium">
                        <div className="flex space-x-2">
                          {order.status !== 'cancelled' && order.status !== 'delivered' && (
                            <button
                              onClick={() => onAddTracking(order)}
                              className="text-blue-600 hover:text-blue-900"
                              title={order.tracking_number ? "Update tracking" : "Add tracking"}
                            >
                              <Truck className="w-5 h-5" />
                            </button>
                          )}
                          <button
                            onClick={() => onDeleteOrder(order.id)}
                            className="text-red-600 hover:text-red-900"
                            title="Delete order"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                    
                    {/* Expanded Order Details */}
                    {showOrderDetails === order.id && (
                      <tr className="bg-blue-50">
                        <td colSpan={7} className="px-6 py-4">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                              <h4 className="text-sm font-medium text-gray-900 mb-2">Shipping Address</h4>
                              <div className="bg-white p-3 rounded-lg border border-gray-200">
                                <div className="text-sm text-gray-700 whitespace-pre-line">
                                  {order.shipping_address}
                                </div>
                              </div>
                              
                              {order.notes && (
                                <div className="mt-4">
                                  <h4 className="text-sm font-medium text-gray-900 mb-2">Order Notes</h4>
                                  <div className="bg-white p-3 rounded-lg border border-gray-200">
                                    <div className="text-sm text-gray-700 whitespace-pre-line">
                                      {order.notes}
                                    </div>
                                  </div>
                                </div>
                              )}
                            </div>
                            
                            <div>
                              <h4 className="text-sm font-medium text-gray-900 mb-2">Order Items</h4>
                              <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                                <table className="min-w-full divide-y divide-gray-200">
                                  <thead className="bg-gray-50">
                                    <tr>
                                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Item</th>
                                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Qty</th>
                                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Price</th>
                                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Total</th>
                                    </tr>
                                  </thead>
                                  <tbody className="divide-y divide-gray-200">
                                    {order.items.map((item) => (
                                      <tr key={item.id}>
                                        <td className="px-3 py-2">
                                          <div className="flex items-center">
                                            {item.product.image_url ? (
                                              <img 
                                                src={item.product.image_url} 
                                                alt={item.product.name}
                                                className="w-8 h-8 rounded object-cover mr-2"
                                              />
                                            ) : (
                                              <div className="w-8 h-8 bg-gray-100 rounded flex items-center justify-center mr-2">
                                                <Package className="w-4 h-4 text-gray-400" />
                                              </div>
                                            )}
                                            <div className="text-xs">
                                              <div className="font-medium text-gray-900">{item.product.name}</div>
                                              <div className="text-gray-500">{item.product.category}</div>
                                            </div>
                                          </div>
                                        </td>
                                        <td className="px-3 py-2 text-xs text-gray-900">{item.quantity}</td>
                                        <td className="px-3 py-2 text-xs text-gray-900">${item.price.toFixed(2)}</td>
                                        <td className="px-3 py-2 text-xs font-medium text-gray-900">
                                          ${(item.quantity * item.price).toFixed(2)}
                                        </td>
                                      </tr>
                                    ))}
                                    <tr className="bg-gray-50">
                                      <td colSpan={3} className="px-3 py-2 text-xs font-medium text-gray-900 text-right">
                                        Total:
                                      </td>
                                      <td className="px-3 py-2 text-xs font-medium text-gray-900">
                                        ${order.total_amount.toFixed(2)}
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                              </div>
                              
                              <div className="mt-4">
                                <h4 className="text-sm font-medium text-gray-900 mb-2">Vendor Contact</h4>
                                <div className="bg-white p-3 rounded-lg border border-gray-200 space-y-2">
                                  <div className="flex items-center text-xs text-gray-700">
                                    <User className="w-4 h-4 mr-2 text-gray-500" />
                                    {order.vendor.name}
                                  </div>
                                  <div className="flex items-center text-xs text-gray-700">
                                    <Mail className="w-4 h-4 mr-2 text-gray-500" />
                                    <a href={`mailto:${order.vendor.email}`} className="text-blue-600 hover:text-blue-800">
                                      {order.vendor.email}
                                    </a>
                                  </div>
                                  {order.vendor.phone && (
                                    <div className="flex items-center text-xs text-gray-700">
                                      <Phone className="w-4 h-4 mr-2 text-gray-500" />
                                      <a href={`tel:${order.vendor.phone}`} className="text-blue-600 hover:text-blue-800">
                                        {order.vendor.phone}
                                      </a>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// Additional component for the chevron icon
function ChevronRight(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m9 18 6-6-6-6" />
    </svg>
  );
}

function ChevronDown(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m6 9 6 6 6-6" />
    </svg>
  );
}