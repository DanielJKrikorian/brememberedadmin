import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  ArrowLeft, Save, Package, DollarSign, Clock, Plus, Minus, 
  Check, X, AlertCircle, CheckCircle, Calendar, User, Heart 
} from 'lucide-react';

interface CustomPackageOption {
  id: string;
  name: string;
  description: string | null;
  type: 'hour' | 'addon' | 'feature';
  price: number;
  is_required: boolean;
  min_quantity: number;
  max_quantity: number | null;
  quantity: number; // For UI tracking
}

interface CustomPackageTemplate {
  id: string;
  name: string;
  description: string | null;
  base_price: number;
  min_hours: number;
  max_hours: number | null;
  options: Array<{
    option_id: string;
    default_quantity: number;
  }>;
}

interface Service {
  id: string;
  name: string;
  description: string;
  base_price: number;
}

interface Lead {
  id: string;
  name: string;
  email: string;
  phone: string;
  partner_name: string | null;
  wedding_date: string | null;
}

interface Vendor {
  id: string;
  name: string;
  email: string;
  accepts_custom_packages: boolean;
}

export default function CustomPackageBuilder() {
  const { serviceId, leadId } = useParams();
  const navigate = useNavigate();
  
  const [service, setService] = useState<Service | null>(null);
  const [lead, setLead] = useState<Lead | null>(null);
  const [vendor, setVendor] = useState<Vendor | null>(null);
  const [templates, setTemplates] = useState<CustomPackageTemplate[]>([]);
  const [options, setOptions] = useState<CustomPackageOption[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [hours, setHours] = useState(1);
  const [totalPrice, setTotalPrice] = useState(0);
  const [packageName, setPackageName] = useState('');
  const [notes, setNotes] = useState('');
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  
  useEffect(() => {
    if (serviceId && leadId) {
      Promise.all([
        fetchService(),
        fetchLead(),
        fetchOptions(),
        fetchTemplates()
      ]).finally(() => setLoading(false));
    }
  }, [serviceId, leadId]);
  
  useEffect(() => {
    // When a template is selected, apply its defaults
    if (selectedTemplate) {
      const template = templates.find(t => t.id === selectedTemplate);
      if (template) {
        // Set hours to template minimum
        setHours(template.min_hours);
        
        // Set package name based on template
        setPackageName(`Custom ${template.name}`);
        
        // Apply default quantities from template
        const updatedOptions = options.map(option => {
          const templateOption = template.options.find(to => to.option_id === option.id);
          return {
            ...option,
            quantity: templateOption ? templateOption.default_quantity : 0
          };
        });
        
        setOptions(updatedOptions);
      }
    }
  }, [selectedTemplate, templates]);
  
  useEffect(() => {
    // Calculate total price whenever options or hours change
    calculateTotalPrice();
  }, [options, hours, selectedTemplate]);
  
  async function fetchService() {
    try {
      const { data, error } = await supabase
        .from('services')
        .select(`
          id, 
          name, 
          description, 
          base_price,
          vendor_services(vendor_id, vendor:vendors(id, name, email, accepts_custom_packages))
        `)
        .eq('id', serviceId)
        .single();
        
      if (error) throw error;
      
      setService({
        id: data.id,
        name: data.name,
        description: data.description,
        base_price: data.base_price
      });
      
      // Set vendor if available
      if (data.vendor_services && data.vendor_services.length > 0) {
        setVendor(data.vendor_services[0].vendor);
      }
    } catch (err) {
      console.error('Error fetching service:', err);
      setError('Failed to load service details');
    }
  }
  
  async function fetchLead() {
    try {
      const { data, error } = await supabase
        .from('leads')
        .select('id, name, email, phone, partner_name, wedding_date')
        .eq('id', leadId)
        .single();
        
      if (error) throw error;
      setLead(data);
      
      // Set default package name
      setPackageName(`Custom Package for ${data.name}`);
    } catch (err) {
      console.error('Error fetching lead:', err);
      setError('Failed to load customer details');
    }
  }
  
  async function fetchOptions() {
    try {
      const { data, error } = await supabase
        .from('custom_package_options')
        .select('*')
        .eq('service_id', serviceId)
        .order('name');
        
      if (error) throw error;
      
      // Initialize all options with quantity 0
      setOptions((data || []).map(option => ({
        ...option,
        quantity: 0
      })));
    } catch (err) {
      console.error('Error fetching options:', err);
      setError('Failed to load package options');
    }
  }
  
  async function fetchTemplates() {
    try {
      // Fetch templates
      const { data: templates, error: templatesError } = await supabase
        .from('custom_package_templates')
        .select('*')
        .eq('service_id', serviceId)
        .order('name');
        
      if (templatesError) throw templatesError;
      
      // Fetch template options for each template
      const templatesWithOptions = await Promise.all((templates || []).map(async (template) => {
        const { data: templateOptions, error: optionsError } = await supabase
          .from('custom_package_template_options')
          .select('option_id, default_quantity')
          .eq('template_id', template.id);
          
        if (optionsError) throw optionsError;
        
        return {
          ...template,
          options: templateOptions || []
        };
      }));
      
      setTemplates(templatesWithOptions);
    } catch (err) {
      console.error('Error fetching templates:', err);
      setError('Failed to load package templates');
    }
  }
  
  function calculateTotalPrice() {
    if (!service) return;
    
    let template = null;
    if (selectedTemplate) {
      template = templates.find(t => t.id === selectedTemplate);
    }
    
    // Start with base price (either from template or service)
    let price = template ? template.base_price : service.base_price;
    
    // Add price for hours if any hour-type options exist
    const hourOption = options.find(o => o.type === 'hour');
    if (hourOption) {
      price += hourOption.price * hours;
    }
    
    // Add price for all selected options
    options.forEach(option => {
      if (option.type !== 'hour' && option.quantity > 0) {
        price += option.price * option.quantity;
      }
    });
    
    setTotalPrice(price);
  }
  
  function updateOptionQuantity(optionId: string, change: number) {
    setOptions(options.map(option => {
      if (option.id === optionId) {
        // Calculate new quantity
        let newQuantity = option.quantity + change;
        
        // Enforce min/max constraints
        if (newQuantity < option.min_quantity && option.is_required) {
          newQuantity = option.min_quantity;
        } else if (newQuantity < 0) {
          newQuantity = 0;
        }
        
        if (option.max_quantity !== null && newQuantity > option.max_quantity) {
          newQuantity = option.max_quantity;
        }
        
        return { ...option, quantity: newQuantity };
      }
      return option;
    }));
  }
  
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    
    try {
      if (!service || !lead) {
        throw new Error('Missing service or lead information');
      }
      
      // Validate that required options have been selected
      const requiredOptions = options.filter(o => o.is_required);
      for (const option of requiredOptions) {
        if (option.quantity < option.min_quantity) {
          throw new Error(`${option.name} requires at least ${option.min_quantity} quantity`);
        }
      }
      
      // Create the custom package
      const { data: packageData, error: packageError } = await supabase
        .from('custom_packages')
        .insert({
          lead_id: lead.id,
          service_id: service.id,
          template_id: selectedTemplate,
          name: packageName,
          description: notes,
          hours: hours,
          total_price: totalPrice,
          status: 'submitted'
        })
        .select()
        .single();
        
      if (packageError) throw packageError;
      
      // Add all selected options
      const selectedOptions = options.filter(o => o.quantity > 0);
      if (selectedOptions.length > 0) {
        const { error: selectionsError } = await supabase
          .from('custom_package_selections')
          .insert(
            selectedOptions.map(option => ({
              package_id: packageData.id,
              option_id: option.id,
              quantity: option.quantity,
              price: option.price * option.quantity
            }))
          );
          
        if (selectionsError) throw selectionsError;
      }
      
      setSuccess('Custom package created successfully!');
      
      // Redirect after a short delay
      setTimeout(() => {
        navigate(`/leads/${lead.id}`);
      }, 2000);
    } catch (err) {
      console.error('Error creating custom package:', err);
      setError(err instanceof Error ? err.message : 'Failed to create custom package');
    } finally {
      setSaving(false);
    }
  }
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  
  if (!service || !lead) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-700">Service or lead information not found</p>
        </div>
      </div>
    );
  }
  
  if (vendor && !vendor.accepts_custom_packages) {
    return (
      <div className="p-6">
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <h2 className="text-lg font-semibold text-yellow-800 mb-2">Custom Packages Not Available</h2>
          <p className="text-yellow-700">This vendor does not currently accept custom package requests.</p>
        </div>
        <div className="mt-4">
          <button
            onClick={() => navigate(-1)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate(-1)}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Build Custom Package</h1>
        </div>
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}
      
      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Service Information */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Service Information</h2>
              <div className="flex items-center gap-3 mb-4">
                <Package className="w-6 h-6 text-blue-500" />
                <div>
                  <h3 className="font-medium text-gray-900">{service.name}</h3>
                  <p className="text-sm text-gray-500">{service.description}</p>
                </div>
              </div>
              
              {vendor && (
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <h3 className="font-medium text-gray-900 mb-2">Vendor</h3>
                  <p className="text-gray-700">{vendor.name}</p>
                </div>
              )}
            </div>
            
            {/* Customer Information */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Customer Information</h2>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <User className="w-5 h-5 text-gray-400" />
                  <span className="font-medium text-gray-900">{lead.name}</span>
                  {lead.partner_name && (
                    <>
                      <Heart className="w-4 h-4 text-pink-500 mx-1" />
                      <span className="text-gray-900">{lead.partner_name}</span>
                    </>
                  )}
                </div>
                
                <div className="flex items-center gap-2 text-gray-600">
                  <Calendar className="w-5 h-5 text-gray-400" />
                  <span>
                    {lead.wedding_date 
                      ? new Date(lead.wedding_date).toLocaleDateString() 
                      : 'No date specified'}
                  </span>
                </div>
              </div>
            </div>
            
            {/* Package Builder */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Build Your Package</h2>
              
              {/* Package Name */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Package Name
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  value={packageName}
                  onChange={(e) => setPackageName(e.target.value)}
                  required
                />
              </div>
              
              {/* Template Selection */}
              {templates.length > 0 && (
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Start with a Template (Optional)
                  </label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {templates.map(template => (
                      <div
                        key={template.id}
                        className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                          selectedTemplate === template.id
                            ? 'border-blue-500 bg-blue-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => setSelectedTemplate(
                          selectedTemplate === template.id ? null : template.id
                        )}
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-medium text-gray-900">{template.name}</h3>
                            {template.description && (
                              <p className="text-sm text-gray-500 mt-1">{template.description}</p>
                            )}
                          </div>
                          {selectedTemplate === template.id && (
                            <Check className="w-5 h-5 text-blue-500" />
                          )}
                        </div>
                        <div className="mt-2 flex items-center gap-3">
                          <div className="flex items-center">
                            <DollarSign className="w-4 h-4 text-gray-400 mr-1" />
                            <span className="text-sm font-medium">${template.base_price}</span>
                          </div>
                          <div className="flex items-center">
                            <Clock className="w-4 h-4 text-gray-400 mr-1" />
                            <span className="text-sm">{template.min_hours}h min</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Hours Selection */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Hours
                </label>
                <div className="flex items-center">
                  <button
                    type="button"
                    onClick={() => setHours(Math.max(1, hours - 1))}
                    className="p-2 border border-gray-300 rounded-l-lg hover:bg-gray-100"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <input
                    type="number"
                    min="1"
                    className="w-20 border-t border-b border-gray-300 px-3 py-2 text-center"
                    value={hours}
                    onChange={(e) => setHours(Math.max(1, parseInt(e.target.value) || 1))}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setHours(hours + 1)}
                    className="p-2 border border-gray-300 rounded-r-lg hover:bg-gray-100"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                  <span className="ml-2 text-gray-700">hours</span>
                </div>
              </div>
              
              {/* Options Selection */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Package Options
                </label>
                
                {options.length === 0 ? (
                  <div className="text-center py-6 border border-gray-200 rounded-lg">
                    <p className="text-gray-500">No options available for this service</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {options.map(option => (
                      <div key={option.id} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <div className="flex items-center gap-2">
                              <h3 className="font-medium text-gray-900">{option.name}</h3>
                              {option.is_required && (
                                <span className="px-2 py-0.5 bg-red-100 text-red-800 text-xs rounded-full">
                                  Required
                                </span>
                              )}
                            </div>
                            {option.description && (
                              <p className="text-sm text-gray-500 mt-1">{option.description}</p>
                            )}
                          </div>
                          <div className="text-right">
                            <div className="font-medium text-gray-900">${option.price.toFixed(2)}</div>
                            <div className="text-xs text-gray-500">per {option.type === 'hour' ? 'hour' : 'item'}</div>
                          </div>
                        </div>
                        
                        {option.type !== 'hour' && (
                          <div className="flex items-center justify-end mt-2">
                            <button
                              type="button"
                              onClick={() => updateOptionQuantity(option.id, -1)}
                              className="p-1 border border-gray-300 rounded-l-lg hover:bg-gray-100"
                              disabled={option.quantity <= 0}
                            >
                              <Minus className="w-4 h-4" />
                            </button>
                            <input
                              type="number"
                              min="0"
                              className="w-16 border-t border-b border-gray-300 px-2 py-1 text-center"
                              value={option.quantity}
                              onChange={(e) => {
                                const newQuantity = parseInt(e.target.value) || 0;
                                setOptions(options.map(o => 
                                  o.id === option.id ? { ...o, quantity: newQuantity } : o
                                ));
                              }}
                            />
                            <button
                              type="button"
                              onClick={() => updateOptionQuantity(option.id, 1)}
                              className="p-1 border border-gray-300 rounded-r-lg hover:bg-gray-100"
                              disabled={option.max_quantity !== null && option.quantity >= option.max_quantity}
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
              {/* Notes */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Special Requests or Notes
                </label>
                <textarea
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  rows={4}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Add any special requests or notes for this package..."
                />
              </div>
              
              <div className="flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => navigate(-1)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  disabled={saving}
                >
                  {saving ? 'Creating...' : 'Create Custom Package'}
                </button>
              </div>
            </div>
          </form>
        </div>
        
        {/* Summary Panel */}
        <div>
          <div className="bg-white rounded-lg shadow-md p-6 sticky top-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Package Summary</h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-medium text-gray-700">Service</h3>
                <p className="text-gray-900">{service.name}</p>
              </div>
              
              {selectedTemplate && (
                <div>
                  <h3 className="font-medium text-gray-700">Template</h3>
                  <p className="text-gray-900">
                    {templates.find(t => t.id === selectedTemplate)?.name}
                  </p>
                </div>
              )}
              
              <div>
                <h3 className="font-medium text-gray-700">Hours</h3>
                <p className="text-gray-900">{hours} hours</p>
              </div>
              
              <div>
                <h3 className="font-medium text-gray-700">Selected Options</h3>
                {options.filter(o => o.quantity > 0 && o.type !== 'hour').length === 0 ? (
                  <p className="text-gray-500 italic">No options selected</p>
                ) : (
                  <ul className="space-y-2">
                    {options
                      .filter(o => o.quantity > 0 && o.type !== 'hour')
                      .map(option => (
                        <li key={option.id} className="flex justify-between text-sm">
                          <span>{option.name} × {option.quantity}</span>
                          <span>${(option.price * option.quantity).toFixed(2)}</span>
                        </li>
                      ))}
                  </ul>
                )}
              </div>
              
              <div className="pt-4 border-t border-gray-200">
                <div className="flex justify-between items-center">
                  <h3 className="font-medium text-gray-900">Total Price</h3>
                  <span className="text-xl font-bold text-gray-900">${totalPrice.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}