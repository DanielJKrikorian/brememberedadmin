import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { supabase } from '../lib/supabase';
import { 
  ArrowLeft, Save, Trash2, X, Upload, Plus, Minus, 
  DollarSign, Clock, AlertCircle, CheckCircle, Eye, 
  EyeOff, Repeat, Image as ImageIcon
} from 'lucide-react';
import ProductImageGallery from '../components/ProductImageGallery';

interface RentalCategory {
  id: string;
  name: string;
  description: string | null;
  slug: string | null;
}

interface RentalRate {
  id?: string;
  duration_type: 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly';
  rate: number;
  minimum_duration: number;
  is_subscription: boolean;
}

interface RentalImage {
  id?: string;
  url: string;
  alt_text: string | null;
  display_order: number;
  is_primary: boolean;
}

interface RentalItem {
  id: string;
  name: string;
  description: string | null;
  category_id: string | null;
  condition: string;
  status: 'available' | 'rented' | 'maintenance' | 'retired';
  replacement_value: number;
  serial_number: string | null;
  notes: string | null;
  display_on_landing_page: boolean;
  display_on_couple_site: boolean;
  display_on_vendor_site: boolean;
  created_at: string;
  updated_at: string;
  images: RentalImage[];
  rates: RentalRate[];
}

export default function RentalEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [rentalItem, setRentalItem] = useState<Partial<RentalItem>>({
    name: '',
    description: '',
    category_id: null,
    condition: 'good',
    status: 'available',
    replacement_value: 0,
    serial_number: '',
    notes: '',
    display_on_landing_page: false,
    display_on_couple_site: false,
    display_on_vendor_site: false,
    images: [],
    rates: []
  });
  const [categories, setCategories] = useState<RentalCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({});
  const [showImageGallery, setShowImageGallery] = useState(false);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [isSaved, setIsSaved] = useState(false);

  const isNew = id === 'new';

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.gif', '.webp']
    },
    onDrop: handleImageDrop
  });

  useEffect(() => {
    fetchCategories();
    if (!isNew) {
      fetchRentalItem();
    } else {
      setLoading(false);
    }
  }, [id]);

  async function fetchCategories() {
    try {
      const { data, error } = await supabase
        .from('rental_categories')
        .select('*')
        .order('name');

      if (error) throw error;
      setCategories(data || []);
    } catch (err) {
      console.error('Error fetching categories:', err);
      setError('Failed to load categories');
    }
  }

  async function fetchRentalItem() {
    try {
      const { data, error } = await supabase
        .from('rental_items')
        .select(`
          *,
          images:rental_images(*),
          rates:rental_rates(*)
        `)
        .eq('id', id)
        .single();

      if (error) throw error;
      setRentalItem(data);
    } catch (err) {
      console.error('Error fetching rental item:', err);
      setError('Failed to load rental item');
    } finally {
      setLoading(false);
    }
  }

  async function handleImageDrop(acceptedFiles: File[]) {
    if (!rentalItem.id && !isNew) return;

    for (const file of acceptedFiles) {
      const fileId = Math.random().toString(36).substring(7);
      setUploadProgress(prev => ({ ...prev, [fileId]: 0 }));

      try {
        // If this is a new item, we'll need to create it first to get an ID
        let itemId = rentalItem.id;
        
        if (isNew && !itemId) {
          const { data, error } = await supabase
            .from('rental_items')
            .insert({
              name: rentalItem.name || 'New Rental Item',
              description: rentalItem.description,
              category_id: rentalItem.category_id,
              condition: rentalItem.condition,
              status: rentalItem.status,
              replacement_value: rentalItem.replacement_value,
              serial_number: rentalItem.serial_number,
              notes: rentalItem.notes,
              display_on_landing_page: rentalItem.display_on_landing_page,
              display_on_couple_site: rentalItem.display_on_couple_site,
              display_on_vendor_site: rentalItem.display_on_vendor_site
            })
            .select()
            .single();

          if (error) throw error;
          itemId = data.id;
          setRentalItem(prev => ({ ...prev, id: itemId }));
        }

        // Create a unique file path
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
        const filePath = `${itemId}/${fileName}`;

        // Upload the file
        const { error: uploadError } = await supabase.storage
          .from('rental-images')
          .upload(filePath, file, {
            onUploadProgress: (progress) => {
              const percent = (progress.loaded / progress.total) * 100;
              setUploadProgress(prev => ({ ...prev, [fileId]: percent }));
            }
          });

        if (uploadError) throw uploadError;

        // Get the public URL
        const { data: { publicUrl } } = supabase.storage
          .from('rental-images')
          .getPublicUrl(filePath);

        // Determine if this should be the primary image
        const isPrimary = rentalItem.images?.length === 0;

        // Add the image to the database
        const { data: imageData, error: imageError } = await supabase
          .from('rental_images')
          .insert({
            rental_item_id: itemId,
            url: publicUrl,
            alt_text: file.name,
            display_order: rentalItem.images?.length || 0,
            is_primary: isPrimary
          })
          .select()
          .single();

        if (imageError) throw imageError;

        // Update the rental item with the new image
        setRentalItem(prev => ({
          ...prev,
          images: [...(prev.images || []), imageData]
        }));

        // Clean up progress indicator
        setUploadProgress(prev => {
          const newProgress = { ...prev };
          delete newProgress[fileId];
          return newProgress;
        });
      } catch (err) {
        console.error('Error uploading image:', err);
        setError('Failed to upload image');
        setUploadProgress(prev => {
          const newProgress = { ...prev };
          delete newProgress[fileId];
          return newProgress;
        });
      }
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSuccess(null);

    try {
      if (isNew) {
        // Create new rental item
        const { data, error } = await supabase
          .from('rental_items')
          .insert({
            name: rentalItem.name,
            description: rentalItem.description,
            category_id: rentalItem.category_id,
            condition: rentalItem.condition,
            status: rentalItem.status,
            replacement_value: rentalItem.replacement_value,
            serial_number: rentalItem.serial_number,
            notes: rentalItem.notes,
            display_on_landing_page: rentalItem.display_on_landing_page,
            display_on_couple_site: rentalItem.display_on_couple_site,
            display_on_vendor_site: rentalItem.display_on_vendor_site
          })
          .select()
          .single();

        if (error) throw error;

        // Create rates
        if (rentalItem.rates && rentalItem.rates.length > 0) {
          const { error: ratesError } = await supabase
            .from('rental_rates')
            .insert(
              rentalItem.rates.map(rate => ({
                rental_item_id: data.id,
                duration_type: rate.duration_type,
                rate: rate.rate,
                minimum_duration: rate.minimum_duration,
                is_subscription: rate.is_subscription
              }))
            );

          if (ratesError) throw ratesError;
        }

        setSuccess('Rental item created successfully');
        setIsSaved(true);
        // Navigate back to rentals page after a short delay
        setTimeout(() => {
          navigate('/rentals');
        }, 1500);
      } else {
        // Update existing rental item
        const { error } = await supabase
          .from('rental_items')
          .update({
            name: rentalItem.name,
            description: rentalItem.description,
            category_id: rentalItem.category_id,
            condition: rentalItem.condition,
            status: rentalItem.status,
            replacement_value: rentalItem.replacement_value,
            serial_number: rentalItem.serial_number,
            notes: rentalItem.notes,
            display_on_landing_page: rentalItem.display_on_landing_page,
            display_on_couple_site: rentalItem.display_on_couple_site,
            display_on_vendor_site: rentalItem.display_on_vendor_site
          })
          .eq('id', id);

        if (error) throw error;

        // Delete existing rates
        await supabase
          .from('rental_rates')
          .delete()
          .eq('rental_item_id', id);

        // Create new rates
        if (rentalItem.rates && rentalItem.rates.length > 0) {
          const { error: ratesError } = await supabase
            .from('rental_rates')
            .insert(
              rentalItem.rates.map(rate => ({
                rental_item_id: id,
                duration_type: rate.duration_type,
                rate: rate.rate,
                minimum_duration: rate.minimum_duration,
                is_subscription: rate.is_subscription
              }))
            );

          if (ratesError) throw ratesError;
        }

        setSuccess('Rental item updated successfully');
        setIsSaved(true);
        // Navigate back to rentals page after a short delay
        setTimeout(() => {
          navigate('/rentals');
        }, 1500);
      }
    } catch (err) {
      console.error('Error saving rental item:', err);
      setError(err instanceof Error ? err.message : 'Failed to save rental item');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    if (!rentalItem.id) return;

    try {
      // Delete all images from storage
      if (rentalItem.images && rentalItem.images.length > 0) {
        for (const image of rentalItem.images) {
          const url = new URL(image.url);
          const pathParts = url.pathname.split('/');
          const storagePath = pathParts.slice(pathParts.indexOf('rental-images') + 1).join('/');
          
          await supabase.storage
            .from('rental-images')
            .remove([storagePath]);
        }
      }

      // Delete the rental item (this will cascade delete images and rates)
      const { error } = await supabase
        .from('rental_items')
        .delete()
        .eq('id', rentalItem.id);

      if (error) throw error;

      navigate('/rentals');
    } catch (err) {
      console.error('Error deleting rental item:', err);
      setError(err instanceof Error ? err.message : 'Failed to delete rental item');
    }
  }

  function addRate() {
    setRentalItem(prev => ({
      ...prev,
      rates: [
        ...(prev.rates || []),
        {
          duration_type: 'daily',
          rate: 0,
          minimum_duration: 1,
          is_subscription: false
        }
      ]
    }));
  }

  function removeRate(index: number) {
    setRentalItem(prev => ({
      ...prev,
      rates: prev.rates?.filter((_, i) => i !== index) || []
    }));
  }

  function updateRate(index: number, field: keyof RentalRate, value: any) {
    setRentalItem(prev => {
      const newRates = [...(prev.rates || [])];
      newRates[index] = { ...newRates[index], [field]: value };
      return { ...prev, rates: newRates };
    });
  }

  function setImageAsPrimary(imageId: string) {
    setRentalItem(prev => ({
      ...prev,
      images: prev.images?.map(img => ({
        ...img,
        is_primary: img.id === imageId
      })) || []
    }));

    // Update in database
    if (rentalItem.id) {
      // First, set all images as not primary
      supabase
        .from('rental_images')
        .update({ is_primary: false })
        .eq('rental_item_id', rentalItem.id)
        .then(() => {
          // Then set the selected image as primary
          supabase
            .from('rental_images')
            .update({ is_primary: true })
            .eq('id', imageId)
            .then(() => {
              console.log('Primary image updated');
            })
            .catch(err => {
              console.error('Error updating primary image:', err);
            });
        })
        .catch(err => {
          console.error('Error updating images:', err);
        });
    }
  }

  async function deleteImage(imageId: string, imageUrl: string) {
    try {
      // Delete from storage
      const url = new URL(imageUrl);
      const pathParts = url.pathname.split('/');
      const storagePath = pathParts.slice(pathParts.indexOf('rental-images') + 1).join('/');
      
      await supabase.storage
        .from('rental-images')
        .remove([storagePath]);

      // Delete from database
      const { error } = await supabase
        .from('rental_images')
        .delete()
        .eq('id', imageId);

      if (error) throw error;

      // Update local state
      setRentalItem(prev => ({
        ...prev,
        images: prev.images?.filter(img => img.id !== imageId) || []
      }));
    } catch (err) {
      console.error('Error deleting image:', err);
      setError('Failed to delete image');
    }
  }

  function viewImage(index: number) {
    setSelectedImageIndex(index);
    setShowImageGallery(true);
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/rentals')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">
            {isNew ? 'New Rental Item' : 'Edit Rental Item'}
          </h1>
        </div>
        {!isNew && (
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="flex items-center gap-2 px-4 py-2 text-red-600 hover:text-red-700"
          >
            <Trash2 className="w-5 h-5" />
            Delete Item
          </button>
        )}
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6 space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Name *
              </label>
              <input
                type="text"
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
                value={rentalItem.name}
                onChange={(e) => setRentalItem({ ...rentalItem, name: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
                rows={4}
                value={rentalItem.description || ''}
                onChange={(e) => setRentalItem({ ...rentalItem, description: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Category
                </label>
                <select
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  value={rentalItem.category_id || ''}
                  onChange={(e) => setRentalItem({ ...rentalItem, category_id: e.target.value || null })}
                >
                  <option value="">Select a category</option>
                  {categories.map(category => (
                    <option key={category.id} value={category.id}>{category.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Condition
                </label>
                <select
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  value={rentalItem.condition}
                  onChange={(e) => setRentalItem({ ...rentalItem, condition: e.target.value })}
                >
                  <option value="excellent">Excellent</option>
                  <option value="good">Good</option>
                  <option value="fair">Fair</option>
                  <option value="poor">Poor</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Status
                </label>
                <select
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  value={rentalItem.status}
                  onChange={(e) => setRentalItem({ ...rentalItem, status: e.target.value as any })}
                >
                  <option value="available">Available</option>
                  <option value="rented">Rented</option>
                  <option value="maintenance">Maintenance</option>
                  <option value="retired">Retired</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Replacement Value
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                    $
                  </span>
                  <input
                    type="number"
                    className="w-full pl-7 pr-3 py-2 border border-gray-300 rounded-lg"
                    value={rentalItem.replacement_value}
                    onChange={(e) => setRentalItem({ ...rentalItem, replacement_value: parseFloat(e.target.value) || 0 })}
                    min="0"
                    step="0.01"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Serial Number
              </label>
              <input
                type="text"
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
                value={rentalItem.serial_number || ''}
                onChange={(e) => setRentalItem({ ...rentalItem, serial_number: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Notes
              </label>
              <textarea
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
                rows={3}
                value={rentalItem.notes || ''}
                onChange={(e) => setRentalItem({ ...rentalItem, notes: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Display Options
              </label>
              <div className="space-y-2">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={rentalItem.display_on_landing_page}
                    onChange={(e) => setRentalItem({ ...rentalItem, display_on_landing_page: e.target.checked })}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Display on Landing Page</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={rentalItem.display_on_couple_site}
                    onChange={(e) => setRentalItem({ ...rentalItem, display_on_couple_site: e.target.checked })}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Display on Couple Site</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={rentalItem.display_on_vendor_site}
                    onChange={(e) => setRentalItem({ ...rentalItem, display_on_vendor_site: e.target.checked })}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Display on Vendor Site</span>
                </label>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Rental Rates
              </label>
              <div className="space-y-4">
                {rentalItem.rates && rentalItem.rates.map((rate, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-sm font-medium text-gray-700">Rate {index + 1}</h3>
                      <button
                        type="button"
                        onClick={() => removeRate(index)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Duration Type
                        </label>
                        <select
                          className="w-full border border-gray-300 rounded-lg px-3 py-2"
                          value={rate.duration_type}
                          onChange={(e) => updateRate(index, 'duration_type', e.target.value)}
                          required
                        >
                          <option value="hourly">Hourly</option>
                          <option value="daily">Daily</option>
                          <option value="weekly">Weekly</option>
                          <option value="monthly">Monthly</option>
                          <option value="yearly">Yearly</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Rate
                        </label>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                            $
                          </span>
                          <input
                            type="number"
                            className="w-full pl-7 pr-3 py-2 border border-gray-300 rounded-lg"
                            value={rate.rate}
                            onChange={(e) => updateRate(index, 'rate', parseFloat(e.target.value) || 0)}
                            min="0"
                            step="0.01"
                            required
                          />
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Minimum Duration
                        </label>
                        <input
                          type="number"
                          className="w-full border border-gray-300 rounded-lg px-3 py-2"
                          value={rate.minimum_duration}
                          onChange={(e) => updateRate(index, 'minimum_duration', parseInt(e.target.value) || 1)}
                          min="1"
                          required
                        />
                      </div>

                      <div className="flex items-center">
                        <label className="flex items-center">
                          <input
                            type="checkbox"
                            checked={rate.is_subscription}
                            onChange={(e) => updateRate(index, 'is_subscription', e.target.checked)}
                            className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                          />
                          <span className="ml-2 text-sm text-gray-700">Available as subscription</span>
                        </label>
                      </div>
                    </div>
                  </div>
                ))}

                <button
                  type="button"
                  onClick={addRate}
                  className="w-full py-2 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-gray-400 hover:text-gray-700 transition-colors flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Add Rate
                </button>
              </div>
            </div>

            <div className="pt-6 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => navigate('/rentals')}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                disabled={saving || isSaved}
              >
                <Save className="w-5 h-5" />
                {saving ? 'Saving...' : isSaved ? 'Saved!' : 'Save'}
              </button>
            </div>
          </form>
        </div>

        <div>
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Images</h2>
            
            <div {...getRootProps()} className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer mb-6">
              <input {...getInputProps()} />
              <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-600">
                {isDragActive ? 'Drop images here' : 'Drag & drop images here, or click to select'}
              </p>
              <p className="text-sm text-gray-500 mt-1">
                Supported formats: JPEG, PNG, GIF, WebP
              </p>
            </div>

            {/* Upload Progress */}
            {Object.entries(uploadProgress).map(([fileId, progress]) => (
              <div key={fileId} className="mb-4">
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>Uploading image...</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            ))}

            {/* Image Gallery */}
            <div className="grid grid-cols-2 gap-4">
              {rentalItem.images && rentalItem.images.map((image, index) => (
                <div key={image.id || index} className="relative group">
                  <img
                    src={image.url}
                    alt={image.alt_text || 'Rental item image'}
                    className="w-full h-32 object-cover rounded-lg cursor-pointer"
                    onClick={() => viewImage(index)}
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-opacity rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        viewImage(index);
                      }}
                      className="p-1 bg-white rounded-full text-gray-700 hover:text-gray-900 mx-1"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setImageAsPrimary(image.id!);
                      }}
                      className={`p-1 rounded-full mx-1 ${
                        image.is_primary 
                          ? 'bg-blue-500 text-white' 
                          : 'bg-white text-gray-700 hover:text-gray-900'
                      }`}
                      disabled={image.is_primary}
                    >
                      <ImageIcon className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteImage(image.id!, image.url);
                      }}
                      className="p-1 bg-white rounded-full text-red-600 hover:text-red-700 mx-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  {image.is_primary && (
                    <div className="absolute top-2 left-2 bg-blue-500 text-white text-xs px-2 py-1 rounded-full">
                      Primary
                    </div>
                  )}
                </div>
              ))}
            </div>

            {(!rentalItem.images || rentalItem.images.length === 0) && (
              <div className="text-center py-4 text-gray-500">
                No images uploaded yet
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Delete Rental Item</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this rental item? This action cannot be undone and will remove all associated images and rates.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Delete Item
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Image Gallery Modal */}
      {showImageGallery && rentalItem.images && (
        <ProductImageGallery
          images={rentalItem.images}
          onClose={() => setShowImageGallery(false)}
        />
      )}
    </div>
  );
}