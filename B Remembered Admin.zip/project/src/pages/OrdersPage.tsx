import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { 
  PlusCircle, Search, Filter, Calendar, Download, 
  AlertCircle, X, Truck, Printer, FileText
} from 'lucide-react';
import OrdersTable from './OrdersTable';
import OrderStats from '../components/OrderStats';

interface Order {
  id: string;
  vendor_id: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  total_amount: number;
  shipping_address: string;
  tracking_number: string | null;
  tracking_url: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
  vendor: {
    name: string;
    email: string;
    phone: string | null;
  };
  items: Array<{
    id: string;
    product_id: string;
    quantity: number;
    price: number;
    product: {
      name: string;
      image_url: string | null;
      category: string;
    };
  }>;
}

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showTrackingModal, setShowTrackingModal] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [trackingInfo, setTrackingInfo] = useState({
    tracking_number: '',
    tracking_url: '',
    notify_customer: true,
    notification_type: 'email' as 'email' | 'sms' | 'both'
  });
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [orderToDelete, setOrderToDelete] = useState<string | null>(null);
  const [orderStats, setOrderStats] = useState({
    total: 0,
    pending: 0,
    processing: 0,
    shipped: 0,
    delivered: 0,
    cancelled: 0,
    totalValue: 0,
    avgValue: 0,
    recentOrders: 0
  });

  useEffect(() => {
    fetchOrders();
  }, []);

  async function fetchOrders() {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          vendor:vendors(name, email, phone),
          items:order_items(
            id,
            product_id,
            quantity,
            price,
            product:products(name, image_url, category)
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      setOrders(data || []);
      
      // Calculate stats
      if (data) {
        const now = new Date();
        const oneWeekAgo = new Date(now);
        oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
        
        const pending = data.filter(o => o.status === 'pending').length;
        const processing = data.filter(o => o.status === 'processing').length;
        const shipped = data.filter(o => o.status === 'shipped').length;
        const delivered = data.filter(o => o.status === 'delivered').length;
        const cancelled = data.filter(o => o.status === 'cancelled').length;
        const totalValue = data.reduce((sum, order) => sum + order.total_amount, 0);
        const recentOrders = data.filter(o => new Date(o.created_at) >= oneWeekAgo).length;
        
        setOrderStats({
          total: data.length,
          pending,
          processing,
          shipped,
          delivered,
          cancelled,
          totalValue,
          avgValue: data.length > 0 ? totalValue / data.length : 0,
          recentOrders
        });
      }
    } catch (err) {
      console.error('Error fetching orders:', err);
      setError('Failed to load orders');
    } finally {
      setLoading(false);
    }
  }

  async function handleTrackingUpdate(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedOrder) return;
    setError(null);

    try {
      // Update order with tracking info
      const { error: updateError } = await supabase
        .from('orders')
        .update({
          tracking_number: trackingInfo.tracking_number,
          tracking_url: trackingInfo.tracking_url || null,
          status: 'shipped'
        })
        .eq('id', selectedOrder.id);

      if (updateError) throw updateError;

      // Send notification if requested
      if (trackingInfo.notify_customer) {
        const notificationTypes = trackingInfo.notification_type === 'both' 
          ? ['email', 'sms'] 
          : [trackingInfo.notification_type];
        
        for (const type of notificationTypes) {
          const content = `Your order has been shipped! Tracking number: ${trackingInfo.tracking_number}${
            trackingInfo.tracking_url ? `. Track your package at: ${trackingInfo.tracking_url}` : ''
          }`;
          
          const { error: notificationError } = await supabase
            .from('order_notifications')
            .insert({
              order_id: selectedOrder.id,
              type,
              content,
              status: 'pending'
            });
          
          if (notificationError) throw notificationError;
        }
        
        // Trigger notification sending via edge function
        try {
          await fetch('/functions/v1/send-tracking-notification', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              orderId: selectedOrder.id,
              notificationTypes
            }),
          });
        } catch (notifyError) {
          console.error('Error sending notifications:', notifyError);
          // Continue even if notification sending fails
        }
      }

      setShowTrackingModal(false);
      setSelectedOrder(null);
      setTrackingInfo({
        tracking_number: '',
        tracking_url: '',
        notify_customer: true,
        notification_type: 'email'
      });
      fetchOrders();
    } catch (err) {
      console.error('Error updating tracking:', err);
      setError(err instanceof Error ? err.message : 'Failed to update tracking information');
    }
  }

  async function handleDeleteOrder() {
    if (!orderToDelete) return;
    setError(null);

    try {
      // For orders, first delete related items and notifications
      await supabase
        .from('order_notifications')
        .delete()
        .eq('order_id', orderToDelete);
        
      await supabase
        .from('order_items')
        .delete()
        .eq('order_id', orderToDelete);
      
      // Then delete the order
      const { error } = await supabase
        .from('orders')
        .delete()
        .eq('id', orderToDelete);

      if (error) throw error;

      setShowDeleteConfirm(false);
      setOrderToDelete(null);
      fetchOrders();
    } catch (err) {
      console.error('Error deleting order:', err);
      setError(err instanceof Error ? err.message : 'Failed to delete order');
    }
  }

  function handleAddTracking(order: Order) {
    setSelectedOrder(order);
    setTrackingInfo({
      tracking_number: order.tracking_number || '',
      tracking_url: order.tracking_url || '',
      notify_customer: true,
      notification_type: 'email'
    });
    setShowTrackingModal(true);
  }

  function confirmDeleteOrder(orderId: string) {
    setOrderToDelete(orderId);
    setShowDeleteConfirm(true);
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Orders</h1>
        <div className="flex gap-2">
          <button
            onClick={() => {
              // Export orders to CSV
              alert('Export functionality would go here');
            }}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            <Download className="w-5 h-5" />
            Export
          </button>
          <button
            onClick={() => {
              // Print orders
              window.print();
            }}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            <Printer className="w-5 h-5" />
            Print
          </button>
        </div>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {/* Order Statistics */}
      <OrderStats stats={orderStats} />

      {/* Orders Table */}
      <OrdersTable 
        onAddTracking={handleAddTracking}
        onDeleteOrder={confirmDeleteOrder}
      />

      {/* Tracking Modal */}
      {showTrackingModal && selectedOrder && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-lg">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-gray-900">
                {selectedOrder.tracking_number ? 'Update' : 'Add'} Tracking Information
              </h2>
              <button
                onClick={() => setShowTrackingModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleTrackingUpdate} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Order
                </label>
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="text-sm font-medium text-gray-900">
                    Order #{selectedOrder.id.substring(0, 8)}
                  </div>
                  <div className="text-sm text-gray-500">
                    {selectedOrder.vendor.name} - ${selectedOrder.total_amount.toFixed(2)}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tracking Number *
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  value={trackingInfo.tracking_number}
                  onChange={(e) => setTrackingInfo({ ...trackingInfo, tracking_number: e.target.value })}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tracking URL
                </label>
                <input
                  type="url"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  value={trackingInfo.tracking_url}
                  onChange={(e) => setTrackingInfo({ ...trackingInfo, tracking_url: e.target.value })}
                  placeholder="https://example.com/track?number=123456789"
                />
              </div>

              <div className="border-t border-gray-200 pt-4">
                <div className="flex items-center mb-4">
                  <input
                    type="checkbox"
                    id="notify-customer"
                    checked={trackingInfo.notify_customer}
                    onChange={(e) => setTrackingInfo({ ...trackingInfo, notify_customer: e.target.checked })}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <label htmlFor="notify-customer" className="ml-2 block text-sm text-gray-900">
                    Notify vendor about shipment
                  </label>
                </div>

                {trackingInfo.notify_customer && (
                  <div className="ml-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Notification Method
                    </label>
                    <div className="space-y-2">
                      <label className="flex items-center">
                        <input
                          type="radio"
                          checked={trackingInfo.notification_type === 'email'}
                          onChange={() => setTrackingInfo({ ...trackingInfo, notification_type: 'email' })}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                        />
                        <span className="ml-2 block text-sm text-gray-900">Email only</span>
                      </label>
                      <label className="flex items-center">
                        <input
                          type="radio"
                          checked={trackingInfo.notification_type === 'sms'}
                          onChange={() => setTrackingInfo({ ...trackingInfo, notification_type: 'sms' })}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                        />
                        <span className="ml-2 block text-sm text-gray-900">SMS only</span>
                      </label>
                      <label className="flex items-center">
                        <input
                          type="radio"
                          checked={trackingInfo.notification_type === 'both'}
                          onChange={() => setTrackingInfo({ ...trackingInfo, notification_type: 'both' })}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                        />
                        <span className="ml-2 block text-sm text-gray-900">Both Email and SMS</span>
                      </label>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowTrackingModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  {selectedOrder.tracking_number ? 'Update' : 'Add'} Tracking
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Confirm Delete</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this order? This action cannot be undone and will remove all associated order items and notifications.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteOrder}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Delete Order
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}