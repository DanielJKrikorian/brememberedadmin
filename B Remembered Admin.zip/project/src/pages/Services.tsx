import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { PlusCircle, Search, Package, ChevronRight, Eye, EyeOff, Settings } from 'lucide-react';

interface ServiceVariant {
  id: string;
  name: string;
  price: number;
  hours: number | null;
  description: string | null;
}

interface Service {
  id: string;
  name: string;
  description: string;
  base_price: number;
  visibility: 'visible' | 'hidden';
  allows_custom_packages: boolean;
  variants: ServiceVariant[];
}

export default function Services() {
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchServices();
  }, []);

  async function fetchServices() {
    try {
      const { data: servicesData, error: servicesError } = await supabase
        .from('services')
        .select(`
          *,
          variants:service_variants(id, name, price, hours)
        `)
        .order('name');

      if (servicesError) throw servicesError;
      setServices(servicesData || []);
    } catch (error) {
      console.error('Error fetching services:', error);
    } finally {
      setLoading(false);
    }
  }

  async function toggleVisibility(serviceId: string, currentVisibility: 'visible' | 'hidden') {
    try {
      const newVisibility = currentVisibility === 'visible' ? 'hidden' : 'visible';
      
      const { error } = await supabase
        .from('services')
        .update({ visibility: newVisibility })
        .eq('id', serviceId);

      if (error) throw error;

      // Update local state
      setServices(services.map(service => 
        service.id === serviceId 
          ? { ...service, visibility: newVisibility }
          : service
      ));
    } catch (error) {
      console.error('Error updating service visibility:', error);
    }
  }

  const filteredServices = services.filter(service =>
    service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    service.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Services</h1>
        <button
          onClick={() => navigate('/services/new')}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <PlusCircle className="w-5 h-5" />
          New Service
        </button>
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
        <input
          type="text"
          placeholder="Search services..."
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredServices.map((service) => (
            <div
              key={service.id}
              className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h2 className="text-xl font-semibold text-gray-900">{service.name}</h2>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleVisibility(service.id, service.visibility);
                        }}
                        className={`p-1 rounded-full transition-colors ${
                          service.visibility === 'visible'
                            ? 'text-green-600 hover:bg-green-50'
                            : 'text-gray-400 hover:bg-gray-50'
                        }`}
                        title={service.visibility === 'visible' ? 'Service is visible' : 'Service is hidden'}
                      >
                        {service.visibility === 'visible' ? (
                          <Eye className="w-4 h-4" />
                        ) : (
                          <EyeOff className="w-4 h-4" />
                        )}
                      </button>
                      
                      {service.allows_custom_packages && (
                        <span 
                          className="p-1 rounded-full text-blue-600 hover:bg-blue-50"
                          title="Allows custom packages"
                        >
                          <Settings className="w-4 h-4" />
                        </span>
                      )}
                    </div>
                  </div>
                  <p className="text-gray-600 line-clamp-2 mb-4">{service.description}</p>
                  <div className="flex items-center text-gray-500">
                    <Package className="w-4 h-4 mr-2" />
                    <span>{service.variants?.length || 0} variants</span>
                  </div>
                </div>
                <button
                  onClick={() => navigate(`/services/${service.id}`)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {filteredServices.length === 0 && (
        <div className="text-center py-12">
          <h3 className="text-lg font-medium text-gray-900">No services found</h3>
          <p className="text-gray-600 mt-2">
            {searchTerm ? 'Try adjusting your search terms' : 'Get started by creating your first service'}
          </p>
        </div>
      )}
    </div>
  );
}