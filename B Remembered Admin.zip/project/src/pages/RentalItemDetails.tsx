import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  ArrowLeft, Edit, Truck, DollarSign, Calendar, Clock, 
  Wrench, CheckCircle, XCircle, Repeat, AlertCircle, 
  Plus, Eye, Image as ImageIcon, Tag, FileText, Building2, User,
  MapPin, ExternalLink
} from 'lucide-react';
import ProductImageGallery from '../components/ProductImageGallery';

interface RentalImage {
  id: string;
  url: string;
  alt_text: string | null;
  display_order: number;
  is_primary: boolean;
}

interface RentalRate {
  id: string;
  duration_type: 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly';
  rate: number;
  minimum_duration: number;
  is_subscription: boolean;
}

interface RentalBooking {
  id: string;
  start_date: string;
  end_date: string;
  status: 'pending' | 'confirmed' | 'active' | 'completed' | 'cancelled';
  delivery_method: 'pickup' | 'shipping';
  pickup_date: string | null;
  pickup_location: string | null;
  shipping_address: string | null;
  shipping_method: string | null;
  tracking_number: string | null;
  tracking_url: string | null;
  lead?: {
    name: string;
  };
  vendor?: {
    name: string;
  };
}

interface RentalMaintenance {
  id: string;
  maintenance_type: string;
  description: string;
  scheduled_date: string | null;
  completed_date: string | null;
  cost: number;
  performed_by: string | null;
}

interface RentalItem {
  id: string;
  name: string;
  description: string | null;
  category_id: string | null;
  condition: string;
  status: 'available' | 'rented' | 'maintenance' | 'retired';
  replacement_value: number;
  serial_number: string | null;
  notes: string | null;
  display_on_landing_page: boolean;
  display_on_couple_site: boolean;
  display_on_vendor_site: boolean;
  created_at: string;
  updated_at: string;
  category?: {
    name: string;
    slug: string;
  };
  images: RentalImage[];
  rates: RentalRate[];
  bookings: RentalBooking[];
  maintenance: RentalMaintenance[];
}

export default function RentalItemDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [rentalItem, setRentalItem] = useState<RentalItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showImageGallery, setShowImageGallery] = useState(false);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [activeTab, setActiveTab] = useState<'details' | 'bookings' | 'maintenance'>('details');

  useEffect(() => {
    fetchRentalItem();
  }, [id]);

  async function fetchRentalItem() {
    try {
      const { data, error } = await supabase
        .from('rental_items')
        .select(`
          *,
          category:rental_categories(name, slug),
          images:rental_images(*),
          rates:rental_rates(*),
          bookings:rental_bookings(
            id, 
            start_date, 
            end_date, 
            status,
            delivery_method,
            pickup_date,
            pickup_location,
            shipping_address,
            shipping_method,
            tracking_number,
            tracking_url,
            lead:leads(name),
            vendor:vendors(name)
          ),
          maintenance:rental_maintenance(
            id,
            maintenance_type,
            description,
            scheduled_date,
            completed_date,
            cost,
            performed_by
          )
        `)
        .eq('id', id)
        .single();

      if (error) throw error;
      setRentalItem(data);
    } catch (err) {
      console.error('Error fetching rental item:', err);
      setError('Failed to load rental item');
    } finally {
      setLoading(false);
    }
  }

  function viewImage(index: number) {
    setSelectedImageIndex(index);
    setShowImageGallery(true);
  }

  // Format duration type for display
  const formatDurationType = (type: string, count: number = 1) => {
    switch (type) {
      case 'hourly':
        return count === 1 ? 'Hour' : 'Hours';
      case 'daily':
        return count === 1 ? 'Day' : 'Days';
      case 'weekly':
        return count === 1 ? 'Week' : 'Weeks';
      case 'monthly':
        return count === 1 ? 'Month' : 'Months';
      case 'yearly':
        return count === 1 ? 'Year' : 'Years';
      default:
        return type;
    }
  };

  // Get status badge color
  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'available':
        return 'bg-green-100 text-green-800';
      case 'rented':
        return 'bg-blue-100 text-blue-800';
      case 'maintenance':
        return 'bg-yellow-100 text-yellow-800';
      case 'retired':
        return 'bg-gray-100 text-gray-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'confirmed':
        return 'bg-blue-100 text-blue-800';
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-purple-100 text-purple-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!rentalItem) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-700">Rental item not found</p>
        </div>
      </div>
    );
  }

  // Get primary image
  const primaryImage = rentalItem.images.find(img => img.is_primary) || 
                      (rentalItem.images.length > 0 ? rentalItem.images[0] : null);

  // Filter active bookings and maintenance
  const activeBookings = rentalItem.bookings.filter(b => 
    b.status === 'confirmed' || b.status === 'active'
  );
  
  const scheduledMaintenance = rentalItem.maintenance.filter(m => 
    m.scheduled_date && !m.completed_date
  );

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/rentals')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">{rentalItem.name}</h1>
        </div>
        <button
          onClick={() => navigate(`/rentals/${rentalItem.id}`)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Edit className="w-5 h-5" />
          Edit Item
        </button>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {/* Tabs */}
          <div className="mb-6 border-b border-gray-200">
            <div className="flex space-x-8">
              <button
                onClick={() => setActiveTab('details')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'details'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Item Details
              </button>
              <button
                onClick={() => setActiveTab('bookings')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'bookings'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Bookings
              </button>
              <button
                onClick={() => setActiveTab('maintenance')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'maintenance'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Maintenance
              </button>
            </div>
          </div>

          {/* Details Tab */}
          {activeTab === 'details' && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <div className="aspect-square mb-4 relative">
                    {primaryImage ? (
                      <img
                        src={primaryImage.url}
                        alt={rentalItem.name}
                        className="w-full h-full object-cover rounded-lg cursor-pointer"
                        onClick={() => viewImage(0)}
                      />
                    ) : (
                      <div className="w-full h-full bg-gray-100 flex items-center justify-center rounded-lg">
                        <Truck className="w-16 h-16 text-gray-400" />
                      </div>
                    )}
                    <div className="absolute top-2 right-2">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        getStatusBadgeColor(rentalItem.status)
                      }`}>
                        {rentalItem.status}
                      </span>
                    </div>
                  </div>

                  {rentalItem.images.length > 1 && (
                    <div className="grid grid-cols-4 gap-2">
                      {rentalItem.images.slice(0, 4).map((image, index) => (
                        <div 
                          key={image.id} 
                          className="aspect-square cursor-pointer relative"
                          onClick={() => viewImage(index)}
                        >
                          <img
                            src={image.url}
                            alt={`${rentalItem.name} - image ${index + 1}`}
                            className="w-full h-full object-cover rounded-lg"
                          />
                          {image.is_primary && (
                            <div className="absolute bottom-1 right-1 bg-blue-500 rounded-full w-4 h-4 flex items-center justify-center">
                              <CheckCircle className="w-3 h-3 text-white" />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {rentalItem.images.length > 4 && (
                    <button
                      onClick={() => viewImage(0)}
                      className="mt-2 text-sm text-blue-600 hover:text-blue-800 flex items-center"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View all {rentalItem.images.length} images
                    </button>
                  )}
                </div>

                <div className="space-y-6">
                  <div>
                    <h2 className="text-xl font-semibold text-gray-900 mb-2">{rentalItem.name}</h2>
                    {rentalItem.description && (
                      <p className="text-gray-600">{rentalItem.description}</p>
                    )}
                  </div>

                  <div className="flex items-center">
                    <Tag className="w-5 h-5 text-gray-400 mr-2" />
                    <span className="text-gray-700">
                      Category: <span className="font-medium">{rentalItem.category?.name || 'Uncategorized'}</span>
                    </span>
                  </div>

                  <div className="flex items-center">
                    <FileText className="w-5 h-5 text-gray-400 mr-2" />
                    <span className="text-gray-700">
                      Condition: <span className="font-medium">{rentalItem.condition}</span>
                    </span>
                  </div>

                  {rentalItem.serial_number && (
                    <div className="flex items-center">
                      <Tag className="w-5 h-5 text-gray-400 mr-2" />
                      <span className="text-gray-700">
                        Serial Number: <span className="font-medium">{rentalItem.serial_number}</span>
                      </span>
                    </div>
                  )}

                  <div className="flex items-center">
                    <DollarSign className="w-5 h-5 text-gray-400 mr-2" />
                    <span className="text-gray-700">
                      Replacement Value: <span className="font-medium">${rentalItem.replacement_value.toFixed(2)}</span>
                    </span>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Rental Rates</h3>
                    <div className="space-y-2">
                      {rentalItem.rates.length > 0 ? (
                        rentalItem.rates.map(rate => (
                          <div key={rate.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div className="flex items-center">
                              <DollarSign className="w-5 h-5 text-gray-400 mr-2" />
                              <div>
                                <span className="font-medium text-gray-900">${rate.rate}</span>
                                <span className="text-gray-500 ml-1">per {formatDurationType(rate.duration_type)}</span>
                                {rate.minimum_duration > 1 && (
                                  <div className="text-sm text-gray-500">
                                    Minimum: {rate.minimum_duration} {formatDurationType(rate.duration_type, rate.minimum_duration)}
                                  </div>
                                )}
                              </div>
                            </div>
                            {rate.is_subscription && (
                              <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full flex items-center">
                                <Repeat className="w-3 h-3 mr-1" />
                                Subscription
                              </span>
                            )}
                          </div>
                        ))
                      ) : (
                        <div className="text-gray-500">No rates defined</div>
                      )}
                    </div>
                  </div>

                  {rentalItem.notes && (
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 mb-2">Notes</h3>
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <p className="text-gray-600 whitespace-pre-line">{rentalItem.notes}</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Bookings Tab */}
          {activeTab === 'bookings' && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Booking History</h2>
                <button
                  onClick={() => navigate(`/rentals/booking/new?itemId=${rentalItem.id}`)}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  <Plus className="w-5 h-5" />
                  New Booking
                </button>
              </div>

              {rentalItem.bookings.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-gray-500">No bookings found for this item</p>
                  <button
                    onClick={() => navigate(`/rentals/booking/new?itemId=${rentalItem.id}`)}
                    className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    <Plus className="w-5 h-5" />
                    Create First Booking
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {rentalItem.bookings.map(booking => (
                    <div 
                      key={booking.id} 
                      className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 cursor-pointer"
                      onClick={() => navigate(`/rentals/booking/${booking.id}`)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center gap-2">
                            <Calendar className="w-5 h-5 text-gray-400" />
                            <span className="font-medium text-gray-900">
                              {new Date(booking.start_date).toLocaleDateString()} - {new Date(booking.end_date).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="mt-2 text-sm text-gray-600">
                            {booking.lead ? (
                              <div className="flex items-center">
                                <User className="w-4 h-4 mr-1" />
                                {booking.lead.name}
                              </div>
                            ) : booking.vendor ? (
                              <div className="flex items-center">
                                <Building2 className="w-4 h-4 mr-1" />
                                {booking.vendor.name}
                              </div>
                            ) : (
                              'Unknown customer'
                            )}
                          </div>
                          
                          {/* Delivery Method Information */}
                          <div className="mt-2 text-sm text-gray-600">
                            {booking.delivery_method === 'pickup' ? (
                              <div className="flex items-center">
                                <MapPin className="w-4 h-4 mr-1" />
                                <span>
                                  Pickup: {booking.pickup_date ? new Date(booking.pickup_date).toLocaleString() : 'Not scheduled'}
                                </span>
                              </div>
                            ) : (
                              <div className="flex items-center">
                                <Truck className="w-4 h-4 mr-1" />
                                <span>
                                  Shipping: {booking.tracking_number ? (
                                    <span className="flex items-center">
                                      {booking.tracking_number}
                                      {booking.tracking_url && (
                                        <a 
                                          href={booking.tracking_url} 
                                          target="_blank" 
                                          rel="noopener noreferrer"
                                          className="ml-1 text-blue-600 hover:text-blue-800"
                                          onClick={(e) => e.stopPropagation()}
                                        >
                                          <ExternalLink className="w-3 h-3" />
                                        </a>
                                      )}
                                    </span>
                                  ) : 'No tracking info'}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          getStatusBadgeColor(booking.status)
                        }`}>
                          {booking.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Maintenance Tab */}
          {activeTab === 'maintenance' && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Maintenance History</h2>
                <button
                  onClick={() => navigate(`/rentals/maintenance/new?itemId=${rentalItem.id}`)}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  <Plus className="w-5 h-5" />
                  New Maintenance
                </button>
              </div>

              {rentalItem.maintenance.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-gray-500">No maintenance records found for this item</p>
                  <button
                    onClick={() => navigate(`/rentals/maintenance/new?itemId=${rentalItem.id}`)}
                    className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    <Plus className="w-5 h-5" />
                    Create First Maintenance Record
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {rentalItem.maintenance.map(record => (
                    <div 
                      key={record.id} 
                      className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 cursor-pointer"
                      onClick={() => navigate(`/rentals/maintenance/${record.id}`)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center gap-2">
                            <Wrench className="w-5 h-5 text-gray-400" />
                            <span className="font-medium text-gray-900">
                              {record.maintenance_type}
                            </span>
                          </div>
                          <p className="mt-1 text-sm text-gray-600 line-clamp-2">{record.description}</p>
                          <div className="mt-2 flex flex-wrap gap-4 text-sm text-gray-600">
                            {record.scheduled_date && (
                              <div className="flex items-center">
                                <Calendar className="w-4 h-4 mr-1" />
                                Scheduled: {new Date(record.scheduled_date).toLocaleDateString()}
                              </div>
                            )}
                            {record.completed_date && (
                              <div className="flex items-center">
                                <CheckCircle className="w-4 h-4 mr-1 text-green-500" />
                                Completed: {new Date(record.completed_date).toLocaleDateString()}
                              </div>
                            )}
                            {record.cost > 0 && (
                              <div className="flex items-center">
                                <DollarSign className="w-4 h-4 mr-1" />
                                Cost: ${record.cost.toFixed(2)}
                              </div>
                            )}
                          </div>
                        </div>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          record.completed_date 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {record.completed_date ? 'Completed' : 'Scheduled'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        <div className="space-y-6">
          {/* Status Card */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Item Status</h2>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                {rentalItem.status === 'available' ? (
                  <CheckCircle className="w-6 h-6 text-green-500 mr-2" />
                ) : rentalItem.status === 'rented' ? (
                  <Clock className="w-6 h-6 text-blue-500 mr-2" />
                ) : rentalItem.status === 'maintenance' ? (
                  <Wrench className="w-6 h-6 text-yellow-500 mr-2" />
                ) : (
                  <XCircle className="w-6 h-6 text-gray-500 mr-2" />
                )}
                <span className="text-xl font-medium capitalize">{rentalItem.status}</span>
              </div>
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                getStatusBadgeColor(rentalItem.status)
              }`}>
                {rentalItem.status}
              </span>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
            <div className="space-y-3">
              <button
                onClick={() => navigate(`/rentals/booking/new?itemId=${rentalItem.id}`)}
                className="w-full flex items-center justify-between px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                disabled={rentalItem.status !== 'available'}
              >
                <span className="flex items-center">
                  <Calendar className="w-5 h-5 mr-2" />
                  Create Booking
                </span>
                <Plus className="w-5 h-5" />
              </button>
              <button
                onClick={() => navigate(`/rentals/maintenance/new?itemId=${rentalItem.id}`)}
                className="w-full flex items-center justify-between px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700"
              >
                <span className="flex items-center">
                  <Wrench className="w-5 h-5 mr-2" />
                  Schedule Maintenance
                </span>
                <Plus className="w-5 h-5" />
              </button>
              <button
                onClick={() => navigate(`/rentals/${rentalItem.id}`)}
                className="w-full flex items-center justify-between px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
              >
                <span className="flex items-center">
                  <Edit className="w-5 h-5 mr-2" />
                  Edit Item Details
                </span>
                <ArrowLeft className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Active Bookings */}
          {activeBookings.length > 0 && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Active Bookings</h2>
              <div className="space-y-3">
                {activeBookings.map(booking => (
                  <div 
                    key={booking.id}
                    className="border border-gray-200 rounded-lg p-3 hover:bg-gray-50 cursor-pointer"
                    onClick={() => navigate(`/rentals/booking/${booking.id}`)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        getStatusBadgeColor(booking.status)
                      }`}>
                        {booking.status}
                      </span>
                      <span className="text-sm text-gray-500">
                        {new Date(booking.start_date).toLocaleDateString()} - {new Date(booking.end_date).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="text-sm">
                      {booking.lead ? (
                        <div className="flex items-center">
                          <User className="w-4 h-4 mr-1 text-gray-400" />
                          <span>{booking.lead.name}</span>
                        </div>
                      ) : booking.vendor ? (
                        <div className="flex items-center">
                          <Building2 className="w-4 h-4 mr-1 text-gray-400" />
                          <span>{booking.vendor.name}</span>
                        </div>
                      ) : (
                        'Unknown customer'
                      )}
                    </div>
                    
                    {/* Delivery Method Information */}
                    <div className="mt-2 text-xs text-gray-500">
                      {booking.delivery_method === 'pickup' ? (
                        <div className="flex items-center">
                          <MapPin className="w-3 h-3 mr-1" />
                          <span>
                            Pickup: {booking.pickup_date ? new Date(booking.pickup_date).toLocaleString() : 'Not scheduled'}
                          </span>
                        </div>
                      ) : (
                        <div className="flex items-center">
                          <Truck className="w-3 h-3 mr-1" />
                          <span>
                            Shipping: {booking.tracking_number || 'No tracking info'}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Scheduled Maintenance */}
          {scheduledMaintenance.length > 0 && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Scheduled Maintenance</h2>
              <div className="space-y-3">
                {scheduledMaintenance.map(record => (
                  <div 
                    key={record.id}
                    className="border border-gray-200 rounded-lg p-3 hover:bg-gray-50 cursor-pointer"
                    onClick={() => navigate(`/rentals/maintenance/${record.id}`)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-gray-900">{record.maintenance_type}</span>
                      {record.scheduled_date && (
                        <span className="text-sm text-gray-500">
                          {new Date(record.scheduled_date).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 line-clamp-2">{record.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Image Gallery Modal */}
      {showImageGallery && rentalItem.images.length > 0 && (
        <ProductImageGallery
          images={rentalItem.images}
          onClose={() => setShowImageGallery(false)}
          initialIndex={selectedImageIndex}
        />
      )}
    </div>
  );
}