import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  ArrowLeft, Save, Send, Calendar, Clock, AlertCircle, 
  CheckCircle, X, Mail, Users, BarChart2, Eye, 
  FileText, Copy, Trash2, Edit
} from 'lucide-react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import parse from 'html-react-parser';

interface NewsletterCampaign {
  id: string;
  name: string;
  template_id: string | null;
  subject: string;
  content: string;
  status: 'draft' | 'scheduled' | 'sent' | 'cancelled';
  scheduled_for: string | null;
  sent_at: string | null;
  created_at: string;
  updated_at: string;
}

interface NewsletterTemplate {
  id: string;
  name: string;
  subject: string;
  content: string;
}

interface NewsletterSubscriber {
  id: string;
  email: string;
  name: string | null;
  type: 'lead' | 'vendor' | 'venue';
  status: 'subscribed' | 'unsubscribed';
}

interface CampaignStats {
  total: number;
  sent: number;
  opened: number;
  clicked: number;
  failed: number;
  openRate: number;
  clickRate: number;
}

export default function NewsletterCampaign() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [campaign, setCampaign] = useState<NewsletterCampaign | null>(null);
  const [templates, setTemplates] = useState<NewsletterTemplate[]>([]);
  const [subscribers, setSubscribers] = useState<NewsletterSubscriber[]>([]);
  const [selectedSubscriberTypes, setSelectedSubscriberTypes] = useState<string[]>(['lead', 'vendor', 'venue']);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [showSendModal, setShowSendModal] = useState(false);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [scheduledDate, setScheduledDate] = useState<string>('');
  const [scheduledTime, setScheduledTime] = useState<string>('');
  const [stats, setStats] = useState<CampaignStats | null>(null);
  
  const quillRef = useRef<ReactQuill>(null);
  
  useEffect(() => {
    Promise.all([
      fetchCampaign(),
      fetchTemplates(),
      fetchSubscribers()
    ]).finally(() => setLoading(false));
  }, [id]);
  
  useEffect(() => {
    if (campaign && campaign.status === 'sent') {
      fetchCampaignStats();
    }
  }, [campaign]);
  
  async function fetchCampaign() {
    try {
      const { data, error } = await supabase
        .from('newsletter_campaigns')
        .select('*')
        .eq('id', id)
        .single();
        
      if (error) throw error;
      setCampaign(data);
      
      // Set default scheduled date/time if scheduled
      if (data.scheduled_for) {
        const scheduledDateTime = new Date(data.scheduled_for);
        setScheduledDate(scheduledDateTime.toISOString().split('T')[0]);
        setScheduledTime(scheduledDateTime.toTimeString().split(' ')[0].substring(0, 5));
      } else {
        // Set default to tomorrow at 9 AM
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        tomorrow.setHours(9, 0, 0, 0);
        setScheduledDate(tomorrow.toISOString().split('T')[0]);
        setScheduledTime('09:00');
      }
    } catch (err) {
      console.error('Error fetching newsletter campaign:', err);
      setError('Failed to load newsletter campaign');
    }
  }
  
  async function fetchTemplates() {
    try {
      const { data, error } = await supabase
        .from('newsletter_templates')
        .select('*')
        .order('name');
        
      if (error) throw error;
      setTemplates(data || []);
    } catch (err) {
      console.error('Error fetching newsletter templates:', err);
      setError('Failed to load newsletter templates');
    }
  }
  
  async function fetchSubscribers() {
    try {
      const { data, error } = await supabase
        .from('newsletter_subscribers')
        .select('*')
        .eq('status', 'subscribed')
        .order('email');
        
      if (error) throw error;
      setSubscribers(data || []);
    } catch (err) {
      console.error('Error fetching newsletter subscribers:', err);
      setError('Failed to load newsletter subscribers');
    }
  }
  
  async function fetchCampaignStats() {
    try {
      // Get total sends
      const { count: total } = await supabase
        .from('newsletter_sends')
        .select('*', { count: 'exact', head: true })
        .eq('campaign_id', id);
        
      // Get sent count
      const { count: sent } = await supabase
        .from('newsletter_sends')
        .select('*', { count: 'exact', head: true })
        .eq('campaign_id', id)
        .eq('status', 'sent');
        
      // Get opened count
      const { count: opened } = await supabase
        .from('newsletter_sends')
        .select('*', { count: 'exact', head: true })
        .eq('campaign_id', id)
        .or('status.eq.opened,status.eq.clicked');
        
      // Get clicked count
      const { count: clicked } = await supabase
        .from('newsletter_sends')
        .select('*', { count: 'exact', head: true })
        .eq('campaign_id', id)
        .eq('status', 'clicked');
        
      // Get failed count
      const { count: failed } = await supabase
        .from('newsletter_sends')
        .select('*', { count: 'exact', head: true })
        .eq('campaign_id', id)
        .eq('status', 'failed');
        
      // Calculate rates
      const openRate = sent > 0 ? (opened / sent) * 100 : 0;
      const clickRate = opened > 0 ? (clicked / opened) * 100 : 0;
      
      setStats({
        total: total || 0,
        sent: sent || 0,
        opened: opened || 0,
        clicked: clicked || 0,
        failed: failed || 0,
        openRate,
        clickRate
      });
    } catch (err) {
      console.error('Error fetching campaign stats:', err);
    }
  }
  
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!campaign) return;
    
    setSaving(true);
    setError(null);
    setSuccess(null);
    
    try {
      const { error } = await supabase
        .from('newsletter_campaigns')
        .update({
          name: campaign.name,
          subject: campaign.subject,
          content: campaign.content
        })
        .eq('id', campaign.id);
        
      if (error) throw error;
      
      setSuccess('Campaign updated successfully');
    } catch (err) {
      console.error('Error saving newsletter campaign:', err);
      setError('Failed to save newsletter campaign');
    } finally {
      setSaving(false);
    }
  }
  
  async function handleScheduleCampaign() {
    if (!campaign) return;
    
    try {
      // Combine date and time
      const scheduledDateTime = new Date(`${scheduledDate}T${scheduledTime}`);
      
      // Check if date is in the past
      if (scheduledDateTime <= new Date()) {
        throw new Error('Scheduled date and time must be in the future');
      }
      
      // Update campaign
      const { error } = await supabase
        .from('newsletter_campaigns')
        .update({
          status: 'scheduled',
          scheduled_for: scheduledDateTime.toISOString()
        })
        .eq('id', campaign.id);
        
      if (error) throw error;
      
      // Update local state
      setCampaign({
        ...campaign,
        status: 'scheduled',
        scheduled_for: scheduledDateTime.toISOString()
      });
      
      // Close modal
      setShowScheduleModal(false);
      
      // Show success message
      setSuccess('Campaign scheduled successfully');
    } catch (err) {
      console.error('Error scheduling campaign:', err);
      setError(err instanceof Error ? err.message : 'Failed to schedule campaign');
    }
  }
  
  async function handleSendCampaign() {
    if (!campaign) return;
    
    try {
      // Get filtered subscribers
      const filteredSubscribers = subscribers.filter(sub => 
        selectedSubscriberTypes.includes(sub.type)
      );
      
      if (filteredSubscribers.length === 0) {
        throw new Error('No subscribers selected');
      }
      
      // Update campaign status
      const { error: updateError } = await supabase
        .from('newsletter_campaigns')
        .update({
          status: 'sent',
          sent_at: new Date().toISOString()
        })
        .eq('id', campaign.id);
        
      if (updateError) throw updateError;
      
      // Create send records for each subscriber
      const sendRecords = filteredSubscribers.map(subscriber => ({
        campaign_id: campaign.id,
        subscriber_id: subscriber.id,
        status: 'pending'
      }));
      
      const { error: sendsError } = await supabase
        .from('newsletter_sends')
        .insert(sendRecords);
        
      if (sendsError) throw sendsError;
      
      // Call the edge function to process the sends
      const response = await fetch('/functions/v1/process-newsletter-sends', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          campaignId: campaign.id
        }),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to process newsletter sends');
      }
      
      // Update local state
      setCampaign({
        ...campaign,
        status: 'sent',
        sent_at: new Date().toISOString()
      });
      
      // Close modal
      setShowSendModal(false);
      
      // Show success message
      setSuccess('Campaign sent successfully');
      
      // Fetch stats after a delay
      setTimeout(() => {
        fetchCampaignStats();
      }, 2000);
    } catch (err) {
      console.error('Error sending campaign:', err);
      setError(err instanceof Error ? err.message : 'Failed to send campaign');
    }
  }
  
  async function handleCancelCampaign() {
    if (!campaign) return;
    
    try {
      // Update campaign status
      const { error } = await supabase
        .from('newsletter_campaigns')
        .update({
          status: 'cancelled'
        })
        .eq('id', campaign.id);
        
      if (error) throw error;
      
      // Update local state
      setCampaign({
        ...campaign,
        status: 'cancelled'
      });
      
      // Show success message
      setSuccess('Campaign cancelled successfully');
    } catch (err) {
      console.error('Error cancelling campaign:', err);
      setError('Failed to cancel campaign');
    }
  }
  
  function handleTemplateChange(templateId: string) {
    const selectedTemplate = templates.find(t => t.id === templateId);
    if (selectedTemplate && campaign) {
      setCampaign({
        ...campaign,
        template_id: templateId,
        subject: selectedTemplate.subject,
        content: selectedTemplate.content
      });
    }
  }
  
  const modules = {
    toolbar: [
      [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      [{ 'color': [] }, { 'background': [] }],
      [{ 'align': [] }],
      ['link', 'image'],
      ['clean']
    ],
  };
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  
  if (!campaign) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 dark:bg-red-900/30 dark:border-red-800">
          <p className="text-red-700 dark:text-red-400">Campaign not found</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/newsletters')}
            className="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-gray-100"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            {campaign.name}
          </h1>
          <span className={`px-2 py-1 text-xs font-medium rounded-full ${
            campaign.status === 'draft' 
              ? 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300' 
              : campaign.status === 'scheduled'
              ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400'
              : campaign.status === 'sent'
              ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
              : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
          }`}>
            {campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}
          </span>
        </div>
        
        <div className="flex items-center gap-2">
          {campaign.status === 'draft' && (
            <>
              <button
                onClick={() => setShowScheduleModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Calendar className="w-5 h-5" />
                Schedule
              </button>
              <button
                onClick={() => setShowSendModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                <Send className="w-5 h-5" />
                Send Now
              </button>
            </>
          )}
          
          {campaign.status === 'scheduled' && (
            <button
              onClick={handleCancelCampaign}
              className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
            >
              <X className="w-5 h-5" />
              Cancel Schedule
            </button>
          )}
          
          <button
            onClick={() => setShowPreview(!showPreview)}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600"
          >
            <Eye className="w-5 h-5" />
            {showPreview ? 'Hide Preview' : 'Preview'}
          </button>
        </div>
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700 dark:bg-red-900/30 dark:border-red-800 dark:text-red-400">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}
      
      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700 dark:bg-green-900/30 dark:border-green-800 dark:text-green-400">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}
      
      {campaign.status === 'scheduled' && campaign.scheduled_for && (
        <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg flex items-center gap-2 text-blue-700 dark:bg-blue-900/30 dark:border-blue-800 dark:text-blue-400">
          <Clock className="w-5 h-5" />
          <span>
            This campaign is scheduled to be sent on {new Date(campaign.scheduled_for).toLocaleString()}
          </span>
        </div>
      )}
      
      {campaign.status === 'sent' && stats && (
        <div className="mb-6 bg-white rounded-lg shadow-md p-6 dark:bg-gray-800">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 dark:text-white">Campaign Statistics</h2>
          
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="bg-gray-50 rounded-lg p-4 text-center dark:bg-gray-700">
              <div className="text-sm text-gray-500 mb-1 dark:text-gray-400">Recipients</div>
              <div className="text-2xl font-bold text-gray-900 dark:text-white">{stats.total}</div>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-4 text-center dark:bg-gray-700">
              <div className="text-sm text-gray-500 mb-1 dark:text-gray-400">Sent</div>
              <div className="text-2xl font-bold text-gray-900 dark:text-white">{stats.sent}</div>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-4 text-center dark:bg-gray-700">
              <div className="text-sm text-gray-500 mb-1 dark:text-gray-400">Opened</div>
              <div className="text-2xl font-bold text-gray-900 dark:text-white">{stats.opened}</div>
              <div className="text-xs text-gray-500 dark:text-gray-400">{stats.openRate.toFixed(1)}%</div>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-4 text-center dark:bg-gray-700">
              <div className="text-sm text-gray-500 mb-1 dark:text-gray-400">Clicked</div>
              <div className="text-2xl font-bold text-gray-900 dark:text-white">{stats.clicked}</div>
              <div className="text-xs text-gray-500 dark:text-gray-400">{stats.clickRate.toFixed(1)}%</div>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-4 text-center dark:bg-gray-700">
              <div className="text-sm text-gray-500 mb-1 dark:text-gray-400">Failed</div>
              <div className="text-2xl font-bold text-gray-900 dark:text-white">{stats.failed}</div>
            </div>
          </div>
        </div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className={showPreview ? 'hidden lg:block' : ''}>
          <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6 dark:bg-gray-800">
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                  Campaign Name
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  value={campaign.name}
                  onChange={(e) => setCampaign({ ...campaign, name: e.target.value })}
                  placeholder="e.g., June 2025 Newsletter"
                  required
                  disabled={campaign.status !== 'draft'}
                />
              </div>
              
              {campaign.status === 'draft' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                    Template
                  </label>
                  <select
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                    value={campaign.template_id || ''}
                    onChange={(e) => handleTemplateChange(e.target.value)}
                  >
                    <option value="">Select a template</option>
                    {templates.map(template => (
                      <option key={template.id} value={template.id}>{template.name}</option>
                    ))}
                  </select>
                </div>
              )}
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                  Email Subject
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  value={campaign.subject}
                  onChange={(e) => setCampaign({ ...campaign, subject: e.target.value })}
                  placeholder="e.g., Your Monthly Wedding Planning Update"
                  required
                  disabled={campaign.status !== 'draft'}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                  Email Content
                </label>
                <div className="border border-gray-300 rounded-lg dark:border-gray-600">
                  <ReactQuill
                    ref={quillRef}
                    theme="snow"
                    value={campaign.content}
                    onChange={(content) => setCampaign({ ...campaign, content })}
                    modules={modules}
                    className="h-96 dark:text-white"
                    readOnly={campaign.status !== 'draft'}
                  />
                </div>
                <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                  Use <code>{'{{name}}'}</code> to personalize with recipient's name and <code>{'{{unsubscribe_url}}'}</code> for the unsubscribe link.
                </p>
              </div>
            </div>
            
            {campaign.status === 'draft' && (
              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => navigate('/newsletters')}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 dark:bg-blue-700 dark:hover:bg-blue-600"
                  disabled={saving}
                >
                  <Save className="w-5 h-5" />
                  {saving ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            )}
          </form>
        </div>
        
        {showPreview && (
          <div className={!showPreview ? 'hidden lg:block' : 'lg:col-span-2 xl:col-span-1'}>
            <div className="bg-white rounded-lg shadow-md p-6 dark:bg-gray-800">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Preview</h2>
                <button
                  onClick={() => setShowPreview(false)}
                  className="text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400 lg:hidden"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-4 dark:border-gray-700">
                <div className="flex items-center gap-2 mb-2 text-sm text-gray-500 dark:text-gray-400">
                  <Mail className="w-4 h-4" />
                  <span>From: B. Remembered Weddings</span>
                </div>
                <div className="flex items-center gap-2 mb-2 text-sm text-gray-500 dark:text-gray-400">
                  <FileText className="w-4 h-4" />
                  <span>Subject: {campaign.subject}</span>
                </div>
                <div className="border-t border-gray-200 pt-4 mt-4 dark:border-gray-700">
                  <div className="prose max-w-none dark:prose-invert">
                    {parse(campaign.content)}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Schedule Modal */}
      {showScheduleModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full dark:bg-gray-800">
            <h2 className="text-xl font-bold text-gray-900 mb-4 dark:text-white">Schedule Campaign</h2>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                  Date
                </label>
                <input
                  type="date"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  value={scheduledDate}
                  onChange={(e) => setScheduledDate(e.target.value)}
                  min={new Date().toISOString().split('T')[0]}
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                  Time
                </label>
                <input
                  type="time"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  value={scheduledTime}
                  onChange={(e) => setScheduledTime(e.target.value)}
                  required
                />
              </div>
              
              <div className="bg-blue-50 p-4 rounded-lg dark:bg-blue-900/20">
                <p className="text-sm text-blue-800 dark:text-blue-300">
                  The campaign will be automatically sent at the scheduled time.
                </p>
              </div>
            </div>
            
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowScheduleModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700"
              >
                Cancel
              </button>
              <button
                onClick={handleScheduleCampaign}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600"
              >
                Schedule
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Send Modal */}
      {showSendModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full dark:bg-gray-800">
            <h2 className="text-xl font-bold text-gray-900 mb-4 dark:text-white">Send Campaign</h2>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 dark:text-gray-300">
                  Select Recipients
                </label>
                <div className="space-y-2">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={selectedSubscriberTypes.includes('lead')}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedSubscriberTypes([...selectedSubscriberTypes, 'lead']);
                        } else {
                          setSelectedSubscriberTypes(selectedSubscriberTypes.filter(t => t !== 'lead'));
                        }
                      }}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-gray-600"
                    />
                    <span className="ml-2 text-gray-700 dark:text-gray-300">
                      Leads ({subscribers.filter(s => s.type === 'lead').length})
                    </span>
                  </label>
                  
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={selectedSubscriberTypes.includes('vendor')}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedSubscriberTypes([...selectedSubscriberTypes, 'vendor']);
                        } else {
                          setSelectedSubscriberTypes(selectedSubscriberTypes.filter(t => t !== 'vendor'));
                        }
                      }}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-gray-600"
                    />
                    <span className="ml-2 text-gray-700 dark:text-gray-300">
                      Vendors ({subscribers.filter(s => s.type === 'vendor').length})
                    </span>
                  </label>
                  
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={selectedSubscriberTypes.includes('venue')}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedSubscriberTypes([...selectedSubscriberTypes, 'venue']);
                        } else {
                          setSelectedSubscriberTypes(selectedSubscriberTypes.filter(t => t !== 'venue'));
                        }
                      }}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-gray-600"
                    />
                    <span className="ml-2 text-gray-700 dark:text-gray-300">
                      Venues ({subscribers.filter(s => s.type === 'venue').length})
                    </span>
                  </label>
                </div>
              </div>
              
              <div className="bg-blue-50 p-4 rounded-lg dark:bg-blue-900/20">
                <div className="flex items-center mb-2">
                  <Users className="w-5 h-5 text-blue-500 mr-2 dark:text-blue-400" />
                  <span className="font-medium text-blue-800 dark:text-blue-300">
                    Total Recipients: {subscribers.filter(s => selectedSubscriberTypes.includes(s.type)).length}
                  </span>
                </div>
                <p className="text-sm text-blue-800 dark:text-blue-300">
                  This campaign will be sent immediately to all selected subscribers.
                </p>
              </div>
            </div>
            
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowSendModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700"
              >
                Cancel
              </button>
              <button
                onClick={handleSendCampaign}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-600"
                disabled={subscribers.filter(s => selectedSubscriberTypes.includes(s.type)).length === 0}
              >
                Send Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}