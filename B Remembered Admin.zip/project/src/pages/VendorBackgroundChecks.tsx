import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  Search, Filter, FileText, CheckCircle, XCircle, 
  AlertCircle, Calendar, User, Download, Eye, Clock
} from 'lucide-react';

interface BackgroundCheck {
  id: string;
  vendor_id: string;
  status: 'pending' | 'approved' | 'rejected';
  document_url: string | null;
  notes: string | null;
  submitted_at: string;
  reviewed_at: string | null;
  created_at: string;
  vendor: {
    name: string;
    email: string;
  };
  reviewer: {
    name: string;
  } | null;
}

export default function VendorBackgroundChecks() {
  const navigate = useNavigate();
  const [backgroundChecks, setBackgroundChecks] = useState<BackgroundCheck[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [selectedCheck, setSelectedCheck] = useState<BackgroundCheck | null>(null);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [reviewNotes, setReviewNotes] = useState('');
  const [reviewStatus, setReviewStatus] = useState<'approved' | 'rejected'>('approved');
  const [saving, setSaving] = useState(false);
  
  useEffect(() => {
    fetchBackgroundChecks();
  }, []);
  
  async function fetchBackgroundChecks() {
    try {
      const { data, error } = await supabase
        .from('vendor_background_checks')
        .select(`
          *,
          vendor:vendors(name, email),
          reviewer:team_members(name)
        `)
        .order('submitted_at', { ascending: false });
        
      if (error) throw error;
      setBackgroundChecks(data || []);
    } catch (err) {
      console.error('Error fetching background checks:', err);
      setError('Failed to load background checks');
    } finally {
      setLoading(false);
    }
  }
  
  async function handleReviewSubmit() {
    if (!selectedCheck) return;
    
    setSaving(true);
    try {
      // Get current user's team member ID
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');
      
      const { data: teamMember } = await supabase
        .from('team_members')
        .select('id')
        .eq('user_id', user.id)
        .single();
        
      if (!teamMember) throw new Error('Team member not found');
      
      // Update background check
      const { error: updateError } = await supabase
        .from('vendor_background_checks')
        .update({
          status: reviewStatus,
          notes: reviewNotes,
          reviewed_at: new Date().toISOString(),
          reviewed_by: teamMember.id
        })
        .eq('id', selectedCheck.id);
        
      if (updateError) throw updateError;
      
      // Update vendor's background check status
      const { error: vendorError } = await supabase
        .from('vendors')
        .update({
          background_check_status: reviewStatus
        })
        .eq('id', selectedCheck.vendor_id);
        
      if (vendorError) throw vendorError;
      
      // Refresh data
      fetchBackgroundChecks();
      
      // Close modal
      setShowReviewModal(false);
      setSelectedCheck(null);
      setReviewNotes('');
    } catch (err) {
      console.error('Error submitting review:', err);
      setError('Failed to submit review');
    } finally {
      setSaving(false);
    }
  }
  
  // Filter background checks based on search term and status filter
  const filteredChecks = backgroundChecks.filter(check => {
    const matchesSearch = 
      check.vendor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      check.vendor.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (check.notes && check.notes.toLowerCase().includes(searchTerm.toLowerCase()));
      
    const matchesStatus = statusFilter === 'all' || check.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            <Clock className="w-3 h-3 mr-1" />
            Pending
          </span>
        );
      case 'approved':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <CheckCircle className="w-3 h-3 mr-1" />
            Approved
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            <XCircle className="w-3 h-3 mr-1" />
            Rejected
          </span>
        );
      default:
        return null;
    }
  };
  
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Vendor Background Checks</h1>
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}
      
      <div className="mb-6 flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search vendors..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <select
          className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as any)}
        >
          <option value="all">All Status</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
        </select>
      </div>
      
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : filteredChecks.length === 0 ? (
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No background checks found</h3>
          <p className="text-gray-500">
            {searchTerm || statusFilter !== 'all'
              ? 'Try adjusting your filters to see more results'
              : 'Background checks will appear here when vendors submit them'}
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Vendor</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Submitted</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Document</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Reviewed</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredChecks.map((check) => (
                <tr key={check.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <User className="w-5 h-5 text-gray-400 mr-3" />
                      <div>
                        <div className="text-sm font-medium text-gray-900">{check.vendor.name}</div>
                        <div className="text-sm text-gray-500">{check.vendor.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 text-gray-400 mr-2" />
                      <span className="text-sm text-gray-900">
                        {new Date(check.submitted_at).toLocaleDateString()}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {check.document_url ? (
                      <div className="flex items-center gap-2">
                        <a
                          href={check.document_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-800 flex items-center"
                        >
                          <FileText className="w-4 h-4 mr-1" />
                          <span className="text-sm">View</span>
                        </a>
                        <a
                          href={check.document_url}
                          download
                          className="text-blue-600 hover:text-blue-800 flex items-center"
                        >
                          <Download className="w-4 h-4 mr-1" />
                          <span className="text-sm">Download</span>
                        </a>
                      </div>
                    ) : (
                      <span className="text-sm text-gray-500">No document</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {getStatusBadge(check.status)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {check.reviewed_at ? (
                      <div>
                        <div className="text-sm text-gray-900">
                          {new Date(check.reviewed_at).toLocaleDateString()}
                        </div>
                        {check.reviewer && (
                          <div className="text-xs text-gray-500">
                            by {check.reviewer.name}
                          </div>
                        )}
                      </div>
                    ) : (
                      <span className="text-sm text-gray-500">Not reviewed</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setSelectedCheck(check);
                          setShowReviewModal(true);
                          setReviewStatus(check.status === 'rejected' ? 'rejected' : 'approved');
                          setReviewNotes(check.notes || '');
                        }}
                        className="text-blue-600 hover:text-blue-900"
                        title={check.status === 'pending' ? "Review" : "Update review"}
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      
      {/* Review Modal */}
      {showReviewModal && selectedCheck && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">
              {selectedCheck.status === 'pending' ? 'Review' : 'Update'} Background Check
            </h2>
            
            <div className="mb-4">
              <div className="text-sm font-medium text-gray-700 mb-1">Vendor</div>
              <div className="text-gray-900">{selectedCheck.vendor.name}</div>
            </div>
            
            {selectedCheck.document_url && (
              <div className="mb-4">
                <div className="text-sm font-medium text-gray-700 mb-1">Document</div>
                <a
                  href={selectedCheck.document_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-800 flex items-center"
                >
                  <FileText className="w-4 h-4 mr-1" />
                  <span>View Document</span>
                </a>
              </div>
            )}
            
            <div className="mb-4">
              <div className="text-sm font-medium text-gray-700 mb-1">Status</div>
              <div className="flex gap-4">
                <label className="flex items-center">
                  <input
                    type="radio"
                    checked={reviewStatus === 'approved'}
                    onChange={() => setReviewStatus('approved')}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-gray-900">Approve</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    checked={reviewStatus === 'rejected'}
                    onChange={() => setReviewStatus('rejected')}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-gray-900">Reject</span>
                </label>
              </div>
            </div>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Notes
              </label>
              <textarea
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
                rows={4}
                value={reviewNotes}
                onChange={(e) => setReviewNotes(e.target.value)}
                placeholder="Add any notes about this background check..."
              />
            </div>
            
            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowReviewModal(false);
                  setSelectedCheck(null);
                  setReviewNotes('');
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                disabled={saving}
              >
                Cancel
              </button>
              <button
                onClick={handleReviewSubmit}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                disabled={saving}
              >
                {saving ? 'Saving...' : 'Submit Review'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}