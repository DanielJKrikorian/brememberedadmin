import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { supabase } from '../lib/supabase';
import { ArrowLeft, Plus, Minus, Trash2, X, Upload, FileText, Pencil, Save, Calendar, Clock, MapPin, User, DollarSign, Heart, AlertCircle } from 'lucide-react';

interface Venue {
  id: string;
  name: string;
  address: string;
}

interface BookingNote {
  id: string;
  content: string;
  created_at: string;
  created_by: string;
  attachments: Array<{
    id: string;
    file_name: string;
    file_type: string;
    file_size: number;
    url: string;
  }>;
}

interface Booking {
  id: string;
  lead_id: string;
  start_date: string;
  end_date: string;
  amount: number;
  vendor_id: string | null;
  status: string;
  service_id: string | null;
  variant_id: string | null;
  notes: string | null;
  venue_id: string | null;
  lead: {
    name: string;
    email: string;
    phone: string;
    partner_name: string | null;
  };
  venue: {
    name: string;
    address: string;
  } | null;
  vendor: {
    name: string;
    email: string;
    phone: string;
  } | null;
  service: {
    name: string;
    description: string;
  } | null;
  service_variant: {
    name: string;
    description: string;
  } | null;
}

interface EditedBooking {
  start_date: string;
  end_date: string;
  start_time: string;
  end_time: string;
  amount: number;
  status: string;
  notes: string;
  venue_id: string | null;
  venue_name: string;
  venue_address: string;
}

interface UploadProgress {
  [key: string]: number;
}

export default function BookingEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [booking, setBooking] = useState<Booking | null>(null);
  const [notes, setNotes] = useState<BookingNote[]>([]);
  const [newNote, setNewNote] = useState('');
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [editingNoteContent, setEditingNoteContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<UploadProgress>({});
  const [venues, setVenues] = useState<Venue[]>([]);
  const [venueSearchTerm, setVenueSearchTerm] = useState('');
  const [showVenueSearch, setShowVenueSearch] = useState(false);
  const [editedBooking, setEditedBooking] = useState<EditedBooking>({
    start_date: new Date().toISOString().split('T')[0],
    end_date: new Date().toISOString().split('T')[0],
    start_time: '09:00',
    end_time: '17:00',
    amount: 0,
    status: 'pending',
    notes: '',
    venue_id: null,
    venue_name: '',
    venue_address: '',
  });

  const isNew = id === 'new';

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.gif'],
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx']
    },
    onDrop: handleFileDrop
  });

  useEffect(() => {
    if (!isNew) {
      fetchBooking();
      fetchNotes();
    } else {
      setLoading(false);
    }
    fetchVenues();
  }, [id]);

  async function fetchBooking() {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(`
          *,
          lead:leads(name, email, phone, partner_name),
          venue:venues(name, address),
          vendor:vendors(name, email, phone),
          service:services(name, description),
          service_variant:service_variants(name, description)
        `)
        .eq('id', id)
        .single();

      if (error) throw error;
      if (!data) throw new Error('Booking not found');

      setBooking(data);
      
      // Set initial form values
      setEditedBooking({
        start_date: new Date(data.start_date).toISOString().split('T')[0],
        end_date: new Date(data.end_date).toISOString().split('T')[0],
        start_time: new Date(data.start_date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
        end_time: new Date(data.end_date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
        amount: data.amount,
        status: data.status,
        notes: data.notes || '',
        venue_id: data.venue?.id || null,
        venue_name: data.venue?.name || '',
        venue_address: data.venue?.address || '',
      });
    } catch (err) {
      console.error('Error fetching booking:', err);
      setError(err instanceof Error ? err.message : 'Failed to load booking');
    } finally {
      setLoading(false);
    }
  }

  async function fetchVenues() {
    try {
      const { data, error } = await supabase
        .from('venues')
        .select('id, name, address')
        .order('name');
      
      if (error) throw error;
      setVenues(data || []);
    } catch (err) {
      console.error('Error fetching venues:', err);
    }
  }

  async function fetchNotes() {
    if (isNew) return;
    
    try {
      const { data: notesData, error: notesError } = await supabase
        .from('booking_notes')
        .select('*')
        .eq('booking_id', id)
        .order('created_at', { ascending: false });

      if (notesError) throw notesError;

      const notesWithAttachments = await Promise.all((notesData || []).map(async (note) => {
        const { data: attachments, error: attachmentsError } = await supabase
          .from('booking_note_attachments')
          .select('*')
          .eq('note_id', note.id);

        if (attachmentsError) throw attachmentsError;

        return {
          ...note,
          attachments: attachments || []
        };
      }));

      setNotes(notesWithAttachments);
    } catch (err) {
      console.error('Error fetching notes:', err);
      setError('Failed to load notes');
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);

    try {
      // Combine date and time for start and end
      const startDateTime = new Date(`${editedBooking.start_date}T${editedBooking.start_time}`);
      const endDateTime = new Date(`${editedBooking.end_date}T${editedBooking.end_time}`);

      let venueId = editedBooking.venue_id;

      // Create new venue if needed
      if (!venueId && editedBooking.venue_name && editedBooking.venue_address) {
        const { data: venue, error: venueError } = await supabase
          .from('venues')
          .insert({
            name: editedBooking.venue_name,
            address: editedBooking.venue_address
          })
          .select()
          .single();

        if (venueError) throw venueError;
        venueId = venue.id;
      }

      const bookingData = {
        start_date: startDateTime.toISOString(),
        end_date: endDateTime.toISOString(),
        amount: editedBooking.amount,
        status: editedBooking.status,
        notes: editedBooking.notes,
        venue_id: venueId,
      };

      if (isNew) {
        const { error } = await supabase
          .from('bookings')
          .insert(bookingData);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('bookings')
          .update(bookingData)
          .eq('id', id);

        if (error) throw error;
      }

      navigate('/bookings');
    } catch (err) {
      console.error('Error saving booking:', err);
      setError('Failed to save booking');
    } finally {
      setSaving(false);
    }
  }

  async function handleFileDrop(acceptedFiles: File[]) {
    if (!editingNoteId || isNew) return;

    for (const file of acceptedFiles) {
      const fileId = Math.random().toString(36).substring(7);
      setUploadProgress(prev => ({ ...prev, [fileId]: 0 }));

      try {
        const filePath = `${id}/${editingNoteId}/${file.name}`;
        const { error: uploadError } = await supabase.storage
          .from('booking-attachments')
          .upload(filePath, file, {
            onUploadProgress: (progress) => {
              const percent = (progress.loaded / progress.total) * 100;
              setUploadProgress(prev => ({ ...prev, [fileId]: percent }));
            }
          });

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('booking-attachments')
          .getPublicUrl(filePath);

        const { error: attachmentError } = await supabase
          .from('booking_note_attachments')
          .insert({
            note_id: editingNoteId,
            file_name: file.name,
            file_type: file.type,
            file_size: file.size,
            url: publicUrl
          });

        if (attachmentError) throw attachmentError;

        setUploadProgress(prev => {
          const newProgress = { ...prev };
          delete newProgress[fileId];
          return newProgress;
        });

        fetchNotes();
      } catch (error) {
        console.error('Error uploading file:', error);
        setError('Failed to upload file');
        setUploadProgress(prev => {
          const newProgress = { ...prev };
          delete newProgress[fileId];
          return newProgress;
        });
      }
    }
  }

  async function handleAddNote() {
    if (!newNote.trim() || isNew) return;

    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) throw new Error('Not authenticated');

      // First get the team member ID for the current user
      const { data: teamMembers, error: teamMemberError } = await supabase
        .from('team_members')
        .select('id')
        .eq('user_id', userData.user.id);

      if (teamMemberError) throw teamMemberError;

      let teamMemberId;

      // If no team member exists, create one
      if (!teamMembers || teamMembers.length === 0) {
        const { data: newTeamMember, error: createError } = await supabase
          .from('team_members')
          .insert({
            user_id: userData.user.id,
            name: userData.user.email?.split('@')[0] || 'Team Member',
            role: 'team_member'
          })
          .select('id')
          .single();

        if (createError) throw createError;
        if (!newTeamMember) throw new Error('Failed to create team member');
        
        teamMemberId = newTeamMember.id;
      } else {
        teamMemberId = teamMembers[0].id;
      }

      const { error: noteError } = await supabase
        .from('booking_notes')
        .insert({
          booking_id: id,
          content: newNote,
          created_by: teamMemberId
        });

      if (noteError) throw noteError;

      setNewNote('');
      fetchNotes();
    } catch (err) {
      console.error('Error adding note:', err);
      setError('Failed to add note');
    }
  }

  async function handleUpdateNote() {
    if (!editingNoteId || !editingNoteContent.trim() || isNew) return;

    try {
      const { error } = await supabase
        .from('booking_notes')
        .update({ content: editingNoteContent })
        .eq('id', editingNoteId);

      if (error) throw error;

      setEditingNoteId(null);
      setEditingNoteContent('');
      fetchNotes();
    } catch (err) {
      console.error('Error updating note:', err);
      setError('Failed to update note');
    }
  }

  async function handleDeleteNote(noteId: string) {
    if (isNew) return;

    try {
      const { data: attachments } = await supabase
        .from('booking_note_attachments')
        .select('url')
        .eq('note_id', noteId);

      if (attachments) {
        for (const attachment of attachments) {
          const path = new URL(attachment.url).pathname.split('/').pop();
          if (path) {
            await supabase.storage
              .from('booking-attachments')
              .remove([`${id}/${noteId}/${path}`]);
          }
        }
      }

      const { error } = await supabase
        .from('booking_notes')
        .delete()
        .eq('id', noteId);

      if (error) throw error;

      fetchNotes();
    } catch (err) {
      console.error('Error deleting note:', err);
      setError('Failed to delete note');
    }
  }

  const selectVenue = (venue: Venue) => {
    setEditedBooking({
      ...editedBooking,
      venue_id: venue.id,
      venue_name: venue.name,
      venue_address: venue.address,
    });
    setVenueSearchTerm('');
    setShowVenueSearch(false);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/bookings')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">
            {isNew ? 'New Booking' : 'Edit Booking'}
          </h1>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6">
            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
                <AlertCircle className="w-5 h-5" />
                {error}
              </div>
            )}

            {/* Lead Information */}
            {!isNew && booking?.lead && (
              <div className="mb-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Lead Information</h2>
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <User className="w-5 h-5 text-gray-400" />
                    <span className="font-medium text-gray-900">{booking.lead.name}</span>
                    {booking.lead.partner_name && (
                      <div className="flex items-center text-gray-600">
                        <Heart className="w-4 h-4 mx-1 text-pink-500" />
                        <span>{booking.lead.partner_name}</span>
                      </div>
                    )}
                  </div>
                  <div className="space-y-1 text-sm text-gray-600 ml-7">
                    <p>{booking.lead.email}</p>
                    <p>{booking.lead.phone}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Service Information */}
            {!isNew && booking?.service && (
              <div className="mb-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Service Details</h2>
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="font-medium text-gray-900">{booking.service.name}</h3>
                  <p className="text-gray-600 mt-1">{booking.service.description}</p>
                  {booking.service_variant && (
                    <div className="mt-3 pt-3 border-t border-gray-200">
                      <h4 className="font-medium text-gray-900">
                        {booking.service_variant.name}
                      </h4>
                      <p className="text-gray-600 mt-1">
                        {booking.service_variant.description}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Vendor Information */}
            {!isNew && booking?.vendor && (
              <div className="mb-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Vendor Information</h2>
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="font-medium text-gray-900">{booking.vendor.name}</div>
                  <div className="space-y-1 text-sm text-gray-600 mt-2">
                    <p>{booking.vendor.email}</p>
                    <p>{booking.vendor.phone}</p>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-6">
              {/* Date and Time */}
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Date and Time</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Start Date
                    </label>
                    <input
                      type="date"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      value={editedBooking.start_date}
                      onChange={(e) => setEditedBooking({ ...editedBooking, start_date: e.target.value })}
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Start Time
                    </label>
                    <input
                      type="time"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      value={editedBooking.start_time}
                      onChange={(e) => setEditedBooking({ ...editedBooking, start_time: e.target.value })}
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      End Date
                    </label>
                    <input
                      type="date"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      value={editedBooking.end_date}
                      onChange={(e) => setEditedBooking({ ...editedBooking, end_date: e.target.value })}
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      End Time
                    </label>
                    <input
                      type="time"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      value={editedBooking.end_time}
                      onChange={(e) => setEditedBooking({ ...editedBooking, end_time: e.target.value })}
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Venue */}
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Venue</h2>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search venues..."
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={venueSearchTerm}
                    onChange={(e) => {
                      setVenueSearchTerm(e.target.value);
                      setShowVenueSearch(true);
                    }}
                    onFocus={() => setShowVenueSearch(true)}
                  />
                  {showVenueSearch && (
                    <div className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                      {venues
                        .filter(venue => 
                          venue.name.toLowerCase().includes(venueSearchTerm.toLowerCase()) ||
                          venue.address.toLowerCase().includes(venueSearchTerm.toLowerCase())
                        )
                        .map((venue) => (
                          <button
                            key={venue.id}
                            type="button"
                            className="w-full px-4 py-2 text-left hover:bg-gray-50 flex flex-col"
                            onClick={() => selectVenue(venue)}
                          >
                            <span className="font-medium">{venue.name}</span>
                            <span className="text-sm text-gray-500">{venue.address}</span>
                          </button>
                        ))
                      }
                      {venueSearchTerm && (
                        <button
                          type="button"
                          className="w-full px-4 py-2 text-left text-blue-600 hover:bg-gray-50"
                          onClick={() => {
                            setEditedBooking({
                              ...editedBooking,
                              venue_id: null,
                              venue_name: venueSearchTerm,
                              venue_address: '',
                            });
                            setShowVenueSearch(false);
                          }}
                        >
                          + Add new venue "{venueSearchTerm}"
                        </button>
                      )}
                    </div>
                  )}
                </div>

                {!editedBooking.venue_id && (
                  <div className="space-y-2 mt-2">
                    <input
                      type="text"
                      placeholder="Venue name"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      value={editedBooking.venue_name}
                      onChange={(e) => setEditedBooking({
                        ...editedBooking,
                        venue_name: e.target.value,
                      })}
                    />
                    <input
                      type="text"
                      placeholder="Venue address"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      value={editedBooking.venue_address}
                      onChange={(e) => setEditedBooking({
                        ...editedBooking,
                        venue_address: e.target.value,
                      })}
                    />
                  </div>
                )}

                {editedBooking.venue_id && (
                  <div className="mt-2 p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">{editedBooking.venue_name}</div>
                        <div className="text-sm text-gray-500">{editedBooking.venue_address}</div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setEditedBooking({
                          ...editedBooking,
                          venue_id: null,
                          venue_name: '',
                          venue_address: '',
                        })}
                        className="text-gray-400 hover:text-gray-600"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Status and Amount */}
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Status & Amount</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Status
                    </label>
                    <select
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      value={editedBooking.status}
                      onChange={(e) => setEditedBooking({ ...editedBooking, status: e.target.value })}
                      required
                    >
                      <option value="pending">Pending</option>
                      <option value="confirmed">Confirmed</option>
                      <option value="completed">Completed</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Amount
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                        $
                      </span>
                      <input
                        type="number"
                        className="w-full border border-gray-300 rounded-lg pl-7 pr-3 py-2"
                        value={editedBooking.amount}
                        onChange={(e) => setEditedBooking({ ...editedBooking, amount: parseFloat(e.target.value) })}
                        min="0"
                        step="0.01"
                        required
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Notes */}
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Notes</h2>
                <textarea
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  rows={4}
                  value={editedBooking.notes}
                  onChange={(e) => setEditedBooking({ ...editedBooking, notes: e.target.value })}
                  placeholder="Add any additional notes or requirements..."
                />
              </div>

              <div className="flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => navigate('/bookings')}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  disabled={saving}
                >
                  {saving ? 'Saving...' : (isNew ? 'Create Booking' : 'Save Changes')}
                </button>
              </div>
            </div>
          </form>

          {/* Notes Section */}
          {!isNew && (
            <div className="bg-white rounded-lg shadow-md p-6 mt-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Notes & Updates</h2>
              
              <div className="mb-4">
                <textarea
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  rows={3}
                  placeholder="Add a note..."
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                />
                <div className="mt-2 flex justify-end">
                  <button
                    onClick={handleAddNote}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                    disabled={!newNote.trim()}
                  >
                    Add Note
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                {notes.map((note) => (
                  <div key={note.id} className="border border-gray-200 rounded-lg p-4">
                    {editingNoteId === note.id ? (
                      <div className="space-y-4">
                        <textarea
                          className="w-full border border-gray-300 rounded-lg px-3 py-2"
                          rows={3}
                          value={editingNoteContent}
                          onChange={(e) => setEditingNoteContent(e.target.value)}
                        />
                        
                        <div {...getRootProps()} className="border-2 border-dashed rounded-lg p-4 text-center cursor-pointer">
                          <input {...getInputProps()} />
                          <Upload className="w-6 h-6 text-gray-400 mx-auto mb-2" />
                          <p className="text-gray-600">
                            {isDragActive ? 'Drop files here' : 'Drag & drop files here, or click to select'}
                          </p>
                        </div>

                        {Object.entries(uploadProgress).map(([fileId, progress]) => (
                          <div key={fileId} className="bg-gray-100 rounded-lg p-2">
                            <div className="flex justify-between text-sm text-gray-600 mb-1">
                              <span>Uploading...</span>
                              <span>{Math.round(progress)}%</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div
                                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                                style={{ width: `${progress}%` }}
                              />
                            </div>
                          </div>
                        ))}

                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => {
                              setEditingNoteId(null);
                              setEditingNoteContent('');
                            }}
                            className="px-3 py-1 text-gray-600 hover:text-gray-900"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={handleUpdateNote}
                            className="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700"
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="flex justify-between items-start mb-2">
                          <div className="text-sm text-gray-600">
                            {new Date(note.created_at).toLocaleString()}
                          </div>
                          <div className="flex gap-2">
                            <button
                              onClick={() => {
                                setEditingNoteId(note.id);
                                setEditingNoteContent(note.content);
                              }}
                              className="text-gray-600 hover:text-gray-900"
                            >
                              <Pencil className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteNote(note.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                        
                        <p className="text-gray-900 mb-4">{note.content}</p>

                        {note.attachments && note.attachments.length > 0 && (
                          <div className="mt-4">
                            <h4 className="text-sm font-medium text-gray-700 mb-2">Attachments</h4>
                            <div className="space-y-2">
                              {note.attachments.map((attachment) => (
                                <div
                                  key={attachment.id}
                                  className="flex items-center justify-between bg-gray-50 rounded-lg p-2"
                                >
                                  <div className="flex items-center gap-2">
                                    <FileText className="w-4 h-4 text-gray-500" />
                                    <a
                                      href={attachment.url}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="text-blue-600 hover:text-blue-800"
                                    >
                                      {attachment.file_name}
                                    </a>
                                  </div>
                                  <button
                                    onClick={() => handleDeleteNote(note.id)}
                                    className="text-red-600 hover:text-red-700"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Sidebar */}
        <div className="space-y-6">
          {/* Timeline or activity feed could go here */}
        </div>
      </div>
    </div>
  );
}