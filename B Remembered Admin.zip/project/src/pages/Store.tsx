import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  PlusCircle, Search, Filter, Tag, Package, ShoppingCart, 
  DollarSign, Truck, AlertCircle, X, Check, Edit, Trash2,
  Globe, Users, Building2, Eye, EyeOff, MessageSquare, Mail,
  Upload, Image as ImageIcon, XCircle, Plus, CheckCircle
} from 'lucide-react';
import OrdersTable from './OrdersTable';
import ProductImageGallery from '../components/ProductImageGallery';
import ProductCard from '../components/ProductCard';

// Icon components moved to top of file
function ListIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="8" y1="6" x2="21" y2="6" />
      <line x1="8" y1="12" x2="21" y2="12" />
      <line x1="8" y1="18" x2="21" y2="18" />
      <line x1="3" y1="6" x2="3.01" y2="6" />
      <line x1="3" y1="12" x2="3.01" y2="12" />
      <line x1="3" y1="18" x2="3.01" y2="18" />
    </svg>
  );
}

function GridIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect x="3" y="3" width="7" height="7" />
      <rect x="14" y="3" width="7" height="7" />
      <rect x="14" y="14" width="7" height="7" />
      <rect x="3" y="14" width="7" height="7" />
    </svg>
  );
}

function ChevronDownIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

interface ProductImage {
  id: string;
  url: string;
  alt_text: string | null;
  display_order: number;
  is_primary: boolean;
}

interface ProductCategory {
  id: string;
  name: string;
  description: string | null;
  slug: string | null;
}

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image_url: string | null;
  stock: number;
  category: string;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
  display_on_landing_page: boolean;
  display_on_couple_site: boolean;
  display_on_vendor_site: boolean;
  images?: ProductImage[];
}

interface Order {
  id: string;
  vendor_id: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  total_amount: number;
  shipping_address: string;
  tracking_number: string | null;
  tracking_url: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
  vendor: {
    name: string;
    email: string;
    phone: string | null;
  };
  items: Array<{
    id: string;
    product_id: string;
    quantity: number;
    price: number;
    product: {
      name: string;
      image_url: string | null;
      category: string;
    };
  }>;
}

export default function Store() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'products' | 'orders'>('products');
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [displayFilter, setDisplayFilter] = useState('all');
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  
  // Product modal state
  const [showProductModal, setShowProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [newProduct, setNewProduct] = useState({
    name: '',
    description: '',
    price: '',
    image_url: '',
    stock: '',
    category: '',
    status: 'active' as 'active' | 'inactive',
    display_on_landing_page: false,
    display_on_couple_site: false,
    display_on_vendor_site: false
  });
  
  // Category modal state
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [newCategory, setNewCategory] = useState({
    name: '',
    description: '',
    slug: ''
  });
  
  // Image upload state
  const [productImages, setProductImages] = useState<File[]>([]);
  const [imageUploads, setImageUploads] = useState<{[key: string]: {file: File, progress: number, url?: string}}>({});
  const [uploadingImages, setUploadingImages] = useState(false);
  const [showImagePreview, setShowImagePreview] = useState(false);
  const [previewImage, setPreviewImage] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [primaryImageIndex, setPrimaryImageIndex] = useState<number>(0);
  
  // Order tracking modal state
  const [showTrackingModal, setShowTrackingModal] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [trackingInfo, setTrackingInfo] = useState({
    tracking_number: '',
    tracking_url: '',
    notify_customer: true,
    notification_type: 'email' as 'email' | 'sms' | 'both'
  });
  
  // Delete confirmation modal state
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<{ type: 'product' | 'order' | 'category', id: string } | null>(null);

  useEffect(() => {
    if (activeTab === 'products') {
      fetchProducts();
      fetchCategories();
    }
  }, [activeTab]);

  async function fetchProducts() {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('products')
        .select(`
          *,
          images:product_images(*)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProducts(data || []);
    } catch (err) {
      console.error('Error fetching products:', err);
      setError('Failed to load products');
    } finally {
      setLoading(false);
    }
  }

  async function fetchCategories() {
    try {
      const { data, error } = await supabase
        .from('product_categories')
        .select('*')
        .order('name');

      if (error) throw error;
      setCategories(data || []);
    } catch (err) {
      console.error('Error fetching categories:', err);
      setError('Failed to load categories');
    }
  }

  async function handleProductSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    try {
      const productData = {
        name: newProduct.name,
        description: newProduct.description || null,
        price: parseFloat(newProduct.price),
        image_url: newProduct.image_url || null,
        stock: parseInt(newProduct.stock),
        category: newProduct.category,
        status: newProduct.status,
        display_on_landing_page: newProduct.display_on_landing_page,
        display_on_couple_site: newProduct.display_on_couple_site,
        display_on_vendor_site: newProduct.display_on_vendor_site
      };

      let productId: string;

      if (editingProduct) {
        // Update existing product
        const { error } = await supabase
          .from('products')
          .update(productData)
          .eq('id', editingProduct.id);

        if (error) throw error;
        productId = editingProduct.id;
      } else {
        // Create new product
        const { data, error } = await supabase
          .from('products')
          .insert([productData])
          .select();

        if (error) throw error;
        productId = data[0].id;
      }

      // Upload images if any
      if (productImages.length > 0) {
        setUploadingImages(true);
        
        // Upload each image
        for (let i = 0; i < productImages.length; i++) {
          const file = productImages[i];
          const fileId = Math.random().toString(36).substring(7);
          
          // Add to uploads tracking
          setImageUploads(prev => ({
            ...prev,
            [fileId]: { file, progress: 0 }
          }));
          
          // Create a unique file name
          const fileExt = file.name.split('.').pop();
          const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
          const filePath = `${productId}/${fileName}`;
          
          // Upload to storage
          const { data: uploadData, error: uploadError } = await supabase.storage
            .from('product-images')
            .upload(filePath, file, {
              cacheControl: '3600',
              upsert: false,
              onUploadProgress: (progress) => {
                const percent = (progress.loaded / progress.total) * 100;
                setImageUploads(prev => ({
                  ...prev,
                  [fileId]: { ...prev[fileId], progress: percent }
                }));
              }
            });
            
          if (uploadError) {
            console.error('Error uploading image:', uploadError);
            continue; // Skip this image but continue with others
          }
          
          // Get public URL
          const { data: { publicUrl } } = supabase.storage
            .from('product-images')
            .getPublicUrl(filePath);
            
          // Update tracking with URL
          setImageUploads(prev => ({
            ...prev,
            [fileId]: { ...prev[fileId], url: publicUrl }
          }));
          
          // Add to product_images table
          const { error: imageError } = await supabase
            .from('product_images')
            .insert({
              product_id: productId,
              url: publicUrl,
              alt_text: file.name,
              display_order: i,
              is_primary: i === primaryImageIndex // Set primary based on selected index
            });
            
          if (imageError) {
            console.error('Error saving image record:', imageError);
          }
          
          // If this is the primary image and there's no product image_url, update it
          if (i === primaryImageIndex && !productData.image_url) {
            await supabase
              .from('products')
              .update({ image_url: publicUrl })
              .eq('id', productId);
          }
        }
        
        setUploadingImages(false);
      }

      setShowProductModal(false);
      setEditingProduct(null);
      setNewProduct({
        name: '',
        description: '',
        price: '',
        image_url: '',
        stock: '',
        category: '',
        status: 'active',
        display_on_landing_page: false,
        display_on_couple_site: false,
        display_on_vendor_site: false
      });
      setProductImages([]);
      setImageUploads({});
      setPrimaryImageIndex(0);
      fetchProducts();
    } catch (err) {
      console.error('Error saving product:', err);
      setError(err instanceof Error ? err.message : 'Failed to save product');
    }
  }

  async function handleCategorySubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    try {
      // Check if category with same name already exists
      const { data: existingCategories, error: checkError } = await supabase
        .from('product_categories')
        .select('id')
        .ilike('name', newCategory.name);

      if (checkError) {
        throw checkError;
      }

      // If any categories were found with the same name
      if (existingCategories && existingCategories.length > 0) {
        setError(`A category with the name "${newCategory.name}" already exists`);
        return;
      }

      // Generate slug if not provided
      const slug = newCategory.slug || newCategory.name.toLowerCase().replace(/\s+/g, '-');

      const { error } = await supabase
        .from('product_categories')
        .insert({
          name: newCategory.name,
          description: newCategory.description || null,
          slug
        });

      if (error) throw error;

      setShowCategoryModal(false);
      setNewCategory({
        name: '',
        description: '',
        slug: ''
      });
      fetchCategories();
    } catch (err) {
      console.error('Error creating category:', err);
      setError(err instanceof Error ? err.message : 'Failed to create category');
    }
  }

  async function handleTrackingUpdate(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedOrder) return;
    setError(null);

    try {
      // Update order with tracking info
      const { error: updateError } = await supabase
        .from('orders')
        .update({
          tracking_number: trackingInfo.tracking_number,
          tracking_url: trackingInfo.tracking_url || null,
          status: 'shipped'
        })
        .eq('id', selectedOrder.id);

      if (updateError) throw updateError;

      // Send notification if requested
      if (trackingInfo.notify_customer) {
        const notificationTypes = trackingInfo.notification_type === 'both' 
          ? ['email', 'sms'] 
          : [trackingInfo.notification_type];
        
        for (const type of notificationTypes) {
          const content = `Your order has been shipped! Tracking number: ${trackingInfo.tracking_number}${
            trackingInfo.tracking_url ? `. Track your package at: ${trackingInfo.tracking_url}` : ''
          }`;
          
          const { error: notificationError } = await supabase
            .from('order_notifications')
            .insert({
              order_id: selectedOrder.id,
              type,
              content,
              status: 'pending'
            });
          
          if (notificationError) throw notificationError;
        }
        
        // Trigger notification sending via edge function
        try {
          await fetch('/functions/v1/send-tracking-notification', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              orderId: selectedOrder.id,
              notificationTypes
            }),
          });
        } catch (notifyError) {
          console.error('Error sending notifications:', notifyError);
          // Continue even if notification sending fails
        }
      }

      setShowTrackingModal(false);
      setSelectedOrder(null);
      setTrackingInfo({
        tracking_number: '',
        tracking_url: '',
        notify_customer: true,
        notification_type: 'email'
      });
    } catch (err) {
      console.error('Error updating tracking:', err);
      setError(err instanceof Error ? err.message : 'Failed to update tracking information');
    }
  }

  async function handleDelete() {
    if (!itemToDelete) return;
    setError(null);

    try {
      if (itemToDelete.type === 'product') {
        // First, get all images for this product
        const { data: images } = await supabase
          .from('product_images')
          .select('url')
          .eq('product_id', itemToDelete.id);
          
        // Delete images from storage
        if (images && images.length > 0) {
          for (const image of images) {
            const url = new URL(image.url);
            const pathParts = url.pathname.split('/');
            const storagePath = pathParts.slice(pathParts.indexOf('product-images') + 1).join('/');
            
            await supabase.storage
              .from('product-images')
              .remove([storagePath]);
          }
        }
        
        // Delete the product (this will cascade delete product_images)
        const { error } = await supabase
          .from('products')
          .delete()
          .eq('id', itemToDelete.id);

        if (error) throw error;
        fetchProducts();
      } else if (itemToDelete.type === 'category') {
        // Check if category is in use
        const { count, error: countError } = await supabase
          .from('products')
          .select('id', { count: 'exact', head: true })
          .eq('category', itemToDelete.id);
          
        if (countError) throw countError;
        
        if (count && count > 0) {
          throw new Error(`Cannot delete category that is used by ${count} products`);
        }
        
        // Delete the category
        const { error } = await supabase
          .from('product_categories')
          .delete()
          .eq('id', itemToDelete.id);

        if (error) throw error;
        fetchCategories();
      } else {
        // For orders, first delete related items and notifications
        await supabase
          .from('order_notifications')
          .delete()
          .eq('order_id', itemToDelete.id);
          
        await supabase
          .from('order_items')
          .delete()
          .eq('order_id', itemToDelete.id);
        
        // Then delete the order
        const { error } = await supabase
          .from('orders')
          .delete()
          .eq('id', itemToDelete.id);

        if (error) throw error;
      }

      setShowDeleteConfirm(false);
      setItemToDelete(null);
    } catch (err) {
      console.error('Error deleting item:', err);
      setError(err instanceof Error ? err.message : 'Failed to delete item');
    }
  }

  function editProduct(product: Product) {
    setEditingProduct(product);
    setNewProduct({
      name: product.name,
      description: product.description || '',
      price: product.price.toString(),
      image_url: product.image_url || '',
      stock: product.stock.toString(),
      category: product.category,
      status: product.status,
      display_on_landing_page: product.display_on_landing_page || false,
      display_on_couple_site: product.display_on_couple_site || false,
      display_on_vendor_site: product.display_on_vendor_site || false
    });
    setProductImages([]);
    setImageUploads({});
    setPrimaryImageIndex(0);
    setShowProductModal(true);
  }

  function confirmDelete(type: 'product' | 'order' | 'category', id: string) {
    setItemToDelete({ type, id });
    setShowDeleteConfirm(true);
  }

  function handleAddTracking(order: Order) {
    setSelectedOrder(order);
    setTrackingInfo({
      tracking_number: order.tracking_number || '',
      tracking_url: order.tracking_url || '',
      notify_customer: true,
      notification_type: 'email'
    });
    setShowTrackingModal(true);
  }

  function handleImageSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files;
    if (!files) return;
    
    // Limit to 10 images total
    const remainingSlots = 10 - productImages.length;
    if (remainingSlots <= 0) {
      setError('Maximum of 10 images allowed per product');
      return;
    }
    
    const newFiles = Array.from(files).slice(0, remainingSlots);
    setProductImages(prev => [...prev, ...newFiles]);
    
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }

  function removeImage(index: number) {
    setProductImages(prev => prev.filter((_, i) => i !== index));
    // If removing the primary image, reset primary to first image
    if (index === primaryImageIndex) {
      setPrimaryImageIndex(0);
    } else if (index < primaryImageIndex) {
      // If removing an image before the primary, adjust the index
      setPrimaryImageIndex(primaryImageIndex - 1);
    }
  }

  function showImagePreviewModal(url: string) {
    setPreviewImage(url);
    setShowImagePreview(true);
  }

  function setPrimaryImage(index: number) {
    setPrimaryImageIndex(index);
  }

  // Filter products
  const filteredProducts = products.filter(product => {
    const matchesSearch = 
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = categoryFilter === 'all' || product.category === categoryFilter;
    const matchesStatus = statusFilter === 'all' || product.status === statusFilter;
    
    // Filter by display location
    const matchesDisplay = 
      displayFilter === 'all' || 
      (displayFilter === 'landing' && product.display_on_landing_page) ||
      (displayFilter === 'couple' && product.display_on_couple_site) ||
      (displayFilter === 'vendor' && product.display_on_vendor_site);
    
    return matchesSearch && matchesCategory && matchesStatus && matchesDisplay;
  });

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Store</h1>
        <div className="flex gap-2">
          {activeTab === 'products' && (
            <>
              <button
                onClick={() => setShowCategoryModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <Tag className="w-5 h-5" />
                Add Category
              </button>
              <button
                onClick={() => {
                  setEditingProduct(null);
                  setNewProduct({
                    name: '',
                    description: '',
                    price: '',
                    image_url: '',
                    stock: '',
                    category: categories.length > 0 ? categories[0].id : '',
                    status: 'active',
                    display_on_landing_page: false,
                    display_on_couple_site: false,
                    display_on_vendor_site: false
                  });
                  setProductImages([]);
                  setImageUploads({});
                  setPrimaryImageIndex(0);
                  setShowProductModal(true);
                }}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <PlusCircle className="w-5 h-5" />
                Add Product
              </button>
            </>
          )}
        </div>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {/* Tabs */}
      <div className="mb-6 border-b border-gray-200">
        <div className="flex space-x-8">
          <button
            onClick={() => setActiveTab('products')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'products'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Products
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'orders'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Orders
          </button>
        </div>
      </div>

      {/* Products Tab */}
      {activeTab === 'products' && (
        <>
          <div className="mb-6 flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search products..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="flex flex-wrap gap-4">
              <select
                className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
              >
                <option value="all">All Categories</option>
                {categories.map(category => (
                  <option key={category.id} value={category.id}>{category.name}</option>
                ))}
              </select>
              <select
                className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="all">All Status</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
              <select
                className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={displayFilter}
                onChange={(e) => setDisplayFilter(e.target.value)}
              >
                <option value="all">All Locations</option>
                <option value="landing">Landing Page</option>
                <option value="couple">Couple Site</option>
                <option value="vendor">Vendor Site</option>
              </select>
              <div className="flex border border-gray-300 rounded-lg overflow-hidden">
                <button
                  onClick={() => setViewMode('list')}
                  className={`px-3 py-2 ${viewMode === 'list' ? 'bg-blue-50 text-blue-600' : 'bg-white text-gray-600'}`}
                >
                  <ListIcon className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setViewMode('grid')}
                  className={`px-3 py-2 ${viewMode === 'grid' ? 'bg-blue-50 text-blue-600' : 'bg-white text-gray-600'}`}
                >
                  <GridIcon className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : viewMode === 'list' ? (
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Display On</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredProducts.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-6 py-4 text-center text-gray-500">
                        No products found
                      </td>
                    </tr>
                  ) : (
                    filteredProducts.map(product => (
                      <tr key={product.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            {product.image_url ? (
                              <img
                                src={product.image_url}
                                alt={product.name}
                                className="h-10 w-10 rounded-lg object-cover"
                              />
                            ) : (
                              <div className="h-10 w-10 rounded-lg bg-gray-100 flex items-center justify-center">
                                <Package className="w-6 h-6 text-gray-400" />
                              </div>
                            )}
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{product.name}</div>
                              {product.description && (
                                <div className="text-sm text-gray-500">{product.description}</div>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">${product.price.toFixed(2)}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{product.stock}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">
                            {categories.find(c => c.id === product.category)?.name || product.category}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex gap-2">
                            {product.display_on_landing_page && (
                              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                                <Globe className="w-3 h-3 mr-1" />
                                Landing
                              </span>
                            )}
                            {product.display_on_couple_site && (
                              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-pink-100 text-pink-800">
                                <Users className="w-3 h-3 mr-1" />
                                Couple
                              </span>
                            )}
                            {product.display_on_vendor_site && (
                              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-purple-100 text-purple-800">
                                <Building2 className="w-3 h-3 mr-1" />
                                Vendor
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              product.status === 'active'
                                ? 'bg-green-100 text-green-800'
                                : 'bg-gray-100 text-gray-800'
                            }`}
                          >
                            {product.status === 'active' ? (
                              <Eye className="w-3 h-3 mr-1" />
                            ) : (
                              <EyeOff className="w-3 h-3 mr-1" />
                            )}
                            {product.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => editProduct(product)}
                              className="text-blue-600 hover:text-blue-900"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => confirmDelete('product', product.id)}
                              className="text-red-600 hover:text-red-900"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.length === 0 ? (
                <div className="col-span-full text-center text-gray-500 py-12">
                  No products found
                </div>
              ) : (
                filteredProducts.map(product => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onEdit={() => editProduct(product)}
                    onDelete={() => confirmDelete('product', product.id)}
                    categoryName={categories.find(c => c.id === product.category)?.name}
                  />
                ))
              )}
            </div>
          )}
        </>
      )}

      {/* Orders Tab */}
      {activeTab === 'orders' && (
        <OrdersTable
          onAddTracking={handleAddTracking}
          onDelete={(id) => confirmDelete('order', id)}
        />
      )}

      {/* Product Modal */}
      {showProductModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900">
                  {editingProduct ? 'Edit Product' : 'Add New Product'}
                </h2>
                <button
                  onClick={() => setShowProductModal(false)}
                  className="text-gray-400 hover:text-gray-500"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={handleProductSubmit}>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Name
                    </label>
                    <input
                      type="text"
                      required
                      value={newProduct.name}
                      onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                      className="mt-1 block w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Description
                    </label>
                    <textarea
                      value={newProduct.description}
                      onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                      rows={3}
                      className="mt-1 block w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Price
                      </label>
                      <div className="mt-1 relative rounded-lg">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <span className="text-gray-500 sm:text-sm">$</span>
                        </div>
                        <input
                          type="number"
                          required
                          min="0"
                          step="0.01"
                          value={newProduct.price}
                          onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
                          className="block w-full pl-7 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Stock
                      </label>
                      <input
                        type="number"
                        required
                        min="0"
                        value={newProduct.stock}
                        onChange={(e) => setNewProduct({ ...newProduct, stock: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Category
                    </label>
                    <select
                      required
                      value={newProduct.category}
                      onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
                      className="mt-1 block w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">Select a category</option>
                      {categories.map(category => (
                        <option key={category.id} value={category.id}>
                          {category.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Status
                    </label>
                    <select
                      value={newProduct.status}
                      onChange={(e) => setNewProduct({ ...newProduct, status: e.target.value as 'active' | 'inactive' })}
                      className="mt-1 block w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="active">Active</option>
                      <option value="inactive">Inactive</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Display Locations
                    </label>
                    <div className="space-y-2">
                      <label className="flex items-center">
                        <input
                          type="checkbox"
                          checked={newProduct.display_on_landing_page}
                          onChange={(e) => setNewProduct({ ...newProduct, display_on_landing_page: e.target.checked })}
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="ml-2 text-sm text-gray-700">Display on Landing Page</span>
                      </label>
                      <label className="flex items-center">
                        <input
                          type="checkbox"
                          checked={newProduct.display_on_couple_site}
                          onChange={(e) => setNewProduct({ ...newProduct, display_on_couple_site: e.target.checked })}
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="ml-2 text-sm text-gray-700">Display on Couple Site</span>
                      </label>
                      <label className="flex items-center">
                        <input
                          type="checkbox"
                          checked={newProduct.display_on_vendor_site}
                          onChange={(e) => setNewProduct({ ...newProduct, display_on_vendor_site: e.target.checked })}
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="ml-2 text-sm text-gray-700">Display on Vendor Site</span>
                      </label>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Images
                    </label>
                    <div className="space-y-4">
                      {/* Image upload button */}
                      <div>
                        <input
                          type="file"
                          ref={fileInputRef}
                          accept="image/*"
                          multiple
                          onChange={handleImageSelect}
                          className="hidden"
                        />
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                        >
                          <Upload className="w-5 h-5 mr-2" />
                          Upload Images
                        </button>
                        <span className="ml-2 text-sm text-gray-500">
                          Maximum 10 images
                        </span>
                      </div>

                      {/* Selected images preview */}
                      {productImages.length > 0 && (
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                          {productImages.map((file, index) => (
                            <div
                              key={index}
                              className="relative group border border-gray-200 rounded-lg overflow-hidden"
                            >
                              <img
                                src={URL.createObjectURL(file)}
                                alt={`Preview ${index + 1}`}
                                className="w-full h-32 object-cover"
                              />
                              <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                <button
                                  type="button"
                                  onClick={() => showImagePreviewModal(URL.createObjectURL(file))}
                                  className="p-1 bg-white rounded-full text-gray-700 hover:text-blue-600"
                                >
                                  <Eye className="w-4 h-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setPrimaryImage(index)}
                                  className={`p-1 rounded-full ${
                                    index === primaryImageIndex
                                      ? 'bg-blue-600 text-white'
                                      : 'bg-white text-gray-700 hover:text-blue-600'
                                  }`}
                                >
                                  <CheckCircle className="w-4 h-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => removeImage(index)}
                                  className="p-1 bg-white rounded-full text-gray-700 hover:text-red-600"
                                >
                                  <XCircle className="w-4 h-4" />
                                </button>
                              </div>
                              {index === primaryImageIndex && (
                                <div className="absolute top-2 left-2 bg-blue-600 text-white text-xs px-2 py-1 rounded">
                                  Primary
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Upload progress */}
                      {Object.entries(imageUploads).map(([id, { file, progress, url }]) => (
                        <div key={id} className="flex items-center gap-4">
                          <div className="flex-1">
                            <div className="text-sm font-medium text-gray-700">{file.name}</div>
                            <div className="mt-1 relative pt-1">
                              <div className="overflow-hidden h-2 text-xs flex rounded bg-blue-200">
                                <div
                                  style={{ width: `${progress}%` }}
                                  className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-600 transition-all duration-300"
                                />
                              </div>
                            </div>
                          </div>
                          {url && (
                            <Check className="w-5 h-5 text-green-600" />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex justify-end gap-3">
                    <button
                      type="button"
                      onClick={() => setShowProductModal(false)}
                      className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={uploadingImages}
                      className="px-4 py-2 border border-transparent rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {uploadingImages ? (
                        <div className="flex items-center">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                          Uploading...
                        </div>
                      ) : (
                        'Save Product'
                      )}
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Category Modal */}
      {showCategoryModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900">
                  Add New Category
                </h2>
                <button
                  onClick={() => setShowCategoryModal(false)}
                  className="text-gray-400 hover:text-gray-500"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={handleCategorySubmit}>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Name
                    </label>
                    <input
                      type="text"
                      required
                      value={newCategory.name}
                      onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                      className="mt-1 block w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Description
                    </label>
                    <textarea
                      value={newCategory.description}
                      onChange={(e) => setNewCategory({ ...newCategory, description: e.target.value })}
                      rows={3}
                      className="mt-1 block w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Slug (optional)
                    </label>
                    <input
                      type="text"
                      value={newCategory.slug}
                      onChange={(e) => setNewCategory({ ...newCategory, slug: e.target.value })}
                      className="mt-1 block w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="auto-generated-if-empty"
                    />
                  </div>

                  <div className="flex justify-end gap-3">
                    <button
                      type="button"
                      onClick={() => setShowCategoryModal(false)}
                      className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 border border-transparent rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      Create Category
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Tracking Modal */}
      {showTrackingModal && selectedOrder && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900">
                  Add Tracking Information
                </h2>
                <button
                  onClick={() => setShowTrackingModal(false)}
                  className="text-gray-400 hover:text-gray-500"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={handleTrackingUpdate}>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Tracking Number
                    </label>
                    <input
                      type="text"
                      required
                      value={trackingInfo.tracking_number}
                      onChange={(e) => setTrackingInfo({ ...trackingInfo, tracking_number: e.target.value })}
                      className="mt-1 block w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Tracking URL (optional)
                    </label>
                    <input
                      type="url"
                      value={trackingInfo.tracking_url}
                      onChange={(e) => setTrackingInfo({ ...trackingInfo, tracking_url: e.target.value })}
                      className="mt-1 block w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="https://"
                    />
                  </div>

                  <div>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={trackingInfo.notify_customer}
                        onChange={(e) => setTrackingInfo({ ...trackingInfo, notify_customer: e.target.checked })}
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="ml-2 text-sm text-gray-700">
                        Notify Customer
                      </span>
                    </label>
                  </div>

                  {trackingInfo.notify_customer && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Notification Method
                      </label>
                      <div className="space-y-2">
                        <label className="flex items-center">
                          <input
                            type="radio"
                            value="email"
                            checked={trackingInfo.notification_type === 'email'}
                            onChange={(e) => setTrackingInfo({ ...trackingInfo, notification_type: 'email' })}
                            className="rounded-full border-gray-300 text-blue-600 focus:ring-blue-500"
                          />
                          <span className="ml-2 text-sm text-gray-700">Email</span>
                        </label>
                        <label className="flex items-center">
                          <input
                            type="radio"
                            value="sms"
                            checked={trackingInfo.notification_type === 'sms'}
                            onChange={(e) => setTrackingInfo({ ...trackingInfo, notification_type: 'sms' })}
                            className="rounded-full border-gray-300 text-blue-600 focus:ring-blue-500"
                          />
                          <span className="ml-2 text-sm text-gray-700">SMS</span>
                        </label>
                        <label className="flex items-center">
                          <input
                            type="radio"
                            value="both"
                            checked={trackingInfo.notification_type === 'both'}
                            onChange={(e) => setTrackingInfo({ ...trackingInfo, notification_type: 'both' })}
                            className="rounded-full border-gray-300 text-blue-600 focus:ring-blue-500"
                          />
                          <span className="ml-2 text-sm text-gray-700">Both</span>
                        </label>
                      </div>
                    </div>
                  )}

                  <div className="flex justify-end gap-3">
                    <button
                      type="button"
                      onClick={() => setShowTrackingModal(false)}
                      className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 border border-transparent rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      Update Tracking
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && itemToDelete && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full">
            <div className="p-6">
              <div className="flex items-center mb-6">
                <div className="flex-shrink-0">
                  <AlertCircle className="h-6 w-6 text-red-600" />
                </div>
                <div className="ml-3">
                  <h3 className="text-lg font-medium text-gray-900">
                    Confirm Delete
                  </h3>
                </div>
              </div>

              <div className="mt-2">
                <p className="text-sm text-gray-500">
                  {itemToDelete.type === 'product'
                    ? 'Are you sure you want to delete this product? This action cannot be undone.'
                    : itemToDelete.type === 'category'
                    ? 'Are you sure you want to delete this category? This action cannot be undone.'
                    : 'Are you sure you want to delete this order? This action cannot be undone.'}
                </p>
              </div>

              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleDelete}
                  className="px-4 py-2 border border-transparent rounded-lg text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Image Preview Modal */}
      {showImagePreview && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
          <div className="relative max-w-4xl w-full">
            <button
              onClick={() => setShowImagePreview(false)}
              className="absolute top-4 right-4 text-white hover:text-gray-300"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={previewImage}
              alt="Preview"
              className="w-full h-auto rounded-lg"
            />
          </div>
        </div>
      )}
    </div>
  );
}