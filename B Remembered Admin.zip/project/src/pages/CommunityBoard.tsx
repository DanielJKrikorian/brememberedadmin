import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  PlusCircle, Search, Filter, MessageCircle, Heart, 
  ThumbsUp, Calendar, User, Pin, Megaphone, Eye, 
  MessageSquare, AlertCircle, ChevronDown, ChevronUp
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import DateTimeDisplay from '../components/DateTimeDisplay';

interface CommunityBoard {
  id: string;
  name: string;
  description: string;
  type: 'couples' | 'vendors' | 'general';
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

interface CommunityPost {
  id: string;
  board_id: string;
  author_id: string;
  title: string;
  content: string;
  is_pinned: boolean;
  is_announcement: boolean;
  view_count: number;
  created_at: string;
  updated_at: string;
  author: {
    name: string;
    profile_image_url: string | null;
  };
  comments_count: number;
  reactions_count: number;
  board: {
    name: string;
    type: string;
  };
}

export default function CommunityBoard() {
  const navigate = useNavigate();
  const [boards, setBoards] = useState<CommunityBoard[]>([]);
  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBoard, setSelectedBoard] = useState<string | 'all'>('all');
  const [sortBy, setSortBy] = useState<'latest' | 'popular' | 'pinned'>('latest');
  const [expandedPost, setExpandedPost] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([
      fetchBoards(),
      fetchPosts()
    ]).finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    fetchPosts();
  }, [selectedBoard, sortBy]);

  async function fetchBoards() {
    try {
      const { data, error } = await supabase
        .from('community_boards')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setBoards(data || []);
    } catch (err) {
      console.error('Error fetching boards:', err);
      setError('Failed to load community boards');
    }
  }

  async function fetchPosts() {
    try {
      let query = supabase
        .from('community_posts')
        .select(`
          *,
          author:team_members(name, profile_image_url),
          comments_count:community_comments(count),
          reactions_count:community_reactions(count),
          board:community_boards(name, type)
        `);

      // Apply board filter
      if (selectedBoard !== 'all') {
        query = query.eq('board_id', selectedBoard);
      }

      // Apply sorting
      switch (sortBy) {
        case 'latest':
          query = query.order('created_at', { ascending: false });
          break;
        case 'popular':
          query = query.order('view_count', { ascending: false });
          break;
        case 'pinned':
          query = query.order('is_pinned', { ascending: false })
                       .order('created_at', { ascending: false });
          break;
      }

      const { data, error } = await query;

      if (error) throw error;
      setPosts(data || []);
    } catch (err) {
      console.error('Error fetching posts:', err);
      setError('Failed to load community posts');
    }
  }

  async function incrementViewCount(postId: string) {
    try {
      // First get the current view count
      const { data, error } = await supabase
        .from('community_posts')
        .select('view_count')
        .eq('id', postId)
        .single();

      if (error) throw error;

      // Increment the view count
      await supabase
        .from('community_posts')
        .update({ view_count: (data.view_count || 0) + 1 })
        .eq('id', postId);

      // Update local state
      setPosts(posts.map(post => 
        post.id === postId 
          ? { ...post, view_count: post.view_count + 1 } 
          : post
      ));
    } catch (err) {
      console.error('Error incrementing view count:', err);
    }
  }

  function toggleExpandPost(postId: string) {
    if (expandedPost === postId) {
      setExpandedPost(null);
    } else {
      setExpandedPost(postId);
      incrementViewCount(postId);
    }
  }

  // Filter posts based on search term
  const filteredPosts = posts.filter(post =>
    post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.author.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Group posts by board type for the sidebar
  const postsByBoardType = boards.reduce((acc, board) => {
    if (!acc[board.type]) {
      acc[board.type] = [];
    }
    acc[board.type].push(board);
    return acc;
  }, {} as Record<string, CommunityBoard[]>);

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Community Board</h1>
        <button
          onClick={() => navigate('/community/post/new')}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <PlusCircle className="w-5 h-5" />
          New Post
        </button>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-4">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Community Boards</h2>
            
            <div className="space-y-1 mb-4">
              <button
                onClick={() => setSelectedBoard('all')}
                className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                  selectedBoard === 'all'
                    ? 'bg-blue-50 text-blue-600'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                All Boards
              </button>
            </div>

            {Object.entries(postsByBoardType).map(([type, typeBoards]) => (
              <div key={type} className="mb-4">
                <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2 px-3">
                  {type === 'couples' ? 'Couples Boards' : 
                   type === 'vendors' ? 'Vendor Boards' : 'General Boards'}
                </h3>
                <div className="space-y-1">
                  {typeBoards.map(board => (
                    <button
                      key={board.id}
                      onClick={() => setSelectedBoard(board.id)}
                      className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                        selectedBoard === board.id
                          ? 'bg-blue-50 text-blue-600'
                          : 'text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      {board.name}
                    </button>
                  ))}
                </div>
              </div>
            ))}

            <div className="border-t border-gray-200 pt-4 mt-4">
              <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2 px-3">
                Sort By
              </h3>
              <div className="space-y-1">
                <button
                  onClick={() => setSortBy('latest')}
                  className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                    sortBy === 'latest'
                      ? 'bg-blue-50 text-blue-600'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  Latest
                </button>
                <button
                  onClick={() => setSortBy('popular')}
                  className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                    sortBy === 'popular'
                      ? 'bg-blue-50 text-blue-600'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  Most Popular
                </button>
                <button
                  onClick={() => setSortBy('pinned')}
                  className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                    sortBy === 'pinned'
                      ? 'bg-blue-50 text-blue-600'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  Pinned Posts
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3">
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search posts..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : filteredPosts.length === 0 ? (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <MessageCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No posts found</h3>
              <p className="text-gray-600 mb-6">
                {searchTerm
                  ? 'Try adjusting your search terms'
                  : 'Be the first to start a conversation!'}
              </p>
              <button
                onClick={() => navigate('/community/post/new')}
                className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <PlusCircle className="w-5 h-5" />
                Create New Post
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredPosts.map(post => (
                <div 
                  key={post.id} 
                  className="bg-white rounded-lg shadow-md overflow-hidden"
                >
                  <div 
                    className="p-4 cursor-pointer"
                    onClick={() => toggleExpandPost(post.id)}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          {post.is_pinned && (
                            <Pin className="w-4 h-4 text-blue-600" />
                          )}
                          {post.is_announcement && (
                            <Megaphone className="w-4 h-4 text-red-600" />
                          )}
                          <h3 className="text-lg font-medium text-gray-900">{post.title}</h3>
                        </div>
                        
                        <div className="flex items-center text-sm text-gray-500 mb-2">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 mr-2">
                            {post.board.name}
                          </span>
                          <User className="w-4 h-4 mr-1" />
                          <span className="mr-3">{post.author.name}</span>
                          <Calendar className="w-4 h-4 mr-1" />
                          <span>{formatDistanceToNow(new Date(post.created_at), { addSuffix: true })}</span>
                        </div>
                        
                        {expandedPost !== post.id && (
                          <p className="text-gray-600 line-clamp-2">{post.content}</p>
                        )}
                      </div>
                      
                      <div className="flex items-center">
                        {expandedPost === post.id ? (
                          <ChevronUp className="w-5 h-5 text-gray-400" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-gray-400" />
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between mt-4 text-sm text-gray-500">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center">
                          <MessageSquare className="w-4 h-4 mr-1" />
                          <span>{post.comments_count} comments</span>
                        </div>
                        <div className="flex items-center">
                          <Heart className="w-4 h-4 mr-1" />
                          <span>{post.reactions_count} reactions</span>
                        </div>
                        <div className="flex items-center">
                          <Eye className="w-4 h-4 mr-1" />
                          <span>{post.view_count} views</span>
                        </div>
                      </div>
                      
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate(`/community/post/${post.id}`);
                        }}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        View Full Post
                      </button>
                    </div>
                  </div>
                  
                  {expandedPost === post.id && (
                    <div className="px-4 pb-4">
                      <div className="border-t border-gray-200 pt-4 mt-2">
                        <p className="text-gray-600 whitespace-pre-line">{post.content}</p>
                        
                        <div className="mt-6 flex justify-between">
                          <div className="flex gap-2">
                            <button className="flex items-center gap-1 px-3 py-1 bg-gray-100 rounded-full text-gray-700 hover:bg-gray-200">
                              <ThumbsUp className="w-4 h-4" />
                              <span>Like</span>
                            </button>
                            <button className="flex items-center gap-1 px-3 py-1 bg-gray-100 rounded-full text-gray-700 hover:bg-gray-200">
                              <MessageSquare className="w-4 h-4" />
                              <span>Comment</span>
                            </button>
                          </div>
                          
                          <button
                            onClick={() => navigate(`/community/post/${post.id}`)}
                            className="text-blue-600 hover:text-blue-800"
                          >
                            View Full Post
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}