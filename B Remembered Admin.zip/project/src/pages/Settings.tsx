import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { 
  Save, User, Mail, Key, AlertCircle, CheckCircle, 
  Shield, Bell, Globe, Upload, X, Image as ImageIcon
} from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { useTheme } from '../contexts/ThemeContext';

interface TeamMember {
  id: string;
  name: string;
  role: string;
}

interface AdminUser {
  id: string;
  email: string;
  role: string;
}

interface NotificationSettings {
  emailNotifications: boolean;
  smsNotifications: boolean;
  inAppNotifications: boolean;
  dailyDigest: boolean;
  leadAlerts: boolean;
  bookingReminders: boolean;
}

export default function Settings() {
  const { user, adminData } = useAuthStore();
  const { 
    theme, 
    accentColor, 
    compactMode, 
    setTheme, 
    setAccentColor, 
    setCompactMode 
  } = useTheme();
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('profile');
  const [teamMember, setTeamMember] = useState<TeamMember | null>(null);
  
  // Profile settings
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('');
  
  // Security settings
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  // Notification settings
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>({
    emailNotifications: true,
    smsNotifications: false,
    inAppNotifications: true,
    dailyDigest: false,
    leadAlerts: true,
    bookingReminders: true
  });

  // Profile image
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);

  useEffect(() => {
    if (user) {
      fetchUserData();
    }
  }, [user]);

  async function fetchUserData() {
    try {
      setLoading(true);
      
      // Fetch team member data
      const { data: teamMemberData, error: teamMemberError } = await supabase
        .from('team_members')
        .select('*')
        .eq('user_id', user?.id)
        .single();
      
      if (teamMemberError && teamMemberError.code !== 'PGRST116') {
        throw teamMemberError;
      }
      
      if (teamMemberData) {
        setTeamMember(teamMemberData);
        setName(teamMemberData.name);
        setRole(teamMemberData.role);
        setProfileImage(teamMemberData.profile_image_url);
      }
      
      // Set email from auth user
      if (user?.email) {
        setEmail(user.email);
      }
      
      // TODO: Fetch notification and appearance settings from a settings table
      // For now, we'll use the default values
      
    } catch (err) {
      console.error('Error fetching user data:', err);
      setError('Failed to load user data');
    } finally {
      setLoading(false);
    }
  }

  async function handleProfileUpdate(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSuccess(null);
    
    try {
      if (!teamMember) {
        // Create new team member if it doesn't exist
        const { error: createError } = await supabase
          .from('team_members')
          .insert({
            user_id: user?.id,
            name: name,
            role: role || 'admin'
          });
          
        if (createError) throw createError;
      } else {
        // Update existing team member
        const { error: updateError } = await supabase
          .from('team_members')
          .update({
            name: name,
            role: role
          })
          .eq('id', teamMember.id);
          
        if (updateError) throw updateError;
      }
      
      setSuccess('Profile updated successfully');
    } catch (err) {
      console.error('Error updating profile:', err);
      setError('Failed to update profile');
    } finally {
      setSaving(false);
    }
  }

  async function handlePasswordChange(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSuccess(null);
    
    try {
      if (newPassword !== confirmPassword) {
        throw new Error('New passwords do not match');
      }
      
      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });
      
      if (error) throw error;
      
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setSuccess('Password updated successfully');
    } catch (err) {
      console.error('Error changing password:', err);
      setError(err instanceof Error ? err.message : 'Failed to update password');
    } finally {
      setSaving(false);
    }
  }

  async function handleNotificationSettingsUpdate(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSuccess(null);
    
    try {
      // TODO: Save notification settings to a settings table
      
      setSuccess('Notification settings updated successfully');
    } catch (err) {
      console.error('Error updating notification settings:', err);
      setError('Failed to update notification settings');
    } finally {
      setSaving(false);
    }
  }

  async function handleAppearanceSettingsUpdate(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSuccess(null);
    
    try {
      // The actual settings are already saved via the context
      // This is just for showing the success message
      setSuccess('Appearance settings updated successfully');
    } catch (err) {
      console.error('Error updating appearance settings:', err);
      setError('Failed to update appearance settings');
    } finally {
      setSaving(false);
    }
  }

  async function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    
    setUploadingImage(true);
    setError(null);
    
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `profile-images/${user.id}/${user.id}-profile.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from('user-assets')
        .upload(fileName, file, { upsert: true });
        
      if (uploadError) throw uploadError;
      
      const { data: { publicUrl } } = supabase.storage
        .from('user-assets')
        .getPublicUrl(fileName);
        
      setProfileImage(publicUrl);
      
      // Update team member with profile image URL
      if (teamMember) {
        const { error: updateError } = await supabase
          .from('team_members')
          .update({ profile_image_url: publicUrl })
          .eq('id', teamMember.id);
          
        if (updateError) throw updateError;
      }
      
      setSuccess('Profile image updated successfully');
    } catch (err) {
      console.error('Error uploading image:', err);
      setError('Failed to upload profile image');
    } finally {
      setUploadingImage(false);
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Account Settings</h1>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}
      
      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}
      
      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar */}
        <div className="w-full md:w-64 flex-shrink-0">
          <div className="bg-white rounded-lg shadow-md overflow-hidden dark:bg-gray-800">
            <div className="p-6 flex flex-col items-center border-b border-gray-200 dark:border-gray-700">
              <div className="relative mb-4">
                {profileImage ? (
                  <img 
                    src={profileImage} 
                    alt="Profile" 
                    className="w-24 h-24 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center dark:bg-gray-700">
                    <User className="w-12 h-12 text-gray-400 dark:text-gray-500" />
                  </div>
                )}
                <label className="absolute bottom-0 right-0 bg-blue-600 rounded-full p-2 cursor-pointer">
                  <input 
                    type="file" 
                    className="hidden" 
                    accept="image/*"
                    onChange={handleImageUpload}
                    disabled={uploadingImage}
                  />
                  <Upload className="w-4 h-4 text-white" />
                </label>
              </div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">{name || email}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">{role || 'Admin'}</p>
            </div>
            
            <div className="p-4">
              <nav className="space-y-1">
                <button
                  onClick={() => setActiveTab('profile')}
                  className={`w-full flex items-center px-4 py-2 text-sm rounded-lg ${
                    activeTab === 'profile' 
                      ? 'bg-blue-50 text-blue-600 dark:bg-blue-900 dark:text-blue-200' 
                      : 'text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-700'
                  }`}
                >
                  <User className="w-5 h-5 mr-3" />
                  Profile
                </button>
                
                <button
                  onClick={() => setActiveTab('security')}
                  className={`w-full flex items-center px-4 py-2 text-sm rounded-lg ${
                    activeTab === 'security' 
                      ? 'bg-blue-50 text-blue-600 dark:bg-blue-900 dark:text-blue-200' 
                      : 'text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-700'
                  }`}
                >
                  <Shield className="w-5 h-5 mr-3" />
                  Security
                </button>
                
                <button
                  onClick={() => setActiveTab('notifications')}
                  className={`w-full flex items-center px-4 py-2 text-sm rounded-lg ${
                    activeTab === 'notifications' 
                      ? 'bg-blue-50 text-blue-600 dark:bg-blue-900 dark:text-blue-200' 
                      : 'text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-700'
                  }`}
                >
                  <Bell className="w-5 h-5 mr-3" />
                  Notifications
                </button>
                
                <button
                  onClick={() => setActiveTab('appearance')}
                  className={`w-full flex items-center px-4 py-2 text-sm rounded-lg ${
                    activeTab === 'appearance' 
                      ? 'bg-blue-50 text-blue-600 dark:bg-blue-900 dark:text-blue-200' 
                      : 'text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-700'
                  }`}
                >
                  <Globe className="w-5 h-5 mr-3" />
                  Appearance
                </button>
              </nav>
            </div>
          </div>
        </div>
        
        {/* Main content */}
        <div className="flex-1">
          <div className="bg-white rounded-lg shadow-md p-6 dark:bg-gray-800">
            {/* Profile Settings */}
            {activeTab === 'profile' && (
              <form onSubmit={handleProfileUpdate}>
                <h2 className="text-xl font-semibold text-gray-900 mb-6 dark:text-white">Profile Settings</h2>
                
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                      Full Name
                    </label>
                    <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500 dark:border-gray-600">
                      <User className="w-5 h-5 text-gray-400 ml-3 dark:text-gray-500" />
                      <input
                        type="text"
                        className="w-full px-3 py-2 focus:outline-none dark:bg-gray-800 dark:text-white"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                      Email Address
                    </label>
                    <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500 dark:border-gray-600">
                      <Mail className="w-5 h-5 text-gray-400 ml-3 dark:text-gray-500" />
                      <input
                        type="email"
                        className="w-full px-3 py-2 focus:outline-none dark:bg-gray-800 dark:text-white"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        disabled
                      />
                    </div>
                    <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                      Email address cannot be changed. Contact support for assistance.
                    </p>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                      Role
                    </label>
                    <select
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-800 dark:text-white"
                      value={role}
                      onChange={(e) => setRole(e.target.value)}
                      required
                    >
                      <option value="admin">Admin</option>
                      <option value="manager">Manager</option>
                      <option value="team_member">Team Member</option>
                    </select>
                  </div>
                </div>
                
                <div className="mt-6 flex justify-end">
                  <button
                    type="submit"
                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 dark:bg-blue-700 dark:hover:bg-blue-600"
                    disabled={saving}
                  >
                    <Save className="w-5 h-5" />
                    {saving ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              </form>
            )}
            
            {/* Security Settings */}
            {activeTab === 'security' && (
              <form onSubmit={handlePasswordChange}>
                <h2 className="text-xl font-semibold text-gray-900 mb-6 dark:text-white">Security Settings</h2>
                
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                      Current Password
                    </label>
                    <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500 dark:border-gray-600">
                      <Key className="w-5 h-5 text-gray-400 ml-3 dark:text-gray-500" />
                      <input
                        type="password"
                        className="w-full px-3 py-2 focus:outline-none dark:bg-gray-800 dark:text-white"
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                      New Password
                    </label>
                    <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500 dark:border-gray-600">
                      <Key className="w-5 h-5 text-gray-400 ml-3 dark:text-gray-500" />
                      <input
                        type="password"
                        className="w-full px-3 py-2 focus:outline-none dark:bg-gray-800 dark:text-white"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        required
                        minLength={8}
                      />
                    </div>
                    <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                      Password must be at least 8 characters long
                    </p>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                      Confirm New Password
                    </label>
                    <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500 dark:border-gray-600">
                      <Key className="w-5 h-5 text-gray-400 ml-3 dark:text-gray-500" />
                      <input
                        type="password"
                        className="w-full px-3 py-2 focus:outline-none dark:bg-gray-800 dark:text-white"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 flex justify-end">
                  <button
                    type="submit"
                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 dark:bg-blue-700 dark:hover:bg-blue-600"
                    disabled={saving}
                  >
                    <Save className="w-5 h-5" />
                    {saving ? 'Updating...' : 'Update Password'}
                  </button>
                </div>
              </form>
            )}
            
            {/* Notification Settings */}
            {activeTab === 'notifications' && (
              <form onSubmit={handleNotificationSettingsUpdate}>
                <h2 className="text-xl font-semibold text-gray-900 mb-6 dark:text-white">Notification Settings</h2>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-4 dark:text-white">Notification Channels</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Mail className="w-5 h-5 text-gray-400 mr-3 dark:text-gray-500" />
                          <span className="text-gray-700 dark:text-gray-300">Email Notifications</span>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input 
                            type="checkbox" 
                            className="sr-only peer"
                            checked={notificationSettings.emailNotifications}
                            onChange={(e) => setNotificationSettings({
                              ...notificationSettings,
                              emailNotifications: e.target.checked
                            })}
                          />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600 dark:bg-gray-700 dark:peer-focus:ring-blue-800 dark:peer-checked:bg-blue-500"></div>
                        </label>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <MessageSquare className="w-5 h-5 text-gray-400 mr-3 dark:text-gray-500" />
                          <span className="text-gray-700 dark:text-gray-300">SMS Notifications</span>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input 
                            type="checkbox" 
                            className="sr-only peer"
                            checked={notificationSettings.smsNotifications}
                            onChange={(e) => setNotificationSettings({
                              ...notificationSettings,
                              smsNotifications: e.target.checked
                            })}
                          />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600 dark:bg-gray-700 dark:peer-focus:ring-blue-800 dark:peer-checked:bg-blue-500"></div>
                        </label>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Bell className="w-5 h-5 text-gray-400 mr-3 dark:text-gray-500" />
                          <span className="text-gray-700 dark:text-gray-300">In-App Notifications</span>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input 
                            type="checkbox" 
                            className="sr-only peer"
                            checked={notificationSettings.inAppNotifications}
                            onChange={(e) => setNotificationSettings({
                              ...notificationSettings,
                              inAppNotifications: e.target.checked
                            })}
                          />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600 dark:bg-gray-700 dark:peer-focus:ring-blue-800 dark:peer-checked:bg-blue-500"></div>
                        </label>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-4 dark:text-white">Notification Types</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-700 dark:text-gray-300">Daily Digest</span>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input 
                            type="checkbox" 
                            className="sr-only peer"
                            checked={notificationSettings.dailyDigest}
                            onChange={(e) => setNotificationSettings({
                              ...notificationSettings,
                              dailyDigest: e.target.checked
                            })}
                          />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600 dark:bg-gray-700 dark:peer-focus:ring-blue-800 dark:peer-checked:bg-blue-500"></div>
                        </label>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-gray-700 dark:text-gray-300">Lead Alerts</span>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input 
                            type="checkbox" 
                            className="sr-only peer"
                            checked={notificationSettings.leadAlerts}
                            onChange={(e) => setNotificationSettings({
                              ...notificationSettings,
                              leadAlerts: e.target.checked
                            })}
                          />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600 dark:bg-gray-700 dark:peer-focus:ring-blue-800 dark:peer-checked:bg-blue-500"></div>
                        </label>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-gray-700 dark:text-gray-300">Booking Reminders</span>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input 
                            type="checkbox" 
                            className="sr-only peer"
                            checked={notificationSettings.bookingReminders}
                            onChange={(e) => setNotificationSettings({
                              ...notificationSettings,
                              bookingReminders: e.target.checked
                            })}
                          />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600 dark:bg-gray-700 dark:peer-focus:ring-blue-800 dark:peer-checked:bg-blue-500"></div>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 flex justify-end">
                  <button
                    type="submit"
                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 dark:bg-blue-700 dark:hover:bg-blue-600"
                    disabled={saving}
                  >
                    <Save className="w-5 h-5" />
                    {saving ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              </form>
            )}
            
            {/* Appearance Settings */}
            {activeTab === 'appearance' && (
              <form onSubmit={handleAppearanceSettingsUpdate}>
                <h2 className="text-xl font-semibold text-gray-900 mb-6 dark:text-white">Appearance Settings</h2>
                
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2 dark:text-gray-300">
                      Theme
                    </label>
                    <div className="grid grid-cols-3 gap-4">
                      <label className={`flex flex-col items-center p-4 border rounded-lg cursor-pointer ${
                        theme === 'light' 
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900 dark:border-blue-400' 
                          : 'border-gray-200 hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-700'
                      }`}>
                        <input 
                          type="radio" 
                          name="theme" 
                          value="light"
                          className="sr-only"
                          checked={theme === 'light'}
                          onChange={() => setTheme('light')}
                        />
                        <Sun className="w-8 h-8 text-gray-700 mb-2 dark:text-gray-300" />
                        <span className="text-sm font-medium dark:text-gray-300">Light</span>
                      </label>
                      
                      <label className={`flex flex-col items-center p-4 border rounded-lg cursor-pointer ${
                        theme === 'dark' 
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900 dark:border-blue-400' 
                          : 'border-gray-200 hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-700'
                      }`}>
                        <input 
                          type="radio" 
                          name="theme" 
                          value="dark"
                          className="sr-only"
                          checked={theme === 'dark'}
                          onChange={() => setTheme('dark')}
                        />
                        <Moon className="w-8 h-8 text-gray-700 mb-2 dark:text-gray-300" />
                        <span className="text-sm font-medium dark:text-gray-300">Dark</span>
                      </label>
                      
                      <label className={`flex flex-col items-center p-4 border rounded-lg cursor-pointer ${
                        theme === 'system' 
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900 dark:border-blue-400' 
                          : 'border-gray-200 hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-700'
                      }`}>
                        <input 
                          type="radio" 
                          name="theme" 
                          value="system"
                          className="sr-only"
                          checked={theme === 'system'}
                          onChange={() => setTheme('system')}
                        />
                        <Monitor className="w-8 h-8 text-gray-700 mb-2 dark:text-gray-300" />
                        <span className="text-sm font-medium dark:text-gray-300">System</span>
                      </label>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2 dark:text-gray-300">
                      Accent Color
                    </label>
                    <div className="grid grid-cols-6 gap-4">
                      {['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'].map(color => (
                        <button
                          key={color}
                          type="button"
                          className={`w-10 h-10 rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                            accentColor === color ? 'ring-2 ring-offset-2 ring-blue-500 dark:ring-offset-gray-800' : ''
                          }`}
                          style={{ backgroundColor: color }}
                          onClick={() => setAccentColor(color)}
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-700 font-medium dark:text-gray-300">Compact Mode</span>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          className="sr-only peer"
                          checked={compactMode}
                          onChange={(e) => setCompactMode(e.target.checked)}
                        />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600 dark:bg-gray-700 dark:peer-focus:ring-blue-800 dark:peer-checked:bg-blue-500"></div>
                      </label>
                    </div>
                    <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                      Reduces padding and spacing throughout the interface
                    </p>
                  </div>
                </div>
                
                <div className="mt-6 flex justify-end">
                  <button
                    type="submit"
                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 dark:bg-blue-700 dark:hover:bg-blue-600"
                    disabled={saving}
                  >
                    <Save className="w-5 h-5" />
                    {saving ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// These components are needed for the appearance settings
function Sun(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2v2" />
      <path d="M12 20v2" />
      <path d="m4.93 4.93 1.41 1.41" />
      <path d="m17.66 17.66 1.41 1.41" />
      <path d="M2 12h2" />
      <path d="M20 12h2" />
      <path d="m6.34 17.66-1.41 1.41" />
      <path d="m19.07 4.93-1.41 1.41" />
    </svg>
  );
}

function Moon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" />
    </svg>
  );
}

function Monitor(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="20" height="14" x="2" y="3" rx="2" />
      <line x1="8" x2="16" y1="21" y2="21" />
      <line x1="12" x2="12" y1="17" y2="21" />
    </svg>
  );
}

function MessageSquare(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
    </svg>
  );
}