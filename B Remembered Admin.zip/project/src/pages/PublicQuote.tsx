import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { loadStripe } from '@stripe/stripe-js';
import { Calendar, DollarSign, FileText, Check } from 'lucide-react';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface Quote {
  id: string;
  amount: number;
  description: string;
  expires_at: string;
  status: string;
  lead: {
    name: string;
    email: string;
  };
  services: Array<{
    service: {
      name: string;
    };
    quantity: number;
    price: number;
    start_time: string;
  }>;
  contract?: {
    id: string;
    name: string;
    content: string;
  };
}

// Service fee amount in dollars
const SERVICE_FEE = 50;

export default function PublicQuote() {
  const { id } = useParams();
  const [quote, setQuote] = useState<Quote | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [signature, setSignature] = useState('');
  const [showContract, setShowContract] = useState(false);
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    fetchQuote();
  }, [id]);

  async function fetchQuote() {
    try {
      const { data, error } = await supabase
        .from('quotes')
        .select(`
          *,
          lead:leads(name, email),
          services:quote_services(
            service:services(name),
            quantity,
            price,
            start_time
          ),
          contract:contracts(*)
        `)
        .eq('id', id)
        .single();

      if (error) throw error;
      setQuote(data);
    } catch (error) {
      console.error('Error fetching quote:', error);
      setError('Quote not found or has expired');
    } finally {
      setLoading(false);
    }
  }

  async function handlePayment() {
    if (!quote) return;
    setProcessing(true);

    try {
      // Create payment session
      const response = await fetch('/functions/v1/create-payment-link', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          quoteId: quote.id,
          amount: quote.amount,
          description: quote.description,
        }),
      });

      const { paymentLink, error } = await response.json();
      if (error) throw new Error(error);

      // Redirect to payment page
      window.location.href = paymentLink;
    } catch (error) {
      console.error('Error creating payment:', error);
      setError('Failed to process payment. Please try again.');
    } finally {
      setProcessing(false);
    }
  }

  async function handleSignContract() {
    if (!quote || !signature) return;
    setProcessing(true);

    try {
      const { error } = await supabase
        .from('signed_contracts')
        .insert({
          contract_id: quote.contract?.id,
          lead_id: quote.lead.id,
          quote_id: quote.id,
          signed_at: new Date().toISOString(),
          signature,
          ip_address: await fetch('https://api.ipify.org?format=json')
            .then(res => res.json())
            .then(data => data.ip),
        });

      if (error) throw error;

      // Refresh quote to update status
      await fetchQuote();
      setShowContract(false);
    } catch (error) {
      console.error('Error signing contract:', error);
      setError('Failed to sign contract. Please try again.');
    } finally {
      setProcessing(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error || !quote) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Error</h1>
          <p className="text-gray-600">{error || 'Quote not found'}</p>
        </div>
      </div>
    );
  }

  const isExpired = new Date(quote.expires_at) < new Date();
  const isPaid = quote.status === 'paid';
  const isSigned = quote.contract && quote.status === 'signed';
  
  // Calculate total with service fee
  const totalWithFee = quote.amount + SERVICE_FEE;

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <img
            src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png"
            alt="B. Remembered Logo"
            className="h-16 mx-auto mb-8"
          />
          <h1 className="text-3xl font-bold text-gray-900">Your Quote</h1>
          <p className="mt-2 text-gray-600">
            Prepared for {quote.lead.name}
          </p>
        </div>

        {isExpired && (
          <div className="mb-8 bg-red-50 border border-red-200 rounded-lg p-4 text-center text-red-700">
            This quote has expired. Please contact us for an updated quote.
          </div>
        )}

        <div className="bg-white shadow-lg rounded-lg overflow-hidden mb-8">
          <div className="p-6 sm:p-8">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Service Quote</h2>
                <div className="mt-2 flex items-center text-gray-600">
                  <Calendar className="w-5 h-5 mr-2" />
                  Valid until {new Date(quote.expires_at).toLocaleDateString()}
                </div>
              </div>
              <div className="mt-4 sm:mt-0 text-right">
                <div className="text-sm text-gray-600">Quote Amount</div>
                <div className="text-3xl font-bold text-gray-900">
                  ${quote.amount.toLocaleString()}
                </div>
              </div>
            </div>

            <div className="border-t border-gray-200 pt-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Services</h3>
              <div className="space-y-6">
                {quote.services.map((service, index) => (
                  <div key={index} className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium text-gray-900">
                        {service.service.name}
                      </h4>
                      <p className="text-sm text-gray-600">
                        {new Date(service.start_time).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="font-medium text-gray-900">
                        ${service.price.toLocaleString()}
                      </div>
                      {service.quantity > 1 && (
                        <div className="text-sm text-gray-600">
                          {service.quantity} × ${(service.price / service.quantity).toLocaleString()}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t border-gray-200 mt-8 pt-8">
              <div className="prose prose-sm max-w-none text-gray-600">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Description</h3>
                <p>{quote.description}</p>
              </div>
            </div>
            
            <div className="border-t border-gray-200 mt-8 pt-8">
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-600">Quote Amount:</span>
                <span className="text-gray-900 font-medium">${quote.amount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-600">Service Fee:</span>
                <span className="text-gray-900 font-medium">${SERVICE_FEE.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-gray-200">
                <span className="text-gray-900 font-semibold">Total Amount:</span>
                <span className="text-xl font-bold text-gray-900">${totalWithFee.toLocaleString()}</span>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 px-6 py-8 sm:px-8">
            <div className="space-y-4">
              {quote.contract && !isSigned && (
                <button
                  onClick={() => setShowContract(true)}
                  disabled={isExpired || processing}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-white border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50"
                >
                  <FileText className="w-5 h-5" />
                  Review & Sign Contract
                </button>
              )}

              {!isPaid && (
                <button
                  onClick={handlePayment}
                  disabled={isExpired || processing || (quote.contract && !isSigned)}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  <DollarSign className="w-5 h-5" />
                  {processing ? 'Processing...' : 'Pay Now'}
                </button>
              )}

              {isPaid && (
                <div className="flex items-center justify-center gap-2 text-green-600">
                  <Check className="w-5 h-5" />
                  Payment Complete
                </div>
              )}
            </div>

            {quote.contract && !isSigned && (
              <p className="mt-4 text-sm text-center text-gray-600">
                Please review and sign the contract before proceeding with payment
              </p>
            )}
            
            <p className="mt-4 text-sm text-center text-gray-500">
              A $50 service fee will be added to your total at checkout
            </p>
          </div>
        </div>
      </div>

      {showContract && quote.contract && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-gray-900">{quote.contract.name}</h2>
              <button
                onClick={() => setShowContract(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="prose prose-sm max-w-none mb-8">
              {quote.contract.content}
            </div>

            <div className="border-t border-gray-200 pt-6">
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Signature
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Type your full name to sign"
                  value={signature}
                  onChange={(e) => setSignature(e.target.value)}
                />
              </div>

              <div className="flex justify-end gap-3">
                <button
                  onClick={() => setShowContract(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSignContract}
                  disabled={!signature || processing}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  {processing ? 'Signing...' : 'Sign Contract'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}