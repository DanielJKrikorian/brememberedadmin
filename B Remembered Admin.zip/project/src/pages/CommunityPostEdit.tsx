import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { supabase } from '../lib/supabase';
import { 
  ArrowLeft, Save, Trash2, Upload, X, Send, 
  User, Calendar, MessageSquare, Heart, Pin, 
  Megaphone, AlertCircle, CheckCircle, ThumbsUp,
  Paperclip, Image as ImageIcon, File, Download
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { useAuthStore } from '../store/authStore';

interface CommunityBoard {
  id: string;
  name: string;
  description: string;
  type: 'couples' | 'vendors' | 'general';
}

interface CommunityAttachment {
  id: string;
  file_name: string;
  file_type: string;
  file_size: number;
  url: string;
  created_at: string;
}

interface CommunityComment {
  id: string;
  post_id: string;
  parent_id: string | null;
  author_id: string;
  content: string;
  created_at: string;
  updated_at: string;
  author: {
    name: string;
    profile_image_url: string | null;
  };
  attachments: CommunityAttachment[];
  replies?: CommunityComment[];
}

interface CommunityReaction {
  id: string;
  post_id: string | null;
  comment_id: string | null;
  user_id: string;
  reaction_type: 'like' | 'love' | 'haha' | 'wow' | 'sad' | 'angry';
  created_at: string;
}

interface CommunityPost {
  id: string;
  board_id: string;
  author_id: string;
  title: string;
  content: string;
  is_pinned: boolean;
  is_announcement: boolean;
  view_count: number;
  created_at: string;
  updated_at: string;
  author: {
    name: string;
    profile_image_url: string | null;
  };
  board: {
    name: string;
    type: string;
  };
  attachments: CommunityAttachment[];
  comments: CommunityComment[];
  reactions: CommunityReaction[];
}

export default function CommunityPostEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [post, setPost] = useState<Partial<CommunityPost>>({
    title: '',
    content: '',
    board_id: '',
    is_pinned: false,
    is_announcement: false,
    attachments: []
  });
  const [boards, setBoards] = useState<CommunityBoard[]>([]);
  const [comments, setComments] = useState<CommunityComment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({});
  const [teamMemberId, setTeamMemberId] = useState<string | null>(null);
  const commentInputRef = useRef<HTMLTextAreaElement>(null);

  const isNew = id === 'new';

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: handleFileDrop,
    multiple: true
  });

  useEffect(() => {
    fetchBoards();
    if (!isNew) {
      fetchPost();
    } else {
      setLoading(false);
    }
    fetchTeamMemberId();
  }, [id]);

  async function fetchTeamMemberId() {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('team_members')
        .select('id')
        .eq('user_id', user.id)
        .single();
        
      if (error) throw error;
      setTeamMemberId(data.id);
    } catch (err) {
      console.error('Error fetching team member ID:', err);
    }
  }

  async function fetchBoards() {
    try {
      const { data, error } = await supabase
        .from('community_boards')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setBoards(data || []);
      
      // Set default board if creating a new post
      if (isNew && data && data.length > 0) {
        setPost(prev => ({ ...prev, board_id: data[0].id }));
      }
    } catch (err) {
      console.error('Error fetching boards:', err);
      setError('Failed to load community boards');
    }
  }

  async function fetchPost() {
    try {
      // Fetch post details
      const { data: postData, error: postError } = await supabase
        .from('community_posts')
        .select(`
          *,
          author:team_members(name, profile_image_url),
          board:community_boards(name, type)
        `)
        .eq('id', id)
        .single();

      if (postError) throw postError;
      
      // Fetch post attachments
      const { data: attachments, error: attachmentsError } = await supabase
        .from('community_attachments')
        .select('*')
        .eq('post_id', id);
        
      if (attachmentsError) throw attachmentsError;
      
      // Fetch post reactions
      const { data: reactions, error: reactionsError } = await supabase
        .from('community_reactions')
        .select('*')
        .eq('post_id', id);
        
      if (reactionsError) throw reactionsError;
      
      // Fetch comments
      const { data: commentsData, error: commentsError } = await supabase
        .from('community_comments')
        .select(`
          *,
          author:team_members(name, profile_image_url)
        `)
        .eq('post_id', id)
        .is('parent_id', null)
        .order('created_at', { ascending: true });
        
      if (commentsError) throw commentsError;
      
      // Fetch comment attachments
      const commentIds = commentsData?.map(c => c.id) || [];
      let commentAttachments: any[] = [];
      
      if (commentIds.length > 0) {
        const { data: attachments, error: attachmentsError } = await supabase
          .from('community_attachments')
          .select('*')
          .in('comment_id', commentIds);
          
        if (attachmentsError) throw attachmentsError;
        commentAttachments = attachments || [];
      }
      
      // Fetch replies
      let replies: any[] = [];
      if (commentIds.length > 0) {
        const { data: repliesData, error: repliesError } = await supabase
          .from('community_comments')
          .select(`
            *,
            author:team_members(name, profile_image_url)
          `)
          .in('parent_id', commentIds)
          .order('created_at', { ascending: true });
          
        if (repliesError) throw repliesError;
        replies = repliesData || [];
      }
      
      // Fetch reply attachments
      const replyIds = replies?.map(r => r.id) || [];
      let replyAttachments: any[] = [];
      
      if (replyIds.length > 0) {
        const { data: attachments, error: attachmentsError } = await supabase
          .from('community_attachments')
          .select('*')
          .in('comment_id', replyIds);
          
        if (attachmentsError) throw attachmentsError;
        replyAttachments = attachments || [];
      }
      
      // Organize comments with their attachments and replies
      const commentsWithAttachments = commentsData?.map(comment => {
        const commentAttachmentList = commentAttachments.filter(a => a.comment_id === comment.id);
        const commentReplies = replies.filter(r => r.parent_id === comment.id).map(reply => {
          const replyAttachmentList = replyAttachments.filter(a => a.comment_id === reply.id);
          return { ...reply, attachments: replyAttachmentList };
        });
        
        return { 
          ...comment, 
          attachments: commentAttachmentList,
          replies: commentReplies
        };
      }) || [];
      
      // Set post data with all related information
      setPost({
        ...postData,
        attachments: attachments || [],
        reactions: reactions || []
      });
      
      setComments(commentsWithAttachments);
    } catch (err) {
      console.error('Error fetching post:', err);
      setError('Failed to load post');
    } finally {
      setLoading(false);
    }
  }

  async function handleFileDrop(acceptedFiles: File[]) {
    if (isNew && !post.board_id) {
      setError('Please select a board before uploading files');
      return;
    }

    for (const file of acceptedFiles) {
      const fileId = Math.random().toString(36).substring(7);
      setUploadProgress(prev => ({ ...prev, [fileId]: 0 }));

      try {
        // Create a unique file path
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
        const filePath = `${isNew ? 'temp' : id}/${fileName}`;

        // Upload the file
        const { error: uploadError } = await supabase.storage
          .from('community-attachments')
          .upload(filePath, file, {
            onUploadProgress: (progress) => {
              const percent = (progress.loaded / progress.total) * 100;
              setUploadProgress(prev => ({ ...prev, [fileId]: percent }));
            }
          });

        if (uploadError) throw uploadError;

        // Get the public URL
        const { data: { publicUrl } } = supabase.storage
          .from('community-attachments')
          .getPublicUrl(filePath);

        // Add the file to the post attachments
        setPost(prev => ({
          ...prev,
          attachments: [
            ...(prev.attachments || []),
            {
              id: fileId,
              file_name: file.name,
              file_type: file.type,
              file_size: file.size,
              url: publicUrl,
              created_at: new Date().toISOString()
            }
          ]
        }));

        // Clean up progress indicator
        setUploadProgress(prev => {
          const newProgress = { ...prev };
          delete newProgress[fileId];
          return newProgress;
        });
      } catch (err) {
        console.error('Error uploading file:', err);
        setError('Failed to upload file');
        setUploadProgress(prev => {
          const newProgress = { ...prev };
          delete newProgress[fileId];
          return newProgress;
        });
      }
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!teamMemberId) {
      setError('You must be logged in to create or edit posts');
      return;
    }

    setSaving(true);
    setError(null);
    setSuccess(null);

    try {
      if (isNew) {
        // Create new post
        const { data, error } = await supabase
          .from('community_posts')
          .insert({
            board_id: post.board_id,
            author_id: teamMemberId,
            title: post.title,
            content: post.content,
            is_pinned: post.is_pinned,
            is_announcement: post.is_announcement
          })
          .select()
          .single();

        if (error) throw error;

        // Save attachments
        if (post.attachments && post.attachments.length > 0) {
          for (const attachment of post.attachments) {
            // Move file from temp to permanent location if needed
            if (attachment.url.includes('/temp/')) {
              const oldPath = new URL(attachment.url).pathname.split('/').pop();
              const newPath = `${data.id}/${oldPath}`;
              
              // Copy the file to the new location
              await supabase.storage
                .from('community-attachments')
                .copy(`temp/${oldPath}`, newPath);
                
              // Update the URL
              attachment.url = attachment.url.replace('/temp/', `/${data.id}/`);
            }
            
            // Save attachment record
            await supabase
              .from('community_attachments')
              .insert({
                post_id: data.id,
                file_name: attachment.file_name,
                file_type: attachment.file_type,
                file_size: attachment.file_size,
                url: attachment.url
              });
          }
        }

        setSuccess('Post created successfully');
        setTimeout(() => {
          navigate(`/community/post/${data.id}`);
        }, 1000);
      } else {
        // Update existing post
        const { error } = await supabase
          .from('community_posts')
          .update({
            board_id: post.board_id,
            title: post.title,
            content: post.content,
            is_pinned: post.is_pinned,
            is_announcement: post.is_announcement
          })
          .eq('id', id);

        if (error) throw error;

        // Handle new attachments
        const existingAttachments = post.attachments?.filter(a => a.id.length > 10) || [];
        const newAttachments = post.attachments?.filter(a => a.id.length <= 10) || [];
        
        for (const attachment of newAttachments) {
          await supabase
            .from('community_attachments')
            .insert({
              post_id: id,
              file_name: attachment.file_name,
              file_type: attachment.file_type,
              file_size: attachment.file_size,
              url: attachment.url
            });
        }

        setSuccess('Post updated successfully');
        setTimeout(() => {
          fetchPost();
        }, 1000);
      }
    } catch (err) {
      console.error('Error saving post:', err);
      setError(err instanceof Error ? err.message : 'Failed to save post');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    if (!post.id) return;

    try {
      // Delete all attachments from storage
      if (post.attachments && post.attachments.length > 0) {
        for (const attachment of post.attachments) {
          const url = new URL(attachment.url);
          const pathParts = url.pathname.split('/');
          const storagePath = pathParts.slice(pathParts.indexOf('community-attachments') + 1).join('/');
          
          await supabase.storage
            .from('community-attachments')
            .remove([storagePath]);
        }
      }

      // Delete the post (this will cascade delete comments, reactions, and attachments)
      const { error } = await supabase
        .from('community_posts')
        .delete()
        .eq('id', post.id);

      if (error) throw error;

      navigate('/community');
    } catch (err) {
      console.error('Error deleting post:', err);
      setError(err instanceof Error ? err.message : 'Failed to delete post');
    }
  }

  async function handleAddComment() {
    if (!teamMemberId || !newComment.trim() || !post.id) return;

    try {
      const { data, error } = await supabase
        .from('community_comments')
        .insert({
          post_id: post.id,
          author_id: teamMemberId,
          content: newComment
        })
        .select(`
          *,
          author:team_members(name, profile_image_url)
        `)
        .single();

      if (error) throw error;

      // Add the new comment to the list
      setComments([...comments, { ...data, attachments: [], replies: [] }]);
      setNewComment('');
    } catch (err) {
      console.error('Error adding comment:', err);
      setError('Failed to add comment');
    }
  }

  async function handleAddReply() {
    if (!teamMemberId || !replyContent.trim() || !post.id || !replyTo) return;

    try {
      const { data, error } = await supabase
        .from('community_comments')
        .insert({
          post_id: post.id,
          parent_id: replyTo,
          author_id: teamMemberId,
          content: replyContent
        })
        .select(`
          *,
          author:team_members(name, profile_image_url)
        `)
        .single();

      if (error) throw error;

      // Add the reply to the appropriate comment
      setComments(comments.map(comment => {
        if (comment.id === replyTo) {
          return {
            ...comment,
            replies: [...(comment.replies || []), { ...data, attachments: [] }]
          };
        }
        return comment;
      }));

      setReplyTo(null);
      setReplyContent('');
    } catch (err) {
      console.error('Error adding reply:', err);
      setError('Failed to add reply');
    }
  }

  async function handleReaction(type: 'like' | 'love' | 'haha' | 'wow' | 'sad' | 'angry') {
    if (!teamMemberId || !post.id) return;

    try {
      // Check if user already reacted with this type
      const existingReaction = post.reactions?.find(r => 
        r.user_id === teamMemberId && r.reaction_type === type
      );

      if (existingReaction) {
        // Remove the reaction
        const { error } = await supabase
          .from('community_reactions')
          .delete()
          .eq('id', existingReaction.id);

        if (error) throw error;

        // Update local state
        setPost({
          ...post,
          reactions: post.reactions?.filter(r => r.id !== existingReaction.id)
        });
      } else {
        // Add the reaction
        const { data, error } = await supabase
          .from('community_reactions')
          .insert({
            post_id: post.id,
            user_id: teamMemberId,
            reaction_type: type
          })
          .select()
          .single();

        if (error) throw error;

        // Update local state
        setPost({
          ...post,
          reactions: [...(post.reactions || []), data]
        });
      }
    } catch (err) {
      console.error('Error handling reaction:', err);
      setError('Failed to update reaction');
    }
  }

  function removeAttachment(attachmentId: string) {
    setPost({
      ...post,
      attachments: post.attachments?.filter(a => a.id !== attachmentId)
    });
  }

  function getFileIcon(fileType: string) {
    if (fileType.startsWith('image/')) {
      return <ImageIcon className="w-5 h-5 text-blue-500" />;
    }
    return <File className="w-5 h-5 text-gray-500" />;
  }

  function formatFileSize(bytes: number) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/community')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">
            {isNew ? 'New Post' : 'View Post'}
          </h1>
        </div>
        {!isNew && (
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="flex items-center gap-2 px-4 py-2 text-red-600 hover:text-red-700"
          >
            <Trash2 className="w-5 h-5" />
            Delete Post
          </button>
        )}
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {isNew || (post.author && post.author_id === teamMemberId) ? (
            // Edit form
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6 space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Board *
                </label>
                <select
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  value={post.board_id}
                  onChange={(e) => setPost({ ...post, board_id: e.target.value })}
                  required
                >
                  <option value="">Select a board</option>
                  {boards.map(board => (
                    <option key={board.id} value={board.id}>{board.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Title *
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  value={post.title}
                  onChange={(e) => setPost({ ...post, title: e.target.value })}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Content *
                </label>
                <textarea
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  rows={8}
                  value={post.content}
                  onChange={(e) => setPost({ ...post, content: e.target.value })}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Attachments
                </label>
                <div {...getRootProps()} className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer">
                  <input {...getInputProps()} />
                  <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-600">
                    {isDragActive ? 'Drop files here' : 'Drag & drop files here, or click to select'}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">
                    You can upload images, documents, and other files
                  </p>
                </div>

                {/* Upload Progress */}
                {Object.entries(uploadProgress).map(([fileId, progress]) => (
                  <div key={fileId} className="mt-4">
                    <div className="flex justify-between text-sm text-gray-600 mb-1">
                      <span>Uploading file...</span>
                      <span>{Math.round(progress)}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </div>
                ))}

                {/* Attachment List */}
                {post.attachments && post.attachments.length > 0 && (
                  <div className="mt-4 space-y-2">
                    <h3 className="text-sm font-medium text-gray-700">Attached Files</h3>
                    {post.attachments.map(attachment => (
                      <div key={attachment.id} className="flex items-center justify-between bg-gray-50 p-2 rounded-lg">
                        <div className="flex items-center">
                          {getFileIcon(attachment.file_type)}
                          <span className="ml-2 text-sm text-gray-900">{attachment.file_name}</span>
                          <span className="ml-2 text-xs text-gray-500">({formatFileSize(attachment.file_size)})</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeAttachment(attachment.id)}
                          className="text-red-600 hover:text-red-800"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex items-center space-x-4">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={post.is_pinned}
                    onChange={(e) => setPost({ ...post, is_pinned: e.target.checked })}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Pin this post</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={post.is_announcement}
                    onChange={(e) => setPost({ ...post, is_announcement: e.target.checked })}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Mark as announcement</span>
                </label>
              </div>

              <div className="pt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => navigate('/community')}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  disabled={saving}
                >
                  <Save className="w-5 h-5" />
                  {saving ? 'Saving...' : (isNew ? 'Create Post' : 'Save Changes')}
                </button>
              </div>
            </form>
          ) : (
            // View post
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-2">
                  {post.is_pinned && (
                    <Pin className="w-5 h-5 text-blue-600" />
                  )}
                  {post.is_announcement && (
                    <Megaphone className="w-5 h-5 text-red-600" />
                  )}
                  <h2 className="text-2xl font-bold text-gray-900">{post.title}</h2>
                </div>
                
                <div className="flex items-center text-sm text-gray-500 mb-4">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 mr-2">
                    {post.board?.name}
                  </span>
                  <div className="flex items-center">
                    {post.author?.profile_image_url ? (
                      <img 
                        src={post.author.profile_image_url} 
                        alt={post.author.name}
                        className="w-5 h-5 rounded-full mr-1"
                      />
                    ) : (
                      <User className="w-4 h-4 mr-1" />
                    )}
                    <span className="mr-3">{post.author?.name}</span>
                  </div>
                  <Calendar className="w-4 h-4 mr-1" />
                  <span>{formatDistanceToNow(new Date(post.created_at), { addSuffix: true })}</span>
                </div>
                
                <div className="prose max-w-none">
                  <p className="text-gray-700 whitespace-pre-line">{post.content}</p>
                </div>
                
                {/* Attachments */}
                {post.attachments && post.attachments.length > 0 && (
                  <div className="mt-6 border-t border-gray-200 pt-4">
                    <h3 className="text-sm font-medium text-gray-700 mb-2">Attachments</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {post.attachments.map(attachment => (
                        <a
                          key={attachment.id}
                          href={attachment.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center p-2 bg-gray-50 rounded-lg hover:bg-gray-100"
                        >
                          {getFileIcon(attachment.file_type)}
                          <div className="ml-2 flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">{attachment.file_name}</p>
                            <p className="text-xs text-gray-500">{formatFileSize(attachment.file_size)}</p>
                          </div>
                          <Download className="w-4 h-4 text-gray-400" />
                        </a>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Reactions */}
                <div className="mt-6 flex items-center gap-2">
                  <button 
                    onClick={() => handleReaction('like')}
                    className={`flex items-center gap-1 px-3 py-1 rounded-full ${
                      post.reactions?.some(r => r.user_id === teamMemberId && r.reaction_type === 'like')
                        ? 'bg-blue-100 text-blue-700'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    <ThumbsUp className="w-4 h-4" />
                    <span>Like</span>
                    {post.reactions && post.reactions.filter(r => r.reaction_type === 'like').length > 0 && (
                      <span className="ml-1 text-xs bg-white rounded-full px-1.5">
                        {post.reactions.filter(r => r.reaction_type === 'like').length}
                      </span>
                    )}
                  </button>
                  
                  <button 
                    onClick={() => handleReaction('love')}
                    className={`flex items-center gap-1 px-3 py-1 rounded-full ${
                      post.reactions?.some(r => r.user_id === teamMemberId && r.reaction_type === 'love')
                        ? 'bg-red-100 text-red-700'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    <Heart className="w-4 h-4" />
                    <span>Love</span>
                    {post.reactions && post.reactions.filter(r => r.reaction_type === 'love').length > 0 && (
                      <span className="ml-1 text-xs bg-white rounded-full px-1.5">
                        {post.reactions.filter(r => r.reaction_type === 'love').length}
                      </span>
                    )}
                  </button>
                  
                  <button 
                    onClick={() => {
                      if (commentInputRef.current) {
                        commentInputRef.current.focus();
                      }
                    }}
                    className="flex items-center gap-1 px-3 py-1 bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Comment</span>
                    {comments.length > 0 && (
                      <span className="ml-1 text-xs bg-white rounded-full px-1.5">
                        {comments.length}
                      </span>
                    )}
                  </button>
                </div>
              </div>
              
              {/* Comments Section */}
              <div className="border-t border-gray-200 pt-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Comments</h3>
                
                {/* New Comment Form */}
                <div className="mb-6">
                  <textarea
                    ref={commentInputRef}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows={3}
                    placeholder="Add a comment..."
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                  />
                  <div className="mt-2 flex justify-end">
                    <button
                      onClick={handleAddComment}
                      disabled={!newComment.trim() || !teamMemberId}
                      className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                    >
                      <Send className="w-4 h-4" />
                      Post Comment
                    </button>
                  </div>
                </div>
                
                {/* Comments List */}
                <div className="space-y-6">
                  {comments.length === 0 ? (
                    <p className="text-center text-gray-500 py-4">No comments yet. Be the first to comment!</p>
                  ) : (
                    comments.map(comment => (
                      <div key={comment.id} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-start gap-3">
                          {comment.author.profile_image_url ? (
                            <img 
                              src={comment.author.profile_image_url} 
                              alt={comment.author.name}
                              className="w-10 h-10 rounded-full"
                            />
                          ) : (
                            <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                              <User className="w-6 h-6 text-gray-500" />
                            </div>
                          )}
                          
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-gray-900">{comment.author.name}</span>
                              <span className="text-xs text-gray-500">
                                {formatDistanceToNow(new Date(comment.created_at), { addSuffix: true })}
                              </span>
                            </div>
                            
                            <p className="mt-1 text-gray-700">{comment.content}</p>
                            
                            {/* Comment Attachments */}
                            {comment.attachments && comment.attachments.length > 0 && (
                              <div className="mt-2 space-y-1">
                                {comment.attachments.map(attachment => (
                                  <a
                                    key={attachment.id}
                                    href={attachment.url}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="flex items-center text-sm text-blue-600 hover:text-blue-800"
                                  >
                                    <Paperclip className="w-4 h-4 mr-1" />
                                    {attachment.file_name}
                                  </a>
                                ))}
                              </div>
                            )}
                            
                            {/* Comment Actions */}
                            <div className="mt-2 flex items-center gap-3 text-sm">
                              <button 
                                onClick={() => setReplyTo(comment.id)}
                                className="text-gray-500 hover:text-gray-700"
                              >
                                Reply
                              </button>
                            </div>
                            
                            {/* Replies */}
                            {comment.replies && comment.replies.length > 0 && (
                              <div className="mt-4 space-y-4 pl-6 border-l-2 border-gray-100">
                                {comment.replies.map(reply => (
                                  <div key={reply.id} className="flex items-start gap-3">
                                    {reply.author.profile_image_url ? (
                                      <img 
                                        src={reply.author.profile_image_url} 
                                        alt={reply.author.name}
                                        className="w-8 h-8 rounded-full"
                                      />
                                    ) : (
                                      <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                                        <User className="w-4 h-4 text-gray-500" />
                                      </div>
                                    )}
                                    
                                    <div>
                                      <div className="flex items-center gap-2">
                                        <span className="font-medium text-gray-900">{reply.author.name}</span>
                                        <span className="text-xs text-gray-500">
                                          {formatDistanceToNow(new Date(reply.created_at), { addSuffix: true })}
                                        </span>
                                      </div>
                                      
                                      <p className="mt-1 text-gray-700">{reply.content}</p>
                                      
                                      {/* Reply Attachments */}
                                      {reply.attachments && reply.attachments.length > 0 && (
                                        <div className="mt-2 space-y-1">
                                          {reply.attachments.map(attachment => (
                                            <a
                                              key={attachment.id}
                                              href={attachment.url}
                                              target="_blank"
                                              rel="noopener noreferrer"
                                              className="flex items-center text-sm text-blue-600 hover:text-blue-800"
                                            >
                                              <Paperclip className="w-4 h-4 mr-1" />
                                              {attachment.file_name}
                                            </a>
                                          ))}
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                            
                            {/* Reply Form */}
                            {replyTo === comment.id && (
                              <div className="mt-4 pl-6">
                                <textarea
                                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  rows={2}
                                  placeholder="Write a reply..."
                                  value={replyContent}
                                  onChange={(e) => setReplyContent(e.target.value)}
                                />
                                <div className="mt-2 flex justify-end gap-2">
                                  <button
                                    onClick={() => {
                                      setReplyTo(null);
                                      setReplyContent('');
                                    }}
                                    className="px-3 py-1 text-gray-600 hover:text-gray-800"
                                  >
                                    Cancel
                                  </button>
                                  <button
                                    onClick={handleAddReply}
                                    disabled={!replyContent.trim() || !teamMemberId}
                                    className="flex items-center gap-1 px-3 py-1 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                                  >
                                    <Send className="w-3 h-3" />
                                    Reply
                                  </button>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        <div>
          {/* Board Information */}
          {post.board_id && boards.length > 0 && (
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Board Information</h2>
              
              {boards.find(b => b.id === post.board_id) && (
                <div>
                  <h3 className="font-medium text-gray-900">
                    {boards.find(b => b.id === post.board_id)?.name}
                  </h3>
                  <p className="text-gray-600 mt-2">
                    {boards.find(b => b.id === post.board_id)?.description}
                  </p>
                  <div className="mt-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      boards.find(b => b.id === post.board_id)?.type === 'couples'
                        ? 'bg-pink-100 text-pink-800'
                        : boards.find(b => b.id === post.board_id)?.type === 'vendors'
                        ? 'bg-purple-100 text-purple-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}>
                      {boards.find(b => b.id === post.board_id)?.type === 'couples'
                        ? 'Couples Board'
                        : boards.find(b => b.id === post.board_id)?.type === 'vendors'
                        ? 'Vendors Board'
                        : 'General Board'}
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Post Statistics */}
          {!isNew && post.id && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Post Statistics</h2>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-gray-600">
                    <Eye className="w-5 h-5 mr-2" />
                    <span>Views</span>
                  </div>
                  <span className="font-medium text-gray-900">{post.view_count}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-gray-600">
                    <MessageSquare className="w-5 h-5 mr-2" />
                    <span>Comments</span>
                  </div>
                  <span className="font-medium text-gray-900">{comments.length}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-gray-600">
                    <Heart className="w-5 h-5 mr-2" />
                    <span>Reactions</span>
                  </div>
                  <span className="font-medium text-gray-900">{post.reactions?.length || 0}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-gray-600">
                    <Calendar className="w-5 h-5 mr-2" />
                    <span>Created</span>
                  </div>
                  <span className="font-medium text-gray-900">
                    <DateTimeDisplay date={post.created_at} format="datetime" />
                  </span>
                </div>
                
                {post.created_at !== post.updated_at && (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-gray-600">
                      <Calendar className="w-5 h-5 mr-2" />
                      <span>Last Updated</span>
                    </div>
                    <span className="font-medium text-gray-900">
                      <DateTimeDisplay date={post.updated_at} format="datetime" />
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Delete Post</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this post? This action cannot be undone and will remove all comments and reactions.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Delete Post
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}