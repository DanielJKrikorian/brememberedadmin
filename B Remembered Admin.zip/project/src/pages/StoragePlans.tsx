import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  HardDrive, Database, Edit, Trash2, Plus, Search, 
  AlertCircle, CheckCircle, X, DollarSign, Users, 
  Calendar, Clock, Save, FolderOpen, User, Building2
} from 'lucide-react';

interface StoragePlan {
  id: string;
  name: string;
  description: string | null;
  storage_limit: number; // in bytes
  price_monthly: number;
  price_yearly: number;
  is_active: boolean;
  features: {
    max_folders: number;
    max_shares: number;
  };
  created_at: string;
  updated_at: string;
}

interface VendorStorageSubscription {
  id: string;
  vendor_id: string;
  plan_id: string;
  status: 'active' | 'canceled' | 'expired';
  storage_used: number; // in bytes
  billing_cycle: 'monthly' | 'yearly';
  current_period_start: string;
  current_period_end: string;
  stripe_subscription_id: string | null;
  created_at: string;
  updated_at: string;
  vendor: {
    id: string;
    name: string;
    email: string;
  };
  plan: StoragePlan;
}

interface CoupleStorageSubscription {
  id: string;
  lead_id: string;
  folder_share_id: string;
  status: 'active' | 'canceled' | 'expired';
  billing_cycle: 'monthly' | 'yearly';
  current_period_start: string;
  current_period_end: string;
  stripe_subscription_id: string | null;
  created_at: string;
  updated_at: string;
  lead: {
    id: string;
    name: string;
    email: string;
  };
  folder_share: {
    id: string;
    folder_id: string;
    price_monthly: number;
    folder: {
      name: string;
      vendor: {
        name: string;
      };
    };
  };
}

export default function StoragePlans() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'plans' | 'vendors' | 'couples'>('plans');
  const [plans, setPlans] = useState<StoragePlan[]>([]);
  const [vendorSubscriptions, setVendorSubscriptions] = useState<VendorStorageSubscription[]>([]);
  const [coupleSubscriptions, setCoupleSubscriptions] = useState<CoupleStorageSubscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Plan edit modal state
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [editingPlan, setEditingPlan] = useState<StoragePlan | null>(null);
  const [planForm, setPlanForm] = useState({
    name: '',
    description: '',
    storage_limit: 0,
    price_monthly: 0,
    price_yearly: 0,
    is_active: true,
    max_folders: 0,
    max_shares: 0
  });
  
  // Delete confirmation modal state
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<{id: string, type: 'plan' | 'vendor' | 'couple'} | null>(null);
  
  useEffect(() => {
    fetchData();
  }, [activeTab]);
  
  async function fetchData() {
    setLoading(true);
    try {
      // Always fetch plans
      await fetchPlans();
      
      // Fetch subscriptions based on active tab
      if (activeTab === 'vendors') {
        await fetchVendorSubscriptions();
      } else if (activeTab === 'couples') {
        await fetchCoupleSubscriptions();
      }
    } catch (err) {
      console.error('Error fetching data:', err);
      setError('Failed to load data');
    } finally {
      setLoading(false);
    }
  }
  
  async function fetchPlans() {
    try {
      const { data, error } = await supabase
        .from('storage_plans')
        .select('*')
        .order('price_monthly');
        
      if (error) throw error;
      setPlans(data || []);
    } catch (err) {
      console.error('Error fetching plans:', err);
      throw err;
    }
  }
  
  async function fetchVendorSubscriptions() {
    try {
      const { data, error } = await supabase
        .from('vendor_storage_subscriptions')
        .select(`
          *,
          vendor:vendors(id, name, email),
          plan:storage_plans(*)
        `)
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      setVendorSubscriptions(data || []);
    } catch (err) {
      console.error('Error fetching vendor subscriptions:', err);
      throw err;
    }
  }
  
  async function fetchCoupleSubscriptions() {
    try {
      const { data, error } = await supabase
        .from('couple_storage_subscriptions')
        .select(`
          *,
          lead:leads(id, name, email),
          folder_share:folder_shares(
            id,
            folder_id,
            price_monthly,
            folder:storage_folders(
              name,
              vendor:vendors(name)
            )
          )
        `)
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      setCoupleSubscriptions(data || []);
    } catch (err) {
      console.error('Error fetching couple subscriptions:', err);
      throw err;
    }
  }
  
  function handleEditPlan(plan: StoragePlan) {
    setEditingPlan(plan);
    setPlanForm({
      name: plan.name,
      description: plan.description || '',
      storage_limit: plan.storage_limit / (1024 * 1024 * 1024), // Convert bytes to GB
      price_monthly: plan.price_monthly,
      price_yearly: plan.price_yearly,
      is_active: plan.is_active,
      max_folders: plan.features.max_folders,
      max_shares: plan.features.max_shares
    });
    setShowPlanModal(true);
  }
  
  function handleAddPlan() {
    setEditingPlan(null);
    setPlanForm({
      name: '',
      description: '',
      storage_limit: 5, // Default 5GB
      price_monthly: 9.99,
      price_yearly: 99.99,
      is_active: true,
      max_folders: 10,
      max_shares: 5
    });
    setShowPlanModal(true);
  }
  
  async function handleSavePlan() {
    try {
      const planData = {
        name: planForm.name,
        description: planForm.description || null,
        storage_limit: planForm.storage_limit * 1024 * 1024 * 1024, // Convert GB to bytes
        price_monthly: planForm.price_monthly,
        price_yearly: planForm.price_yearly,
        is_active: planForm.is_active,
        features: {
          max_folders: planForm.max_folders,
          max_shares: planForm.max_shares
        }
      };
      
      if (editingPlan) {
        // Update existing plan
        const { error } = await supabase
          .from('storage_plans')
          .update(planData)
          .eq('id', editingPlan.id);
          
        if (error) throw error;
      } else {
        // Create new plan
        const { error } = await supabase
          .from('storage_plans')
          .insert([planData]);
          
        if (error) throw error;
      }
      
      // Refresh plans
      await fetchPlans();
      
      // Close modal
      setShowPlanModal(false);
      setEditingPlan(null);
      
      // Show success message
      setSuccess(editingPlan ? 'Plan updated successfully' : 'Plan created successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error saving plan:', err);
      setError('Failed to save plan');
    }
  }
  
  async function handleDelete() {
    if (!itemToDelete) return;
    
    try {
      if (itemToDelete.type === 'plan') {
        // Check if plan is in use
        const { count, error: countError } = await supabase
          .from('vendor_storage_subscriptions')
          .select('id', { count: 'exact', head: true })
          .eq('plan_id', itemToDelete.id);
          
        if (countError) throw countError;
        
        if (count && count > 0) {
          throw new Error('Cannot delete plan that is currently in use');
        }
        
        // Delete plan
        const { error } = await supabase
          .from('storage_plans')
          .delete()
          .eq('id', itemToDelete.id);
          
        if (error) throw error;
        
        // Refresh plans
        await fetchPlans();
      } else if (itemToDelete.type === 'vendor') {
        // Delete vendor subscription
        const { error } = await supabase
          .from('vendor_storage_subscriptions')
          .delete()
          .eq('id', itemToDelete.id);
          
        if (error) throw error;
        
        // Refresh vendor subscriptions
        await fetchVendorSubscriptions();
      } else if (itemToDelete.type === 'couple') {
        // Delete couple subscription
        const { error } = await supabase
          .from('couple_storage_subscriptions')
          .delete()
          .eq('id', itemToDelete.id);
          
        if (error) throw error;
        
        // Refresh couple subscriptions
        await fetchCoupleSubscriptions();
      }
      
      // Close modal
      setShowDeleteConfirm(false);
      setItemToDelete(null);
      
      // Show success message
      setSuccess('Item deleted successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error deleting item:', err);
      setError(err instanceof Error ? err.message : 'Failed to delete item');
    }
  }
  
  function formatBytes(bytes: number, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }
  
  function getUsagePercentage(used: number, limit: number) {
    return Math.min(100, Math.round((used / limit) * 100));
  }
  
  // Filter data based on search term
  const filteredPlans = plans.filter(plan => 
    plan.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (plan.description && plan.description.toLowerCase().includes(searchTerm.toLowerCase()))
  );
  
  const filteredVendorSubscriptions = vendorSubscriptions.filter(sub => 
    sub.vendor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sub.vendor.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sub.plan.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const filteredCoupleSubscriptions = coupleSubscriptions.filter(sub => 
    sub.lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sub.lead.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sub.folder_share.folder.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sub.folder_share.folder.vendor.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Storage Plans</h1>
        
        {activeTab === 'plans' && (
          <button
            onClick={handleAddPlan}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-5 h-5" />
            Add Plan
          </button>
        )}
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700 dark:bg-red-900/30 dark:border-red-800 dark:text-red-400">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}
      
      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700 dark:bg-green-900/30 dark:border-green-800 dark:text-green-400">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}
      
      {/* Tabs */}
      <div className="mb-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex space-x-8">
          <button
            onClick={() => setActiveTab('plans')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'plans'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            Storage Plans
          </button>
          <button
            onClick={() => setActiveTab('vendors')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'vendors'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            Vendor Subscriptions
          </button>
          <button
            onClick={() => setActiveTab('couples')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'couples'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            Couple Subscriptions
          </button>
        </div>
      </div>
      
      {/* Search */}
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder={`Search ${activeTab === 'plans' ? 'plans' : activeTab === 'vendors' ? 'vendor subscriptions' : 'couple subscriptions'}...`}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-800 dark:text-white"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      
      {/* Content based on active tab */}
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <>
          {/* Plans Tab */}
          {activeTab === 'plans' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredPlans.length === 0 ? (
                <div className="col-span-full bg-white rounded-lg shadow-md p-8 text-center dark:bg-gray-800">
                  <Database className="w-12 h-12 text-gray-400 mx-auto mb-4 dark:text-gray-500" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2 dark:text-white">No Plans Found</h3>
                  <p className="text-gray-500 dark:text-gray-400">
                    {searchTerm ? 'Try adjusting your search terms' : 'Get started by creating your first storage plan'}
                  </p>
                  <button
                    onClick={handleAddPlan}
                    className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Add Plan
                  </button>
                </div>
              ) : (
                filteredPlans.map(plan => (
                  <div 
                    key={plan.id} 
                    className={`border rounded-lg overflow-hidden ${
                      plan.is_active 
                        ? 'border-gray-200 dark:border-gray-700' 
                        : 'border-red-200 dark:border-red-800'
                    }`}
                  >
                    <div className={`px-6 py-4 ${
                      plan.is_active 
                        ? 'bg-white dark:bg-gray-800' 
                        : 'bg-red-50 dark:bg-red-900/20'
                    }`}>
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{plan.name}</h3>
                          {plan.description && (
                            <p className="text-sm text-gray-500 mt-1 dark:text-gray-400">{plan.description}</p>
                          )}
                        </div>
                        {!plan.is_active && (
                          <span className="px-2 py-1 bg-red-100 text-red-800 text-xs rounded-full dark:bg-red-900/50 dark:text-red-300">
                            Inactive
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <div className="px-6 py-4 border-t border-gray-200 dark:border-gray-700">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-gray-600 dark:text-gray-400">Storage</span>
                        <span className="font-medium text-gray-900 dark:text-white">{formatBytes(plan.storage_limit)}</span>
                      </div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-gray-600 dark:text-gray-400">Monthly Price</span>
                        <span className="font-medium text-gray-900 dark:text-white">${plan.price_monthly.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-gray-600 dark:text-gray-400">Yearly Price</span>
                        <span className="font-medium text-gray-900 dark:text-white">${plan.price_yearly.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-gray-600 dark:text-gray-400">Max Folders</span>
                        <span className="font-medium text-gray-900 dark:text-white">{plan.features.max_folders}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600 dark:text-gray-400">Max Shares</span>
                        <span className="font-medium text-gray-900 dark:text-white">{plan.features.max_shares}</span>
                      </div>
                    </div>
                    
                    <div className="px-6 py-4 bg-gray-50 dark:bg-gray-700 flex justify-end gap-2">
                      <button
                        onClick={() => handleEditPlan(plan)}
                        className="flex items-center gap-1 px-3 py-1 text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                      >
                        <Edit className="w-4 h-4" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => {
                          setItemToDelete({ id: plan.id, type: 'plan' });
                          setShowDeleteConfirm(true);
                        }}
                        className="flex items-center gap-1 px-3 py-1 text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300"
                      >
                        <Trash2 className="w-4 h-4" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
          
          {/* Vendor Subscriptions Tab */}
          {activeTab === 'vendors' && (
            <div className="bg-white rounded-lg shadow-md overflow-hidden dark:bg-gray-800">
              {filteredVendorSubscriptions.length === 0 ? (
                <div className="p-8 text-center">
                  <HardDrive className="w-12 h-12 text-gray-400 mx-auto mb-4 dark:text-gray-500" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2 dark:text-white">No Vendor Subscriptions Found</h3>
                  <p className="text-gray-500 dark:text-gray-400">
                    {searchTerm ? 'Try adjusting your search terms' : 'No vendors have subscribed to storage plans yet'}
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                    <thead className="bg-gray-50 dark:bg-gray-700">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Vendor</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Plan</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Storage Usage</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Billing</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-700">
                      {filteredVendorSubscriptions.map(subscription => (
                        <tr key={subscription.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <Building2 className="w-5 h-5 text-gray-400 mr-3 dark:text-gray-500" />
                              <div>
                                <div className="text-sm font-medium text-gray-900 dark:text-white">{subscription.vendor.name}</div>
                                <div className="text-sm text-gray-500 dark:text-gray-400">{subscription.vendor.email}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900 dark:text-white">{subscription.plan.name}</div>
                            <div className="text-xs text-gray-500 dark:text-gray-400">{formatBytes(subscription.plan.storage_limit)}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="flex-1 mr-4">
                                <div className="text-xs text-gray-500 flex justify-between mb-1 dark:text-gray-400">
                                  <span>{formatBytes(subscription.storage_used)}</span>
                                  <span>{formatBytes(subscription.plan.storage_limit)}</span>
                                </div>
                                <div className="w-full bg-gray-200 rounded-full h-2 dark:bg-gray-700">
                                  <div 
                                    className={`h-2 rounded-full ${
                                      getUsagePercentage(subscription.storage_used, subscription.plan.storage_limit) > 90
                                        ? 'bg-red-600'
                                        : getUsagePercentage(subscription.storage_used, subscription.plan.storage_limit) > 75
                                        ? 'bg-yellow-600'
                                        : 'bg-green-600'
                                    }`}
                                    style={{ width: `${getUsagePercentage(subscription.storage_used, subscription.plan.storage_limit)}%` }}
                                  ></div>
                                </div>
                              </div>
                              <span className="text-sm font-medium text-gray-900 dark:text-white">
                                {getUsagePercentage(subscription.storage_used, subscription.plan.storage_limit)}%
                              </span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900 dark:text-white">
                              ${subscription.billing_cycle === 'monthly' 
                                ? subscription.plan.price_monthly.toFixed(2) + '/mo' 
                                : subscription.plan.price_yearly.toFixed(2) + '/yr'}
                            </div>
                            <div className="text-xs text-gray-500 flex items-center dark:text-gray-400">
                              <Calendar className="w-3 h-3 mr-1" />
                              Renews {new Date(subscription.current_period_end).toLocaleDateString()}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              subscription.status === 'active' 
                                ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' 
                                : subscription.status === 'canceled'
                                ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400'
                                : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                            }`}>
                              {subscription.status.charAt(0).toUpperCase() + subscription.status.slice(1)}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button
                              onClick={() => {
                                setItemToDelete({ id: subscription.id, type: 'vendor' });
                                setShowDeleteConfirm(true);
                              }}
                              className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                            >
                              Cancel
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
          
          {/* Couple Subscriptions Tab */}
          {activeTab === 'couples' && (
            <div className="bg-white rounded-lg shadow-md overflow-hidden dark:bg-gray-800">
              {filteredCoupleSubscriptions.length === 0 ? (
                <div className="p-8 text-center">
                  <FolderOpen className="w-12 h-12 text-gray-400 mx-auto mb-4 dark:text-gray-500" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2 dark:text-white">No Couple Subscriptions Found</h3>
                  <p className="text-gray-500 dark:text-gray-400">
                    {searchTerm ? 'Try adjusting your search terms' : 'No couples have subscribed to shared folders yet'}
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                    <thead className="bg-gray-50 dark:bg-gray-700">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Couple</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Folder</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Vendor</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Billing</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-700">
                      {filteredCoupleSubscriptions.map(subscription => (
                        <tr key={subscription.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <User className="w-5 h-5 text-gray-400 mr-3 dark:text-gray-500" />
                              <div>
                                <div className="text-sm font-medium text-gray-900 dark:text-white">{subscription.lead.name}</div>
                                <div className="text-sm text-gray-500 dark:text-gray-400">{subscription.lead.email}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900 dark:text-white">
                              {subscription.folder_share.folder.name}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900 dark:text-white">
                              {subscription.folder_share.folder.vendor.name}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900 dark:text-white">
                              ${subscription.folder_share.price_monthly.toFixed(2)}/mo
                            </div>
                            <div className="text-xs text-gray-500 flex items-center dark:text-gray-400">
                              <Calendar className="w-3 h-3 mr-1" />
                              Renews {new Date(subscription.current_period_end).toLocaleDateString()}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              subscription.status === 'active' 
                                ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' 
                                : subscription.status === 'canceled'
                                ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400'
                                : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                            }`}>
                              {subscription.status.charAt(0).toUpperCase() + subscription.status.slice(1)}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button
                              onClick={() => {
                                setItemToDelete({ id: subscription.id, type: 'couple' });
                                setShowDeleteConfirm(true);
                              }}
                              className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                            >
                              Cancel
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </>
      )}
      
      {/* Plan Edit Modal */}
      {showPlanModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full dark:bg-gray-800">
            <div className="flex justify-between items-center p-6 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                {editingPlan ? 'Edit Storage Plan' : 'Add Storage Plan'}
              </h2>
              <button
                onClick={() => setShowPlanModal(false)}
                className="text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                    Plan Name
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                    value={planForm.name}
                    onChange={(e) => setPlanForm({ ...planForm, name: e.target.value })}
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                    Description
                  </label>
                  <textarea
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                    rows={2}
                    value={planForm.description}
                    onChange={(e) => setPlanForm({ ...planForm, description: e.target.value })}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                    Storage Limit (GB)
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="1"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                    value={planForm.storage_limit}
                    onChange={(e) => setPlanForm({ ...planForm, storage_limit: parseInt(e.target.value) || 0 })}
                    required
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                      Monthly Price ($)
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                      value={planForm.price_monthly}
                      onChange={(e) => setPlanForm({ ...planForm, price_monthly: parseFloat(e.target.value) || 0 })}
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                      Yearly Price ($)
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                      value={planForm.price_yearly}
                      onChange={(e) => setPlanForm({ ...planForm, price_yearly: parseFloat(e.target.value) || 0 })}
                      required
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                      Max Folders
                    </label>
                    <input
                      type="number"
                      min="1"
                      step="1"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                      value={planForm.max_folders}
                      onChange={(e) => setPlanForm({ ...planForm, max_folders: parseInt(e.target.value) || 0 })}
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                      Max Shares
                    </label>
                    <input
                      type="number"
                      min="1"
                      step="1"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                      value={planForm.max_shares}
                      onChange={(e) => setPlanForm({ ...planForm, max_shares: parseInt(e.target.value) || 0 })}
                      required
                    />
                  </div>
                </div>
                
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="is_active"
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700"
                    checked={planForm.is_active}
                    onChange={(e) => setPlanForm({ ...planForm, is_active: e.target.checked })}
                  />
                  <label htmlFor="is_active" className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                    Active (available for purchase)
                  </label>
                </div>
              </div>
              
              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowPlanModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSavePlan}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600"
                >
                  <Save className="w-5 h-5" />
                  {editingPlan ? 'Update Plan' : 'Create Plan'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && itemToDelete && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full dark:bg-gray-800">
            <h2 className="text-xl font-bold text-gray-900 mb-4 dark:text-white">
              {itemToDelete.type === 'plan' ? 'Delete Plan' : 'Cancel Subscription'}
            </h2>
            <p className="text-gray-600 mb-6 dark:text-gray-300">
              {itemToDelete.type === 'plan'
                ? 'Are you sure you want to delete this storage plan? This action cannot be undone.'
                : `Are you sure you want to cancel this ${itemToDelete.type} subscription? This will revoke their access to the storage.`}
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowDeleteConfirm(false);
                  setItemToDelete(null);
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 dark:bg-red-700 dark:hover:bg-red-600"
              >
                {itemToDelete.type === 'plan' ? 'Delete Plan' : 'Cancel Subscription'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}