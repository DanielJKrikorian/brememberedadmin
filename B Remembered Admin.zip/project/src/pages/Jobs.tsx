import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Calendar, MapPin, DollarSign, Clock, Eye, PlusCircle, Search, Filter, AlertCircle, X, Package, Building2 } from 'lucide-react';

interface Job {
  id: string;
  title: string;
  description: string;
  requirements: string | null;
  status: string;
  venue_id: string | null;
  date: string;
  budget: number | null;
  created_at: string;
  updated_at: string;
  venue?: {
    name: string;
    address: string;
  };
}

interface Service {
  id: string;
  name: string;
  description: string;
  base_price: number;
  variants: Array<{
    id: string;
    name: string;
    price: number;
    hours: number | null;
  }>;
}

interface Venue {
  id: string;
  name: string;
  address: string;
}

export default function Jobs() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [services, setServices] = useState<Service[]>([]);
  const [venues, setVenues] = useState<Venue[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [venueSearchTerm, setVenueSearchTerm] = useState('');
  const [showVenueSearch, setShowVenueSearch] = useState(false);
  const navigate = useNavigate();

  // New job form state
  const [newJob, setNewJob] = useState({
    title: '',
    description: '',
    requirements: '',
    date: new Date().toISOString().split('T')[0],
    budget: '',
    venue_id: null as string | null,
    venue_name: '',
    venue_address: '',
    service_type: 'existing' as 'existing' | 'custom',
    service_id: '',
    variant_id: '',
    custom_service_name: '',
    custom_service_description: '',
    custom_service_price: '',
    custom_service_hours: '',
  });

  useEffect(() => {
    fetchJobs();
    fetchServices();
    fetchVenues();
  }, []);

  async function fetchJobs() {
    try {
      const { data, error } = await supabase
        .from('jobs')
        .select(`
          *,
          venue:venues(
            name,
            address
          )
        `)
        .eq('status', 'open')
        .order('date', { ascending: true });

      if (error) throw error;
      setJobs(data || []);
    } catch (error) {
      console.error('Error fetching jobs:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchServices() {
    try {
      const { data, error } = await supabase
        .from('services')
        .select(`
          *,
          variants:service_variants(*)
        `)
        .order('name');

      if (error) throw error;
      setServices(data || []);
    } catch (error) {
      console.error('Error fetching services:', error);
    }
  }

  async function fetchVenues() {
    try {
      const { data, error } = await supabase
        .from('venues')
        .select('id, name, address')
        .order('name');
      
      if (error) throw error;
      setVenues(data || []);
    } catch (error) {
      console.error('Error fetching venues:', error);
    }
  }

  const selectVenue = (venue: Venue) => {
    setNewJob({
      ...newJob,
      venue_id: venue.id,
      venue_name: venue.name,
      venue_address: venue.address,
    });
    setVenueSearchTerm('');
    setShowVenueSearch(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);

    try {
      let venueId = newJob.venue_id;

      // Create new venue if needed
      if (!venueId && newJob.venue_name && newJob.venue_address) {
        const { data: venue, error: venueError } = await supabase
          .from('venues')
          .insert({
            name: newJob.venue_name,
            address: newJob.venue_address
          })
          .select()
          .single();

        if (venueError) throw venueError;
        venueId = venue.id;
      }

      // Initialize service and variant IDs as null
      let serviceId: string | null = null;
      let variantId: string | null = null;

      // Handle existing service selection
      if (newJob.service_type === 'existing') {
        serviceId = newJob.service_id || null;
        variantId = newJob.variant_id || null;
      }
      
      // Create custom service if needed
      if (newJob.service_type === 'custom' && newJob.custom_service_name) {
        const { data: service, error: serviceError } = await supabase
          .from('services')
          .insert({
            name: newJob.custom_service_name,
            description: newJob.custom_service_description,
            base_price: parseFloat(newJob.custom_service_price) || 0,
          })
          .select()
          .single();

        if (serviceError) throw serviceError;
        serviceId = service.id;

        // Create service variant if hours specified
        if (newJob.custom_service_hours) {
          const { data: variant, error: variantError } = await supabase
            .from('service_variants')
            .insert({
              service_id: service.id,
              name: `${newJob.custom_service_name} - ${newJob.custom_service_hours}h`,
              price: parseFloat(newJob.custom_service_price) || 0,
              hours: parseInt(newJob.custom_service_hours) || null,
            })
            .select()
            .single();

          if (variantError) throw variantError;
          variantId = variant.id;
        }
      }

      const { error: jobError } = await supabase
        .from('jobs')
        .insert({
          title: newJob.title,
          description: newJob.description,
          requirements: newJob.requirements || null,
          date: newJob.date,
          budget: parseFloat(newJob.budget) || null,
          venue_id: venueId,
          status: 'open',
          service_id: serviceId,
          variant_id: variantId,
        });

      if (jobError) throw jobError;

      setShowModal(false);
      fetchJobs();
    } catch (err) {
      console.error('Error creating job:', err);
      setError(err instanceof Error ? err.message : 'Failed to create job');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  const selectedService = services.find(s => s.id === newJob.service_id);

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Job Board</h1>
        <button 
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <PlusCircle className="w-5 h-5" />
          Post New Job
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {jobs.map((job) => (
          <div
            key={job.id}
            className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
          >
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h2 className="text-xl font-semibold text-gray-900 mb-2">{job.title}</h2>
                <span className="px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
                  Open
                </span>
              </div>

              <p className="text-gray-600 mb-4 line-clamp-2">{job.description}</p>

              <div className="space-y-2">
                <div className="flex items-center text-gray-600">
                  <Calendar className="w-4 h-4 mr-2" />
                  <span>{new Date(job.date).toLocaleDateString()}</span>
                </div>
                
                {job.venue && (
                  <div className="flex items-center text-gray-600">
                    <MapPin className="w-4 h-4 mr-2" />
                    <span>{job.venue.name}</span>
                  </div>
                )}

                {job.budget && (
                  <div className="flex items-center text-gray-600">
                    <DollarSign className="w-4 h-4 mr-2" />
                    <span>${job.budget.toLocaleString()}</span>
                  </div>
                )}

                {job.requirements && (
                  <div className="flex items-center text-gray-600">
                    <Clock className="w-4 h-4 mr-2" />
                    <span className="line-clamp-1">{job.requirements}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="px-6 py-4 bg-gray-50 border-t">
              <button
                onClick={() => navigate(`/jobs/${job.id}`)}
                className="w-full bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
              >
                <Eye className="w-4 h-4" />
                View Details
              </button>
            </div>
          </div>
        ))}
      </div>

      {jobs.length === 0 && (
        <div className="text-center py-12">
          <h3 className="text-lg font-medium text-gray-900">No open jobs available</h3>
          <p className="text-gray-600 mt-2">There are currently no job postings.</p>
        </div>
      )}

      {/* New Job Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-gray-900">Post New Job</h2>
              <button
                onClick={() => setShowModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
                <AlertCircle className="w-5 h-5" />
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Job Title
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  value={newJob.title}
                  onChange={(e) => setNewJob({ ...newJob, title: e.target.value })}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  rows={4}
                  value={newJob.description}
                  onChange={(e) => setNewJob({ ...newJob, description: e.target.value })}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Requirements (Optional)
                </label>
                <textarea
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  rows={3}
                  value={newJob.requirements}
                  onChange={(e) => setNewJob({ ...newJob, requirements: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Date
                  </label>
                  <input
                    type="date"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newJob.date}
                    onChange={(e) => setNewJob({ ...newJob, date: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Budget (Optional)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                      $
                    </span>
                    <input
                      type="number"
                      className="w-full border border-gray-300 rounded-lg pl-7 pr-3 py-2"
                      value={newJob.budget}
                      onChange={(e) => setNewJob({ ...newJob, budget: e.target.value })}
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Venue
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search venues..."
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={venueSearchTerm}
                    onChange={(e) => {
                      setVenueSearchTerm(e.target.value);
                      setShowVenueSearch(true);
                    }}
                    onFocus={() => setShowVenueSearch(true)}
                  />
                  {showVenueSearch && (
                    <div className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                      {venues
                        .filter(venue => 
                          venue.name.toLowerCase().includes(venueSearchTerm.toLowerCase()) ||
                          venue.address.toLowerCase().includes(venueSearchTerm.toLowerCase())
                        )
                        .map((venue) => (
                          <button
                            key={venue.id}
                            type="button"
                            className="w-full px-4 py-2 text-left hover:bg-gray-50 flex flex-col"
                            onClick={() => selectVenue(venue)}
                          >
                            <span className="font-medium">{venue.name}</span>
                            <span className="text-sm text-gray-500">{venue.address}</span>
                          </button>
                        ))
                      }
                      {venueSearchTerm && (
                        <button
                          type="button"
                          className="w-full px-4 py-2 text-left text-blue-600 hover:bg-gray-50"
                          onClick={() => {
                            setNewJob({
                              ...newJob,
                              venue_id: null,
                              venue_name: venueSearchTerm,
                              venue_address: '',
                            });
                            setShowVenueSearch(false);
                          }}
                        >
                          + Add new venue "{venueSearchTerm}"
                        </button>
                      )}
                    </div>
                  )}
                </div>

                {!newJob.venue_id && (
                  <div className="space-y-2 mt-2">
                    <input
                      type="text"
                      placeholder="Venue name"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      value={newJob.venue_name}
                      onChange={(e) => setNewJob({
                        ...newJob,
                        venue_name: e.target.value,
                      })}
                    />
                    <input
                      type="text"
                      placeholder="Venue address"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      value={newJob.venue_address}
                      onChange={(e) => setNewJob({
                        ...newJob,
                        venue_address: e.target.value,
                      })}
                    />
                  </div>
                )}

                {newJob.venue_id && (
                  <div className="mt-2 p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">{newJob.venue_name}</div>
                        <div className="text-sm text-gray-500">{newJob.venue_address}</div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setNewJob({
                          ...newJob,
                          venue_id: null,
                          venue_name: '',
                          venue_address: '',
                        })}
                        className="text-gray-400 hover:text-gray-600"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )}
              </div>

              <div className="border-t border-gray-200 pt-6">
                <div className="flex items-center gap-4 mb-6">
                  <label className="flex items-center gap-2">
                    <input
                      type="radio"
                      checked={newJob.service_type === 'existing'}
                      onChange={() => setNewJob({ ...newJob, service_type: 'existing' })}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <span className="text-sm font-medium text-gray-700">Use Existing Service</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="radio"
                      checked={newJob.service_type === 'custom'}
                      onChange={() => setNewJob({ ...newJob, service_type: 'custom' })}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <span className="text-sm font-medium text-gray-700">Create Custom Service</span>
                  </label>
                </div>

                {newJob.service_type === 'existing' ? (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Select Service
                      </label>
                      <select
                        className="w-full border border-gray-300 rounded-lg px-3 py-2"
                        value={newJob.service_id}
                        onChange={(e) => setNewJob({ 
                          ...newJob, 
                          service_id: e.target.value,
                          variant_id: ''
                        })}
                        required={newJob.service_type === 'existing'}
                      >
                        <option value="">Choose a service...</option>
                        {services.map((service) => (
                          <option key={service.id} value={service.id}>
                            {service.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    {selectedService && selectedService.variants.length > 0 && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Select Variant
                        </label>
                        <select
                          className="w-full border border-gray-300 rounded-lg px-3 py-2"
                          value={newJob.variant_id}
                          onChange={(e) => setNewJob({ ...newJob, variant_id: e.target.value })}
                        >
                          <option value="">Choose a variant...</option>
                          {selectedService.variants.map((variant) => (
                            <option key={variant.id} value={variant.id}>
                              {variant.name} - ${variant.price} {variant.hours && `(${variant.hours}h)`}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Service Name
                      </label>
                      <input
                        type="text"
                        className="w-full border border-gray-300 rounded-lg px-3 py-2"
                        value={newJob.custom_service_name}
                        onChange={(e) => setNewJob({ ...newJob, custom_service_name: e.target.value })}
                        required={newJob.service_type === 'custom'}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Service Description
                      </label>
                      <textarea
                        className="w-full border border-gray-300 rounded-lg px-3 py-2"
                        rows={3}
                        value={newJob.custom_service_description}
                        onChange={(e) => setNewJob({ ...newJob, custom_service_description: e.target.value })}
                        required={newJob.service_type === 'custom'}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Price
                        </label>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                            $
                          </span>
                          <input
                            type="number"
                            className="w-full border border-gray-300 rounded-lg pl-7 pr-3 py-2"
                            value={newJob.custom_service_price}
                            onChange={(e) => setNewJob({ ...newJob, custom_service_price: e.target.value })}
                            min="0"
                            step="0.01"
                            required={newJob.service_type === 'custom'}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Hours (Optional)
                        </label>
                        <input
                          type="number"
                          className="w-full border border-gray-300 rounded-lg px-3 py-2"
                          value={newJob.custom_service_hours}
                          onChange={(e) => setNewJob({ ...newJob, custom_service_hours: e.target.value })}
                          min="1"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-3 pt-6">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  disabled={saving}
                >
                  {saving ? 'Posting...' : 'Post Job'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}