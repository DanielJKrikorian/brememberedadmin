import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  ArrowLeft, Save, Eye, AlertCircle, CheckCircle, 
  X, Mail, FileText
} from 'lucide-react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import parse from 'html-react-parser';

interface NewsletterTemplate {
  id: string;
  name: string;
  subject: string;
  content: string;
  created_at: string;
  updated_at: string;
}

export default function NewsletterEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [template, setTemplate] = useState<NewsletterTemplate>({
    id: '',
    name: '',
    subject: '',
    content: '',
    created_at: '',
    updated_at: ''
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  
  const quillRef = useRef<ReactQuill>(null);
  
  const isNew = id === 'new';
  
  useEffect(() => {
    if (!isNew) {
      fetchTemplate();
    } else {
      setTemplate({
        id: '',
        name: '',
        subject: '',
        content: getDefaultTemplate(),
        created_at: '',
        updated_at: ''
      });
      setLoading(false);
    }
  }, [id]);
  
  async function fetchTemplate() {
    try {
      const { data, error } = await supabase
        .from('newsletter_templates')
        .select('*')
        .eq('id', id)
        .single();
        
      if (error) throw error;
      setTemplate(data);
    } catch (err) {
      console.error('Error fetching newsletter template:', err);
      setError('Failed to load newsletter template');
    } finally {
      setLoading(false);
    }
  }
  
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSuccess(null);
    
    try {
      if (isNew) {
        // Create new template
        const { data, error } = await supabase
          .from('newsletter_templates')
          .insert({
            name: template.name,
            subject: template.subject,
            content: template.content
          })
          .select()
          .single();
          
        if (error) throw error;
        
        setTemplate(data);
        setSuccess('Template created successfully');
        setTimeout(() => {
          navigate(`/newsletters/templates/${data.id}`);
        }, 1500);
      } else {
        // Update existing template
        const { error } = await supabase
          .from('newsletter_templates')
          .update({
            name: template.name,
            subject: template.subject,
            content: template.content
          })
          .eq('id', id);
          
        if (error) throw error;
        
        setSuccess('Template updated successfully');
      }
    } catch (err) {
      console.error('Error saving newsletter template:', err);
      setError('Failed to save newsletter template');
    } finally {
      setSaving(false);
    }
  }
  
  function getDefaultTemplate() {
    return `
      <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #333333; line-height: 1.5;">
        <div style="text-align: center; margin-bottom: 30px;">
          <img src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png" alt="B. Remembered Logo" style="max-width: 200px; height: auto;">
          <p style="margin-top: 15px; font-size: 12px; letter-spacing: 3px; color: #666666; text-transform: uppercase;">• W E D D I N G S •</p>
        </div>
        
        <h1 style="color: #333333; font-size: 28px; margin-bottom: 25px; text-align: center; font-weight: normal;">Your Newsletter Title</h1>
        
        <p style="margin-bottom: 20px; font-size: 16px;">Hello {{name}},</p>
        
        <p style="margin-bottom: 25px; font-size: 16px;">Welcome to our newsletter! We're excited to share the latest updates and inspiration for your special day.</p>
        
        <div style="background-color: #f8f8f8; padding: 25px; border-radius: 6px; margin-bottom: 30px;">
          <h2 style="color: #333333; font-size: 20px; margin-bottom: 15px; font-weight: normal; border-bottom: 1px solid #eeeeee; padding-bottom: 10px;">Featured Section</h2>
          <p style="margin-bottom: 15px; font-size: 16px;">This is a highlighted section where you can showcase important information or special offers.</p>
          <a href="#" style="display: inline-block; background-color: #9e8a78; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-size: 15px;">Learn More</a>
        </div>
        
        <h2 style="color: #333333; font-size: 20px; margin-bottom: 20px; font-weight: normal; border-bottom: 1px solid #eeeeee; padding-bottom: 10px;">Latest Updates</h2>
        
        <ul style="padding-left: 20px; margin-bottom: 30px;">
          <li style="margin-bottom: 15px; font-size: 16px;">Update item 1 - Add your content here</li>
          <li style="margin-bottom: 15px; font-size: 16px;">Update item 2 - Add your content here</li>
          <li style="margin-bottom: 15px; font-size: 16px;">Update item 3 - Add your content here</li>
        </ul>
        
        <div style="background-color: #f8f8f8; padding: 25px; border-radius: 6px; margin-bottom: 30px;">
          <h2 style="color: #333333; font-size: 20px; margin-bottom: 15px; font-weight: normal; border-bottom: 1px solid #eeeeee; padding-bottom: 10px;">Upcoming Events</h2>
          <div style="margin-bottom: 15px;">
            <p style="margin-bottom: 5px; font-weight: bold; font-size: 16px;">Wedding Expo 2025</p>
            <p style="margin-bottom: 5px; font-size: 15px;">June 15-16, 2025 • Convention Center</p>
            <p style="font-size: 15px;">Join us for the largest wedding expo of the year featuring top vendors and the latest trends.</p>
          </div>
          <div>
            <p style="margin-bottom: 5px; font-weight: bold; font-size: 16px;">Bridal Showcase</p>
            <p style="margin-bottom: 5px; font-size: 15px;">July 8, 2025 • Grand Hotel</p>
            <p style="font-size: 15px;">An intimate gathering showcasing this season's bridal collections.</p>
          </div>
        </div>
        
        <div style="text-align: center; margin-top: 40px; margin-bottom: 20px;">
          <a href="#" style="display: inline-block; margin: 0 10px; text-decoration: none;">
            <img src="https://cdn-icons-png.flaticon.com/512/733/733547.png" alt="Facebook" style="width: 32px; height: 32px;">
          </a>
          <a href="#" style="display: inline-block; margin: 0 10px; text-decoration: none;">
            <img src="https://cdn-icons-png.flaticon.com/512/2111/2111463.png" alt="Instagram" style="width: 32px; height: 32px;">
          </a>
          <a href="#" style="display: inline-block; margin: 0 10px; text-decoration: none;">
            <img src="https://cdn-icons-png.flaticon.com/512/733/733579.png" alt="Twitter" style="width: 32px; height: 32px;">
          </a>
        </div>
        
        <div style="border-top: 1px solid #eeeeee; padding-top: 20px; margin-top: 30px; text-align: center; font-size: 14px; color: #777777;">
          <p>© 2025 B. Remembered Weddings. All rights reserved.</p>
          <p style="margin-top: 10px;">
            <a href="{{unsubscribe_url}}" style="color: #777777; text-decoration: underline;">Unsubscribe</a> | 
            <a href="#" style="color: #777777; text-decoration: underline;">View in Browser</a> | 
            <a href="#" style="color: #777777; text-decoration: underline;">Privacy Policy</a>
          </p>
          <p style="margin-top: 15px; font-size: 12px; color: #999999;">
            123 Wedding Lane, Suite 101, Celebration City, CA 90210
          </p>
        </div>
      </div>
    `;
  }
  
  const modules = {
    toolbar: [
      [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      [{ 'color': [] }, { 'background': [] }],
      [{ 'align': [] }],
      ['link', 'image'],
      ['clean']
    ],
  };
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  
  return (
    <div className="p-6 w-full">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/newsletters')}
            className="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-gray-100"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            {isNew ? 'Create Newsletter Template' : 'Edit Newsletter Template'}
          </h1>
        </div>
        
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowPreview(!showPreview)}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600"
          >
            <Eye className="w-5 h-5" />
            {showPreview ? 'Hide Preview' : 'Preview'}
          </button>
        </div>
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700 dark:bg-red-900/30 dark:border-red-800 dark:text-red-400">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}
      
      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700 dark:bg-green-900/30 dark:border-green-800 dark:text-green-400">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className={showPreview ? 'hidden lg:block' : ''}>
          <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6 dark:bg-gray-800">
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                  Template Name
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  value={template.name}
                  onChange={(e) => setTemplate({ ...template, name: e.target.value })}
                  placeholder="e.g., Monthly Newsletter"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                  Email Subject
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  value={template.subject}
                  onChange={(e) => setTemplate({ ...template, subject: e.target.value })}
                  placeholder="e.g., Your Monthly Wedding Planning Update"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                  Email Content
                </label>
                <div className="border border-gray-300 rounded-lg dark:border-gray-600">
                  <ReactQuill
                    ref={quillRef}
                    theme="snow"
                    value={template.content}
                    onChange={(content) => setTemplate({ ...template, content })}
                    modules={modules}
                    className="h-96 dark:text-white"
                  />
                </div>
                <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                  Use <code>{'{{name}}'}</code> to personalize with recipient's name and <code>{'{{unsubscribe_url}}'}</code> for the unsubscribe link.
                </p>
              </div>
            </div>
            
            <div className="mt-6 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => navigate('/newsletters')}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 dark:bg-blue-700 dark:hover:bg-blue-600"
                disabled={saving}
              >
                <Save className="w-5 h-5" />
                {saving ? 'Saving...' : (isNew ? 'Create Template' : 'Save Changes')}
              </button>
            </div>
          </form>
        </div>
        
        {showPreview && (
          <div className={!showPreview ? 'hidden lg:block' : 'lg:col-span-2 xl:col-span-1'}>
            <div className="bg-white rounded-lg shadow-md p-6 dark:bg-gray-800">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Preview</h2>
                <button
                  onClick={() => setShowPreview(false)}
                  className="text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400 lg:hidden"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-4 dark:border-gray-700">
                <div className="flex items-center gap-2 mb-2 text-sm text-gray-500 dark:text-gray-400">
                  <Mail className="w-4 h-4" />
                  <span>From: B. Remembered Weddings</span>
                </div>
                <div className="flex items-center gap-2 mb-2 text-sm text-gray-500 dark:text-gray-400">
                  <FileText className="w-4 h-4" />
                  <span>Subject: {template.subject}</span>
                </div>
                <div className="border-t border-gray-200 pt-4 mt-4 dark:border-gray-700">
                  <div className="prose max-w-none dark:prose-invert">
                    {parse(template.content)}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}