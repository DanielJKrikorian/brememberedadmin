import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  PlusCircle, Search, Filter, Mail, User, Building2, 
  MapPin, Calendar, AlertCircle, CheckCircle, X, 
  Upload, Download, FileText, Trash2
} from 'lucide-react';
import * as Papa from 'papaparse';

interface NewsletterSubscriber {
  id: string;
  email: string;
  name: string | null;
  type: 'lead' | 'vendor' | 'venue';
  status: 'subscribed' | 'unsubscribed';
  unsubscribed_at: string | null;
  created_at: string;
  updated_at: string;
  lead_id: string | null;
  vendor_id: string | null;
  venue_id: string | null;
  lead?: {
    name: string;
  };
  vendor?: {
    name: string;
  };
  venue?: {
    name: string;
  };
}

interface Lead {
  id: string;
  name: string;
  email: string;
}

interface Vendor {
  id: string;
  name: string;
  email: string;
}

interface Venue {
  id: string;
  name: string;
  contact_email: string;
}

export default function NewsletterSubscribers() {
  const navigate = useNavigate();
  const [subscribers, setSubscribers] = useState<NewsletterSubscriber[]>([]);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [venues, setVenues] = useState<Venue[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'lead' | 'vendor' | 'venue'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'subscribed' | 'unsubscribed'>('all');
  
  // Add subscriber modal state
  const [showAddModal, setShowAddModal] = useState(false);
  const [newSubscriberEmail, setNewSubscriberEmail] = useState('');
  const [newSubscriberName, setNewSubscriberName] = useState('');
  const [newSubscriberType, setNewSubscriberType] = useState<'lead' | 'vendor' | 'venue'>('lead');
  const [newSubscriberEntityId, setNewSubscriberEntityId] = useState('');
  
  // Import modal state
  const [showImportModal, setShowImportModal] = useState(false);
  const [importType, setImportType] = useState<'lead' | 'vendor' | 'venue'>('lead');
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importProgress, setImportProgress] = useState(0);
  const [importing, setImporting] = useState(false);
  
  // Delete confirmation modal state
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [subscriberToDelete, setSubscriberToDelete] = useState<string | null>(null);
  
  // Bulk action modal state
  const [showBulkActionModal, setShowBulkActionModal] = useState(false);
  const [selectedSubscribers, setSelectedSubscribers] = useState<string[]>([]);
  const [bulkAction, setBulkAction] = useState<'subscribe' | 'unsubscribe'>('subscribe');
  
  useEffect(() => {
    Promise.all([
      fetchSubscribers(),
      fetchLeads(),
      fetchVendors(),
      fetchVenues()
    ]).finally(() => setLoading(false));
  }, []);
  
  async function fetchSubscribers() {
    try {
      const { data, error } = await supabase
        .from('newsletter_subscribers')
        .select(`
          *,
          lead:leads(name),
          vendor:vendors(name),
          venue:venues(name)
        `)
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      setSubscribers(data || []);
    } catch (err) {
      console.error('Error fetching newsletter subscribers:', err);
      setError('Failed to load newsletter subscribers');
    }
  }
  
  async function fetchLeads() {
    try {
      const { data, error } = await supabase
        .from('leads')
        .select('id, name, email')
        .order('name');
        
      if (error) throw error;
      setLeads(data || []);
    } catch (err) {
      console.error('Error fetching leads:', err);
    }
  }
  
  async function fetchVendors() {
    try {
      const { data, error } = await supabase
        .from('vendors')
        .select('id, name, email')
        .order('name');
        
      if (error) throw error;
      setVendors(data || []);
    } catch (err) {
      console.error('Error fetching vendors:', err);
    }
  }
  
  async function fetchVenues() {
    try {
      const { data, error } = await supabase
        .from('venues')
        .select('id, name, contact_email')
        .order('name');
        
      if (error) throw error;
      setVenues(data || []);
    } catch (err) {
      console.error('Error fetching venues:', err);
    }
  }
  
  async function handleAddSubscriber() {
    try {
      // Check if subscriber already exists
      const { data: existingSubscriber } = await supabase
        .from('newsletter_subscribers')
        .select('id')
        .eq('email', newSubscriberEmail)
        .maybeSingle();
        
      if (existingSubscriber) {
        // Update existing subscriber
        const { error } = await supabase
          .from('newsletter_subscribers')
          .update({
            name: newSubscriberName,
            type: newSubscriberType,
            lead_id: newSubscriberType === 'lead' ? newSubscriberEntityId : null,
            vendor_id: newSubscriberType === 'vendor' ? newSubscriberEntityId : null,
            venue_id: newSubscriberType === 'venue' ? newSubscriberEntityId : null,
            status: 'subscribed',
            unsubscribed_at: null
          })
          .eq('id', existingSubscriber.id);
          
        if (error) throw error;
      } else {
        // Create new subscriber
        const { error } = await supabase
          .from('newsletter_subscribers')
          .insert({
            email: newSubscriberEmail,
            name: newSubscriberName,
            type: newSubscriberType,
            lead_id: newSubscriberType === 'lead' ? newSubscriberEntityId : null,
            vendor_id: newSubscriberType === 'vendor' ? newSubscriberEntityId : null,
            venue_id: newSubscriberType === 'venue' ? newSubscriberEntityId : null,
            status: 'subscribed'
          });
          
        if (error) throw error;
      }
      
      // Refresh subscribers
      fetchSubscribers();
      
      // Reset form and close modal
      setNewSubscriberEmail('');
      setNewSubscriberName('');
      setNewSubscriberType('lead');
      setNewSubscriberEntityId('');
      setShowAddModal(false);
      
      // Show success message
      setSuccess('Subscriber added successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error adding subscriber:', err);
      setError('Failed to add subscriber');
    }
  }
  
  async function handleImportSubscribers() {
    if (!importFile) return;
    
    setImporting(true);
    setImportProgress(0);
    
    try {
      Papa.parse(importFile, {
        header: true,
        skipEmptyLines: true,
        complete: async (results) => {
          const subscribers = results.data as { email: string; name?: string }[];
          const totalSubscribers = subscribers.length;
          let processedCount = 0;
          
          // Process subscribers in batches
          const batchSize = 10;
          for (let i = 0; i < subscribers.length; i += batchSize) {
            const batch = subscribers.slice(i, i + batchSize);
            
            // Check which subscribers already exist
            const emails = batch.map(s => s.email);
            const { data: existingSubscribers } = await supabase
              .from('newsletter_subscribers')
              .select('email')
              .in('email', emails);
              
            const existingEmails = new Set(existingSubscribers?.map(s => s.email) || []);
            
            // Prepare new subscribers
            const newSubscribers = batch
              .filter(s => !existingEmails.has(s.email))
              .map(s => ({
                email: s.email,
                name: s.name || null,
                type: importType,
                status: 'subscribed'
              }));
              
            // Insert new subscribers
            if (newSubscribers.length > 0) {
              const { error } = await supabase
                .from('newsletter_subscribers')
                .insert(newSubscribers);
                
              if (error) throw error;
            }
            
            // Update progress
            processedCount += batch.length;
            setImportProgress(Math.round((processedCount / totalSubscribers) * 100));
          }
          
          // Refresh subscribers
          fetchSubscribers();
          
          // Reset form and close modal
          setImportFile(null);
          setImportType('lead');
          setShowImportModal(false);
          setImporting(false);
          
          // Show success message
          setSuccess(`${totalSubscribers} subscribers imported successfully`);
          setTimeout(() => setSuccess(null), 3000);
        },
        error: (error) => {
          throw new Error(error.message);
        }
      });
    } catch (err) {
      console.error('Error importing subscribers:', err);
      setError('Failed to import subscribers');
      setImporting(false);
    }
  }
  
  async function handleDeleteSubscriber() {
    if (!subscriberToDelete) return;
    
    try {
      const { error } = await supabase
        .from('newsletter_subscribers')
        .delete()
        .eq('id', subscriberToDelete);
        
      if (error) throw error;
      
      // Refresh subscribers
      fetchSubscribers();
      
      // Reset state and close modal
      setSubscriberToDelete(null);
      setShowDeleteConfirm(false);
      
      // Show success message
      setSuccess('Subscriber deleted successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error deleting subscriber:', err);
      setError('Failed to delete subscriber');
    }
  }
  
  async function handleBulkAction() {
    if (selectedSubscribers.length === 0) return;
    
    try {
      const { error } = await supabase
        .from('newsletter_subscribers')
        .update({
          status: bulkAction === 'subscribe' ? 'subscribed' : 'unsubscribed',
          unsubscribed_at: bulkAction === 'unsubscribe' ? new Date().toISOString() : null
        })
        .in('id', selectedSubscribers);
        
      if (error) throw error;
      
      // Refresh subscribers
      fetchSubscribers();
      
      // Reset state and close modal
      setSelectedSubscribers([]);
      setShowBulkActionModal(false);
      
      // Show success message
      setSuccess(`${selectedSubscribers.length} subscribers ${bulkAction === 'subscribe' ? 'subscribed' : 'unsubscribed'} successfully`);
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error performing bulk action:', err);
      setError('Failed to perform bulk action');
    }
  }
  
  function handleExportSubscribers() {
    // Filter subscribers based on current filters
    const filteredSubscribers = subscribers.filter(subscriber => {
      const matchesType = typeFilter === 'all' || subscriber.type === typeFilter;
      const matchesStatus = statusFilter === 'all' || subscriber.status === statusFilter;
      return matchesType && matchesStatus;
    });
    
    // Convert to CSV
    const csv = Papa.unparse(filteredSubscribers.map(subscriber => ({
      email: subscriber.email,
      name: subscriber.name || '',
      type: subscriber.type,
      status: subscriber.status,
      created_at: subscriber.created_at
    })));
    
    // Create download link
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `newsletter_subscribers_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
  
  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) {
      setImportFile(file);
    }
  }
  
  function handleSelectAllSubscribers(checked: boolean) {
    if (checked) {
      // Filter subscribers based on current filters
      const filteredSubscribers = subscribers.filter(subscriber => {
        const matchesType = typeFilter === 'all' || subscriber.type === typeFilter;
        const matchesStatus = statusFilter === 'all' || subscriber.status === statusFilter;
        const matchesSearch = searchTerm === '' || 
          subscriber.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (subscriber.name && subscriber.name.toLowerCase().includes(searchTerm.toLowerCase()));
        return matchesType && matchesStatus && matchesSearch;
      });
      
      setSelectedSubscribers(filteredSubscribers.map(s => s.id));
    } else {
      setSelectedSubscribers([]);
    }
  }
  
  function handleSelectSubscriber(subscriberId: string, checked: boolean) {
    if (checked) {
      setSelectedSubscribers([...selectedSubscribers, subscriberId]);
    } else {
      setSelectedSubscribers(selectedSubscribers.filter(id => id !== subscriberId));
    }
  }
  
  // Filter subscribers based on search term, type filter, and status filter
  const filteredSubscribers = subscribers.filter(subscriber => {
    const matchesSearch = searchTerm === '' || 
      subscriber.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (subscriber.name && subscriber.name.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesType = typeFilter === 'all' || subscriber.type === typeFilter;
    const matchesStatus = statusFilter === 'all' || subscriber.status === statusFilter;
    return matchesSearch && matchesType && matchesStatus;
  });
  
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Newsletter Subscribers</h1>
        
        <div className="flex gap-2">
          <button
            onClick={() => setShowImportModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600"
          >
            <Upload className="w-5 h-5" />
            Import
          </button>
          <button
            onClick={handleExportSubscribers}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600"
          >
            <Download className="w-5 h-5" />
            Export
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <PlusCircle className="w-5 h-5" />
            Add Subscriber
          </button>
        </div>
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700 dark:bg-red-900/30 dark:border-red-800 dark:text-red-400">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}
      
      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700 dark:bg-green-900/30 dark:border-green-800 dark:text-green-400">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}
      
      <div className="mb-6 flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search subscribers..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-800 dark:text-white"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <div className="flex gap-4">
          <select
            className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-800 dark:text-white"
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value as any)}
          >
            <option value="all">All Types</option>
            <option value="lead">Leads</option>
            <option value="vendor">Vendors</option>
            <option value="venue">Venues</option>
          </select>
          <select
            className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-800 dark:text-white"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
          >
            <option value="all">All Status</option>
            <option value="subscribed">Subscribed</option>
            <option value="unsubscribed">Unsubscribed</option>
          </select>
        </div>
      </div>
      
      {selectedSubscribers.length > 0 && (
        <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg flex items-center justify-between dark:bg-blue-900/20 dark:border-blue-800">
          <div className="flex items-center gap-2 text-blue-700 dark:text-blue-300">
            <CheckCircle className="w-5 h-5" />
            <span>{selectedSubscribers.length} subscribers selected</span>
          </div>
          <button
            onClick={() => setShowBulkActionModal(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Bulk Actions
          </button>
        </div>
      )}
      
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-md overflow-hidden dark:bg-gray-800">
          {filteredSubscribers.length === 0 ? (
            <div className="p-8 text-center">
              <Mail className="w-12 h-12 text-gray-400 mx-auto mb-4 dark:text-gray-500" />
              <h3 className="text-lg font-medium text-gray-900 mb-2 dark:text-white">No Subscribers Found</h3>
              <p className="text-gray-500 dark:text-gray-400">
                {searchTerm || typeFilter !== 'all' || statusFilter !== 'all'
                  ? 'Try adjusting your filters'
                  : 'Get started by adding your first subscriber'}
              </p>
              <button
                onClick={() => setShowAddModal(true)}
                className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Add Subscriber
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-700">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-gray-600"
                          checked={selectedSubscribers.length === filteredSubscribers.length && filteredSubscribers.length > 0}
                          onChange={(e) => handleSelectAllSubscribers(e.target.checked)}
                        />
                      </div>
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Email</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Name</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Type</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Subscribed Since</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-700">
                  {filteredSubscribers.map(subscriber => (
                    <tr key={subscriber.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <input
                          type="checkbox"
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-gray-600"
                          checked={selectedSubscribers.includes(subscriber.id)}
                          onChange={(e) => handleSelectSubscriber(subscriber.id, e.target.checked)}
                        />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <Mail className="w-5 h-5 text-gray-400 mr-3 dark:text-gray-500" />
                          <span className="text-sm text-gray-900 dark:text-white">{subscriber.email}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="text-sm text-gray-900 dark:text-white">
                          {subscriber.name || (
                            subscriber.type === 'lead' ? subscriber.lead?.name :
                            subscriber.type === 'vendor' ? subscriber.vendor?.name :
                            subscriber.venue?.name
                          ) || '-'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          subscriber.type === 'lead' 
                            ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400' 
                            : subscriber.type === 'vendor'
                            ? 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400'
                            : 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
                        }`}>
                          {subscriber.type === 'lead' ? (
                            <User className="w-3 h-3 mr-1" />
                          ) : subscriber.type === 'vendor' ? (
                            <Building2 className="w-3 h-3 mr-1" />
                          ) : (
                            <MapPin className="w-3 h-3 mr-1" />
                          )}
                          {subscriber.type.charAt(0).toUpperCase() + subscriber.type.slice(1)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          subscriber.status === 'subscribed' 
                            ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' 
                            : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                        }`}>
                          {subscriber.status.charAt(0).toUpperCase() + subscriber.status.slice(1)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                          <Calendar className="w-4 h-4 mr-2" />
                          {new Date(subscriber.created_at).toLocaleDateString()}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button
                          onClick={() => {
                            setSubscriberToDelete(subscriber.id);
                            setShowDeleteConfirm(true);
                          }}
                          className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
      
      {/* Add Subscriber Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full dark:bg-gray-800">
            <h2 className="text-xl font-bold text-gray-900 mb-4 dark:text-white">Add Subscriber</h2>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                  Email *
                </label>
                <input
                  type="email"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  value={newSubscriberEmail}
                  onChange={(e) => setNewSubscriberEmail(e.target.value)}
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                  Name
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  value={newSubscriberName}
                  onChange={(e) => setNewSubscriberName(e.target.value)}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                  Type *
                </label>
                <select
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  value={newSubscriberType}
                  onChange={(e) => {
                    setNewSubscriberType(e.target.value as any);
                    setNewSubscriberEntityId('');
                  }}
                  required
                >
                  <option value="lead">Lead</option>
                  <option value="vendor">Vendor</option>
                  <option value="venue">Venue</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                  {newSubscriberType === 'lead' ? 'Lead' : newSubscriberType === 'vendor' ? 'Vendor' : 'Venue'}
                </label>
                <select
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  value={newSubscriberEntityId}
                  onChange={(e) => {
                    setNewSubscriberEntityId(e.target.value);
                    
                    // Auto-fill email and name if entity is selected
                    if (newSubscriberType === 'lead') {
                      const lead = leads.find(l => l.id === e.target.value);
                      if (lead) {
                        setNewSubscriberEmail(lead.email);
                        setNewSubscriberName(lead.name);
                      }
                    } else if (newSubscriberType === 'vendor') {
                      const vendor = vendors.find(v => v.id === e.target.value);
                      if (vendor) {
                        setNewSubscriberEmail(vendor.email);
                        setNewSubscriberName(vendor.name);
                      }
                    } else if (newSubscriberType === 'venue') {
                      const venue = venues.find(v => v.id === e.target.value);
                      if (venue) {
                        setNewSubscriberEmail(venue.contact_email);
                        setNewSubscriberName(venue.name);
                      }
                    }
                  }}
                >
                  <option value="">Select {newSubscriberType === 'lead' ? 'a lead' : newSubscriberType === 'vendor' ? 'a vendor' : 'a venue'}</option>
                  {newSubscriberType === 'lead' && leads.map(lead => (
                    <option key={lead.id} value={lead.id}>{lead.name} ({lead.email})</option>
                  ))}
                  {newSubscriberType === 'vendor' && vendors.map(vendor => (
                    <option key={vendor.id} value={vendor.id}>{vendor.name} ({vendor.email})</option>
                  ))}
                  {newSubscriberType === 'venue' && venues.map(venue => (
                    <option key={venue.id} value={venue.id}>{venue.name} ({venue.contact_email})</option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700"
              >
                Cancel
              </button>
              <button
                onClick={handleAddSubscriber}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600"
                disabled={!newSubscriberEmail}
              >
                Add Subscriber
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Import Modal */}
      {showImportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full dark:bg-gray-800">
            <h2 className="text-xl font-bold text-gray-900 mb-4 dark:text-white">Import Subscribers</h2>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                  Subscriber Type
                </label>
                <select
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  value={importType}
                  onChange={(e) => setImportType(e.target.value as any)}
                  required
                >
                  <option value="lead">Lead</option>
                  <option value="vendor">Vendor</option>
                  <option value="venue">Venue</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                  CSV File
                </label>
                <div className="border border-gray-300 rounded-lg p-4 dark:border-gray-600">
                  <div className="flex items-center justify-center">
                    <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 dark:border-gray-600 dark:hover:bg-gray-700">
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        <FileText className="w-10 h-10 text-gray-400 mb-3 dark:text-gray-500" />
                        <p className="mb-2 text-sm text-gray-500 dark:text-gray-400">
                          <span className="font-semibold">Click to upload</span> or drag and drop
                        </p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">CSV file with email and name columns</p>
                      </div>
                      <input 
                        type="file" 
                        className="hidden" 
                        accept=".csv" 
                        onChange={handleFileChange}
                      />
                    </label>
                  </div>
                  
                  {importFile && (
                    <div className="mt-4 flex items-center justify-between">
                      <div className="flex items-center">
                        <FileText className="w-5 h-5 text-gray-400 mr-2 dark:text-gray-500" />
                        <span className="text-sm text-gray-900 dark:text-white">{importFile.name}</span>
                      </div>
                      <button
                        onClick={() => setImportFile(null)}
                        className="text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  )}
                </div>
                
                <div className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                  <p>CSV file should have the following columns:</p>
                  <ul className="list-disc list-inside mt-1">
                    <li>email (required)</li>
                    <li>name (optional)</li>
                  </ul>
                </div>
              </div>
              
              {importing && (
                <div className="mt-4">
                  <div className="flex justify-between text-sm text-gray-600 mb-1 dark:text-gray-400">
                    <span>Importing...</span>
                    <span>{importProgress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2 dark:bg-gray-700">
                    <div
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${importProgress}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
            
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowImportModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700"
              >
                Cancel
              </button>
              <button
                onClick={handleImportSubscribers}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600"
                disabled={!importFile || importing}
              >
                {importing ? 'Importing...' : 'Import'}
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full dark:bg-gray-800">
            <h2 className="text-xl font-bold text-gray-900 mb-4 dark:text-white">Delete Subscriber</h2>
            <p className="text-gray-600 mb-6 dark:text-gray-300">
              Are you sure you want to delete this subscriber? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowDeleteConfirm(false);
                  setSubscriberToDelete(null);
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteSubscriber}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 dark:bg-red-700 dark:hover:bg-red-600"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Bulk Action Modal */}
      {showBulkActionModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full dark:bg-gray-800">
            <h2 className="text-xl font-bold text-gray-900 mb-4 dark:text-white">Bulk Action</h2>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                  Action
                </label>
                <select
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  value={bulkAction}
                  onChange={(e) => setBulkAction(e.target.value as any)}
                  required
                >
                  <option value="subscribe">Subscribe</option>
                  <option value="unsubscribe">Unsubscribe</option>
                </select>
              </div>
              
              <div className="bg-blue-50 p-4 rounded-lg dark:bg-blue-900/20">
                <p className="text-sm text-blue-800 dark:text-blue-300">
                  This action will be applied to {selectedSubscribers.length} selected subscribers.
                </p>
              </div>
            </div>
            
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowBulkActionModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700"
              >
                Cancel
              </button>
              <button
                onClick={handleBulkAction}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600"
              >
                Apply to {selectedSubscribers.length} Subscribers
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}