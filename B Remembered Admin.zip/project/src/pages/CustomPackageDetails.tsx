import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  ArrowLeft, Package, User, Calendar, Building2, Clock, 
  DollarSign, CheckCircle, XCircle, AlertCircle, FileText,
  MessageSquare, Send
} from 'lucide-react';

interface CustomPackageOption {
  id: string;
  name: string;
  description: string | null;
  type: 'hour' | 'addon' | 'feature';
  price: number;
  quantity: number;
}

interface CustomPackage {
  id: string;
  lead_id: string;
  service_id: string;
  template_id: string | null;
  name: string;
  description: string | null;
  hours: number;
  total_price: number;
  status: 'draft' | 'submitted' | 'approved' | 'rejected';
  created_at: string;
  updated_at: string;
  lead: {
    name: string;
    email: string;
    phone: string;
    wedding_date: string | null;
  };
  service: {
    name: string;
    description: string;
    vendor_services: Array<{
      vendor: {
        name: string;
        email: string;
      };
    }>;
  };
  template: {
    name: string;
    description: string | null;
  } | null;
  selections: CustomPackageOption[];
}

export default function CustomPackageDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [customPackage, setCustomPackage] = useState<CustomPackage | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showApproveConfirm, setShowApproveConfirm] = useState(false);
  const [showRejectConfirm, setShowRejectConfirm] = useState(false);
  const [showQuoteModal, setShowQuoteModal] = useState(false);
  const [quoteAmount, setQuoteAmount] = useState(0);
  const [quoteDescription, setQuoteDescription] = useState('');
  const [saving, setSaving] = useState(false);
  
  useEffect(() => {
    if (id) {
      fetchCustomPackage();
    }
  }, [id]);
  
  async function fetchCustomPackage() {
    try {
      // Fetch the custom package
      const { data: packageData, error: packageError } = await supabase
        .from('custom_packages')
        .select(`
          *,
          lead:leads(name, email, phone, wedding_date),
          service:services(
            name, 
            description,
            vendor_services(vendor:vendors(name, email))
          ),
          template:custom_package_templates(name, description)
        `)
        .eq('id', id)
        .single();
        
      if (packageError) throw packageError;
      
      // Fetch the package selections with option details
      const { data: selectionsData, error: selectionsError } = await supabase
        .from('custom_package_selections')
        .select(`
          quantity,
          price,
          option:custom_package_options(
            id,
            name,
            description,
            type,
            price
          )
        `)
        .eq('package_id', id);
        
      if (selectionsError) throw selectionsError;
      
      // Format the selections data
      const formattedSelections = selectionsData.map(selection => ({
        id: selection.option.id,
        name: selection.option.name,
        description: selection.option.description,
        type: selection.option.type,
        price: selection.option.price,
        quantity: selection.quantity
      }));
      
      // Set the custom package with selections
      setCustomPackage({
        ...packageData,
        selections: formattedSelections
      });
      
      // Initialize quote amount with package total price
      setQuoteAmount(packageData.total_price);
      setQuoteDescription(`Custom package: ${packageData.name}`);
    } catch (err) {
      console.error('Error fetching custom package:', err);
      setError('Failed to load custom package details');
    } finally {
      setLoading(false);
    }
  }
  
  async function handleStatusUpdate(status: 'approved' | 'rejected') {
    if (!customPackage) return;
    
    setSaving(true);
    try {
      const { error } = await supabase
        .from('custom_packages')
        .update({ status })
        .eq('id', customPackage.id);
        
      if (error) throw error;
      
      // Update local state
      setCustomPackage({
        ...customPackage,
        status
      });
      
      // Close modals
      setShowApproveConfirm(false);
      setShowRejectConfirm(false);
    } catch (err) {
      console.error('Error updating package status:', err);
      setError('Failed to update package status');
    } finally {
      setSaving(false);
    }
  }
  
  async function handleCreateQuote() {
    if (!customPackage) return;
    
    setSaving(true);
    try {
      // Create a new quote
      const { data: quote, error: quoteError } = await supabase
        .from('quotes')
        .insert({
          lead_id: customPackage.lead_id,
          vendor_id: customPackage.service.vendor_services[0]?.vendor?.id || null,
          amount: quoteAmount,
          description: quoteDescription,
          status: 'pending',
          expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days from now
          custom_package_id: customPackage.id
        })
        .select()
        .single();
        
      if (quoteError) throw quoteError;
      
      // Update package status to approved
      await handleStatusUpdate('approved');
      
      // Close modal
      setShowQuoteModal(false);
      
      // Navigate to the quote
      navigate(`/quotes/${quote.id}`);
    } catch (err) {
      console.error('Error creating quote:', err);
      setError('Failed to create quote');
    } finally {
      setSaving(false);
    }
  }
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  
  if (!customPackage) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-700">Custom package not found</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/custom-packages')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Custom Package Details</h1>
        </div>
        
        <div className="flex items-center gap-2">
          {customPackage.status === 'submitted' && (
            <>
              <button
                onClick={() => setShowApproveConfirm(true)}
                className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                <CheckCircle className="w-5 h-5" />
                Approve
              </button>
              <button
                onClick={() => setShowRejectConfirm(true)}
                className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                <XCircle className="w-5 h-5" />
                Reject
              </button>
            </>
          )}
          
          {customPackage.status === 'approved' && (
            <button
              onClick={() => setShowQuoteModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <FileText className="w-5 h-5" />
              Create Quote
            </button>
          )}
        </div>
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          {/* Package Details */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h2 className="text-xl font-semibold text-gray-900">{customPackage.name}</h2>
                <div className="flex items-center mt-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    customPackage.status === 'draft' ? 'bg-gray-100 text-gray-800' :
                    customPackage.status === 'submitted' ? 'bg-blue-100 text-blue-800' :
                    customPackage.status === 'approved' ? 'bg-green-100 text-green-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {customPackage.status.charAt(0).toUpperCase() + customPackage.status.slice(1)}
                  </span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-gray-900">${customPackage.total_price.toFixed(2)}</div>
                <div className="text-sm text-gray-500">Total Package Price</div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-2">Service</h3>
                <div className="flex items-start gap-3">
                  <Package className="w-5 h-5 text-gray-400 mt-0.5" />
                  <div>
                    <div className="font-medium text-gray-900">{customPackage.service.name}</div>
                    <div className="text-sm text-gray-500">{customPackage.service.description}</div>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-2">Vendor</h3>
                {customPackage.service.vendor_services[0]?.vendor ? (
                  <div className="flex items-start gap-3">
                    <Building2 className="w-5 h-5 text-gray-400 mt-0.5" />
                    <div>
                      <div className="font-medium text-gray-900">
                        {customPackage.service.vendor_services[0].vendor.name}
                      </div>
                      <div className="text-sm text-gray-500">
                        {customPackage.service.vendor_services[0].vendor.email}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-gray-500">No vendor assigned</div>
                )}
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-2">Customer</h3>
                <div className="flex items-start gap-3">
                  <User className="w-5 h-5 text-gray-400 mt-0.5" />
                  <div>
                    <div className="font-medium text-gray-900">{customPackage.lead.name}</div>
                    <div className="text-sm text-gray-500">{customPackage.lead.email}</div>
                    {customPackage.lead.phone && (
                      <div className="text-sm text-gray-500">{customPackage.lead.phone}</div>
                    )}
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-2">Event Details</h3>
                {customPackage.lead.wedding_date ? (
                  <div className="flex items-start gap-3">
                    <Calendar className="w-5 h-5 text-gray-400 mt-0.5" />
                    <div>
                      <div className="font-medium text-gray-900">
                        {new Date(customPackage.lead.wedding_date).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-gray-500">No event date specified</div>
                )}
              </div>
            </div>
            
            {customPackage.template && (
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-700 mb-2">Template</h3>
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="font-medium text-gray-900">{customPackage.template.name}</div>
                  {customPackage.template.description && (
                    <div className="text-sm text-gray-500 mt-1">{customPackage.template.description}</div>
                  )}
                </div>
              </div>
            )}
            
            <div className="mb-6">
              <h3 className="text-sm font-medium text-gray-700 mb-2">Hours</h3>
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-gray-400" />
                <span className="text-lg font-medium text-gray-900">{customPackage.hours} hours</span>
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-2">Selected Options</h3>
              {customPackage.selections.length === 0 ? (
                <div className="text-gray-500">No additional options selected</div>
              ) : (
                <div className="space-y-4">
                  {customPackage.selections
                    .filter(option => option.type !== 'hour')
                    .map(option => (
                      <div key={option.id} className="bg-gray-50 rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="font-medium text-gray-900">{option.name}</div>
                            {option.description && (
                              <div className="text-sm text-gray-500 mt-1">{option.description}</div>
                            )}
                          </div>
                          <div className="text-right">
                            <div className="font-medium text-gray-900">
                              {option.quantity} × ${option.price.toFixed(2)}
                            </div>
                            <div className="text-sm text-gray-500">
                              ${(option.quantity * option.price).toFixed(2)}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>
            
            {customPackage.description && (
              <div className="mt-6 pt-6 border-t border-gray-200">
                <h3 className="text-sm font-medium text-gray-700 mb-2">Special Requests & Notes</h3>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-gray-700 whitespace-pre-line">{customPackage.description}</p>
                </div>
              </div>
            )}
          </div>
        </div>
        
        <div>
          {/* Status Card */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Package Status</h2>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                {customPackage.status === 'draft' && (
                  <FileText className="w-6 h-6 text-gray-500 mr-2" />
                )}
                {customPackage.status === 'submitted' && (
                  <MessageSquare className="w-6 h-6 text-blue-500 mr-2" />
                )}
                {customPackage.status === 'approved' && (
                  <CheckCircle className="w-6 h-6 text-green-500 mr-2" />
                )}
                {customPackage.status === 'rejected' && (
                  <XCircle className="w-6 h-6 text-red-500 mr-2" />
                )}
                <span className="text-xl font-medium capitalize">{customPackage.status}</span>
              </div>
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                customPackage.status === 'draft' ? 'bg-gray-100 text-gray-800' :
                customPackage.status === 'submitted' ? 'bg-blue-100 text-blue-800' :
                customPackage.status === 'approved' ? 'bg-green-100 text-green-800' :
                'bg-red-100 text-red-800'
              }`}>
                {customPackage.status}
              </span>
            </div>
            
            <div className="mt-4 text-sm text-gray-500">
              Last updated: {new Date(customPackage.updated_at).toLocaleString()}
            </div>
          </div>
          
          {/* Price Summary */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Price Summary</h2>
            
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Base Price</span>
                <span className="font-medium text-gray-900">
                  ${customPackage.total_price - customPackage.selections.reduce((sum, option) => 
                    sum + (option.type !== 'hour' ? option.price * option.quantity : 0), 0
                  ).toFixed(2)}
                </span>
              </div>
              
              {customPackage.selections
                .filter(option => option.type !== 'hour')
                .map(option => (
                  <div key={option.id} className="flex justify-between items-center">
                    <span className="text-gray-600">
                      {option.name} ({option.quantity})
                    </span>
                    <span className="font-medium text-gray-900">
                      ${(option.price * option.quantity).toFixed(2)}
                    </span>
                  </div>
                ))}
              
              <div className="pt-3 border-t border-gray-200 flex justify-between items-center">
                <span className="font-medium text-gray-900">Total</span>
                <span className="text-xl font-bold text-gray-900">
                  ${customPackage.total_price.toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Approve Confirmation Modal */}
      {showApproveConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Approve Custom Package</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to approve this custom package? This will allow you to create a quote based on this package.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowApproveConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                disabled={saving}
              >
                Cancel
              </button>
              <button
                onClick={() => handleStatusUpdate('approved')}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
                disabled={saving}
              >
                {saving ? 'Approving...' : 'Approve Package'}
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Reject Confirmation Modal */}
      {showRejectConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Reject Custom Package</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to reject this custom package? The client will need to create a new package request.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowRejectConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                disabled={saving}
              >
                Cancel
              </button>
              <button
                onClick={() => handleStatusUpdate('rejected')}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50"
                disabled={saving}
              >
                {saving ? 'Rejecting...' : 'Reject Package'}
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Create Quote Modal */}
      {showQuoteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Create Quote</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Quote Amount
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                    $
                  </span>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    className="w-full pl-7 pr-3 py-2 border border-gray-300 rounded-lg"
                    value={quoteAmount}
                    onChange={(e) => setQuoteAmount(parseFloat(e.target.value) || 0)}
                    required
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  rows={4}
                  value={quoteDescription}
                  onChange={(e) => setQuoteDescription(e.target.value)}
                  required
                />
              </div>
            </div>
            
            <div className="mt-6 flex justify-end gap-3">
              <button
                onClick={() => setShowQuoteModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                disabled={saving}
              >
                Cancel
              </button>
              <button
                onClick={handleCreateQuote}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                disabled={saving || quoteAmount <= 0 || !quoteDescription}
              >
                <Send className="w-4 h-4" />
                {saving ? 'Creating...' : 'Create Quote'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}