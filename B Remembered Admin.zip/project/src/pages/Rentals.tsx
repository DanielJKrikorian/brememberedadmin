import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  PlusCircle, Search, Filter, Truck, Calendar, 
  DollarSign, CheckCircle, XCircle, Wrench, Clock,
  MapPin, ExternalLink
} from 'lucide-react';
import RentalCard from '../components/RentalCard';
import RentalActionButtons from '../components/RentalActionButtons';

interface RentalCategory {
  id: string;
  name: string;
  description: string | null;
  slug: string | null;
}

interface RentalItem {
  id: string;
  name: string;
  description: string | null;
  category_id: string | null;
  condition: string;
  status: 'available' | 'rented' | 'maintenance' | 'retired';
  replacement_value: number;
  serial_number: string | null;
  notes: string | null;
  display_on_landing_page: boolean;
  display_on_couple_site: boolean;
  display_on_vendor_site: boolean;
  created_at: string;
  updated_at: string;
  images: Array<{
    id: string;
    url: string;
    alt_text: string | null;
    display_order: number;
    is_primary: boolean;
  }>;
  rates: Array<{
    id: string;
    duration_type: 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly';
    rate: number;
    minimum_duration: number;
    is_subscription: boolean;
  }>;
  category?: {
    name: string;
    slug: string;
  };
}

interface RentalBooking {
  id: string;
  rental_item_id: string;
  lead_id: string | null;
  vendor_id: string | null;
  start_date: string;
  end_date: string;
  status: 'pending' | 'confirmed' | 'active' | 'completed' | 'cancelled';
  delivery_method: 'pickup' | 'shipping';
  pickup_date: string | null;
  pickup_location: string | null;
  shipping_address: string | null;
  shipping_method: string | null;
  tracking_number: string | null;
  tracking_url: string | null;
  lead?: {
    name: string;
  };
  vendor?: {
    name: string;
  };
  rental_item?: {
    name: string;
  };
}

export default function Rentals() {
  const navigate = useNavigate();
  const [rentalItems, setRentalItems] = useState<RentalItem[]>([]);
  const [rentalBookings, setRentalBookings] = useState<RentalBooking[]>([]);
  const [categories, setCategories] = useState<RentalCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'items' | 'bookings'>('items');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([
      fetchRentalItems(),
      fetchCategories(),
      fetchRentalBookings()
    ]).finally(() => setLoading(false));
  }, []);

  async function fetchRentalItems() {
    try {
      const { data, error } = await supabase
        .from('rental_items')
        .select(`
          *,
          images:rental_images(*),
          rates:rental_rates(*),
          category:rental_categories(name, slug)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRentalItems(data || []);
    } catch (err) {
      console.error('Error fetching rental items:', err);
      setError('Failed to load rental items');
    }
  }

  async function fetchCategories() {
    try {
      const { data, error } = await supabase
        .from('rental_categories')
        .select('*')
        .order('name');

      if (error) throw error;
      setCategories(data || []);
    } catch (err) {
      console.error('Error fetching categories:', err);
      setError('Failed to load categories');
    }
  }
  
  async function fetchRentalBookings() {
    try {
      const { data, error } = await supabase
        .from('rental_bookings')
        .select(`
          *,
          lead:leads(name),
          vendor:vendors(name),
          rental_item:rental_items(name)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRentalBookings(data || []);
    } catch (err) {
      console.error('Error fetching rental bookings:', err);
      setError('Failed to load rental bookings');
    }
  }

  async function handleDeleteItem(itemId: string) {
    try {
      // Check if item has any active bookings
      const { data: bookings, error: bookingsError } = await supabase
        .from('rental_bookings')
        .select('id')
        .eq('rental_item_id', itemId)
        .or('status.eq.confirmed,status.eq.active');

      if (bookingsError) throw bookingsError;

      if (bookings && bookings.length > 0) {
        setError('Cannot delete item with active bookings');
        setShowDeleteConfirm(null);
        return;
      }

      // Delete the item
      const { error } = await supabase
        .from('rental_items')
        .delete()
        .eq('id', itemId);

      if (error) throw error;

      // Refresh the list
      fetchRentalItems();
      setShowDeleteConfirm(null);
    } catch (err) {
      console.error('Error deleting rental item:', err);
      setError('Failed to delete rental item');
    }
  }

  // Filter rental items based on search term, category, and status
  const filteredItems = rentalItems.filter(item => {
    const matchesSearch = 
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.category?.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = categoryFilter === 'all' || item.category_id === categoryFilter;
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
    
    return matchesSearch && matchesCategory && matchesStatus;
  });
  
  // Filter rental bookings based on search term
  const filteredBookings = rentalBookings.filter(booking => {
    const matchesSearch = 
      booking.rental_item?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      booking.lead?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      booking.vendor?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      booking.tracking_number?.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesSearch;
  });

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Rentals</h1>
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('items')}
            className={`px-4 py-2 rounded-lg ${
              activeTab === 'items' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Items
          </button>
          <button
            onClick={() => setActiveTab('bookings')}
            className={`px-4 py-2 rounded-lg ${
              activeTab === 'bookings' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Bookings
          </button>
          <button
            onClick={() => navigate('/rentals/new')}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <PlusCircle className="w-5 h-5" />
            Add Item
          </button>
        </div>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          {error}
        </div>
      )}

      {/* Items Tab */}
      {activeTab === 'items' && (
        <>
          <div className="mb-6 flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search rental items..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="flex gap-4">
              <select
                className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
              >
                <option value="all">All Categories</option>
                {categories.map(category => (
                  <option key={category.id} value={category.id}>{category.name}</option>
                ))}
              </select>
              <select
                className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="all">All Status</option>
                <option value="available">Available</option>
                <option value="rented">Rented</option>
                <option value="maintenance">Maintenance</option>
                <option value="retired">Retired</option>
              </select>
            </div>
          </div>

          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : filteredItems.length === 0 ? (
            <div className="text-center py-12">
              <h3 className="text-lg font-medium text-gray-900">No rental items found</h3>
              <p className="text-gray-600 mt-2">
                {searchTerm || categoryFilter !== 'all' || statusFilter !== 'all'
                  ? 'Try adjusting your filters'
                  : 'Get started by adding your first rental item'}
              </p>
              <button
                onClick={() => navigate('/rentals/new')}
                className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Add Rental Item
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredItems.map(item => (
                <RentalCard
                  key={item.id}
                  rental={item}
                  onEdit={(id) => navigate(`/rentals/${id}`)}
                  onDelete={(id) => setShowDeleteConfirm(id)}
                  onBook={(id) => navigate(`/rentals/booking/new?itemId=${id}`)}
                />
              ))}
            </div>
          )}
        </>
      )}
      
      {/* Bookings Tab */}
      {activeTab === 'bookings' && (
        <>
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search bookings..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : filteredBookings.length === 0 ? (
            <div className="text-center py-12">
              <h3 className="text-lg font-medium text-gray-900">No bookings found</h3>
              <p className="text-gray-600 mt-2">
                {searchTerm ? 'Try adjusting your search terms' : 'No rental bookings have been created yet'}
              </p>
              <button
                onClick={() => navigate('/rentals/booking/new')}
                className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Create Booking
              </button>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dates</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Delivery</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredBookings.map((booking) => (
                    <tr key={booking.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{booking.rental_item?.name}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {booking.lead?.name || booking.vendor?.name || 'Unknown'}
                        </div>
                        <div className="text-xs text-gray-500">
                          {booking.lead_id ? 'Lead' : 'Vendor'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {new Date(booking.start_date).toLocaleDateString()} - {new Date(booking.end_date).toLocaleDateString()}
                        </div>
                        <div className="text-xs text-gray-500">
                          {booking.is_subscription ? 'Subscription' : `${booking.duration_type}`}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {booking.delivery_method === 'pickup' ? (
                          <div className="flex items-center">
                            <MapPin className="w-4 h-4 text-gray-400 mr-1" />
                            <div>
                              <div className="text-sm text-gray-900">Pickup</div>
                              {booking.pickup_date && (
                                <div className="text-xs text-gray-500">
                                  {new Date(booking.pickup_date).toLocaleDateString()}
                                </div>
                              )}
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center">
                            <Truck className="w-4 h-4 text-gray-400 mr-1" />
                            <div>
                              <div className="text-sm text-gray-900">Shipping</div>
                              {booking.tracking_number && (
                                <div className="text-xs text-gray-500 flex items-center">
                                  {booking.tracking_number.substring(0, 10)}...
                                  {booking.tracking_url && (
                                    <a 
                                      href={booking.tracking_url} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                      className="ml-1 text-blue-600 hover:text-blue-800"
                                      onClick={(e) => e.stopPropagation()}
                                    >
                                      <ExternalLink className="w-3 h-3" />
                                    </a>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          booking.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                          booking.status === 'confirmed' ? 'bg-blue-100 text-blue-800' :
                          booking.status === 'active' ? 'bg-green-100 text-green-800' :
                          booking.status === 'completed' ? 'bg-purple-100 text-purple-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {booking.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button
                          onClick={() => navigate(`/rentals/booking/${booking.id}`)}
                          className="text-blue-600 hover:text-blue-900"
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Delete Rental Item</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this rental item? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowDeleteConfirm(null)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDeleteItem(showDeleteConfirm)}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Delete Item
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}