import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Wallet, TrendingUp, TrendingDown, Calendar, Search, Filter, Download, Plus, X, AlertCircle } from 'lucide-react';

interface Quote {
  id: string;
  amount: number;
  description: string;
  status: string;
  created_at: string;
  lead: {
    name: string;
  };
}

interface Payout {
  id: string;
  vendor_id: string;
  quote_id: string | null;
  amount: number;
  status: string;
  description: string;
  created_at: string;
  stripe_transfer_id: string | null;
  vendor: {
    name: string;
    email: string;
  };
  quote?: {
    id: string;
    amount: number;
    lead: {
      name: string;
    };
  };
}

interface Vendor {
  id: string;
  name: string;
  email: string;
  stripe_account_id: string | null;
}

export default function Payouts() {
  const [payouts, setPayouts] = useState<Payout[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [creatingPayout, setCreatingPayout] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [metrics, setMetrics] = useState({
    totalPayouts: 0,
    pendingPayouts: 0,
    monthlyPayouts: 0,
    averagePayout: 0,
  });

  const [newPayout, setNewPayout] = useState({
    vendor_id: '',
    quote_id: '',
    amount: 0,
    description: '',
    percentage: 50, // Default to 50%
  });

  useEffect(() => {
    fetchPayouts();
    fetchVendors();
    fetchQuotes();
  }, []);

  async function fetchVendors() {
    try {
      const { data, error } = await supabase
        .from('vendors')
        .select('id, name, email, stripe_account_id')
        .eq('approved', true)
        .order('name');

      if (error) throw error;
      setVendors(data || []);
    } catch (error) {
      console.error('Error fetching vendors:', error);
    }
  }

  async function fetchQuotes() {
    try {
      const { data, error } = await supabase
        .from('quotes')
        .select(`
          id,
          amount,
          description,
          status,
          created_at,
          lead:leads(name)
        `)
        .eq('status', 'paid')
        .not('vendor_id', 'is', null)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setQuotes(data || []);
    } catch (error) {
      console.error('Error fetching quotes:', error);
    }
  }

  async function fetchPayouts() {
    try {
      const { data, error } = await supabase
        .from('payouts')
        .select(`
          *,
          vendor:vendors(name, email),
          quote:quotes(
            id,
            amount,
            lead:leads(name)
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPayouts(data || []);

      // Calculate metrics
      const total = data?.reduce((sum, p) => sum + p.amount, 0) || 0;
      const pending = data?.filter(p => p.status === 'pending')
        .reduce((sum, p) => sum + p.amount, 0) || 0;
      
      const monthStart = new Date();
      monthStart.setDate(1);
      monthStart.setHours(0, 0, 0, 0);
      
      const monthly = data?.filter(p => new Date(p.created_at) >= monthStart)
        .reduce((sum, p) => sum + p.amount, 0) || 0;

      setMetrics({
        totalPayouts: total,
        pendingPayouts: pending,
        monthlyPayouts: monthly,
        averagePayout: total / (data?.length || 1),
      });
    } catch (error) {
      console.error('Error fetching payouts:', error);
    } finally {
      setLoading(false);
    }
  }

  // Update amount when quote or percentage changes
  useEffect(() => {
    if (newPayout.quote_id && newPayout.percentage) {
      const quote = quotes.find(q => q.id === newPayout.quote_id);
      if (quote) {
        const amount = (quote.amount * newPayout.percentage) / 100;
        setNewPayout(prev => ({ ...prev, amount }));
      }
    }
  }, [newPayout.quote_id, newPayout.percentage]);

  async function handleCreatePayout(e: React.FormEvent) {
    e.preventDefault();
    setCreatingPayout(true);
    setError(null);

    try {
      const vendor = vendors.find(v => v.id === newPayout.vendor_id);
      if (!vendor?.stripe_account_id) {
        throw new Error('Selected vendor has no connected Stripe account');
      }

      const quote = quotes.find(q => q.id === newPayout.quote_id);
      if (!quote) {
        throw new Error('Selected quote not found');
      }

      // Create description with quote reference
      const description = `Payout for Quote #${quote.id.slice(0, 8)} - ${quote.lead.name} (${newPayout.percentage}% of $${quote.amount})`;

      // Create Stripe transfer
      const response = await fetch('/functions/v1/create-vendor-payout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          vendorId: newPayout.vendor_id,
          amount: newPayout.amount,
          description,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create Stripe transfer');
      }

      const { transfer } = await response.json();

      // Record payout in database
      const { error: payoutError } = await supabase
        .from('payouts')
        .insert({
          vendor_id: newPayout.vendor_id,
          quote_id: newPayout.quote_id,
          amount: newPayout.amount,
          status: 'completed',
          stripe_transfer_id: transfer.id,
          description,
        });

      if (payoutError) throw payoutError;

      setShowCreateModal(false);
      setNewPayout({
        vendor_id: '',
        quote_id: '',
        amount: 0,
        description: '',
        percentage: 50,
      });
      fetchPayouts();
    } catch (err) {
      console.error('Error creating payout:', err);
      setError(err instanceof Error ? err.message : 'Failed to create payout');
    } finally {
      setCreatingPayout(false);
    }
  }

  const filteredPayouts = payouts.filter(payout =>
    payout.vendor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    payout.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Vendor Payouts</h1>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-5 h-5" />
          Create Payout
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-700">Total Payouts</h3>
            <Wallet className="w-6 h-6 text-green-500" />
          </div>
          <p className="text-2xl font-bold text-gray-900">
            ${metrics.totalPayouts.toLocaleString()}
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-700">Pending Payouts</h3>
            <TrendingUp className="w-6 h-6 text-blue-500" />
          </div>
          <p className="text-2xl font-bold text-gray-900">
            ${metrics.pendingPayouts.toLocaleString()}
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-700">Monthly Payouts</h3>
            <Calendar className="w-6 h-6 text-purple-500" />
          </div>
          <p className="text-2xl font-bold text-gray-900">
            ${metrics.monthlyPayouts.toLocaleString()}
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-700">Average Payout</h3>
            <TrendingDown className="w-6 h-6 text-orange-500" />
          </div>
          <p className="text-2xl font-bold text-gray-900">
            ${metrics.averagePayout.toLocaleString()}
          </p>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <h2 className="text-xl font-bold text-gray-900">Payout History</h2>
          <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
            <div className="relative flex-grow sm:flex-grow-0">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search payouts..."
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="relative flex-grow sm:flex-grow-0">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <select
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none bg-white"
              >
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="completed">Completed</option>
                <option value="failed">Failed</option>
              </select>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Vendor</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {loading ? (
                <tr>
                  <td colSpan={5} className="px-6 py-4 text-center">
                    <div className="flex justify-center">
                      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                    </div>
                  </td>
                </tr>
              ) : filteredPayouts.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-4 text-center text-gray-500">
                    No payouts found
                  </td>
                </tr>
              ) : (
                filteredPayouts.map((payout) => (
                  <tr key={payout.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="text-sm font-medium text-gray-900">{payout.vendor.name}</div>
                      <div className="text-sm text-gray-500">{payout.vendor.email}</div>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900">
                      ${payout.amount.toLocaleString()}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        payout.status === 'completed' ? 'bg-green-100 text-green-800' :
                        payout.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {payout.status.charAt(0).toUpperCase() + payout.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900">
                      {payout.description}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900">
                      {new Date(payout.created_at).toLocaleDateString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Payout Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900">Create New Payout</h2>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
                <AlertCircle className="w-5 h-5" />
                {error}
              </div>
            )}

            <form onSubmit={handleCreatePayout}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Vendor
                  </label>
                  <select
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={newPayout.vendor_id}
                    onChange={(e) => setNewPayout({ ...newPayout, vendor_id: e.target.value })}
                    required
                  >
                    <option value="">Select a vendor</option>
                    {vendors.map((vendor) => (
                      <option key={vendor.id} value={vendor.id} disabled={!vendor.stripe_account_id}>
                        {vendor.name} {!vendor.stripe_account_id && '(No Stripe account)'}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Quote
                  </label>
                  <select
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={newPayout.quote_id}
                    onChange={(e) => setNewPayout({ ...newPayout, quote_id: e.target.value })}
                    required
                  >
                    <option value="">Select a quote</option>
                    {quotes.map((quote) => (
                      <option key={quote.id} value={quote.id}>
                        Quote #{quote.id.slice(0, 8)} - ${quote.amount} - {quote.lead.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Percentage
                  </label>
                  <select
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={newPayout.percentage}
                    onChange={(e) => setNewPayout({ ...newPayout, percentage: parseInt(e.target.value) })}
                    required
                  >
                    <option value="50">50% of quote amount</option>
                    <option value="60">60% of quote amount</option>
                    <option value="70">70% of quote amount</option>
                    <option value="80">80% of quote amount</option>
                    <option value="90">90% of quote amount</option>
                    <option value="100">100% of quote amount</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Amount
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                      $
                    </span>
                    <input
                      type="number"
                      className="w-full border border-gray-300 rounded-lg pl-7 pr-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={newPayout.amount}
                      onChange={(e) => setNewPayout({ ...newPayout, amount: parseFloat(e.target.value) })}
                      required
                      readOnly
                    />
                  </div>
                </div>
              </div>

              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  disabled={creatingPayout}
                >
                  {creatingPayout ? 'Creating...' : 'Create Payout'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}