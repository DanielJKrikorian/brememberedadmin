import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { PlusCircle, Search, Upload, X, Users, Calendar, Clock, TrendingUp, Download, Filter } from 'lucide-react';
import * as Papa from 'papaparse';

interface Lead {
  id: string;
  name: string;
  email: string;
  phone: string;
  source: string;
  status: string;
  notes: string | null;
  partner_name: string | null;
  wedding_date: string | null;
  venue_id: string | null;
  venue_name: string | null;
  venue_address: string | null;
  lead_date: string;
  bookings: Array<{
    id: string;
    status: string;
  }>;
}

interface LeadMetrics {
  totalLeadsMonth: number;
  totalLeadsYear: number;
  avgDaysToClose: number;
  conversionRate: number;
}

interface Venue {
  id: string;
  name: string;
  address: string;
}

export default function Leads() {
  const navigate = useNavigate();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [venues, setVenues] = useState<Venue[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [venueSearchTerm, setVenueSearchTerm] = useState('');
  const [metrics, setMetrics] = useState<LeadMetrics>({
    totalLeadsMonth: 0,
    totalLeadsYear: 0,
    avgDaysToClose: 0,
    conversionRate: 0
  });
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showExportModal, setShowExportModal] = useState(false);
  const [exportRange, setExportRange] = useState('month');
  const [customDateRange, setCustomDateRange] = useState({
    start: new Date().toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0]
  });
  const [importProgress, setImportProgress] = useState<number | null>(null);

  const [newLead, setNewLead] = useState<Partial<Lead>>({
    name: '',
    email: '',
    phone: '',
    source: '',
    status: 'new',
    notes: '',
    partner_name: '',
    wedding_date: null,
    venue_id: null,
    venue_name: '',
    venue_address: '',
    lead_date: new Date().toISOString().split('T')[0],
  });

  useEffect(() => {
    fetchLeads();
    fetchVenues();
    calculateMetrics();
  }, []);

  async function calculateMetrics() {
    try {
      const now = new Date();
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
      const yearStart = new Date(now.getFullYear(), 0, 1).toISOString();

      // Get all leads with their associated bookings
      const { data: leads, error: leadsError } = await supabase
        .from('leads')
        .select(`
          id,
          created_at,
          bookings (
            id,
            status
          )
        `);

      if (leadsError) throw leadsError;

      // Calculate conversion metrics
      const totalLeads = leads?.length || 0;
      const convertedLeads = leads?.filter(lead => 
        lead.bookings && lead.bookings.length > 0 && 
        lead.bookings.some(booking => booking.status === 'confirmed')
      ).length || 0;

      const conversionRate = totalLeads > 0 
        ? (convertedLeads / totalLeads) * 100 
        : 0;

      const [
        { count: monthlyLeadsCount },
        { count: yearlyLeadsCount },
        { data: bookings },
        { data: yearlyBookings },
        { count: vendorsCount },
        { count: venuesCount },
        { count: jobsCount },
        { data: monthlyRevenue },
        { data: yearlyRevenue }
      ] = await Promise.all([
        // Total leads this month
        supabase
          .from('leads')
          .select('*', { count: 'exact', head: true })
          .gte('created_at', monthStart),
        // Total leads this year
        supabase
          .from('leads')
          .select('*', { count: 'exact', head: true })
          .gte('created_at', yearStart),
        // Active bookings this month
        supabase
          .from('bookings')
          .select('amount')
          .eq('status', 'confirmed')
          .gte('created_at', monthStart),
        // Total bookings this year
        supabase
          .from('bookings')
          .select('amount')
          .eq('status', 'confirmed')
          .gte('created_at', yearStart),
        // Approved vendors
        supabase
          .from('vendors')
          .select('*', { count: 'exact', head: true })
          .eq('approved', true),
        // Total venues
        supabase
          .from('venues')
          .select('*', { count: 'exact', head: true }),
        // Open jobs
        supabase
          .from('jobs')
          .select('*', { count: 'exact', head: true })
          .eq('status', 'open'),
        // Monthly revenue
        supabase
          .from('bookings')
          .select('amount')
          .eq('status', 'confirmed')
          .gte('created_at', monthStart),
        // Yearly revenue
        supabase
          .from('bookings')
          .select('amount')
          .eq('status', 'confirmed')
          .gte('created_at', yearStart)
      ]);

      const monthlyRevenueTotal = (monthlyRevenue || []).reduce((sum, booking) => sum + (booking.amount || 0), 0);
      const yearlyRevenueTotal = (yearlyRevenue || []).reduce((sum, booking) => sum + (booking.amount || 0), 0);

      setMetrics({
        totalLeadsMonth: monthlyLeadsCount || 0,
        totalLeadsYear: yearlyLeadsCount || 0,
        avgDaysToClose: 0, // This would need additional calculation logic
        conversionRate: Math.round(conversionRate)
      });
    } catch (error) {
      console.error('Error fetching dashboard metrics:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchLeads() {
    try {
      const { data, error } = await supabase
        .from('leads')
        .select('*')
        .order('lead_date', { ascending: false });

      if (error) throw error;
      setLeads(data || []);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching leads:', error);
      setError('Failed to fetch leads. Please try refreshing the page.');
      setLoading(false);
    }
  }

  async function fetchVenues() {
    try {
      const { data, error } = await supabase
        .from('venues')
        .select('id, name, address');

      if (error) throw error;
      setVenues(data || []);
    } catch (error) {
      console.error('Error fetching venues:', error);
      setError('Failed to fetch venues. Please try refreshing the page.');
    }
  }

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImportProgress(0);
    setError(null);

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        try {
          const totalRows = results.data.length;
          let processedRows = 0;

          // Process in batches of 10 to avoid overwhelming the database
          const batchSize = 10;
          for (let i = 0; i < results.data.length; i += batchSize) {
            const batch = results.data.slice(i, i + batchSize);
            
            // Map CSV data to leads table structure
            const leads = batch.map((row: any) => ({
              name: row.Name || row.name || '',
              email: row.Email || row.email || '',
              phone: row.Phone || row.phone || '',
              source: row.Source || row.source || 'Import',
              status: row.Status || row.status || 'new',
              notes: row.Notes || row.notes || '',
              partner_name: row['Partner Name'] || row.partner_name || '',
              wedding_date: row['Wedding Date'] || row.wedding_date || null,
              venue_name: row['Venue Name'] || row.venue_name || '',
              venue_address: row['Venue Address'] || row.venue_address || '',
              lead_date: row['Lead Date'] || row.lead_date || new Date().toISOString().split('T')[0]
            }));

            // Insert leads into the leads table
            const { error } = await supabase.from('leads').insert(leads);
            if (error) throw error;

            // Update progress
            processedRows += batch.length;
            setImportProgress(Math.round((processedRows / totalRows) * 100));
          }

          // Reset file input after 3 seconds
          setTimeout(() => {
            if (fileInputRef.current) {
              fileInputRef.current.value = '';
            }
            setImportProgress(null);
          }, 3000);

          // Refresh leads list
          fetchLeads();
          calculateMetrics();
        } catch (error) {
          console.error('Error importing leads:', error);
          setError('Failed to import leads. Please try again.');
          setImportProgress(null);
        }
      },
      error: (err) => {
        console.error('Error parsing CSV:', err);
        setError('Failed to parse CSV file. Please check the file format.');
        setImportProgress(null);
      }
    });
  };

  const handleAddLead = async () => {
    try {
      // Validate required fields
      if (!newLead.name || !newLead.source || !newLead.lead_date) {
        setError('Name, Source, and Lead Date are required fields.');
        return;
      }

      // Create the lead
      const { error: leadError } = await supabase
        .from('leads')
        .insert([newLead]);

      if (leadError) throw leadError;
      
      setShowModal(false);
      setError(null);
      fetchLeads();
      calculateMetrics();
      
      // Reset form
      setNewLead({
        name: '',
        email: '',
        phone: '',
        source: '',
        status: 'new',
        notes: '',
        partner_name: '',
        wedding_date: null,
        venue_id: null,
        venue_name: '',
        venue_address: '',
        lead_date: new Date().toISOString().split('T')[0],
      });
    } catch (error) {
      console.error('Error adding lead:', error);
      setError('Failed to add lead. Please try again.');
    }
  };

  const handleExportLeads = () => {
    // Filter leads based on export range
    let filteredLeads = [...leads];
    const now = new Date();
    
    if (exportRange === 'month') {
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      filteredLeads = leads.filter(lead => new Date(lead.lead_date) >= monthStart);
    } else if (exportRange === 'year') {
      const yearStart = new Date(now.getFullYear(), 0, 1);
      filteredLeads = leads.filter(lead => new Date(lead.lead_date) >= yearStart);
    } else if (exportRange === 'custom') {
      const startDate = new Date(customDateRange.start);
      const endDate = new Date(customDateRange.end);
      endDate.setHours(23, 59, 59, 999); // Set to end of day
      
      filteredLeads = leads.filter(lead => {
        const leadDate = new Date(lead.lead_date);
        return leadDate >= startDate && leadDate <= endDate;
      });
    }
    
    // Convert leads to CSV format
    const csvData = filteredLeads.map(lead => ({
      'Name': lead.name,
      'Email': lead.email,
      'Phone': lead.phone,
      'Source': lead.source,
      'Status': lead.status,
      'Partner Name': lead.partner_name || '',
      'Wedding Date': lead.wedding_date || '',
      'Venue Name': lead.venue_name || '',
      'Venue Address': lead.venue_address || '',
      'Lead Date': lead.lead_date || '',
      'Notes': lead.notes || ''
    }));
    
    // Generate CSV
    const csv = Papa.unparse(csvData);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `leads_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Close modal
    setShowExportModal(false);
  };

  const filteredLeads = leads.filter(lead =>
    lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    lead.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    lead.phone.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (lead.partner_name && lead.partner_name.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (lead.venue_name && lead.venue_name.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="p-6">
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      {importProgress !== null && (
        <div className="bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded mb-4">
          <div className="flex justify-between mb-1">
            <span>Importing leads...</span>
            <span>{importProgress}%</span>
          </div>
          <div className="w-full bg-blue-200 rounded-full h-2.5">
            <div 
              className="bg-blue-600 h-2.5 rounded-full" 
              style={{ width: `${importProgress}%` }}
            ></div>
          </div>
        </div>
      )}

      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Leads</h1>
        <div className="flex gap-2">
          <button
            onClick={() => setShowExportModal(true)}
            className="bg-gray-100 hover:bg-gray-200 text-gray-800 px-4 py-2 rounded-lg flex items-center gap-2"
          >
            <Download size={20} />
            Export
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".csv"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="bg-gray-100 hover:bg-gray-200 text-gray-800 px-4 py-2 rounded-lg flex items-center gap-2"
          >
            <Upload size={20} />
            Import
          </button>
          <button
            onClick={() => setShowModal(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
          >
            <PlusCircle size={20} />
            Add Lead
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="flex items-center gap-2 text-blue-600 mb-2">
            <Users size={24} />
            <h3 className="font-semibold">Monthly Leads</h3>
          </div>
          <p className="text-2xl font-bold">{metrics.totalLeadsMonth}</p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="flex items-center gap-2 text-green-600 mb-2">
            <Calendar size={24} />
            <h3 className="font-semibold">Yearly Leads</h3>
          </div>
          <p className="text-2xl font-bold">{metrics.totalLeadsYear}</p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="flex items-center gap-2 text-purple-600 mb-2">
            <Clock size={24} />
            <h3 className="font-semibold">Avg. Days to Close</h3>
          </div>
          <p className="text-2xl font-bold">{metrics.avgDaysToClose}</p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="flex items-center gap-2 text-orange-600 mb-2">
            <TrendingUp size={24} />
            <h3 className="font-semibold">Conversion Rate</h3>
          </div>
          <p className="text-2xl font-bold">{metrics.conversionRate}%</p>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="p-4 border-b">
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Search leads..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border rounded-lg"
                />
              </div>
            </div>
            <button className="flex items-center gap-2 px-4 py-2 border rounded-lg hover:bg-gray-50">
              <Filter size={20} />
              Filter
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Lead Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Source</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {loading ? (
                <tr>
                  <td colSpan={7} className="px-6 py-4 text-center">Loading...</td>
                </tr>
              ) : leads.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-4 text-center">No leads found</td>
                </tr>
              ) : (
                filteredLeads.map((lead) => (
                  <tr key={lead.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">{lead.name}</td>
                    <td className="px-6 py-4">{lead.email}</td>
                    <td className="px-6 py-4">{lead.phone}</td>
                    <td className="px-6 py-4">{lead.lead_date ? new Date(lead.lead_date).toLocaleDateString() : 'N/A'}</td>
                    <td className="px-6 py-4">{lead.source}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        lead.status === 'new' ? 'bg-blue-100 text-blue-800' :
                        lead.status === 'contacted' ? 'bg-yellow-100 text-yellow-800' :
                        lead.status === 'qualified' ? 'bg-green-100 text-green-800' :
                        lead.status === 'lost' ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {lead.status.charAt(0).toUpperCase() + lead.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <button
                        onClick={() => navigate(`/leads/${lead.id}`)}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-gray-900">Add New Lead</h2>
                <button
                  onClick={() => setShowModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X size={24} />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Name *</label>
                  <input
                    type="text"
                    value={newLead.name}
                    onChange={(e) => setNewLead({ ...newLead, name: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <input
                    type="email"
                    value={newLead.email}
                    onChange={(e) => setNewLead({ ...newLead, email: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                  <input
                    type="tel"
                    value={newLead.phone}
                    onChange={(e) => setNewLead({ ...newLead, phone: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Lead Date *</label>
                  <input
                    type="date"
                    value={newLead.lead_date}
                    onChange={(e) => setNewLead({ ...newLead, lead_date: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Source *</label>
                  <select
                    value={newLead.source}
                    onChange={(e) => setNewLead({ ...newLead, source: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg"
                    required
                  >
                    <option value="">Select source</option>
                    <option value="website">Website</option>
                    <option value="referral">Referral</option>
                    <option value="social">Social Media</option>
                    <option value="thumbtack">Thumbtack</option>
                    <option value="email">Email</option>
                    <option value="cold_outreach">Cold Outreach</option>
                    <option value="phone">Phone</option>
                    <option value="zola">Zola</option>
                    <option value="facebook">Facebook</option>
                    <option value="instagram">Instagram</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Wedding Date</label>
                  <input
                    type="date"
                    value={newLead.wedding_date || ''}
                    onChange={(e) => setNewLead({ ...newLead, wedding_date: e.target.value || null })}
                    className="w-full px-3 py-2 border rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Partner Name</label>
                  <input
                    type="text"
                    value={newLead.partner_name || ''}
                    onChange={(e) => setNewLead({ ...newLead, partner_name: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
                  <textarea
                    value={newLead.notes || ''}
                    onChange={(e) => setNewLead({ ...newLead, notes: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg"
                    rows={3}
                  />
                </div>
              </div>
              <div className="mt-6 flex justify-end gap-2">
                <button
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 border rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddLead}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Add Lead
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showExportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">Export Leads</h2>
                <button onClick={() => setShowExportModal(false)} className="text-gray-500 hover:text-gray-700">
                  <X size={24} />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Date Range</label>
                  <select
                    value={exportRange}
                    onChange={(e) => setExportRange(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg"
                  >
                    <option value="all">All Time</option>
                    <option value="month">This Month</option>
                    <option value="year">This Year</option>
                    <option value="custom">Custom Range</option>
                  </select>
                </div>
                {exportRange === 'custom' && (
                  <div className="space-y-2">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
                      <input
                        type="date"
                        value={customDateRange.start}
                        onChange={(e) => setCustomDateRange({ ...customDateRange, start: e.target.value })}
                        className="w-full px-3 py-2 border rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
                      <input
                        type="date"
                        value={customDateRange.end}
                        onChange={(e) => setCustomDateRange({ ...customDateRange, end: e.target.value })}
                        className="w-full px-3 py-2 border rounded-lg"
                      />
                    </div>
                  </div>
                )}
              </div>
              <div className="mt-6 flex justify-end gap-2">
                <button
                  onClick={() => setShowExportModal(false)}
                  className="px-4 py-2 border rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleExportLeads}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Export
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}