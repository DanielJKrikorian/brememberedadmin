import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { supabase } from '../lib/supabase';
import { ArrowLeft, Save, MapPin, Phone, Mail, Globe, Star, Building2, AlertCircle, Upload, FileText, X, Calendar, TrendingUp, BarChart } from 'lucide-react';

interface Venue {
  id: string;
  name: string;
  address: string;
  coi_url: string | null;
  contact_name: string | null;
  contact_email: string | null;
  contact_phone: string | null;
  rating: number | null;
  service_type: string | null;
  phone_number: string | null;
  website: string | null;
  state: string | null;
  region: string | null;
}

interface BookingStats {
  monthlyStats: Array<{
    month: string;
    count: number;
  }>;
  yearlyStats: Array<{
    year: number;
    count: number;
  }>;
}

export default function VenueEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [venue, setVenue] = useState<Venue | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [coiFileName, setCoiFileName] = useState<string | null>(null);
  const [bookingStats, setBookingStats] = useState<BookingStats>({
    monthlyStats: [],
    yearlyStats: []
  });

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'application/pdf': ['.pdf']
    },
    maxFiles: 1,
    onDrop: handleCoiDrop
  });

  useEffect(() => {
    if (id === 'new') {
      setVenue({
        id: '',
        name: '',
        address: '',
        coi_url: null,
        contact_name: null,
        contact_email: null,
        contact_phone: null,
        rating: null,
        service_type: null,
        phone_number: null,
        website: null,
        state: null,
        region: null,
      });
      setLoading(false);
      return;
    }

    Promise.all([
      fetchVenue(),
      fetchBookingStats()
    ]).finally(() => setLoading(false));
  }, [id]);

  async function fetchVenue() {
    try {
      const { data, error } = await supabase
        .from('venues')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      setVenue(data);

      // Set COI filename if URL exists
      if (data.coi_url) {
        const fileName = new URL(data.coi_url).pathname.split('/').pop();
        setCoiFileName(fileName || null);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  }

  async function fetchBookingStats() {
    if (!id) return;

    try {
      // Fetch all bookings for this venue
      const { data: bookings, error } = await supabase
        .from('bookings')
        .select('created_at')
        .eq('venue_id', id)
        .eq('status', 'confirmed');

      if (error) throw error;

      // Process monthly stats
      const monthlyData = new Map<string, number>();
      const yearlyData = new Map<number, number>();

      bookings?.forEach(booking => {
        const date = new Date(booking.created_at);
        const monthKey = date.toLocaleString('default', { month: 'long', year: 'numeric' });
        const yearKey = date.getFullYear();

        monthlyData.set(monthKey, (monthlyData.get(monthKey) || 0) + 1);
        yearlyData.set(yearKey, (yearlyData.get(yearKey) || 0) + 1);
      });

      // Convert to sorted arrays
      const monthlyStats = Array.from(monthlyData.entries())
        .map(([month, count]) => ({ month, count }))
        .sort((a, b) => new Date(b.month).getTime() - new Date(a.month).getTime());

      const yearlyStats = Array.from(yearlyData.entries())
        .map(([year, count]) => ({ year, count }))
        .sort((a, b) => b.year - a.year);

      setBookingStats({
        monthlyStats,
        yearlyStats
      });
    } catch (err) {
      console.error('Error fetching booking stats:', err);
    }
  }

  async function handleCoiDrop(acceptedFiles: File[]) {
    const file = acceptedFiles[0];
    if (!file || !venue) return;

    try {
      // Remove old file if exists
      if (venue.coi_url) {
        const oldFileName = new URL(venue.coi_url).pathname.split('/').pop();
        if (oldFileName) {
          await supabase.storage
            .from('venue-documents')
            .remove([`${venue.id}/${oldFileName}`]);
        }
      }

      // Upload new file
      const filePath = `${venue.id}/${file.name}`;
      const { error: uploadError } = await supabase.storage
        .from('venue-documents')
        .upload(filePath, file, {
          onUploadProgress: (progress) => {
            const percent = (progress.loaded / progress.total) * 100;
            setUploadProgress(percent);
          }
        });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('venue-documents')
        .getPublicUrl(filePath);

      // Update venue with new COI URL
      const { error: updateError } = await supabase
        .from('venues')
        .update({ coi_url: publicUrl })
        .eq('id', venue.id);

      if (updateError) throw updateError;

      setVenue({ ...venue, coi_url: publicUrl });
      setCoiFileName(file.name);
      setUploadProgress(null);
    } catch (err) {
      console.error('Error uploading COI:', err);
      setError('Failed to upload Certificate of Insurance');
      setUploadProgress(null);
    }
  }

  async function handleRemoveCoi() {
    if (!venue?.coi_url) return;

    try {
      const fileName = new URL(venue.coi_url).pathname.split('/').pop();
      if (fileName) {
        await supabase.storage
          .from('venue-documents')
          .remove([`${venue.id}/${fileName}`]);
      }

      const { error } = await supabase
        .from('venues')
        .update({ coi_url: null })
        .eq('id', venue.id);

      if (error) throw error;

      setVenue({ ...venue, coi_url: null });
      setCoiFileName(null);
    } catch (err) {
      console.error('Error removing COI:', err);
      setError('Failed to remove Certificate of Insurance');
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!venue) return;

    setSaving(true);
    try {
      if (id === 'new') {
        const { error } = await supabase
          .from('venues')
          .insert([venue]);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('venues')
          .update(venue)
          .eq('id', id);
        if (error) throw error;
      }

      navigate('/venues');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!venue) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-700">Venue not found</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/venues')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">
            {id === 'new' ? 'New Venue' : 'Edit Venue'}
          </h1>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6">
            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
                <AlertCircle className="w-5 h-5" />
                {error}
              </div>
            )}

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Name
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={venue.name}
                  onChange={(e) => setVenue({ ...venue, name: e.target.value })}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Address
                </label>
                <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500">
                  <MapPin className="w-5 h-5 text-gray-400 ml-3" />
                  <input
                    type="text"
                    className="w-full px-3 py-2 focus:outline-none"
                    value={venue.address}
                    onChange={(e) => setVenue({ ...venue, address: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    State
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={venue.state || ''}
                    onChange={(e) => setVenue({ ...venue, state: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Region
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={venue.region || ''}
                    onChange={(e) => setVenue({ ...venue, region: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Service Type
                </label>
                <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500">
                  <Building2 className="w-5 h-5 text-gray-400 ml-3" />
                  <input
                    type="text"
                    className="w-full px-3 py-2 focus:outline-none"
                    value={venue.service_type || ''}
                    onChange={(e) => setVenue({ ...venue, service_type: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Rating
                </label>
                <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500">
                  <Star className="w-5 h-5 text-gray-400 ml-3" />
                  <input
                    type="number"
                    min="0"
                    max="5"
                    step="0.1"
                    className="w-full px-3 py-2 focus:outline-none"
                    value={venue.rating || ''}
                    onChange={(e) => setVenue({ ...venue, rating: parseFloat(e.target.value) })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number
                  </label>
                  <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500">
                    <Phone className="w-5 h-5 text-gray-400 ml-3" />
                    <input
                      type="tel"
                      className="w-full px-3 py-2 focus:outline-none"
                      value={venue.phone_number || ''}
                      onChange={(e) => setVenue({ ...venue, phone_number: e.target.value })}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Website
                  </label>
                  <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500">
                    <Globe className="w-5 h-5 text-gray-400 ml-3" />
                    <input
                      type="url"
                      className="w-full px-3 py-2 focus:outline-none"
                      value={venue.website || ''}
                      onChange={(e) => setVenue({ ...venue, website: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              <div className="border-t border-gray-200 pt-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Contact Information</h2>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Contact Name
                    </label>
                    <input
                      type="text"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={venue.contact_name || ''}
                      onChange={(e) => setVenue({ ...venue, contact_name: e.target.value })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Contact Email
                    </label>
                    <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500">
                      <Mail className="w-5 h-5 text-gray-400 ml-3" />
                      <input
                        type="email"
                        className="w-full px-3 py-2 focus:outline-none"
                        value={venue.contact_email || ''}
                        onChange={(e) => setVenue({ ...venue, contact_email: e.target.value })}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Contact Phone
                    </label>
                    <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500">
                      <Phone className="w-5 h-5 text-gray-400 ml-3" />
                      <input
                        type="tel"
                        className="w-full px-3 py-2 focus:outline-none"
                        value={venue.contact_phone || ''}
                        onChange={(e) => setVenue({ ...venue, contact_phone: e.target.value })}
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-t border-gray-200 pt-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Documents</h2>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Certificate of Insurance
                  </label>

                  {venue.coi_url ? (
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <FileText className="w-5 h-5 text-gray-400" />
                        <div>
                          <div className="font-medium text-gray-900">{coiFileName}</div>
                          <a
                            href={venue.coi_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue-600 hover:text-blue-800"
                          >
                            View PDF
                          </a>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={handleRemoveCoi}
                        className="text-gray-400 hover:text-gray-600"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  ) : (
                    <div 
                      {...getRootProps()} 
                      className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors cursor-pointer ${
                        isDragActive ? 'border-blue-400 bg-blue-50' : 'border-gray-300 hover:border-gray-400'
                      }`}
                    >
                      <input {...getInputProps()} />
                      <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600">
                        {isDragActive ? 'Drop PDF here' : 'Drag & drop PDF here, or click to select'}
                      </p>
                      <p className="text-sm text-gray-500 mt-1">Only PDF files are accepted</p>
                    </div>
                  )}

                  {uploadProgress !== null && (
                    <div className="mt-4">
                      <div className="flex justify-between text-sm text-gray-600 mb-1">
                        <span>Uploading...</span>
                        <span>{Math.round(uploadProgress)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${uploadProgress}%` }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => navigate('/venues')}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                disabled={saving}
              >
                <Save className="w-5 h-5" />
                {saving ? 'Saving...' : (id === 'new' ? 'Create Venue' : 'Save Changes')}
              </button>
            </div>
          </form>
        </div>

        <div className="space-y-6">
          {/* Booking Statistics */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-gray-900">Booking Statistics</h2>
              <BarChart className="w-5 h-5 text-gray-400" />
            </div>

            {/* Yearly Stats */}
            <div className="mb-8">
              <h3 className="text-sm font-medium text-gray-700 mb-4">Yearly Bookings</h3>
              <div className="space-y-3">
                {bookingStats.yearlyStats.map(stat => (
                  <div key={stat.year} className="flex items-center">
                    <span className="w-16 text-sm text-gray-600">{stat.year}</span>
                    <div className="flex-1 ml-4">
                      <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-600 rounded-full"
                          style={{
                            width: `${(stat.count / Math.max(...bookingStats.yearlyStats.map(s => s.count))) * 100}%`
                          }}
                        />
                      </div>
                    </div>
                    <span className="ml-4 text-sm font-medium text-gray-900">{stat.count}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Monthly Stats */}
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-4">Recent Monthly Bookings</h3>
              <div className="space-y-3">
                {bookingStats.monthlyStats.slice(0, 6).map(stat => (
                  <div key={stat.month} className="flex items-center">
                    <span className="w-32 text-sm text-gray-600">{stat.month}</span>
                    <div className="flex-1 ml-4">
                      <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-green-600 rounded-full"
                          style={{
                            width: `${(stat.count / Math.max(...bookingStats.monthlyStats.map(s => s.count))) * 100}%`
                          }}
                        />
                      </div>
                    </div>
                    <span className="ml-4 text-sm font-medium text-gray-900">{stat.count}</span>
                  </div>
                ))}
              </div>
            </div>

            {bookingStats.monthlyStats.length === 0 && bookingStats.yearlyStats.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                No booking data available
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}