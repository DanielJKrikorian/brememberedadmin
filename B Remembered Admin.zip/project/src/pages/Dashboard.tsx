import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Users, Briefcase, Building2, MapPin, ClipboardList, DollarSign, TrendingUp, Calendar } from 'lucide-react';
import DashboardNotifications from '../components/DashboardNotifications';

interface DashboardMetrics {
  totalLeads: number;
  activeBookings: number;
  approvedVendors: number;
  totalVenues: number;
  openJobs: number;
  monthlyRevenue: number;
  yearlyRevenue: number;
  yearlyLeads: number;
  yearlyBookings: number;
  conversionRate: number;
}

export default function Dashboard() {
  const [metrics, setMetrics] = useState<DashboardMetrics>({
    totalLeads: 0,
    activeBookings: 0,
    approvedVendors: 0,
    totalVenues: 0,
    openJobs: 0,
    monthlyRevenue: 0,
    yearlyRevenue: 0,
    yearlyLeads: 0,
    yearlyBookings: 0,
    conversionRate: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardMetrics();
  }, []);

  async function fetchDashboardMetrics() {
    try {
      const now = new Date();
      const startOfYear = new Date(now.getFullYear(), 0, 1).toISOString();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();

      // Get all leads with their associated bookings
      const { data: leads, error: leadsError } = await supabase
        .from('leads')
        .select(`
          id,
          created_at,
          bookings (
            id,
            status
          )
        `);

      if (leadsError) throw leadsError;

      // Calculate conversion metrics
      const totalLeads = leads?.length || 0;
      const convertedLeads = leads?.filter(lead => 
        lead.bookings && lead.bookings.length > 0 && 
        lead.bookings.some(booking => booking.status === 'confirmed')
      ).length || 0;

      const conversionRate = totalLeads > 0 
        ? (convertedLeads / totalLeads) * 100 
        : 0;

      const [
        { count: monthlyLeadsCount },
        { count: yearlyLeadsCount },
        { data: bookings },
        { data: yearlyBookings },
        { count: vendorsCount },
        { count: venuesCount },
        { count: jobsCount },
        { data: monthlyRevenue },
        { data: yearlyRevenue }
      ] = await Promise.all([
        // Total leads this month
        supabase
          .from('leads')
          .select('*', { count: 'exact', head: true })
          .gte('created_at', startOfMonth),
        // Total leads this year
        supabase
          .from('leads')
          .select('*', { count: 'exact', head: true })
          .gte('created_at', startOfYear),
        // Active bookings this month
        supabase
          .from('bookings')
          .select('amount')
          .eq('status', 'confirmed')
          .gte('created_at', startOfMonth),
        // Total bookings this year
        supabase
          .from('bookings')
          .select('amount')
          .eq('status', 'confirmed')
          .gte('created_at', startOfYear),
        // Approved vendors
        supabase
          .from('vendors')
          .select('*', { count: 'exact', head: true })
          .eq('approved', true),
        // Total venues
        supabase
          .from('venues')
          .select('*', { count: 'exact', head: true }),
        // Open jobs
        supabase
          .from('jobs')
          .select('*', { count: 'exact', head: true })
          .eq('status', 'open'),
        // Monthly revenue
        supabase
          .from('bookings')
          .select('amount')
          .eq('status', 'confirmed')
          .gte('created_at', startOfMonth),
        // Yearly revenue
        supabase
          .from('bookings')
          .select('amount')
          .eq('status', 'confirmed')
          .gte('created_at', startOfYear)
      ]);

      const monthlyRevenueTotal = (monthlyRevenue || []).reduce((sum, booking) => sum + (booking.amount || 0), 0);
      const yearlyRevenueTotal = (yearlyRevenue || []).reduce((sum, booking) => sum + (booking.amount || 0), 0);

      setMetrics({
        totalLeads: monthlyLeadsCount || 0,
        yearlyLeads: yearlyLeadsCount || 0,
        activeBookings: (bookings || []).length,
        yearlyBookings: (yearlyBookings || []).length,
        approvedVendors: vendorsCount || 0,
        totalVenues: venuesCount || 0,
        openJobs: jobsCount || 0,
        monthlyRevenue: monthlyRevenueTotal,
        yearlyRevenue: yearlyRevenueTotal,
        conversionRate: Math.round(conversionRate)
      });
    } catch (error) {
      console.error('Error fetching dashboard metrics:', error);
    } finally {
      setLoading(false);
    }
  }

  const DashboardCard = ({ icon: Icon, title, value, subValue, color }: any) => (
    <div className="bg-white rounded-lg shadow p-6 dark:bg-gray-800">
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-full ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        {subValue && (
          <span className="text-sm font-medium text-gray-500 dark:text-gray-400">
            {subValue}
          </span>
        )}
      </div>
      <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{value}</h3>
      <p className="text-gray-600 mt-1 dark:text-gray-400">{title}</p>
    </div>
  );

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6 w-full">
      <h1 className="text-2xl font-bold text-gray-900 mb-6 dark:text-white">Dashboard Overview</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <DashboardCard
              icon={Users}
              title="Monthly Leads"
              value={metrics.totalLeads}
              subValue={`${metrics.yearlyLeads} this year`}
              color="bg-blue-500"
            />
            <DashboardCard
              icon={Briefcase}
              title="Active Bookings"
              value={metrics.activeBookings}
              subValue={`${metrics.yearlyBookings} this year`}
              color="bg-green-500"
            />
            <DashboardCard
              icon={Building2}
              title="Approved Vendors"
              value={metrics.approvedVendors}
              color="bg-purple-500"
            />
            <DashboardCard
              icon={MapPin}
              title="Total Venues"
              value={metrics.totalVenues}
              color="bg-orange-500"
            />
            <DashboardCard
              icon={DollarSign}
              title="Monthly Revenue"
              value={`$${metrics.monthlyRevenue.toLocaleString()}`}
              subValue={`$${metrics.yearlyRevenue.toLocaleString()} this year`}
              color="bg-emerald-500"
            />
            <DashboardCard
              icon={ClipboardList}
              title="Conversion Rate"
              value={`${metrics.conversionRate}%`}
              subValue="Leads to Bookings"
              color="bg-red-500"
            />
          </div>

          {/* Yearly Overview Section */}
          <div className="mt-8">
            <h2 className="text-xl font-bold text-gray-900 mb-4 dark:text-white">Yearly Overview</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-lg shadow p-6 dark:bg-gray-800">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 rounded-full bg-indigo-500">
                    <Calendar className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">{new Date().getFullYear()}</span>
                </div>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Revenue</h4>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">${metrics.yearlyRevenue.toLocaleString()}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Leads</h4>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">{metrics.yearlyLeads}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Bookings</h4>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">{metrics.yearlyBookings}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6 dark:bg-gray-800">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 rounded-full bg-blue-500">
                    <TrendingUp className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Performance</span>
                </div>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Avg. Revenue per Booking</h4>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      ${metrics.yearlyBookings > 0 
                        ? Math.round(metrics.yearlyRevenue / metrics.yearlyBookings).toLocaleString()
                        : 0}
                    </p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Lead to Booking Rate</h4>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      {metrics.yearlyLeads > 0 
                        ? Math.round((metrics.yearlyBookings / metrics.yearlyLeads) * 100)
                        : 0}%
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6 dark:bg-gray-800">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 rounded-full bg-green-500">
                    <DollarSign className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Monthly Average</span>
                </div>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Avg. Monthly Revenue</h4>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      ${Math.round(metrics.yearlyRevenue / 12).toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Avg. Monthly Leads</h4>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      {Math.round(metrics.yearlyLeads / 12)}
                    </p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Avg. Monthly Bookings</h4>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      {Math.round(metrics.yearlyBookings / 12)}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Notifications Column */}
        <div className="lg:col-span-1">
          <DashboardNotifications />
        </div>
      </div>
    </div>
  );
}