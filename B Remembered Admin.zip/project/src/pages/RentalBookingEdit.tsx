import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  ArrowLeft, Save, Trash2, Calendar, Clock, DollarSign, 
  User, Building2, Repeat, CheckCircle, AlertCircle, X,
  Mail, Link, Send, MapPin, Truck, ExternalLink
} from 'lucide-react';
import RentalBookingForm from '../components/RentalBookingForm';

interface RentalBooking {
  id: string;
  rental_item_id: string;
  lead_id: string | null;
  vendor_id: string | null;
  start_date: string;
  end_date: string;
  duration_type: 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly';
  rate: number;
  total_amount: number;
  status: 'pending' | 'confirmed' | 'active' | 'completed' | 'cancelled';
  is_subscription: boolean;
  subscription_end_date: string | null;
  deposit_amount: number;
  deposit_paid: boolean;
  notes: string | null;
  payment_link: string | null;
  payment_status: 'unpaid' | 'paid' | 'partial' | null;
  created_at: string;
  updated_at: string;
  
  // Delivery method fields
  delivery_method: 'pickup' | 'shipping';
  pickup_date: string | null;
  pickup_location: string | null;
  shipping_address: string | null;
  shipping_method: string | null;
  tracking_number: string | null;
  tracking_url: string | null;
  shipping_notes: string | null;
  
  rental_item?: {
    id: string;
    name: string;
    status: string;
  };
  lead?: {
    id: string;
    name: string;
    email: string;
    phone: string;
  };
  vendor?: {
    id: string;
    name: string;
    email: string;
    phone: string;
  };
}

export default function RentalBookingEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [booking, setBooking] = useState<RentalBooking | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showPaymentLinkModal, setShowPaymentLinkModal] = useState(false);
  const [sendingPaymentLink, setSendingPaymentLink] = useState(false);
  const [paymentLinkEmail, setPaymentLinkEmail] = useState('');
  const [paymentLinkSent, setPaymentLinkSent] = useState(false);
  
  // Tracking information
  const [showTrackingModal, setShowTrackingModal] = useState(false);
  const [trackingNumber, setTrackingNumber] = useState('');
  const [trackingUrl, setTrackingUrl] = useState('');

  const isNew = id === 'new';

  useEffect(() => {
    if (!isNew) {
      fetchBooking();
    } else {
      setLoading(false);
    }
  }, [id]);

  async function fetchBooking() {
    try {
      const { data, error } = await supabase
        .from('rental_bookings')
        .select(`
          *,
          rental_item:rental_items(id, name, status),
          lead:leads(id, name, email, phone),
          vendor:vendors(id, name, email, phone)
        `)
        .eq('id', id)
        .single();

      if (error) throw error;
      setBooking(data);
      
      // Set email for payment link if available
      if (data.lead?.email) {
        setPaymentLinkEmail(data.lead.email);
      } else if (data.vendor?.email) {
        setPaymentLinkEmail(data.vendor.email);
      }
      
      // Set tracking info if available
      if (data.tracking_number) {
        setTrackingNumber(data.tracking_number);
      }
      if (data.tracking_url) {
        setTrackingUrl(data.tracking_url);
      }
    } catch (err) {
      console.error('Error fetching booking:', err);
      setError('Failed to load booking');
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(bookingData: any) {
    setSaving(true);
    setError(null);
    setSuccess(null);

    try {
      if (isNew) {
        // Create new booking
        const { data, error } = await supabase
          .from('rental_bookings')
          .insert(bookingData)
          .select()
          .single();

        if (error) throw error;

        // Update rental item status to rented
        const { error: updateError } = await supabase
          .from('rental_items')
          .update({ status: 'rented' })
          .eq('id', bookingData.rental_item_id);

        if (updateError) throw updateError;

        // Generate payment link
        const paymentLink = await generatePaymentLink(data);
        
        // Update booking with payment link
        if (paymentLink) {
          await supabase
            .from('rental_bookings')
            .update({ payment_link: paymentLink })
            .eq('id', data.id);
        }

        setSuccess('Booking created successfully');
        
        // If we have an email and payment link, show the payment link modal
        if (paymentLink && (bookingData.lead_id || bookingData.vendor_id)) {
          setBooking(data);
          setShowPaymentLinkModal(true);
        } else {
          // Otherwise navigate back after a delay
          setTimeout(() => {
            navigate('/rentals');
          }, 1500);
        }
      } else if (booking) {
        // Update existing booking
        const { error } = await supabase
          .from('rental_bookings')
          .update({
            status: bookingData.status,
            notes: bookingData.notes,
            deposit_paid: bookingData.deposit_paid,
            
            // Update delivery method fields
            delivery_method: bookingData.delivery_method,
            pickup_date: bookingData.pickup_date,
            pickup_location: bookingData.pickup_location,
            shipping_address: bookingData.shipping_address,
            shipping_method: bookingData.shipping_method,
            shipping_notes: bookingData.shipping_notes
          })
          .eq('id', booking.id);

        if (error) throw error;

        // If status changed to completed or cancelled, update rental item status
        if (bookingData.status === 'completed' || bookingData.status === 'cancelled') {
          const { error: updateError } = await supabase
            .from('rental_items')
            .update({ status: 'available' })
            .eq('id', booking.rental_item_id);

          if (updateError) throw updateError;
        }

        setSuccess('Booking updated successfully');
        setTimeout(() => {
          navigate('/rentals');
        }, 1500);
      }
    } catch (err) {
      console.error('Error saving booking:', err);
      setError(err instanceof Error ? err.message : 'Failed to save booking');
    } finally {
      setSaving(false);
    }
  }

  async function generatePaymentLink(bookingData: any): Promise<string | null> {
    try {
      // Call the edge function to create a payment link
      const response = await fetch('/functions/v1/create-rental-payment-link', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          bookingId: bookingData.id,
          rentalItemId: bookingData.rental_item_id,
          amount: bookingData.total_amount,
          isSubscription: bookingData.is_subscription,
          durationType: bookingData.duration_type,
          customerEmail: bookingData.lead_id ? bookingData.lead?.email : bookingData.vendor?.email,
          customerName: bookingData.lead_id ? bookingData.lead?.name : bookingData.vendor?.name,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to create payment link');
      }

      const { paymentLink } = await response.json();
      return paymentLink;
    } catch (err) {
      console.error('Error generating payment link:', err);
      return null;
    }
  }

  async function handleSendPaymentLink() {
    if (!booking || !booking.payment_link) return;
    
    setSendingPaymentLink(true);
    setError(null);
    
    try {
      // Call the edge function to send the payment link via email
      const response = await fetch('/functions/v1/send-rental-payment-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          bookingId: booking.id,
          email: paymentLinkEmail,
          paymentLink: booking.payment_link,
          rentalItemName: booking.rental_item?.name,
          customerName: booking.lead?.name || booking.vendor?.name,
          amount: booking.total_amount,
          isSubscription: booking.is_subscription,
          durationType: booking.duration_type,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to send payment link');
      }

      setPaymentLinkSent(true);
      setTimeout(() => {
        setShowPaymentLinkModal(false);
        navigate('/rentals');
      }, 2000);
    } catch (err) {
      console.error('Error sending payment link:', err);
      setError(err instanceof Error ? err.message : 'Failed to send payment link');
    } finally {
      setSendingPaymentLink(false);
    }
  }

  async function handleDelete() {
    if (!booking) return;
    setSaving(true);
    setError(null);

    try {
      // Delete the booking
      const { error } = await supabase
        .from('rental_bookings')
        .delete()
        .eq('id', booking.id);

      if (error) throw error;

      // If the booking was active, update the rental item status
      if (booking.status === 'confirmed' || booking.status === 'active') {
        const { error: updateError } = await supabase
          .from('rental_items')
          .update({ status: 'available' })
          .eq('id', booking.rental_item_id);

        if (updateError) throw updateError;
      }

      navigate('/rentals');
    } catch (err) {
      console.error('Error deleting booking:', err);
      setError(err instanceof Error ? err.message : 'Failed to delete booking');
      setSaving(false);
    }
  }

  function copyPaymentLink() {
    if (booking?.payment_link) {
      navigator.clipboard.writeText(booking.payment_link);
      setSuccess('Payment link copied to clipboard');
      setTimeout(() => setSuccess(null), 2000);
    }
  }
  
  async function handleUpdateTracking() {
    if (!booking) return;
    
    setSaving(true);
    setError(null);
    
    try {
      const { error } = await supabase
        .from('rental_bookings')
        .update({
          tracking_number: trackingNumber,
          tracking_url: trackingUrl
        })
        .eq('id', booking.id);
        
      if (error) throw error;
      
      setShowTrackingModal(false);
      setBooking({
        ...booking,
        tracking_number: trackingNumber,
        tracking_url: trackingUrl
      });
      
      setSuccess('Tracking information updated successfully');
      setTimeout(() => setSuccess(null), 2000);
    } catch (err) {
      console.error('Error updating tracking information:', err);
      setError('Failed to update tracking information');
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/rentals')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">
            {isNew ? 'New Rental Booking' : 'Edit Rental Booking'}
          </h1>
        </div>
        {!isNew && booking && (
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="flex items-center gap-2 px-4 py-2 text-red-600 hover:text-red-700"
          >
            <Trash2 className="w-5 h-5" />
            Delete Booking
          </button>
        )}
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md p-6">
            {isNew ? (
              <RentalBookingForm 
                onSubmit={handleSubmit}
                onCancel={() => navigate('/rentals')}
              />
            ) : booking ? (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h2 className="text-lg font-semibold text-gray-900 mb-4">Rental Item</h2>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="text-lg font-medium text-gray-900">{booking.rental_item?.name}</div>
                      <div className="mt-2 flex items-center">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          booking.rental_item?.status === 'available' ? 'bg-green-100 text-green-800' :
                          booking.rental_item?.status === 'rented' ? 'bg-blue-100 text-blue-800' :
                          booking.rental_item?.status === 'maintenance' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {booking.rental_item?.status}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h2 className="text-lg font-semibold text-gray-900 mb-4">Customer</h2>
                    <div className="bg-gray-50 rounded-lg p-4">
                      {booking.lead ? (
                        <div>
                          <div className="flex items-center">
                            <User className="w-5 h-5 text-gray-400 mr-2" />
                            <span className="text-lg font-medium text-gray-900">{booking.lead.name}</span>
                          </div>
                          <div className="mt-2 space-y-1 text-sm text-gray-600">
                            <div>{booking.lead.email}</div>
                            {booking.lead.phone && <div>{booking.lead.phone}</div>}
                          </div>
                        </div>
                      ) : booking.vendor ? (
                        <div>
                          <div className="flex items-center">
                            <Building2 className="w-5 h-5 text-gray-400 mr-2" />
                            <span className="text-lg font-medium text-gray-900">{booking.vendor.name}</span>
                          </div>
                          <div className="mt-2 space-y-1 text-sm text-gray-600">
                            <div>{booking.vendor.email}</div>
                            {booking.vendor.phone && <div>{booking.vendor.phone}</div>}
                          </div>
                        </div>
                      ) : (
                        <div className="text-gray-500">No customer information</div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h2 className="text-lg font-semibold text-gray-900 mb-4">Booking Details</h2>
                    <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                      <div className="flex justify-between">
                        <div className="flex items-center text-gray-600">
                          <Calendar className="w-5 h-5 mr-2" />
                          <span>Start Date:</span>
                        </div>
                        <span className="font-medium text-gray-900">
                          {new Date(booking.start_date).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <div className="flex items-center text-gray-600">
                          <Calendar className="w-5 h-5 mr-2" />
                          <span>End Date:</span>
                        </div>
                        <span className="font-medium text-gray-900">
                          {new Date(booking.end_date).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <div className="flex items-center text-gray-600">
                          <Clock className="w-5 h-5 mr-2" />
                          <span>Duration Type:</span>
                        </div>
                        <span className="font-medium text-gray-900">
                          {booking.duration_type}
                        </span>
                      </div>
                      {booking.is_subscription && (
                        <div className="flex justify-between">
                          <div className="flex items-center text-gray-600">
                            <Repeat className="w-5 h-5 mr-2" />
                            <span>Subscription Until:</span>
                          </div>
                          <span className="font-medium text-gray-900">
                            {booking.subscription_end_date ? new Date(booking.subscription_end_date).toLocaleDateString() : 'N/A'}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <h2 className="text-lg font-semibold text-gray-900 mb-4">Payment Details</h2>
                    <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                      <div className="flex justify-between">
                        <div className="flex items-center text-gray-600">
                          <DollarSign className="w-5 h-5 mr-2" />
                          <span>Rate:</span>
                        </div>
                        <span className="font-medium text-gray-900">
                          ${booking.rate}/{booking.duration_type}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <div className="flex items-center text-gray-600">
                          <DollarSign className="w-5 h-5 mr-2" />
                          <span>Total Amount:</span>
                        </div>
                        <span className="font-medium text-gray-900">
                          ${booking.total_amount.toFixed(2)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <div className="flex items-center text-gray-600">
                          <DollarSign className="w-5 h-5 mr-2" />
                          <span>Payment Status:</span>
                        </div>
                        <span className={`font-medium ${
                          booking.payment_status === 'paid' ? 'text-green-600' : 
                          booking.payment_status === 'partial' ? 'text-yellow-600' : 
                          'text-red-600'
                        }`}>
                          {booking.payment_status || 'Unpaid'}
                        </span>
                      </div>
                      {booking.payment_link && (
                        <div className="pt-2">
                          <button
                            onClick={copyPaymentLink}
                            className="flex items-center gap-2 text-blue-600 hover:text-blue-800 text-sm"
                          >
                            <Link className="w-4 h-4" />
                            Copy Payment Link
                          </button>
                          <button
                            onClick={() => setShowPaymentLinkModal(true)}
                            className="flex items-center gap-2 text-blue-600 hover:text-blue-800 text-sm mt-2"
                          >
                            <Mail className="w-4 h-4" />
                            Send Payment Link
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                
                {/* Delivery Method Section */}
                <div>
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Delivery Method</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center mb-3">
                        <input
                          type="radio"
                          id="pickup"
                          checked={booking.delivery_method === 'pickup'}
                          onChange={() => setBooking({ ...booking, delivery_method: 'pickup' })}
                          className="text-blue-600 focus:ring-blue-500"
                        />
                        <label htmlFor="pickup" className="ml-2 font-medium text-gray-900">Pickup</label>
                      </div>
                      
                      {booking.delivery_method === 'pickup' && (
                        <div className="space-y-3 pl-6">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Pickup Date & Time
                            </label>
                            <input
                              type="datetime-local"
                              className="w-full border border-gray-300 rounded-lg px-3 py-2"
                              value={booking.pickup_date ? new Date(booking.pickup_date).toISOString().slice(0, 16) : ''}
                              onChange={(e) => setBooking({ ...booking, pickup_date: e.target.value })}
                            />
                          </div>
                          
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Pickup Location
                            </label>
                            <input
                              type="text"
                              className="w-full border border-gray-300 rounded-lg px-3 py-2"
                              value={booking.pickup_location || ''}
                              onChange={(e) => setBooking({ ...booking, pickup_location: e.target.value })}
                              placeholder="Enter pickup location"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center mb-3">
                        <input
                          type="radio"
                          id="shipping"
                          checked={booking.delivery_method === 'shipping'}
                          onChange={() => setBooking({ ...booking, delivery_method: 'shipping' })}
                          className="text-blue-600 focus:ring-blue-500"
                        />
                        <label htmlFor="shipping" className="ml-2 font-medium text-gray-900">Shipping</label>
                      </div>
                      
                      {booking.delivery_method === 'shipping' && (
                        <div className="space-y-3 pl-6">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Shipping Address
                            </label>
                            <textarea
                              className="w-full border border-gray-300 rounded-lg px-3 py-2"
                              rows={2}
                              value={booking.shipping_address || ''}
                              onChange={(e) => setBooking({ ...booking, shipping_address: e.target.value })}
                              placeholder="Enter shipping address"
                            />
                          </div>
                          
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Shipping Method
                            </label>
                            <select
                              className="w-full border border-gray-300 rounded-lg px-3 py-2"
                              value={booking.shipping_method || ''}
                              onChange={(e) => setBooking({ ...booking, shipping_method: e.target.value })}
                            >
                              <option value="">Select shipping method</option>
                              <option value="Standard">Standard Shipping</option>
                              <option value="Express">Express Shipping</option>
                              <option value="Overnight">Overnight Shipping</option>
                              <option value="Local">Local Delivery</option>
                            </select>
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <div>
                              <label className="block text-sm font-medium text-gray-700">
                                Tracking Information
                              </label>
                              {booking.tracking_number ? (
                                <div className="mt-1">
                                  <div className="text-sm text-gray-900">{booking.tracking_number}</div>
                                  {booking.tracking_url && (
                                    <a 
                                      href={booking.tracking_url} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center mt-1"
                                    >
                                      <ExternalLink className="w-3 h-3 mr-1" />
                                      Track Package
                                    </a>
                                  )}
                                </div>
                              ) : (
                                <span className="text-sm text-gray-500">No tracking info</span>
                              )}
                            </div>
                            
                            <button
                              type="button"
                              onClick={() => setShowTrackingModal(true)}
                              className="text-sm text-blue-600 hover:text-blue-800"
                            >
                              {booking.tracking_number ? 'Update' : 'Add'} Tracking
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div>
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Status</h2>
                  <select
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={booking.status}
                    onChange={(e) => setBooking({ ...booking, status: e.target.value as any })}
                  >
                    <option value="pending">Pending</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="active">Active</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>

                <div>
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Notes</h2>
                  <textarea
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    rows={4}
                    value={booking.notes || ''}
                    onChange={(e) => setBooking({ ...booking, notes: e.target.value })}
                    placeholder="Add any special instructions or notes..."
                  />
                </div>

                <div className="pt-6 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => navigate('/rentals')}
                    className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSubmit(booking)}
                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                    disabled={saving}
                  >
                    <Save className="w-5 h-5" />
                    {saving ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                Booking not found
              </div>
            )}
          </div>
        </div>

        <div>
          {!isNew && booking && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Booking Timeline</h2>
              <div className="space-y-4">
                <div className="flex">
                  <div className="flex flex-col items-center">
                    <div className="rounded-full w-8 h-8 bg-blue-100 text-blue-600 flex items-center justify-center">
                      <Calendar className="w-4 h-4" />
                    </div>
                    <div className="h-full w-0.5 bg-gray-200 mt-2"></div>
                  </div>
                  <div className="ml-4">
                    <div className="text-sm font-medium text-gray-900">Booking Created</div>
                    <div className="text-sm text-gray-500">{new Date(booking.created_at).toLocaleString()}</div>
                  </div>
                </div>

                {booking.status !== 'pending' && (
                  <div className="flex">
                    <div className="flex flex-col items-center">
                      <div className="rounded-full w-8 h-8 bg-green-100 text-green-600 flex items-center justify-center">
                        <CheckCircle className="w-4 h-4" />
                      </div>
                      <div className="h-full w-0.5 bg-gray-200 mt-2"></div>
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">Booking Confirmed</div>
                      <div className="text-sm text-gray-500">{new Date(booking.updated_at).toLocaleString()}</div>
                    </div>
                  </div>
                )}
                
                {booking.delivery_method === 'pickup' && booking.pickup_date && (
                  <div className="flex">
                    <div className="flex flex-col items-center">
                      <div className={`rounded-full w-8 h-8 ${
                        new Date() >= new Date(booking.pickup_date) 
                          ? 'bg-green-100 text-green-600' 
                          : 'bg-gray-100 text-gray-400'
                      } flex items-center justify-center`}>
                        <MapPin className="w-4 h-4" />
                      </div>
                      <div className="h-full w-0.5 bg-gray-200 mt-2"></div>
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">Pickup</div>
                      <div className="text-sm text-gray-500">{new Date(booking.pickup_date).toLocaleString()}</div>
                      {booking.pickup_location && (
                        <div className="text-sm text-gray-500">{booking.pickup_location}</div>
                      )}
                    </div>
                  </div>
                )}
                
                {booking.delivery_method === 'shipping' && booking.tracking_number && (
                  <div className="flex">
                    <div className="flex flex-col items-center">
                      <div className="rounded-full w-8 h-8 bg-blue-100 text-blue-600 flex items-center justify-center">
                        <Truck className="w-4 h-4" />
                      </div>
                      <div className="h-full w-0.5 bg-gray-200 mt-2"></div>
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">Shipped</div>
                      <div className="text-sm text-gray-500">Tracking: {booking.tracking_number}</div>
                      {booking.tracking_url && (
                        <a 
                          href={booking.tracking_url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-sm text-blue-600 hover:text-blue-800 flex items-center mt-1"
                        >
                          <ExternalLink className="w-3 h-3 mr-1" />
                          Track Package
                        </a>
                      )}
                    </div>
                  </div>
                )}

                <div className="flex">
                  <div className="flex flex-col items-center">
                    <div className={`rounded-full w-8 h-8 ${
                      new Date() >= new Date(booking.start_date) 
                        ? 'bg-green-100 text-green-600' 
                        : 'bg-gray-100 text-gray-400'
                    } flex items-center justify-center`}>
                      <Calendar className="w-4 h-4" />
                    </div>
                    <div className="h-full w-0.5 bg-gray-200 mt-2"></div>
                  </div>
                  <div className="ml-4">
                    <div className="text-sm font-medium text-gray-900">Rental Start</div>
                    <div className="text-sm text-gray-500">{new Date(booking.start_date).toLocaleString()}</div>
                  </div>
                </div>

                <div className="flex">
                  <div className="flex flex-col items-center">
                    <div className={`rounded-full w-8 h-8 ${
                      new Date() >= new Date(booking.end_date) 
                        ? 'bg-green-100 text-green-600' 
                        : 'bg-gray-100 text-gray-400'
                    } flex items-center justify-center`}>
                      <Calendar className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <div className="text-sm font-medium text-gray-900">Rental End</div>
                    <div className="text-sm text-gray-500">{new Date(booking.end_date).toLocaleString()}</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Delete Booking</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this booking? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Delete Booking
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Payment Link Modal */}
      {showPaymentLinkModal && booking && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Send Payment Link</h2>
            
            {paymentLinkSent ? (
              <div className="text-center py-4">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <p className="text-lg font-medium text-gray-900 mb-2">Payment Link Sent!</p>
                <p className="text-gray-600">
                  The payment link has been sent to {paymentLinkEmail}
                </p>
              </div>
            ) : (
              <>
                <p className="text-gray-600 mb-6">
                  Send a payment link to the customer to collect payment for this booking.
                  {booking.is_subscription && (
                    <span className="block mt-2 font-medium">
                      This is a subscription booking. The customer will be charged {booking.is_subscription ? 'automatically' : ''} 
                      on a {booking.duration_type} basis until they cancel.
                    </span>
                  )}
                </p>
                
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={paymentLinkEmail}
                    onChange={(e) => setPaymentLinkEmail(e.target.value)}
                    required
                  />
                </div>
                
                <div className="bg-gray-50 rounded-lg p-4 mb-6">
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Payment Summary</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Item:</span>
                      <span className="font-medium">{booking.rental_item?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Amount:</span>
                      <span className="font-medium">${booking.total_amount.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Type:</span>
                      <span className="font-medium">
                        {booking.is_subscription ? 'Subscription' : 'One-time payment'}
                      </span>
                    </div>
                    {booking.is_subscription && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Billing:</span>
                        <span className="font-medium">
                          ${booking.rate} per {booking.duration_type}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="flex justify-end gap-3">
                  <button
                    onClick={() => {
                      setShowPaymentLinkModal(false);
                      navigate('/rentals');
                    }}
                    className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                  >
                    Skip
                  </button>
                  <button
                    onClick={handleSendPaymentLink}
                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                    disabled={!paymentLinkEmail || sendingPaymentLink}
                  >
                    {sendingPaymentLink ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        Send Payment Link
                      </>
                    )}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
      
      {/* Tracking Information Modal */}
      {showTrackingModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">
              {booking?.tracking_number ? 'Update' : 'Add'} Tracking Information
            </h2>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tracking Number
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  value={trackingNumber}
                  onChange={(e) => setTrackingNumber(e.target.value)}
                  placeholder="Enter tracking number"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tracking URL (optional)
                </label>
                <input
                  type="url"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  value={trackingUrl}
                  onChange={(e) => setTrackingUrl(e.target.value)}
                  placeholder="https://example.com/track?number=123456789"
                />
              </div>
            </div>
            
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowTrackingModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleUpdateTracking}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                disabled={!trackingNumber.trim() || saving}
              >
                {saving ? 'Saving...' : (booking?.tracking_number ? 'Update' : 'Add') + ' Tracking'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}