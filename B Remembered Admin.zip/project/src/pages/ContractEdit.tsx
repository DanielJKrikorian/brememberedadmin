import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { ArrowLeft, Trash2, Save, FileText, User, Calendar } from 'lucide-react';

interface SignedContract {
  id: string;
  signed_at: string;
  lead: {
    name: string;
    email: string;
  };
  quote: {
    id: string;
    amount: number;
  };
}

interface Contract {
  id: string;
  name: string;
  content: string;
  created_at: string;
  signed_contracts: SignedContract[];
}

export default function ContractEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [contract, setContract] = useState<Contract>({
    id: '',
    name: '',
    content: '',
    created_at: new Date().toISOString(),
    signed_contracts: [],
  });

  useEffect(() => {
    if (id !== 'new') {
      fetchContract();
    } else {
      setLoading(false);
    }
  }, [id]);

  async function fetchContract() {
    try {
      const { data, error } = await supabase
        .from('contracts')
        .select(`
          *,
          signed_contracts (
            id,
            signed_at,
            lead:leads (
              name,
              email
            ),
            quote:quotes (
              id,
              amount
            )
          )
        `)
        .eq('id', id)
        .single();

      if (error) throw error;
      if (data) {
        setContract(data);
      }
    } catch (error) {
      console.error('Error fetching contract:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);

    try {
      if (id === 'new') {
        const { error } = await supabase
          .from('contracts')
          .insert({
            name: contract.name,
            content: contract.content,
          });

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('contracts')
          .update({
            name: contract.name,
            content: contract.content,
          })
          .eq('id', id);

        if (error) throw error;
      }

      navigate('/contracts');
    } catch (error) {
      console.error('Error saving contract:', error);
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    try {
      const { error } = await supabase
        .from('contracts')
        .delete()
        .eq('id', id);

      if (error) throw error;
      navigate('/contracts');
    } catch (error) {
      console.error('Error deleting contract:', error);
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/contracts')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">
            {id === 'new' ? 'New Contract' : 'Edit Contract'}
          </h1>
        </div>
        {id !== 'new' && (
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="flex items-center gap-2 px-4 py-2 text-red-600 hover:text-red-700"
          >
            <Trash2 className="w-5 h-5" />
            Delete Contract
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Contract Name
              </label>
              <input
                type="text"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={contract.name}
                onChange={(e) => setContract({ ...contract, name: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Contract Content
              </label>
              <textarea
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                rows={20}
                value={contract.content}
                onChange={(e) => setContract({ ...contract, content: e.target.value })}
                required
              />
              <p className="mt-2 text-sm text-gray-500">
                You can use the following variables in your contract:
              </p>
              <ul className="mt-1 text-sm text-gray-500 list-disc list-inside">
                <li>{'{{client_name}}'} - Client's full name</li>
                <li>{'{{client_email}}'} - Client's email address</li>
                <li>{'{{event_date}}'} - Wedding date</li>
                <li>{'{{total_amount}}'} - Total quote amount</li>
                <li>{'{{deposit_amount}}'} - Required deposit (50% of total)</li>
                <li>{'{{balance_amount}}'} - Remaining balance</li>
                <li>{'{{services}}'} - List of services</li>
              </ul>
            </div>

            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => navigate('/contracts')}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                disabled={saving}
              >
                <Save className="w-5 h-5" />
                {saving ? 'Saving...' : (id === 'new' ? 'Create Contract' : 'Save Changes')}
              </button>
            </div>
          </form>
        </div>

        {id !== 'new' && contract.signed_contracts.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Signatures</h2>
            <div className="bg-white rounded-lg shadow-md divide-y divide-gray-200">
              {contract.signed_contracts.map((signed) => (
                <div key={signed.id} className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-gray-400" />
                        <span className="font-medium text-gray-900">{signed.lead.name}</span>
                      </div>
                      <div className="text-sm text-gray-500 mt-1">{signed.lead.email}</div>
                      <div className="flex items-center gap-2 mt-2 text-sm text-gray-500">
                        <Calendar className="w-4 h-4" />
                        <span>Signed on {new Date(signed.signed_at).toLocaleDateString()}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium text-gray-900">
                        Quote #{signed.quote.id.slice(0, 8)}
                      </div>
                      <div className="text-sm text-gray-500">
                        ${signed.quote.amount.toLocaleString()}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Delete Contract</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this contract? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Delete Contract
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}