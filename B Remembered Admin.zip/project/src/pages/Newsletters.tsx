import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  PlusCircle, Search, Mail, Calendar, Clock, 
  Edit, Trash2, Copy, Send, X, AlertCircle, 
  CheckCircle, FileText, Users, BarChart2
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface NewsletterTemplate {
  id: string;
  name: string;
  subject: string;
  created_at: string;
  updated_at: string;
}

interface NewsletterCampaign {
  id: string;
  name: string;
  subject: string;
  status: 'draft' | 'scheduled' | 'sent' | 'cancelled';
  scheduled_for: string | null;
  sent_at: string | null;
  created_at: string;
  updated_at: string;
  template_id: string | null;
  template?: {
    name: string;
  };
  stats?: {
    total: number;
    sent: number;
    opened: number;
    clicked: number;
    failed: number;
  };
}

export default function Newsletters() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'templates' | 'campaigns'>('campaigns');
  const [templates, setTemplates] = useState<NewsletterTemplate[]>([]);
  const [campaigns, setCampaigns] = useState<NewsletterCampaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Delete confirmation modal state
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<{id: string, type: 'template' | 'campaign'} | null>(null);
  
  // Duplicate template modal state
  const [showDuplicateModal, setShowDuplicateModal] = useState(false);
  const [templateToDuplicate, setTemplateToDuplicate] = useState<NewsletterTemplate | null>(null);
  const [newTemplateName, setNewTemplateName] = useState('');
  
  // Create campaign modal state
  const [showCreateCampaignModal, setShowCreateCampaignModal] = useState(false);
  const [newCampaignName, setNewCampaignName] = useState('');
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('');
  
  useEffect(() => {
    if (activeTab === 'templates') {
      fetchTemplates();
    } else {
      fetchCampaigns();
    }
  }, [activeTab]);
  
  async function fetchTemplates() {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('newsletter_templates')
        .select('*')
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      setTemplates(data || []);
    } catch (err) {
      console.error('Error fetching newsletter templates:', err);
      setError('Failed to load newsletter templates');
    } finally {
      setLoading(false);
    }
  }
  
  async function fetchCampaigns() {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('newsletter_campaigns')
        .select(`
          *,
          template:newsletter_templates(name)
        `)
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      
      // Fetch stats for each campaign
      const campaignsWithStats = await Promise.all((data || []).map(async (campaign) => {
        // Get total sends
        const { count: total } = await supabase
          .from('newsletter_sends')
          .select('*', { count: 'exact', head: true })
          .eq('campaign_id', campaign.id);
          
        // Get sent count
        const { count: sent } = await supabase
          .from('newsletter_sends')
          .select('*', { count: 'exact', head: true })
          .eq('campaign_id', campaign.id)
          .eq('status', 'sent');
          
        // Get opened count
        const { count: opened } = await supabase
          .from('newsletter_sends')
          .select('*', { count: 'exact', head: true })
          .eq('campaign_id', campaign.id)
          .or('status.eq.opened,status.eq.clicked');
          
        // Get clicked count
        const { count: clicked } = await supabase
          .from('newsletter_sends')
          .select('*', { count: 'exact', head: true })
          .eq('campaign_id', campaign.id)
          .eq('status', 'clicked');
          
        // Get failed count
        const { count: failed } = await supabase
          .from('newsletter_sends')
          .select('*', { count: 'exact', head: true })
          .eq('campaign_id', campaign.id)
          .eq('status', 'failed');
          
        return {
          ...campaign,
          stats: {
            total: total || 0,
            sent: sent || 0,
            opened: opened || 0,
            clicked: clicked || 0,
            failed: failed || 0
          }
        };
      }));
      
      setCampaigns(campaignsWithStats);
    } catch (err) {
      console.error('Error fetching newsletter campaigns:', err);
      setError('Failed to load newsletter campaigns');
    } finally {
      setLoading(false);
    }
  }
  
  async function handleDelete() {
    if (!itemToDelete) return;
    
    try {
      if (itemToDelete.type === 'template') {
        // Check if template is used in any campaigns
        const { count, error: countError } = await supabase
          .from('newsletter_campaigns')
          .select('id', { count: 'exact', head: true })
          .eq('template_id', itemToDelete.id);
          
        if (countError) throw countError;
        
        if (count && count > 0) {
          throw new Error('Cannot delete template that is used in campaigns');
        }
        
        // Delete template
        const { error } = await supabase
          .from('newsletter_templates')
          .delete()
          .eq('id', itemToDelete.id);
          
        if (error) throw error;
        
        // Refresh templates
        fetchTemplates();
      } else {
        // Delete campaign
        const { error } = await supabase
          .from('newsletter_campaigns')
          .delete()
          .eq('id', itemToDelete.id);
          
        if (error) throw error;
        
        // Refresh campaigns
        fetchCampaigns();
      }
      
      // Close modal
      setShowDeleteConfirm(false);
      setItemToDelete(null);
      
      // Show success message
      setSuccess(`${itemToDelete.type === 'template' ? 'Template' : 'Campaign'} deleted successfully`);
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error deleting item:', err);
      setError(err instanceof Error ? err.message : 'Failed to delete item');
    }
  }
  
  async function handleDuplicateTemplate() {
    if (!templateToDuplicate) return;
    
    try {
      // Get the template content
      const { data, error } = await supabase
        .from('newsletter_templates')
        .select('*')
        .eq('id', templateToDuplicate.id)
        .single();
        
      if (error) throw error;
      
      // Create a new template with the same content
      const { error: insertError } = await supabase
        .from('newsletter_templates')
        .insert({
          name: newTemplateName,
          subject: data.subject,
          content: data.content
        });
        
      if (insertError) throw insertError;
      
      // Refresh templates
      fetchTemplates();
      
      // Close modal
      setShowDuplicateModal(false);
      setTemplateToDuplicate(null);
      setNewTemplateName('');
      
      // Show success message
      setSuccess('Template duplicated successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error duplicating template:', err);
      setError('Failed to duplicate template');
    }
  }
  
  async function handleCreateCampaign() {
    try {
      if (!selectedTemplateId) {
        throw new Error('Please select a template');
      }
      
      // Get the template content
      const { data: template, error: templateError } = await supabase
        .from('newsletter_templates')
        .select('*')
        .eq('id', selectedTemplateId)
        .single();
        
      if (templateError) throw templateError;
      
      // Create a new campaign
      const { data, error } = await supabase
        .from('newsletter_campaigns')
        .insert({
          name: newCampaignName,
          template_id: selectedTemplateId,
          subject: template.subject,
          content: template.content,
          status: 'draft'
        })
        .select()
        .single();
        
      if (error) throw error;
      
      // Close modal
      setShowCreateCampaignModal(false);
      setNewCampaignName('');
      setSelectedTemplateId('');
      
      // Navigate to the campaign edit page
      navigate(`/newsletters/campaigns/${data.id}`);
    } catch (err) {
      console.error('Error creating campaign:', err);
      setError(err instanceof Error ? err.message : 'Failed to create campaign');
    }
  }
  
  // Filter data based on search term
  const filteredTemplates = templates.filter(template => 
    template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    template.subject.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const filteredCampaigns = campaigns.filter(campaign => 
    campaign.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    campaign.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (campaign.template?.name && campaign.template.name.toLowerCase().includes(searchTerm.toLowerCase()))
  );
  
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Newsletters</h1>
        
        <div className="flex gap-2">
          <button
            onClick={() => navigate('/newsletters/subscribers')}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600"
          >
            <Users className="w-5 h-5" />
            Subscribers
          </button>
          
          {activeTab === 'templates' ? (
            <button
              onClick={() => navigate('/newsletters/templates/new')}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <PlusCircle className="w-5 h-5" />
              New Template
            </button>
          ) : (
            <button
              onClick={() => setShowCreateCampaignModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <PlusCircle className="w-5 h-5" />
              New Campaign
            </button>
          )}
        </div>
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700 dark:bg-red-900/30 dark:border-red-800 dark:text-red-400">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}
      
      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700 dark:bg-green-900/30 dark:border-green-800 dark:text-green-400">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}
      
      {/* Tabs */}
      <div className="mb-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex space-x-8">
          <button
            onClick={() => setActiveTab('campaigns')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'campaigns'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            Campaigns
          </button>
          <button
            onClick={() => setActiveTab('templates')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'templates'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            Templates
          </button>
        </div>
      </div>
      
      {/* Search */}
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder={`Search ${activeTab}...`}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-800 dark:text-white"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      
      {/* Content based on active tab */}
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <>
          {/* Templates Tab */}
          {activeTab === 'templates' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTemplates.length === 0 ? (
                <div className="col-span-full bg-white rounded-lg shadow-md p-8 text-center dark:bg-gray-800">
                  <Mail className="w-12 h-12 text-gray-400 mx-auto mb-4 dark:text-gray-500" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2 dark:text-white">No Templates Found</h3>
                  <p className="text-gray-500 dark:text-gray-400">
                    {searchTerm ? 'Try adjusting your search terms' : 'Get started by creating your first newsletter template'}
                  </p>
                  <button
                    onClick={() => navigate('/newsletters/templates/new')}
                    className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Create Template
                  </button>
                </div>
              ) : (
                filteredTemplates.map(template => (
                  <div 
                    key={template.id} 
                    className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow dark:bg-gray-800 dark:border-gray-700"
                  >
                    <div className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{template.name}</h3>
                          <p className="text-sm text-gray-500 mt-1 dark:text-gray-400">{template.subject}</p>
                        </div>
                        <Mail className="w-6 h-6 text-blue-500" />
                      </div>
                      
                      <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-4">
                        <Calendar className="w-4 h-4 mr-1" />
                        <span>Updated {formatDistanceToNow(new Date(template.updated_at), { addSuffix: true })}</span>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <div className="flex space-x-2">
                          <button
                            onClick={() => navigate(`/newsletters/templates/${template.id}`)}
                            className="flex items-center gap-1 px-2 py-1 text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                          >
                            <Edit className="w-4 h-4" />
                            <span>Edit</span>
                          </button>
                          <button
                            onClick={() => {
                              setTemplateToDuplicate(template);
                              setNewTemplateName(`${template.name} (Copy)`);
                              setShowDuplicateModal(true);
                            }}
                            className="flex items-center gap-1 px-2 py-1 text-green-600 hover:text-green-800 dark:text-green-400 dark:hover:text-green-300"
                          >
                            <Copy className="w-4 h-4" />
                            <span>Duplicate</span>
                          </button>
                        </div>
                        <button
                          onClick={() => {
                            setItemToDelete({ id: template.id, type: 'template' });
                            setShowDeleteConfirm(true);
                          }}
                          className="flex items-center gap-1 px-2 py-1 text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300"
                        >
                          <Trash2 className="w-4 h-4" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
          
          {/* Campaigns Tab */}
          {activeTab === 'campaigns' && (
            <div className="bg-white rounded-lg shadow-md overflow-hidden dark:bg-gray-800">
              {filteredCampaigns.length === 0 ? (
                <div className="p-8 text-center">
                  <Mail className="w-12 h-12 text-gray-400 mx-auto mb-4 dark:text-gray-500" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2 dark:text-white">No Campaigns Found</h3>
                  <p className="text-gray-500 dark:text-gray-400">
                    {searchTerm ? 'Try adjusting your search terms' : 'Get started by creating your first newsletter campaign'}
                  </p>
                  <button
                    onClick={() => setShowCreateCampaignModal(true)}
                    className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Create Campaign
                  </button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                    <thead className="bg-gray-50 dark:bg-gray-700">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Campaign</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Template</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Schedule</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Stats</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-700">
                      {filteredCampaigns.map(campaign => (
                        <tr key={campaign.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <Mail className="w-5 h-5 text-blue-500 mr-3" />
                              <div>
                                <div className="text-sm font-medium text-gray-900 dark:text-white">{campaign.name}</div>
                                <div className="text-xs text-gray-500 dark:text-gray-400">{campaign.subject}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900 dark:text-white">
                              {campaign.template?.name || 'Custom'}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              campaign.status === 'draft' 
                                ? 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300' 
                                : campaign.status === 'scheduled'
                                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400'
                                : campaign.status === 'sent'
                                ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
                                : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                            }`}>
                              {campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {campaign.status === 'scheduled' && campaign.scheduled_for ? (
                              <div className="flex items-center text-sm text-gray-900 dark:text-white">
                                <Clock className="w-4 h-4 text-gray-400 mr-2 dark:text-gray-500" />
                                {new Date(campaign.scheduled_for).toLocaleString()}
                              </div>
                            ) : campaign.status === 'sent' && campaign.sent_at ? (
                              <div className="flex items-center text-sm text-gray-900 dark:text-white">
                                <Calendar className="w-4 h-4 text-gray-400 mr-2 dark:text-gray-500" />
                                {new Date(campaign.sent_at).toLocaleString()}
                              </div>
                            ) : (
                              <span className="text-sm text-gray-500 dark:text-gray-400">—</span>
                            )}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {campaign.stats && (
                              <div className="flex items-center space-x-2">
                                <div className="flex flex-col items-center">
                                  <span className="text-xs text-gray-500 dark:text-gray-400">Sent</span>
                                  <span className="font-medium text-gray-900 dark:text-white">{campaign.stats.sent}</span>
                                </div>
                                <div className="flex flex-col items-center">
                                  <span className="text-xs text-gray-500 dark:text-gray-400">Opened</span>
                                  <span className="font-medium text-gray-900 dark:text-white">{campaign.stats.opened}</span>
                                </div>
                                <div className="flex flex-col items-center">
                                  <span className="text-xs text-gray-500 dark:text-gray-400">Clicked</span>
                                  <span className="font-medium text-gray-900 dark:text-white">{campaign.stats.clicked}</span>
                                </div>
                              </div>
                            )}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <div className="flex items-center space-x-2">
                              <button
                                onClick={() => navigate(`/newsletters/campaigns/${campaign.id}`)}
                                className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300"
                                title="Edit Campaign"
                              >
                                <Edit className="w-4 h-4" />
                              </button>
                              
                              {campaign.status === 'draft' && (
                                <button
                                  onClick={() => {
                                    setItemToDelete({ id: campaign.id, type: 'campaign' });
                                    setShowDeleteConfirm(true);
                                  }}
                                  className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                                  title="Delete Campaign"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              )}
                              
                              {campaign.status === 'sent' && (
                                <button
                                  onClick={() => navigate(`/newsletters/campaigns/${campaign.id}`)}
                                  className="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300"
                                  title="View Stats"
                                >
                                  <BarChart2 className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </>
      )}
      
      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && itemToDelete && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full dark:bg-gray-800">
            <h2 className="text-xl font-bold text-gray-900 mb-4 dark:text-white">
              Delete {itemToDelete.type === 'template' ? 'Template' : 'Campaign'}
            </h2>
            <p className="text-gray-600 mb-6 dark:text-gray-300">
              Are you sure you want to delete this {itemToDelete.type}? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowDeleteConfirm(false);
                  setItemToDelete(null);
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 dark:bg-red-700 dark:hover:bg-red-600"
              >
                Delete {itemToDelete.type === 'template' ? 'Template' : 'Campaign'}
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Duplicate Template Modal */}
      {showDuplicateModal && templateToDuplicate && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full dark:bg-gray-800">
            <h2 className="text-xl font-bold text-gray-900 mb-4 dark:text-white">Duplicate Template</h2>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                New Template Name
              </label>
              <input
                type="text"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                value={newTemplateName}
                onChange={(e) => setNewTemplateName(e.target.value)}
                required
              />
            </div>
            
            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowDuplicateModal(false);
                  setTemplateToDuplicate(null);
                  setNewTemplateName('');
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700"
              >
                Cancel
              </button>
              <button
                onClick={handleDuplicateTemplate}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600"
                disabled={!newTemplateName.trim()}
              >
                Duplicate
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Create Campaign Modal */}
      {showCreateCampaignModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full dark:bg-gray-800">
            <h2 className="text-xl font-bold text-gray-900 mb-4 dark:text-white">Create Campaign</h2>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                  Campaign Name
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  value={newCampaignName}
                  onChange={(e) => setNewCampaignName(e.target.value)}
                  placeholder="e.g., Monthly Newsletter - June 2025"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                  Select Template
                </label>
                <select
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  value={selectedTemplateId}
                  onChange={(e) => setSelectedTemplateId(e.target.value)}
                  required
                >
                  <option value="">Select a template</option>
                  {templates.map(template => (
                    <option key={template.id} value={template.id}>{template.name}</option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowCreateCampaignModal(false);
                  setNewCampaignName('');
                  setSelectedTemplateId('');
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateCampaign}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600"
                disabled={!newCampaignName.trim() || !selectedTemplateId}
              >
                Create Campaign
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}