import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { ArrowLeft, Save, MapPin, Phone, Mail, Heart, Calendar, Building2, AlertCircle, Trash2, X } from 'lucide-react';

interface Lead {
  id: string;
  name: string;
  email: string;
  phone: string;
  source: string;
  status: string;
  notes: string | null;
  assigned_to: string | null;
  partner_name: string | null;
  wedding_date: string | null;
  venue_id: string | null;
  venue_name: string | null;
  venue_address: string | null;
  lead_date: string;
}

interface Venue {
  id: string;
  name: string;
  address: string;
}

export default function LeadEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [lead, setLead] = useState<Lead | null>(null);
  const [venues, setVenues] = useState<Venue[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [venueSearchTerm, setVenueSearchTerm] = useState('');
  const [showVenueSearch, setShowVenueSearch] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const isNew = id === 'new';

  useEffect(() => {
    fetchVenues();
    if (!isNew) {
      fetchLead();
    } else {
      setLead({
        id: '',
        name: '',
        email: '',
        phone: '',
        source: '',
        status: 'new',
        notes: '',
        assigned_to: null,
        partner_name: '',
        wedding_date: null,
        venue_id: null,
        venue_name: '',
        venue_address: '',
        lead_date: new Date().toISOString().split('T')[0]
      });
      setLoading(false);
    }
  }, [id]);

  async function fetchVenues() {
    try {
      const { data, error } = await supabase
        .from('venues')
        .select('id, name, address');
      
      if (error) throw error;
      setVenues(data || []);
    } catch (err) {
      console.error('Error fetching venues:', err);
    }
  }

  async function fetchLead() {
    try {
      const { data, error } = await supabase
        .from('leads')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      if (!data) throw new Error('Lead not found');

      setLead(data);
    } catch (err) {
      console.error('Error fetching lead:', err);
      setError('Failed to load lead data');
    } finally {
      setLoading(false);
    }
  }

  async function handleDelete() {
    if (!lead) return;
    setDeleting(true);
    setError(null);

    try {
      // Check if lead has any confirmed bookings
      const { data: bookings, error: bookingsError } = await supabase
        .from('bookings')
        .select('id, status')
        .eq('lead_id', lead.id);

      if (bookingsError) throw bookingsError;

      const hasConfirmedBookings = bookings?.some(booking => booking.status === 'confirmed');
      if (hasConfirmedBookings) {
        throw new Error('Cannot delete lead with confirmed bookings');
      }

      // Delete associated quotes
      const { data: quotes } = await supabase
        .from('quotes')
        .select('id')
        .eq('lead_id', lead.id);

      if (quotes && quotes.length > 0) {
        // Delete signed contracts for these quotes
        await supabase
          .from('signed_contracts')
          .delete()
          .in('quote_id', quotes.map(q => q.id));

        // Delete quote services
        await supabase
          .from('quote_services')
          .delete()
          .in('quote_id', quotes.map(q => q.id));

        // Delete the quotes
        await supabase
          .from('quotes')
          .delete()
          .in('id', quotes.map(q => q.id));
      }

      // Delete pending/cancelled bookings
      await supabase
        .from('bookings')
        .delete()
        .eq('lead_id', lead.id)
        .not('status', 'eq', 'confirmed');

      // Finally delete the lead
      const { error: deleteError } = await supabase
        .from('leads')
        .delete()
        .eq('id', lead.id);

      if (deleteError) throw deleteError;

      navigate('/leads');
    } catch (err) {
      console.error('Error deleting lead:', err);
      setError(err instanceof Error ? err.message : 'Failed to delete lead');
      setDeleting(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!lead) return;

    setSaving(true);
    try {
      let venueId = lead.venue_id;
      let venueName = lead.venue_name;
      let venueAddress = lead.venue_address;

      // Create new venue if needed
      if (!venueId && venueName && venueAddress) {
        const { data: venue, error: venueError } = await supabase
          .from('venues')
          .insert({
            name: venueName,
            address: venueAddress
          })
          .select()
          .single();

        if (venueError) throw venueError;
        venueId = venue.id;
        // Clear the name/address since we're using venue_id
        venueName = null;
        venueAddress = null;
      }

      if (isNew) {
        // Create new lead
        const { error } = await supabase
          .from('leads')
          .insert({
            name: lead.name,
            email: lead.email,
            phone: lead.phone,
            source: lead.source,
            status: lead.status,
            notes: lead.notes,
            partner_name: lead.partner_name,
            wedding_date: lead.wedding_date,
            venue_id: venueId,
            venue_name: venueName,
            venue_address: venueAddress,
            lead_date: lead.lead_date
          });

        if (error) throw error;
      } else {
        // Update existing lead
        const { error } = await supabase
          .from('leads')
          .update({
            name: lead.name,
            email: lead.email,
            phone: lead.phone,
            source: lead.source,
            status: lead.status,
            notes: lead.notes,
            partner_name: lead.partner_name,
            wedding_date: lead.wedding_date,
            venue_id: venueId,
            venue_name: venueName,
            venue_address: venueAddress,
            lead_date: lead.lead_date
          })
          .eq('id', id);

        if (error) throw error;
      }

      navigate('/leads');
    } catch (err) {
      console.error('Error updating lead:', err);
      setError('Failed to save lead');
    } finally {
      setSaving(false);
    }
  }

  const selectVenue = (venue: Venue) => {
    if (!lead) return;
    setLead({
      ...lead,
      venue_id: venue.id,
      venue_name: venue.name,
      venue_address: venue.address,
    });
    setVenueSearchTerm('');
    setShowVenueSearch(false);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!lead) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-700">Lead not found</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/leads')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">
            {isNew ? 'New Lead' : 'Edit Lead'}
          </h1>
        </div>
      </div>

      <div className="max-w-2xl">
        <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6">
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
              <AlertCircle className="w-5 h-5" />
              {error}
            </div>
          )}

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Name
              </label>
              <input
                type="text"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={lead.name}
                onChange={(e) => setLead({ ...lead, name: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Partner Name
              </label>
              <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500">
                <Heart className="w-5 h-5 text-gray-400 ml-3" />
                <input
                  type="text"
                  className="w-full px-3 py-2 focus:outline-none"
                  value={lead.partner_name || ''}
                  onChange={(e) => setLead({ ...lead, partner_name: e.target.value })}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500">
                <Mail className="w-5 h-5 text-gray-400 ml-3" />
                <input
                  type="email"
                  className="w-full px-3 py-2 focus:outline-none"
                  value={lead.email}
                  onChange={(e) => setLead({ ...lead, email: e.target.value })}
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Phone
              </label>
              <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500">
                <Phone className="w-5 h-5 text-gray-400 ml-3" />
                <input
                  type="tel"
                  className="w-full px-3 py-2 focus:outline-none"
                  value={lead.phone}
                  onChange={(e) => setLead({ ...lead, phone: e.target.value })}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Lead Date
              </label>
              <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500">
                <Calendar className="w-5 h-5 text-gray-400 ml-3" />
                <input
                  type="date"
                  className="w-full px-3 py-2 focus:outline-none"
                  value={lead.lead_date || ''}
                  onChange={(e) => setLead({ ...lead, lead_date: e.target.value })}
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Wedding Date
              </label>
              <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500">
                <Calendar className="w-5 h-5 text-gray-400 ml-3" />
                <input
                  type="date"
                  className="w-full px-3 py-2 focus:outline-none"
                  value={lead.wedding_date || ''}
                  onChange={(e) => setLead({ ...lead, wedding_date: e.target.value })}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Source
              </label>
              <select
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={lead.source}
                onChange={(e) => setLead({ ...lead, source: e.target.value })}
                required
              >
                <option value="">Select source</option>
                <option value="thumbtack">Thumbtack</option>
                <option value="email">Email</option>
                <option value="cold_outreach">Cold Outreach</option>
                <option value="phone">Phone</option>
                <option value="zola">Zola</option>
                <option value="facebook">Facebook</option>
                <option value="instagram">Instagram</option>
                <option value="website">Website</option>
                <option value="referral">Referral</option>
                <option value="social">Social Media</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Status
              </label>
              <select
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={lead.status}
                onChange={(e) => setLead({ ...lead, status: e.target.value })}
                required
              >
                <option value="new">New</option>
                <option value="contacted">Contacted</option>
                <option value="qualified">Qualified</option>
                <option value="proposal">Proposal</option>
                <option value="negotiation">Negotiation</option>
                <option value="booked">Booked</option>
                <option value="closed">Closed</option>
                <option value="lost">Lost</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Venue
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search venues..."
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={venueSearchTerm}
                  onChange={(e) => {
                    setVenueSearchTerm(e.target.value);
                    setShowVenueSearch(true);
                  }}
                  onFocus={() => setShowVenueSearch(true)}
                />
                {showVenueSearch && (
                  <div className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                    {venues
                      .filter(venue => 
                        venue.name.toLowerCase().includes(venueSearchTerm.toLowerCase()) ||
                        venue.address.toLowerCase().includes(venueSearchTerm.toLowerCase())
                      )
                      .map((venue) => (
                        <button
                          key={venue.id}
                          type="button"
                          className="w-full px-4 py-2 text-left hover:bg-gray-50 flex flex-col"
                          onClick={() => selectVenue(venue)}
                        >
                          <span className="font-medium">{venue.name}</span>
                          <span className="text-sm text-gray-500">{venue.address}</span>
                        </button>
                      ))
                    }
                    {venueSearchTerm && (
                      <button
                        type="button"
                        className="w-full px-4 py-2 text-left text-blue-600 hover:bg-gray-50"
                        onClick={() => {
                          setLead({
                            ...lead,
                            venue_id: null,
                            venue_name: venueSearchTerm,
                            venue_address: '',
                          });
                          setShowVenueSearch(false);
                        }}
                      >
                        + Add new venue "{venueSearchTerm}"
                      </button>
                    )}
                  </div>
                )}
              </div>

              {!lead.venue_id && (
                <div className="space-y-2 mt-2">
                  <input
                    type="text"
                    placeholder="Venue name"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={lead.venue_name || ''}
                    onChange={(e) => setLead({
                      ...lead,
                      venue_name: e.target.value,
                    })}
                  />
                  <input
                    type="text"
                    placeholder="Venue address"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={lead.venue_address || ''}
                    onChange={(e) => setLead({
                      ...lead,
                      venue_address: e.target.value,
                    })}
                  />
                </div>
              )}

              {lead.venue_id && (
                <div className="mt-2 p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-gray-400" />
                    <div>
                      <div className="font-medium">{lead.venue_name}</div>
                      <div className="text-sm text-gray-500">{lead.venue_address}</div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Notes
              </label>
              <textarea
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={4}
                value={lead.notes || ''}
                onChange={(e) => setLead({ ...lead, notes: e.target.value })}
              />
            </div>
          </div>

          <div className="mt-6 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setShowDeleteConfirm(true)}
              className="px-4 py-2 text-red-600 hover:text-red-700 border border-red-200 rounded-lg hover:bg-red-50 disabled:opacity-50"
            >
              Delete
            </button>
            <button
              type="button"
              onClick={() => navigate('/leads')}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              disabled={saving}
            >
              <Save className="w-5 h-5" />
              {saving ? 'Saving...' : (isNew ? 'Create Lead' : 'Save Changes')}
            </button>
          </div>
        </form>
      </div>

      {/* Delete confirmation modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Delete Lead</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this lead? This action cannot be undone and will also delete all associated quotes and pending bookings.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                disabled={deleting}
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 flex items-center gap-2"
                disabled={deleting}
              >
                <Trash2 className="w-4 h-4" />
                {deleting ? 'Deleting...' : 'Delete Lead'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}