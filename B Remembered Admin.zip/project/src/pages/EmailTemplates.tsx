import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { 
  PlusCircle, Search, Mail, MessageSquare, Save, Copy, 
  Trash2, Eye, X, CheckCircle, AlertCircle, FileText,
  Edit, ArrowRight, Send, Tag, Calendar
} from 'lucide-react';

interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  content: string;
  type: 'email' | 'sms';
  category: string;
  variables: string[];
  created_at: string;
  updated_at: string;
}

export default function EmailTemplates() {
  const navigate = useNavigate();
  const [templates, setTemplates] = useState<EmailTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'email' | 'sms'>('email');
  const [showPreview, setShowPreview] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [templateToDelete, setTemplateToDelete] = useState<string | null>(null);
  
  // Template editor state
  const [showEditor, setShowEditor] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<EmailTemplate | null>(null);
  const [templateForm, setTemplateForm] = useState({
    name: '',
    subject: '',
    content: '',
    type: 'email' as 'email' | 'sms',
    category: 'general',
    variables: [] as string[]
  });
  const [variableInput, setVariableInput] = useState('');
  
  // Test message state
  const [showTestModal, setShowTestModal] = useState(false);
  const [testRecipient, setTestRecipient] = useState('');
  const [testVariables, setTestVariables] = useState<Record<string, string>>({});
  const [sendingTest, setSendingTest] = useState(false);
  
  const quillRef = useRef<ReactQuill>(null);
  
  // Available template categories
  const categories = [
    'general',
    'welcome',
    'booking',
    'quote',
    'invoice',
    'reminder',
    'confirmation',
    'notification',
    'marketing',
    'follow-up'
  ];
  
  useEffect(() => {
    fetchTemplates();
  }, [activeTab]);
  
  async function fetchTemplates() {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('email_templates')
        .select('*')
        .eq('type', activeTab)
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      setTemplates(data || []);
    } catch (err) {
      console.error('Error fetching templates:', err);
      setError('Failed to load templates');
    } finally {
      setLoading(false);
    }
  }
  
  function handleCreateTemplate() {
    setEditingTemplate(null);
    setTemplateForm({
      name: '',
      subject: activeTab === 'email' ? 'New Email Subject' : '',
      content: activeTab === 'email' 
        ? `<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h1>Hello {{name}},</h1>
            <p>This is a new email template.</p>
            <p>You can customize this content.</p>
            <p>Best regards,<br>Your Team</p>
          </div>`
        : 'Hello {{name}}, this is a new text message template.',
      type: activeTab,
      category: 'general',
      variables: ['name']
    });
    setShowEditor(true);
  }
  
  function handleEditTemplate(template: EmailTemplate) {
    setEditingTemplate(template);
    setTemplateForm({
      name: template.name,
      subject: template.subject || '',
      content: template.content,
      type: template.type,
      category: template.category,
      variables: template.variables || []
    });
    setShowEditor(true);
  }
  
  function handleDuplicateTemplate(template: EmailTemplate) {
    setEditingTemplate(null);
    setTemplateForm({
      name: `${template.name} (Copy)`,
      subject: template.subject || '',
      content: template.content,
      type: template.type,
      category: template.category,
      variables: template.variables || []
    });
    setShowEditor(true);
  }
  
  async function handleSaveTemplate() {
    try {
      const templateData = {
        name: templateForm.name,
        subject: templateForm.type === 'email' ? templateForm.subject : null,
        content: templateForm.content,
        type: templateForm.type,
        category: templateForm.category,
        variables: templateForm.variables
      };
      
      if (editingTemplate) {
        // Update existing template
        const { error } = await supabase
          .from('email_templates')
          .update(templateData)
          .eq('id', editingTemplate.id);
          
        if (error) throw error;
        
        setSuccess('Template updated successfully');
      } else {
        // Create new template
        const { error } = await supabase
          .from('email_templates')
          .insert([templateData]);
          
        if (error) throw error;
        
        setSuccess('Template created successfully');
      }
      
      // Refresh templates and close editor
      fetchTemplates();
      setShowEditor(false);
    } catch (err) {
      console.error('Error saving template:', err);
      setError('Failed to save template');
    }
  }
  
  async function handleDeleteTemplate() {
    if (!templateToDelete) return;
    
    try {
      const { error } = await supabase
        .from('email_templates')
        .delete()
        .eq('id', templateToDelete);
        
      if (error) throw error;
      
      setTemplates(templates.filter(t => t.id !== templateToDelete));
      setShowDeleteConfirm(false);
      setTemplateToDelete(null);
      setSuccess('Template deleted successfully');
    } catch (err) {
      console.error('Error deleting template:', err);
      setError('Failed to delete template');
    }
  }
  
  function handleAddVariable() {
    if (!variableInput.trim()) return;
    
    // Format variable name (remove spaces, special chars)
    const formattedVariable = variableInput.trim()
      .toLowerCase()
      .replace(/[^a-z0-9_]/g, '_');
    
    if (!templateForm.variables.includes(formattedVariable)) {
      setTemplateForm({
        ...templateForm,
        variables: [...templateForm.variables, formattedVariable]
      });
    }
    
    setVariableInput('');
  }
  
  function handleRemoveVariable(variable: string) {
    setTemplateForm({
      ...templateForm,
      variables: templateForm.variables.filter(v => v !== variable)
    });
  }
  
  function insertVariable(variable: string) {
    if (quillRef.current && activeTab === 'email') {
      const editor = quillRef.current.getEditor();
      const cursorPosition = editor.getSelection()?.index || 0;
      editor.insertText(cursorPosition, `{{${variable}}}`);
      editor.setSelection(cursorPosition + variable.length + 4);
    } else if (activeTab === 'sms') {
      // For SMS templates, insert at cursor position in textarea
      const textarea = document.getElementById('sms-content') as HTMLTextAreaElement;
      if (textarea) {
        const cursorPosition = textarea.selectionStart;
        const textBefore = templateForm.content.substring(0, cursorPosition);
        const textAfter = templateForm.content.substring(cursorPosition);
        setTemplateForm({
          ...templateForm,
          content: `${textBefore}{{${variable}}}${textAfter}`
        });
      }
    }
  }
  
  function handleOpenTestModal(template: EmailTemplate) {
    // Initialize test variables with empty values
    const initialVariables: Record<string, string> = {};
    template.variables.forEach(variable => {
      initialVariables[variable] = '';
    });
    
    setTestRecipient('');
    setTestVariables(initialVariables);
    setShowTestModal(true);
  }
  
  async function handleSendTest() {
    if (!editingTemplate) return;
    
    setSendingTest(true);
    try {
      // Call the edge function to send a test message
      const response = await fetch('/functions/v1/send-test-message', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          templateId: editingTemplate.id,
          recipient: testRecipient,
          variables: testVariables,
          type: editingTemplate.type
        }),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to send test message');
      }
      
      setSuccess(`Test ${editingTemplate.type} sent successfully`);
      setShowTestModal(false);
    } catch (err) {
      console.error('Error sending test message:', err);
      setError(err instanceof Error ? err.message : 'Failed to send test message');
    } finally {
      setSendingTest(false);
    }
  }
  
  // Filter templates based on search term
  const filteredTemplates = templates.filter(template => 
    template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (template.subject && template.subject.toLowerCase().includes(searchTerm.toLowerCase())) ||
    template.category.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // Quill editor modules configuration
  const modules = {
    toolbar: [
      [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      [{ 'color': [] }, { 'background': [] }],
      [{ 'align': [] }],
      ['link', 'image'],
      ['clean']
    ],
  };
  
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Message Templates</h1>
        <button
          onClick={handleCreateTemplate}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <PlusCircle className="w-5 h-5" />
          New Template
        </button>
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}
      
      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}
      
      {/* Tabs */}
      <div className="mb-6 border-b border-gray-200">
        <div className="flex space-x-8">
          <button
            onClick={() => setActiveTab('email')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'email'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <div className="flex items-center gap-2">
              <Mail className="w-5 h-5" />
              Email Templates
            </div>
          </button>
          <button
            onClick={() => setActiveTab('sms')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'sms'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <div className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5" />
              SMS Templates
            </div>
          </button>
        </div>
      </div>
      
      {/* Search */}
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder={`Search ${activeTab} templates...`}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      
      {/* Templates Grid */}
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : filteredTemplates.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow-md">
          <div className="flex justify-center mb-4">
            {activeTab === 'email' ? (
              <Mail className="w-16 h-16 text-gray-400" />
            ) : (
              <MessageSquare className="w-16 h-16 text-gray-400" />
            )}
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No templates found</h3>
          <p className="text-gray-500 mb-6">
            {searchTerm ? 'Try adjusting your search terms' : `Get started by creating your first ${activeTab} template`}
          </p>
          <button
            onClick={handleCreateTemplate}
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <PlusCircle className="w-5 h-5" />
            Create Template
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTemplates.map(template => (
            <div 
              key={template.id} 
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
            >
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">{template.name}</h3>
                    <div className="flex items-center mt-1">
                      <Tag className="w-4 h-4 text-gray-400 mr-1" />
                      <span className="text-sm text-gray-500 capitalize">{template.category}</span>
                    </div>
                  </div>
                  <div className="flex items-center">
                    {activeTab === 'email' ? (
                      <Mail className="w-5 h-5 text-blue-500" />
                    ) : (
                      <MessageSquare className="w-5 h-5 text-green-500" />
                    )}
                  </div>
                </div>
                
                <div className="mb-4">
                  {activeTab === 'email' && template.subject && (
                    <div className="text-sm font-medium text-gray-700 mb-1">
                      Subject: <span className="font-normal text-gray-600">{template.subject}</span>
                    </div>
                  )}
                  <div className="text-sm text-gray-500 line-clamp-3">
                    {activeTab === 'email' ? (
                      <div dangerouslySetInnerHTML={{ __html: template.content.substring(0, 150) + '...' }} />
                    ) : (
                      template.content.substring(0, 150) + (template.content.length > 150 ? '...' : '')
                    )}
                  </div>
                </div>
                
                {template.variables && template.variables.length > 0 && (
                  <div className="mb-4">
                    <div className="text-xs text-gray-500 mb-1">Variables:</div>
                    <div className="flex flex-wrap gap-1">
                      {template.variables.map(variable => (
                        <span 
                          key={variable} 
                          className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full"
                        >
                          {`{{${variable}}}`}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="flex justify-between items-center mt-4 pt-4 border-t border-gray-100">
                  <div className="text-xs text-gray-500">
                    <Calendar className="w-3 h-3 inline mr-1" />
                    {new Date(template.updated_at).toLocaleDateString()}
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleEditTemplate(template)}
                      className="p-1 text-blue-600 hover:text-blue-800"
                      title="Edit"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDuplicateTemplate(template)}
                      className="p-1 text-green-600 hover:text-green-800"
                      title="Duplicate"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        setEditingTemplate(template);
                        handleOpenTestModal(template);
                      }}
                      className="p-1 text-purple-600 hover:text-purple-800"
                      title="Send Test"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        setTemplateToDelete(template.id);
                        setShowDeleteConfirm(true);
                      }}
                      className="p-1 text-red-600 hover:text-red-800"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {/* Template Editor Modal */}
      {showEditor && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center p-6 border-b border-gray-200">
              <h2 className="text-xl font-bold text-gray-900">
                {editingTemplate ? 'Edit Template' : 'Create Template'}
              </h2>
              <button
                onClick={() => setShowEditor(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Template Name
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={templateForm.name}
                    onChange={(e) => setTemplateForm({ ...templateForm, name: e.target.value })}
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Category
                  </label>
                  <select
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={templateForm.category}
                    onChange={(e) => setTemplateForm({ ...templateForm, category: e.target.value })}
                  >
                    {categories.map(category => (
                      <option key={category} value={category}>
                        {category.charAt(0).toUpperCase() + category.slice(1)}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              
              {activeTab === 'email' && (
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Subject Line
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={templateForm.subject}
                    onChange={(e) => setTemplateForm({ ...templateForm, subject: e.target.value })}
                    required
                  />
                </div>
              )}
              
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Template Variables
                </label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    className="flex-1 border border-gray-300 rounded-lg px-3 py-2"
                    value={variableInput}
                    onChange={(e) => setVariableInput(e.target.value)}
                    placeholder="Add a variable (e.g. name, date)"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddVariable();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddVariable}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Add
                  </button>
                </div>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {templateForm.variables.map(variable => (
                    <div 
                      key={variable} 
                      className="flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-800 rounded-full"
                    >
                      <span>{`{{${variable}}}`}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveVariable(variable)}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
                
                {templateForm.variables.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-2">
                    {templateForm.variables.map(variable => (
                      <button
                        key={variable}
                        type="button"
                        onClick={() => insertVariable(variable)}
                        className="px-3 py-1 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
                      >
                        Insert {`{{${variable}}}`}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Content
                </label>
                {activeTab === 'email' ? (
                  <div className="border border-gray-300 rounded-lg">
                    <ReactQuill
                      ref={quillRef}
                      theme="snow"
                      value={templateForm.content}
                      onChange={(content) => setTemplateForm({ ...templateForm, content })}
                      modules={modules}
                      className="h-64"
                    />
                  </div>
                ) : (
                  <textarea
                    id="sms-content"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    rows={6}
                    value={templateForm.content}
                    onChange={(e) => setTemplateForm({ ...templateForm, content: e.target.value })}
                    required
                  />
                )}
                
                {activeTab === 'sms' && (
                  <div className="mt-2 text-sm text-gray-500 flex justify-between">
                    <span>Character count: {templateForm.content.length}</span>
                    <span>
                      {templateForm.content.length > 160 ? 
                        `${Math.ceil(templateForm.content.length / 160)} messages` : 
                        '1 message'}
                    </span>
                  </div>
                )}
              </div>
              
              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={() => setShowPreview(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
                >
                  <Eye className="w-5 h-5" />
                  Preview
                </button>
                
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setShowEditor(false)}
                    className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveTemplate}
                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    <Save className="w-5 h-5" />
                    Save Template
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Preview Modal */}
      {showPreview && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center p-6 border-b border-gray-200">
              <h2 className="text-xl font-bold text-gray-900">Template Preview</h2>
              <button
                onClick={() => setShowPreview(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6">
              {activeTab === 'email' ? (
                <div className="border border-gray-200 rounded-lg p-4">
                  <div className="mb-4 pb-4 border-b border-gray-200">
                    <div className="text-sm text-gray-500">From: B. Remembered Weddings &lt;noreply@b-remembered.com&gt;</div>
                    <div className="text-sm text-gray-500">To: [Recipient]</div>
                    <div className="text-sm text-gray-500">Subject: {templateForm.subject}</div>
                  </div>
                  <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: templateForm.content }} />
                </div>
              ) : (
                <div className="border border-gray-200 rounded-lg p-4">
                  <div className="mb-4 pb-4 border-b border-gray-200">
                    <div className="text-sm text-gray-500">From: B. Remembered Weddings</div>
                    <div className="text-sm text-gray-500">To: [Recipient Phone]</div>
                  </div>
                  <div className="bg-gray-100 p-4 rounded-lg max-w-xs mx-auto">
                    <p className="text-gray-800 whitespace-pre-wrap">{templateForm.content}</p>
                  </div>
                </div>
              )}
              
              <div className="mt-6 flex justify-end">
                <button
                  type="button"
                  onClick={() => setShowPreview(false)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Close Preview
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Test Message Modal */}
      {showTestModal && editingTemplate && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center p-6 border-b border-gray-200">
              <h2 className="text-xl font-bold text-gray-900">
                Send Test {editingTemplate.type === 'email' ? 'Email' : 'SMS'}
              </h2>
              <button
                onClick={() => setShowTestModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6">
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {editingTemplate.type === 'email' ? 'Recipient Email' : 'Recipient Phone Number'}
                </label>
                <input
                  type={editingTemplate.type === 'email' ? 'email' : 'tel'}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  value={testRecipient}
                  onChange={(e) => setTestRecipient(e.target.value)}
                  placeholder={editingTemplate.type === 'email' ? 'email@example.com' : '+1 (555) 123-4567'}
                  required
                />
                {editingTemplate.type === 'sms' && (
                  <p className="mt-1 text-sm text-gray-500">
                    Enter phone number in E.164 format (e.g., +15551234567)
                  </p>
                )}
              </div>
              
              {editingTemplate.variables && editingTemplate.variables.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-700 mb-3">Template Variables</h3>
                  <div className="space-y-3">
                    {editingTemplate.variables.map(variable => (
                      <div key={variable}>
                        <label className="block text-sm text-gray-600 mb-1">
                          {variable}
                        </label>
                        <input
                          type="text"
                          className="w-full border border-gray-300 rounded-lg px-3 py-2"
                          value={testVariables[variable] || ''}
                          onChange={(e) => setTestVariables({
                            ...testVariables,
                            [variable]: e.target.value
                          })}
                          placeholder={`Value for {{${variable}}}`}
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              <div className="flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowTestModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSendTest}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  disabled={!testRecipient || sendingTest}
                >
                  {sendingTest ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      Send Test
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Delete Template</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this template? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowDeleteConfirm(false);
                  setTemplateToDelete(null);
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteTemplate}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Delete Template
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}