import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { supabase } from '../lib/supabase';
import { ArrowLeft, Save, Eye, EyeOff, Archive, Calendar, User, AlertCircle, X, Upload, Image as ImageIcon } from 'lucide-react';

interface BlogPost {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string | null;
  featured_image: string | null;
  author_id: string | null;
  status: 'draft' | 'scheduled' | 'published' | 'archived';
  visibility: 'public' | 'private';
  published_at: string | null;
  scheduled_for: string | null;
  meta_title: string | null;
  meta_description: string | null;
  tags: string[];
}

interface UploadProgress {
  [key: string]: number;
}

export default function BlogEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<UploadProgress>({});
  const [post, setPost] = useState<BlogPost>({
    id: '',
    title: '',
    slug: '',
    content: '',
    excerpt: '',
    featured_image: null,
    author_id: null,
    status: 'draft',
    visibility: 'public',
    published_at: null,
    scheduled_for: null,
    meta_title: '',
    meta_description: '',
    tags: [],
  });
  const [tagInput, setTagInput] = useState('');

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.gif', '.webp']
    },
    maxFiles: 1,
    onDrop: handleImageDrop
  });

  useEffect(() => {
    if (id !== 'new') {
      fetchPost();
    } else {
      setLoading(false);
    }
  }, [id]);

  async function fetchPost() {
    try {
      const { data, error } = await supabase
        .from('blog_posts')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      if (data) {
        setPost(data);
      }
    } catch (err) {
      console.error('Error fetching post:', err);
      setError('Failed to load post');
    } finally {
      setLoading(false);
    }
  }

  async function handleImageDrop(acceptedFiles: File[]) {
    const file = acceptedFiles[0];
    if (!file) return;

    const fileId = Math.random().toString(36).substring(7);
    setUploadProgress(prev => ({ ...prev, [fileId]: 0 }));

    try {
      // Create a unique file path
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
      const filePath = `${id === 'new' ? 'temp' : id}/${fileName}`;

      // Upload the file
      const { error: uploadError } = await supabase.storage
        .from('blog-images')
        .upload(filePath, file, {
          onUploadProgress: (progress) => {
            const percent = (progress.loaded / progress.total) * 100;
            setUploadProgress(prev => ({ ...prev, [fileId]: percent }));
          }
        });

      if (uploadError) throw uploadError;

      // Get the public URL
      const { data: { publicUrl } } = supabase.storage
        .from('blog-images')
        .getPublicUrl(filePath);

      // Update the post with the new image URL
      setPost(prev => ({
        ...prev,
        featured_image: publicUrl
      }));

      // Clean up progress indicator
      setUploadProgress(prev => {
        const newProgress = { ...prev };
        delete newProgress[fileId];
        return newProgress;
      });
    } catch (err) {
      console.error('Error uploading image:', err);
      setError('Failed to upload image');
      setUploadProgress(prev => {
        const newProgress = { ...prev };
        delete newProgress[fileId];
        return newProgress;
      });
    }
  }

  async function handleRemoveImage() {
    if (!post.featured_image) return;

    try {
      // Extract the file path from the URL
      const url = new URL(post.featured_image);
      const pathParts = url.pathname.split('/');
      const filePath = pathParts.slice(pathParts.indexOf('blog-images') + 1).join('/');

      // Delete the file from storage
      const { error: deleteError } = await supabase.storage
        .from('blog-images')
        .remove([filePath]);

      if (deleteError) throw deleteError;

      // Update the post
      setPost(prev => ({
        ...prev,
        featured_image: null
      }));
    } catch (err) {
      console.error('Error removing image:', err);
      setError('Failed to remove image');
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    try {
      // Generate slug from title if not set
      const slug = post.slug || post.title.toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');

      // Get current user's team member ID
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data: teamMember } = await supabase
        .from('team_members')
        .select('id')
        .eq('user_id', user.id)
        .single();

      if (!teamMember) throw new Error('Team member not found');

      const postData = {
        ...post,
        slug,
        author_id: post.author_id || teamMember.id,
        published_at: post.status === 'published' && !post.published_at 
          ? new Date().toISOString()
          : post.published_at
      };

      if (id === 'new') {
        const { data, error } = await supabase
          .from('blog_posts')
          .insert([postData])
          .select()
          .single();

        if (error) throw error;

        // If there's a featured image in the temp folder, move it to the new post's folder
        if (post.featured_image && post.featured_image.includes('/temp/')) {
          const oldPath = new URL(post.featured_image).pathname.split('/').pop();
          const newPath = `${data.id}/${oldPath}`;

          // Copy the file to the new location
          const { error: moveError } = await supabase.storage
            .from('blog-images')
            .copy(`temp/${oldPath}`, newPath);

          if (moveError) throw moveError;

          // Delete the temp file
          await supabase.storage
            .from('blog-images')
            .remove([`temp/${oldPath}`]);

          // Update the post with the new image URL
          const { data: { publicUrl } } = supabase.storage
            .from('blog-images')
            .getPublicUrl(newPath);

          await supabase
            .from('blog_posts')
            .update({ featured_image: publicUrl })
            .eq('id', data.id);
        }
      } else {
        const { error } = await supabase
          .from('blog_posts')
          .update(postData)
          .eq('id', id);

        if (error) throw error;
      }

      navigate('/blog');
    } catch (err) {
      console.error('Error saving post:', err);
      setError(err instanceof Error ? err.message : 'Failed to save post');
      setSaving(false);
    }
  }

  const handleAddTag = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && tagInput.trim()) {
      e.preventDefault();
      if (!post.tags.includes(tagInput.trim())) {
        setPost({
          ...post,
          tags: [...post.tags, tagInput.trim()]
        });
      }
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setPost({
      ...post,
      tags: post.tags.filter(tag => tag !== tagToRemove)
    });
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/blog')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">
            {id === 'new' ? 'New Blog Post' : 'Edit Blog Post'}
          </h1>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="max-w-4xl">
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
            <AlertCircle className="w-5 h-5" />
            {error}
          </div>
        )}

        <div className="grid grid-cols-3 gap-8">
          <div className="col-span-2 space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Title
              </label>
              <input
                type="text"
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
                value={post.title}
                onChange={(e) => setPost({ ...post, title: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Slug
              </label>
              <input
                type="text"
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
                value={post.slug}
                onChange={(e) => setPost({ ...post, slug: e.target.value })}
                placeholder="Generated from title if left empty"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Content
              </label>
              <textarea
                className="w-full border border-gray-300 rounded-lg px-3 py-2 font-mono"
                rows={20}
                value={post.content}
                onChange={(e) => setPost({ ...post, content: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md p-4">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Publishing</h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Status
                  </label>
                  <select
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={post.status}
                    onChange={(e) => {
                      const newStatus = e.target.value as BlogPost['status'];
                      setPost(prev => ({
                        ...prev,
                        status: newStatus,
                        // Clear scheduling/publishing dates when changing status
                        scheduled_for: newStatus === 'scheduled' ? prev.scheduled_for : null,
                        published_at: newStatus === 'published' ? prev.published_at : null
                      }));
                    }}
                  >
                    <option value="draft">Draft</option>
                    <option value="scheduled">Scheduled</option>
                    <option value="published">Published</option>
                    <option value="archived">Archived</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Visibility
                  </label>
                  <div className="flex items-center gap-4">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        checked={post.visibility === 'public'}
                        onChange={() => setPost({ ...post, visibility: 'public' })}
                        className="text-blue-600 focus:ring-blue-500"
                      />
                      <div className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        <span>Public</span>
                      </div>
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        checked={post.visibility === 'private'}
                        onChange={() => setPost({ ...post, visibility: 'private' })}
                        className="text-blue-600 focus:ring-blue-500"
                      />
                      <div className="flex items-center gap-1">
                        <EyeOff className="w-4 h-4" />
                        <span>Private</span>
                      </div>
                    </label>
                  </div>
                </div>

                {post.status === 'scheduled' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Schedule Publication
                    </label>
                    <div className="space-y-2">
                      <input
                        type="datetime-local"
                        className="w-full border border-gray-300 rounded-lg px-3 py-2"
                        value={post.scheduled_for ? new Date(post.scheduled_for).toISOString().slice(0, 16) : ''}
                        onChange={(e) => {
                          const date = e.target.value ? new Date(e.target.value) : null;
                          setPost({ 
                            ...post, 
                            scheduled_for: date?.toISOString() || null,
                            // Clear published_at when scheduling
                            published_at: null
                          });
                        }}
                        min={new Date().toISOString().slice(0, 16)}
                        required
                      />
                      {post.scheduled_for && (
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Calendar className="w-4 h-4" />
                          <span>
                            Will be published on {new Date(post.scheduled_for).toLocaleString()}
                          </span>
                          <button
                            type="button"
                            onClick={() => setPost({ ...post, scheduled_for: null })}
                            className="text-gray-400 hover:text-gray-600"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {post.status === 'published' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Published Date
                    </label>
                    <input
                      type="datetime-local"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      value={post.published_at ? new Date(post.published_at).toISOString().slice(0, 16) : ''}
                      onChange={(e) => setPost({ 
                        ...post, 
                        published_at: e.target.value ? new Date(e.target.value).toISOString() : null,
                        // Clear scheduled_for when manually publishing
                        scheduled_for: null
                      })}
                    />
                  </div>
                )}
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md p-4">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Tags</h2>
              <div className="space-y-4">
                <div>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    placeholder="Add a tag and press Enter"
                    value={tagInput}
                    onChange={(e) => setTagInput(e.target.value)}
                    onKeyDown={handleAddTag}
                  />
                </div>

                <div className="flex flex-wrap gap-2">
                  {post.tags.map((tag) => (
                    <span
                      key={tag}
                      className="inline-flex items-center gap-1 px-2 py-1 rounded bg-blue-100 text-blue-800"
                    >
                      {tag}
                      <button
                        type="button"
                        onClick={() => handleRemoveTag(tag)}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md p-4">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">SEO</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Meta Title
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={post.meta_title || ''}
                    onChange={(e) => setPost({ ...post, meta_title: e.target.value })}
                    placeholder="Leave empty to use post title"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Meta Description
                  </label>
                  <textarea
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    rows={3}
                    value={post.meta_description || ''}
                    onChange={(e) => setPost({ ...post, meta_description: e.target.value })}
                    placeholder="Brief description for search engines"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md p-4">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Featured Image</h2>
              
              {post.featured_image ? (
                <div className="space-y-4">
                  <div className="relative">
                    <img
                      src={post.featured_image}
                      alt="Featured"
                      className="w-full h-48 object-cover rounded-lg"
                    />
                    <button
                      type="button"
                      onClick={handleRemoveImage}
                      className="absolute top-2 right-2 p-1 bg-red-600 text-white rounded-full hover:bg-red-700"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="text-sm text-gray-500 break-all">
                    {post.featured_image}
                  </div>
                </div>
              ) : (
                <div 
                  {...getRootProps()} 
                  className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
                    isDragActive ? 'border-blue-400 bg-blue-50' : 'border-gray-300 hover:border-gray-400'
                  }`}
                >
                  <input {...getInputProps()} />
                  <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-600">
                    {isDragActive ? 'Drop image here' : 'Drag & drop an image here, or click to select'}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">
                    Supported formats: JPEG, PNG, GIF, WebP
                  </p>
                </div>
              )}

              {/* Upload Progress */}
              {Object.entries(uploadProgress).map(([fileId, progress]) => (
                <div key={fileId} className="mt-4">
                  <div className="flex justify-between text-sm text-gray-600 mb-1">
                    <span>Uploading image...</span>
                    <span>{Math.round(progress)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-3">
          <button
            type="button"
            onClick={() => navigate('/blog')}
            className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            disabled={saving}
          >
            {saving ? 'Saving...' : (id === 'new' ? 'Create Post' : 'Save Changes')}
          </button>
        </div>
      </form>
    </div>
  );
}