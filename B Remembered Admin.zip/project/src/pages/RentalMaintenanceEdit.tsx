import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  ArrowLeft, Save, Trash2, Calendar, DollarSign, 
  Wrench, User, AlertCircle, CheckCircle, X
} from 'lucide-react';

interface RentalItem {
  id: string;
  name: string;
  status: string;
}

interface RentalMaintenance {
  id: string;
  rental_item_id: string;
  maintenance_type: string;
  description: string;
  cost: number;
  performed_by: string | null;
  scheduled_date: string | null;
  completed_date: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
  rental_item?: RentalItem;
}

export default function RentalMaintenanceEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [maintenance, setMaintenance] = useState<Partial<RentalMaintenance>>({
    rental_item_id: '',
    maintenance_type: '',
    description: '',
    cost: 0,
    performed_by: '',
    scheduled_date: new Date().toISOString().split('T')[0],
    completed_date: null,
    notes: ''
  });
  const [rentalItems, setRentalItems] = useState<RentalItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const isNew = id === 'new';
  const itemIdFromUrl = new URLSearchParams(window.location.search).get('itemId');

  useEffect(() => {
    fetchRentalItems();
    if (!isNew) {
      fetchMaintenance();
    } else {
      if (itemIdFromUrl) {
        setMaintenance(prev => ({ ...prev, rental_item_id: itemIdFromUrl }));
      }
      setLoading(false);
    }
  }, [id, itemIdFromUrl]);

  async function fetchRentalItems() {
    try {
      const { data, error } = await supabase
        .from('rental_items')
        .select('id, name, status')
        .order('name');

      if (error) throw error;
      setRentalItems(data || []);
    } catch (err) {
      console.error('Error fetching rental items:', err);
      setError('Failed to load rental items');
    }
  }

  async function fetchMaintenance() {
    try {
      const { data, error } = await supabase
        .from('rental_maintenance')
        .select(`
          *,
          rental_item:rental_items(id, name, status)
        `)
        .eq('id', id)
        .single();

      if (error) throw error;
      setMaintenance(data);
    } catch (err) {
      console.error('Error fetching maintenance record:', err);
      setError('Failed to load maintenance record');
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSuccess(null);

    try {
      if (isNew) {
        // Create new maintenance record
        const { data, error } = await supabase
          .from('rental_maintenance')
          .insert({
            rental_item_id: maintenance.rental_item_id,
            maintenance_type: maintenance.maintenance_type,
            description: maintenance.description,
            cost: maintenance.cost,
            performed_by: maintenance.performed_by || null,
            scheduled_date: maintenance.scheduled_date,
            completed_date: maintenance.completed_date,
            notes: maintenance.notes
          })
          .select()
          .single();

        if (error) throw error;

        // If maintenance is scheduled but not completed, update item status
        if (maintenance.scheduled_date && !maintenance.completed_date) {
          const { error: updateError } = await supabase
            .from('rental_items')
            .update({ status: 'maintenance' })
            .eq('id', maintenance.rental_item_id);

          if (updateError) throw updateError;
        }

        setSuccess('Maintenance record created successfully');
        setTimeout(() => {
          navigate('/rentals');
        }, 1500);
      } else {
        // Update existing maintenance record
        const { error } = await supabase
          .from('rental_maintenance')
          .update({
            maintenance_type: maintenance.maintenance_type,
            description: maintenance.description,
            cost: maintenance.cost,
            performed_by: maintenance.performed_by || null,
            scheduled_date: maintenance.scheduled_date,
            completed_date: maintenance.completed_date,
            notes: maintenance.notes
          })
          .eq('id', id);

        if (error) throw error;

        // Update rental item status based on maintenance status
        if (maintenance.completed_date) {
          // If maintenance is completed, set item back to available
          const { error: updateError } = await supabase
            .from('rental_items')
            .update({ status: 'available' })
            .eq('id', maintenance.rental_item_id);

          if (updateError) throw updateError;
        } else if (maintenance.scheduled_date) {
          // If maintenance is scheduled but not completed, keep in maintenance
          const { error: updateError } = await supabase
            .from('rental_items')
            .update({ status: 'maintenance' })
            .eq('id', maintenance.rental_item_id);

          if (updateError) throw updateError;
        }

        setSuccess('Maintenance record updated successfully');
        setTimeout(() => {
          navigate('/rentals');
        }, 1500);
      }
    } catch (err) {
      console.error('Error saving maintenance record:', err);
      setError(err instanceof Error ? err.message : 'Failed to save maintenance record');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    if (!maintenance.id) return;
    setSaving(true);
    setError(null);

    try {
      // Delete the maintenance record
      const { error } = await supabase
        .from('rental_maintenance')
        .delete()
        .eq('id', maintenance.id);

      if (error) throw error;

      // If the item was in maintenance status, check if there are other active maintenance records
      if (maintenance.rental_item?.status === 'maintenance') {
        const { count, error: countError } = await supabase
          .from('rental_maintenance')
          .select('id', { count: 'exact', head: true })
          .eq('rental_item_id', maintenance.rental_item_id)
          .is('completed_date', null)
          .neq('id', maintenance.id);

        if (countError) throw countError;

        // If no other active maintenance records, set item back to available
        if (count === 0) {
          const { error: updateError } = await supabase
            .from('rental_items')
            .update({ status: 'available' })
            .eq('id', maintenance.rental_item_id);

          if (updateError) throw updateError;
        }
      }

      navigate('/rentals');
    } catch (err) {
      console.error('Error deleting maintenance record:', err);
      setError(err instanceof Error ? err.message : 'Failed to delete maintenance record');
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/rentals')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">
            {isNew ? 'New Maintenance Record' : 'Edit Maintenance Record'}
          </h1>
        </div>
        {!isNew && (
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="flex items-center gap-2 px-4 py-2 text-red-600 hover:text-red-700"
          >
            <Trash2 className="w-5 h-5" />
            Delete Record
          </button>
        )}
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6 space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Rental Item *
              </label>
              <select
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
                value={maintenance.rental_item_id}
                onChange={(e) => setMaintenance({ ...maintenance, rental_item_id: e.target.value })}
                disabled={!isNew || !!itemIdFromUrl}
                required
              >
                <option value="">Select a rental item</option>
                {rentalItems.map(item => (
                  <option key={item.id} value={item.id}>{item.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Maintenance Type *
              </label>
              <select
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
                value={maintenance.maintenance_type}
                onChange={(e) => setMaintenance({ ...maintenance, maintenance_type: e.target.value })}
                required
              >
                <option value="">Select maintenance type</option>
                <option value="Routine">Routine Maintenance</option>
                <option value="Repair">Repair</option>
                <option value="Inspection">Inspection</option>
                <option value="Cleaning">Cleaning</option>
                <option value="Upgrade">Upgrade</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description *
              </label>
              <textarea
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
                rows={4}
                value={maintenance.description || ''}
                onChange={(e) => setMaintenance({ ...maintenance, description: e.target.value })}
                required
                placeholder="Describe the maintenance work needed or performed"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Scheduled Date
                </label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="date"
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg"
                    value={maintenance.scheduled_date || ''}
                    onChange={(e) => setMaintenance({ ...maintenance, scheduled_date: e.target.value || null })}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Completed Date
                </label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="date"
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg"
                    value={maintenance.completed_date || ''}
                    onChange={(e) => setMaintenance({ ...maintenance, completed_date: e.target.value || null })}
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Cost
                </label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="number"
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg"
                    value={maintenance.cost || 0}
                    onChange={(e) => setMaintenance({ ...maintenance, cost: parseFloat(e.target.value) || 0 })}
                    min="0"
                    step="0.01"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Performed By
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg"
                    value={maintenance.performed_by || ''}
                    onChange={(e) => setMaintenance({ ...maintenance, performed_by: e.target.value })}
                    placeholder="Name of technician or company"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Notes
              </label>
              <textarea
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
                rows={3}
                value={maintenance.notes || ''}
                onChange={(e) => setMaintenance({ ...maintenance, notes: e.target.value })}
                placeholder="Additional notes or instructions"
              />
            </div>

            <div className="pt-6 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => navigate('/rentals')}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                disabled={saving}
              >
                <Save className="w-5 h-5" />
                {saving ? 'Saving...' : (isNew ? 'Create Record' : 'Save Changes')}
              </button>
            </div>
          </form>
        </div>

        <div>
          {maintenance.rental_item_id && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Maintenance Tips</h2>
              <div className="space-y-4">
                <div className="flex items-start">
                  <Wrench className="w-5 h-5 text-blue-500 mt-0.5 mr-3" />
                  <div>
                    <h3 className="font-medium text-gray-900">Regular Maintenance</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      Regular maintenance helps extend the life of rental equipment and prevents unexpected breakdowns.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Calendar className="w-5 h-5 text-blue-500 mt-0.5 mr-3" />
                  <div>
                    <h3 className="font-medium text-gray-900">Schedule Wisely</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      Try to schedule maintenance during off-peak times to minimize impact on rental availability.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <DollarSign className="w-5 h-5 text-blue-500 mt-0.5 mr-3" />
                  <div>
                    <h3 className="font-medium text-gray-900">Track Costs</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      Keeping detailed records of maintenance costs helps with budgeting and identifying items that may need replacement.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Delete Maintenance Record</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this maintenance record? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Delete Record
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}