import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  PlusCircle, Search, Filter, Calendar, DollarSign, Percent,
  Tag, CheckCircle, XCircle, AlertCircle, X, Eye, EyeOff
} from 'lucide-react';

interface Discount {
  id: string;
  name: string;
  code: string;
  type: 'percentage' | 'fixed';
  value: number;
  description: string | null;
  valid_from: string;
  valid_until: string | null;
  max_uses: number | null;
  used_count: number;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
  services: Array<{
    service_id: string | null;
    variant_id: string | null;
    service?: {
      name: string;
      variant?: {
        name: string;
      };
    };
  }>;
}

interface Service {
  id: string;
  name: string;
  variants: Array<{
    id: string;
    name: string;
  }>;
}

export default function Discounts() {
  const navigate = useNavigate();
  const [discounts, setDiscounts] = useState<Discount[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');

  const [newDiscount, setNewDiscount] = useState({
    name: '',
    code: '',
    type: 'percentage' as 'percentage' | 'fixed',
    value: '',
    description: '',
    valid_from: new Date().toISOString().split('T')[0],
    valid_until: '',
    max_uses: '',
    status: 'active' as 'active' | 'inactive',
    applyTo: 'all' as 'all' | 'specific',
    selectedServices: [] as Array<{ service_id: string; variant_id: string | null; }>,
  });

  useEffect(() => {
    fetchDiscounts();
    fetchServices();
  }, []);

  async function fetchDiscounts() {
    try {
      const { data, error } = await supabase
        .from('discounts')
        .select(`
          *,
          services:discount_services(
            service_id,
            variant_id,
            service:services(
              name,
              variant:service_variants(name)
            )
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setDiscounts(data || []);
    } catch (err) {
      console.error('Error fetching discounts:', err);
      setError('Failed to load discounts');
    } finally {
      setLoading(false);
    }
  }

  async function fetchServices() {
    try {
      const { data, error } = await supabase
        .from('services')
        .select(`
          id,
          name,
          variants:service_variants(id, name)
        `)
        .eq('visibility', 'visible')
        .order('name');

      if (error) throw error;
      setServices(data || []);
    } catch (err) {
      console.error('Error fetching services:', err);
    }
  }

  async function handleCreateDiscount(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    try {
      // Create the discount
      const { data: discount, error: discountError } = await supabase
        .from('discounts')
        .insert({
          name: newDiscount.name,
          code: newDiscount.code,
          type: newDiscount.type,
          value: parseFloat(newDiscount.value),
          description: newDiscount.description || null,
          valid_from: new Date(newDiscount.valid_from).toISOString(),
          valid_until: newDiscount.valid_until ? new Date(newDiscount.valid_until).toISOString() : null,
          max_uses: newDiscount.max_uses ? parseInt(newDiscount.max_uses) : null,
          status: newDiscount.status,
        })
        .select()
        .single();

      if (discountError) throw discountError;

      // If specific services are selected, create the service links
      if (newDiscount.applyTo === 'specific' && newDiscount.selectedServices.length > 0) {
        const { error: servicesError } = await supabase
          .from('discount_services')
          .insert(
            newDiscount.selectedServices.map(service => ({
              discount_id: discount.id,
              service_id: service.service_id,
              variant_id: service.variant_id,
            }))
          );

        if (servicesError) throw servicesError;
      }

      setShowModal(false);
      setNewDiscount({
        name: '',
        code: '',
        type: 'percentage',
        value: '',
        description: '',
        valid_from: new Date().toISOString().split('T')[0],
        valid_until: '',
        max_uses: '',
        status: 'active',
        applyTo: 'all',
        selectedServices: [],
      });
      fetchDiscounts();
    } catch (err) {
      console.error('Error creating discount:', err);
      setError(err instanceof Error ? err.message : 'Failed to create discount');
    }
  }

  const filteredDiscounts = discounts.filter(discount => {
    const matchesSearch = 
      discount.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      discount.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      discount.description?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'all' || discount.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Discounts</h1>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <PlusCircle className="w-5 h-5" />
          New Discount
        </button>
      </div>

      <div className="mb-6 flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search discounts..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <select
          className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as 'all' | 'active' | 'inactive')}
        >
          <option value="all">All Status</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Code</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Value</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Validity</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Usage</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {loading ? (
              <tr>
                <td colSpan={7} className="px-6 py-4 text-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                </td>
              </tr>
            ) : filteredDiscounts.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-6 py-4 text-center text-gray-500">
                  No discounts found
                </td>
              </tr>
            ) : (
              filteredDiscounts.map((discount) => (
                <tr key={discount.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-gray-900">{discount.name}</div>
                    {discount.description && (
                      <div className="text-sm text-gray-500">{discount.description}</div>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                      {discount.code}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center text-sm text-gray-900">
                      {discount.type === 'percentage' ? (
                        <>
                          <Percent className="w-4 h-4 mr-1" />
                          {discount.value}%
                        </>
                      ) : (
                        <>
                          <DollarSign className="w-4 h-4 mr-1" />
                          {discount.value}
                        </>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900">
                      From: {new Date(discount.valid_from).toLocaleDateString()}
                    </div>
                    {discount.valid_until && (
                      <div className="text-sm text-gray-500">
                        Until: {new Date(discount.valid_until).toLocaleDateString()}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900">
                      {discount.used_count} used
                    </div>
                    {discount.max_uses && (
                      <div className="text-sm text-gray-500">
                        Max: {discount.max_uses}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      discount.status === 'active'
                        ? 'bg-green-100 text-green-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {discount.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm font-medium">
                    <button
                      onClick={() => navigate(`/discounts/${discount.id}`)}
                      className="text-blue-600 hover:text-blue-900"
                    >
                      Edit
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* New Discount Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-gray-900">Create New Discount</h2>
              <button
                onClick={() => setShowModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateDiscount} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Name *
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newDiscount.name}
                    onChange={(e) => setNewDiscount({ ...newDiscount, name: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Code *
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newDiscount.code}
                    onChange={(e) => setNewDiscount({ ...newDiscount, code: e.target.value.toUpperCase() })}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Type *
                  </label>
                  <select
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newDiscount.type}
                    onChange={(e) => setNewDiscount({ 
                      ...newDiscount, 
                      type: e.target.value as 'percentage' | 'fixed'
                    })}
                    required
                  >
                    <option value="percentage">Percentage</option>
                    <option value="fixed">Fixed Amount</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Value *
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                      {newDiscount.type === 'percentage' ? '%' : '$'}
                    </span>
                    <input
                      type="number"
                      className="w-full pl-7 pr-3 py-2 border border-gray-300 rounded-lg"
                      value={newDiscount.value}
                      onChange={(e) => setNewDiscount({ ...newDiscount, value: e.target.value })}
                      min={0}
                      max={newDiscount.type === 'percentage' ? 100 : undefined}
                      step={newDiscount.type === 'percentage' ? 1 : 0.01}
                      required
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  rows={3}
                  value={newDiscount.description}
                  onChange={(e) => setNewDiscount({ ...newDiscount, description: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Valid From *
                  </label>
                  <input
                    type="date"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newDiscount.valid_from}
                    onChange={(e) => setNewDiscount({ ...newDiscount, valid_from: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Valid Until
                  </label>
                  <input
                    type="date"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newDiscount.valid_until}
                    onChange={(e) => setNewDiscount({ ...newDiscount, valid_until: e.target.value })}
                    min={newDiscount.valid_from}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Maximum Uses
                </label>
                <input
                  type="number"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  value={newDiscount.max_uses}
                  onChange={(e) => setNewDiscount({ ...newDiscount, max_uses: e.target.value })}
                  min={1}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Apply To
                </label>
                <div className="space-y-2">
                  <label className="flex items-center gap-2">
                    <input
                      type="radio"
                      checked={newDiscount.applyTo === 'all'}
                      onChange={() => setNewDiscount({ ...newDiscount, applyTo: 'all' })}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <span>All Services</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="radio"
                      checked={newDiscount.applyTo === 'specific'}
                      onChange={() => setNewDiscount({ ...newDiscount, applyTo: 'specific' })}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <span>Specific Services</span>
                  </label>
                </div>
              </div>

              {newDiscount.applyTo === 'specific' && (
                <div className="space-y-4">
                  {services.map((service) => (
                    <div key={service.id} className="border border-gray-200 rounded-lg p-4">
                      <label className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={newDiscount.selectedServices.some(s => s.service_id === service.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setNewDiscount({
                                ...newDiscount,
                                selectedServices: [
                                  ...newDiscount.selectedServices,
                                  { service_id: service.id, variant_id: null }
                                ]
                              });
                            } else {
                              setNewDiscount({
                                ...newDiscount,
                                selectedServices: newDiscount.selectedServices.filter(
                                  s => s.service_id !== service.id
                                )
                              });
                            }
                          }}
                          className="text-blue-600 focus:ring-blue-500"
                        />
                        <span className="font-medium">{service.name}</span>
                      </label>

                      {service.variants.length > 0 && 
                       newDiscount.selectedServices.some(s => s.service_id === service.id) && (
                        <div className="mt-2 ml-6 space-y-2">
                          {service.variants.map((variant) => (
                            <label key={variant.id} className="flex items-center gap-2">
                              <input
                                type="checkbox"
                                checked={newDiscount.selectedServices.some(
                                  s => s.service_id === service.id && s.variant_id === variant.id
                                )}
                                onChange={(e) => {
                                  if (e.target.checked) {
                                    setNewDiscount({
                                      ...newDiscount,
                                      selectedServices: [
                                        ...newDiscount.selectedServices,
                                        { service_id: service.id, variant_id: variant.id }
                                      ]
                                    });
                                  } else {
                                    setNewDiscount({
                                      ...newDiscount,
                                      selectedServices: newDiscount.selectedServices.filter(
                                        s => !(s.service_id === service.id && s.variant_id === variant.id)
                                      )
                                    });
                                  }
                                }}
                                className="text-blue-600 focus:ring-blue-500"
                              />
                              <span>{variant.name}</span>
                            </label>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Status
                </label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2">
                    <input
                      type="radio"
                      checked={newDiscount.status === 'active'}
                      onChange={() => setNewDiscount({ ...newDiscount, status: 'active' })}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <span>Active</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="radio"
                      checked={newDiscount.status === 'inactive'}
                      onChange={() => setNewDiscount({ ...newDiscount, status: 'inactive' })}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <span>Inactive</span>
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-6">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Create Discount
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}