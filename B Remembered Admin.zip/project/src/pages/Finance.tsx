import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Download, Plus, X, DollarSign, TrendingUp, TrendingDown, Calendar, Wallet, ChevronRight, Trash2, AlertCircle, Edit, Pencil } from 'lucide-react';
import * as Papa from 'papaparse';

interface Expense {
  id: string;
  category_id: string;
  amount: number;
  date: string;
  description: string | null;
  is_subscription: boolean;
  subscription_frequency: 'monthly' | 'yearly' | null;
  expense_categories?: {
    name: string;
    account_number: string | null;
  };
}

interface Revenue {
  id: string;
  amount: number;
  date: string;
  description: string;
  source: string;
  account_number: string | null;
  created_at: string;
}

interface Category {
  id: string;
  name: string;
  description: string | null;
  is_subscription: boolean;
  account_number: string | null;
}

interface FinanceMetrics {
  totalRevenue: number;
  monthlyRevenue: number;
  yearlyRevenue: number;
  totalExpenses: number;
  monthlyExpenses: number;
  yearlyExpenses: number;
  netIncome: number;
  monthlyNetIncome: number;
  yearlyNetIncome: number;
}

interface CategoryMetrics {
  id: string;
  name: string;
  total: number;
  count: number;
  account_number: string | null;
}

interface MonthlyMetrics {
  month: string;
  revenue: number;
  expenses: number;
  netIncome: number;
}

export default function Finance() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [revenues, setRevenues] = useState<Revenue[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showAddRevenueModal, setShowAddRevenueModal] = useState(false);
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [editingExpenseId, setEditingExpenseId] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [showDeleteCategoryConfirm, setShowDeleteCategoryConfirm] = useState<string | null>(null);
  const [showDeleteRevenueConfirm, setShowDeleteRevenueConfirm] = useState<string | null>(null);
  const [showEditCategoryModal, setShowEditCategoryModal] = useState(false);
  const [showManageCategoriesModal, setShowManageCategoriesModal] = useState(false);
  const [showManageRevenueSourcesModal, setShowManageRevenueSourcesModal] = useState(false);
  const [exportRange, setExportRange] = useState('month');
  const [customDateRange, setCustomDateRange] = useState({
    start: '',
    end: ''
  });

  const [metrics, setMetrics] = useState<FinanceMetrics>({
    totalRevenue: 0,
    monthlyRevenue: 0,
    yearlyRevenue: 0,
    totalExpenses: 0,
    monthlyExpenses: 0,
    yearlyExpenses: 0,
    netIncome: 0,
    monthlyNetIncome: 0,
    yearlyNetIncome: 0
  });

  const [categoryMetrics, setCategoryMetrics] = useState<CategoryMetrics[]>([]);
  const [monthlyMetrics, setMonthlyMetrics] = useState<MonthlyMetrics[]>([]);

  const [newExpense, setNewExpense] = useState({
    category_id: '',
    amount: '',
    date: new Date().toISOString().split('T')[0],
    description: '',
    is_subscription: false,
    subscription_frequency: 'monthly' as 'monthly' | 'yearly'
  });

  const [newRevenue, setNewRevenue] = useState({
    amount: '',
    date: new Date().toISOString().split('T')[0],
    description: '',
    source: '',
    account_number: ''
  });

  const [newCategory, setNewCategory] = useState({
    name: '',
    description: '',
    is_subscription: false,
    account_number: ''
  });

  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [editingRevenue, setEditingRevenue] = useState<Revenue | null>(null);
  const [revenueSources, setRevenueSources] = useState<string[]>([]);

  const [error, setError] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    fetchExpenses();
    fetchRevenues();
    fetchCategories();
    fetchFinanceMetrics();
    fetchRevenueSources();
  }, []);

  const fetchRevenueSources = async () => {
    try {
      const { data, error } = await supabase
        .from('revenues')
        .select('source')
        .order('source');

      if (error) throw error;
      
      // Get unique sources
      const sources = [...new Set(data?.map(item => item.source) || [])];
      setRevenueSources(sources);
    } catch (error) {
      console.error('Error fetching revenue sources:', error);
    }
  };

  const fetchFinanceMetrics = async () => {
    try {
      const monthStart = new Date();
      monthStart.setDate(1);
      monthStart.setHours(0, 0, 0, 0);

      const yearStart = new Date();
      yearStart.setMonth(0, 1);
      yearStart.setHours(0, 0, 0, 0);

      // Fetch all confirmed bookings
      const { data: bookings, error: bookingsError } = await supabase
        .from('bookings')
        .select('amount, created_at')
        .eq('status', 'confirmed');

      if (bookingsError) throw bookingsError;

      // Fetch all revenues
      const { data: revenues, error: revenuesError } = await supabase
        .from('revenues')
        .select('amount, date');

      if (revenuesError) throw revenuesError;

      // Fetch all expenses
      const { data: expenses, error: expensesError } = await supabase
        .from('expenses')
        .select('amount, date, category_id, expense_categories(name, account_number)');

      if (expensesError) throw expensesError;

      // Calculate revenue metrics from bookings
      const bookingRevenue = bookings?.reduce((sum, b) => sum + b.amount, 0) || 0;
      const monthlyBookingRevenue = bookings?.filter(b => new Date(b.created_at) >= monthStart)
        .reduce((sum, b) => sum + b.amount, 0) || 0;
      const yearlyBookingRevenue = bookings?.filter(b => new Date(b.created_at) >= yearStart)
        .reduce((sum, b) => sum + b.amount, 0) || 0;

      // Calculate revenue metrics from manual revenues
      const manualRevenue = revenues?.reduce((sum, r) => sum + r.amount, 0) || 0;
      const monthlyManualRevenue = revenues?.filter(r => new Date(r.date) >= monthStart)
        .reduce((sum, r) => sum + r.amount, 0) || 0;
      const yearlyManualRevenue = revenues?.filter(r => new Date(r.date) >= yearStart)
        .reduce((sum, r) => sum + r.amount, 0) || 0;

      // Combine revenue metrics
      const totalRevenue = bookingRevenue + manualRevenue;
      const monthlyRevenue = monthlyBookingRevenue + monthlyManualRevenue;
      const yearlyRevenue = yearlyBookingRevenue + yearlyManualRevenue;

      // Calculate expense metrics
      const totalExpenses = expenses?.reduce((sum, e) => sum + e.amount, 0) || 0;
      const monthlyExpenses = expenses?.filter(e => new Date(e.date) >= monthStart)
        .reduce((sum, e) => sum + e.amount, 0) || 0;
      const yearlyExpenses = expenses?.filter(e => new Date(e.date) >= yearStart)
        .reduce((sum, e) => sum + e.amount, 0) || 0;

      // Calculate net income
      const netIncome = totalRevenue - totalExpenses;
      const monthlyNetIncome = monthlyRevenue - monthlyExpenses;
      const yearlyNetIncome = yearlyRevenue - yearlyExpenses;

      setMetrics({
        totalRevenue,
        monthlyRevenue,
        yearlyRevenue,
        totalExpenses,
        monthlyExpenses,
        yearlyExpenses,
        netIncome,
        monthlyNetIncome,
        yearlyNetIncome
      });

      // Calculate category metrics
      const categoryTotals = expenses?.reduce((acc: { [key: string]: CategoryMetrics }, expense) => {
        const categoryId = expense.category_id;
        const categoryName = expense.expense_categories?.name || 'Uncategorized';
        const accountNumber = expense.expense_categories?.account_number || null;
        
        if (!acc[categoryId]) {
          acc[categoryId] = {
            id: categoryId,
            name: categoryName,
            account_number: accountNumber,
            total: 0,
            count: 0
          };
        }
        
        acc[categoryId].total += expense.amount;
        acc[categoryId].count += 1;
        
        return acc;
      }, {});

      setCategoryMetrics(Object.values(categoryTotals || {}));

      // Calculate monthly metrics for the last 6 months
      const monthlyData: { [key: string]: MonthlyMetrics } = {};
      const now = new Date();
      
      // Initialize last 6 months
      for (let i = 0; i < 6; i++) {
        const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const monthKey = date.toLocaleString('default', { month: 'long', year: 'numeric' });
        monthlyData[monthKey] = {
          month: monthKey,
          revenue: 0,
          expenses: 0,
          netIncome: 0
        };
      }

      // Add booking revenue data
      bookings?.forEach(booking => {
        const date = new Date(booking.created_at);
        const monthKey = date.toLocaleString('default', { month: 'long', year: 'numeric' });
        if (monthlyData[monthKey]) {
          monthlyData[monthKey].revenue += booking.amount;
          monthlyData[monthKey].netIncome += booking.amount;
        }
      });

      // Add manual revenue data
      revenues?.forEach(revenue => {
        const date = new Date(revenue.date);
        const monthKey = date.toLocaleString('default', { month: 'long', year: 'numeric' });
        if (monthlyData[monthKey]) {
          monthlyData[monthKey].revenue += revenue.amount;
          monthlyData[monthKey].netIncome += revenue.amount;
        }
      });

      // Add expense data
      expenses?.forEach(expense => {
        const date = new Date(expense.date);
        const monthKey = date.toLocaleString('default', { month: 'long', year: 'numeric' });
        if (monthlyData[monthKey]) {
          monthlyData[monthKey].expenses += expense.amount;
          monthlyData[monthKey].netIncome -= expense.amount;
        }
      });

      setMonthlyMetrics(Object.values(monthlyData));
    } catch (error) {
      console.error('Error fetching finance metrics:', error);
    }
  };

  const fetchExpenses = async () => {
    try {
      const { data, error } = await supabase
        .from('expenses')
        .select(`
          *,
          expense_categories (
            name,
            account_number
          )
        `)
        .order('date', { ascending: false });

      if (error) throw error;
      setExpenses(data || []);
    } catch (error) {
      console.error('Error fetching expenses:', error);
    }
  };

  const fetchRevenues = async () => {
    try {
      const { data, error } = await supabase
        .from('revenues')
        .select('*')
        .order('date', { ascending: false });

      if (error) throw error;
      setRevenues(data || []);
    } catch (error) {
      console.error('Error fetching revenues:', error);
    }
  };

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('expense_categories')
        .select('*')
        .order('name');

      if (error) throw error;
      setCategories(data || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault();

    const expense = {
      category_id: newExpense.category_id,
      amount: parseFloat(newExpense.amount),
      date: newExpense.date,
      description: newExpense.description || null,
      is_subscription: newExpense.is_subscription,
      subscription_frequency: newExpense.is_subscription ? newExpense.subscription_frequency : null
    };

    try {
      if (editingExpenseId) {
        const { error } = await supabase
          .from('expenses')
          .update(expense)
          .eq('id', editingExpenseId);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('expenses')
          .insert([expense]);

        if (error) throw error;
      }

      setShowAddModal(false);
      setEditingExpenseId(null);
      setNewExpense({
        category_id: '',
        amount: '',
        date: new Date().toISOString().split('T')[0],
        description: '',
        is_subscription: false,
        subscription_frequency: 'monthly'
      });
      
      // Refresh data
      await Promise.all([
        fetchExpenses(),
        fetchFinanceMetrics()
      ]);
    } catch (error) {
      console.error('Error saving expense:', error);
    }
  };

  const handleAddRevenue = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!newRevenue.amount || !newRevenue.date || !newRevenue.source) {
      setError('Amount, date, and source are required');
      return;
    }

    const revenue = {
      amount: parseFloat(newRevenue.amount),
      date: newRevenue.date,
      description: newRevenue.description,
      source: newRevenue.source,
      account_number: newRevenue.account_number || null
    };

    try {
      const { error } = await supabase
        .from('revenues')
        .insert([revenue]);

      if (error) throw error;

      setShowAddRevenueModal(false);
      setNewRevenue({
        amount: '',
        date: new Date().toISOString().split('T')[0],
        description: '',
        source: '',
        account_number: ''
      });
      
      // Refresh data
      await Promise.all([
        fetchRevenues(),
        fetchFinanceMetrics(),
        fetchRevenueSources()
      ]);
    } catch (error) {
      console.error('Error saving revenue:', error);
      setError('Failed to save revenue. Please try again.');
    }
  };

  const handleEditRevenue = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!editingRevenue) return;
    
    try {
      const { error } = await supabase
        .from('revenues')
        .update({
          amount: editingRevenue.amount,
          date: editingRevenue.date,
          description: editingRevenue.description,
          source: editingRevenue.source,
          account_number: editingRevenue.account_number
        })
        .eq('id', editingRevenue.id);

      if (error) throw error;

      setEditingRevenue(null);
      
      // Refresh data
      await Promise.all([
        fetchRevenues(),
        fetchFinanceMetrics(),
        fetchRevenueSources()
      ]);
    } catch (error) {
      console.error('Error updating revenue:', error);
      setError('Failed to update revenue. Please try again.');
    }
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const { error } = await supabase
        .from('expense_categories')
        .insert([newCategory]);

      if (error) throw error;

      setShowCategoryModal(false);
      setNewCategory({
        name: '',
        description: '',
        is_subscription: false,
        account_number: ''
      });
      fetchCategories();
    } catch (error) {
      console.error('Error adding category:', error);
    }
  };

  const handleEditCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!editingCategory) return;
    
    try {
      const { error } = await supabase
        .from('expense_categories')
        .update({
          name: editingCategory.name,
          description: editingCategory.description,
          is_subscription: editingCategory.is_subscription,
          account_number: editingCategory.account_number
        })
        .eq('id', editingCategory.id);

      if (error) throw error;

      setShowEditCategoryModal(false);
      setEditingCategory(null);
      
      // Refresh data
      await Promise.all([
        fetchCategories(),
        fetchExpenses(),
        fetchFinanceMetrics()
      ]);
    } catch (error) {
      console.error('Error updating category:', error);
      setError('Failed to update category. Please try again.');
    }
  };

  const handleExport = async () => {
    setExporting(true);
    try {
      // Get filtered expenses based on date range
      let filteredExpenses = [...expenses];
      const now = new Date();
      let startDate: Date | null = null;
      let endDate: Date | null = null;

      switch (exportRange) {
        case 'month':
          startDate = new Date(now.getFullYear(), now.getMonth(), 1);
          endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0);
          break;
        case 'last_month':
          startDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
          endDate = new Date(now.getFullYear(), now.getMonth(), 0);
          break;
        case 'year':
          startDate = new Date(now.getFullYear(), 0, 1);
          endDate = new Date(now.getFullYear(), 11, 31);
          break;
        case 'last_year':
          startDate = new Date(now.getFullYear() - 1, 0, 1);
          endDate = new Date(now.getFullYear() - 1, 11, 31);
          break;
        case 'custom':
          if (customDateRange.start) startDate = new Date(customDateRange.start);
          if (customDateRange.end) endDate = new Date(customDateRange.end);
          break;
        default:
          // All time - no filtering
          break;
      }

      if (startDate) {
        filteredExpenses = filteredExpenses.filter(expense => 
          new Date(expense.date) >= startDate!
        );
      }

      if (endDate) {
        filteredExpenses = filteredExpenses.filter(expense => 
          new Date(expense.date) <= endDate!
        );
      }

      // Format data for CSV
      const csvData = filteredExpenses.map(expense => ({
        Date: new Date(expense.date).toLocaleDateString(),
        Category: expense.expense_categories?.name || 'Unknown',
        'Account Number': expense.expense_categories?.account_number || '',
        Description: expense.description || '',
        Amount: expense.amount.toFixed(2),
        Type: expense.is_subscription ? 
          `${expense.subscription_frequency} subscription` : 
          'one-time',
      }));

      // Generate CSV
      const csv = Papa.unparse(csvData);
      
      // Create download link
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      
      // Create filename based on date range
      let filename = 'expenses';
      if (startDate && endDate) {
        filename += `_${startDate.toISOString().split('T')[0]}_to_${endDate.toISOString().split('T')[0]}`;
      } else if (startDate) {
        filename += `_from_${startDate.toISOString().split('T')[0]}`;
      } else if (endDate) {
        filename += `_until_${endDate.toISOString().split('T')[0]}`;
      }
      filename += '.csv';
      
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      setShowExportModal(false);
    } catch (error) {
      console.error('Error exporting expenses:', error);
      setError('Failed to export expenses');
    } finally {
      setExporting(false);
    }
  };

  const handleEditExpense = (expense: Expense) => {
    setEditingExpenseId(expense.id);
    setNewExpense({
      category_id: expense.category_id,
      amount: expense.amount.toString(),
      date: expense.date,
      description: expense.description || '',
      is_subscription: expense.is_subscription,
      subscription_frequency: expense.subscription_frequency || 'monthly'
    });
    setShowAddModal(true);
  };

  const handleDeleteExpense = async () => {
    if (!showDeleteConfirm) return;
    
    setDeleting(true);
    setError(null);
    
    try {
      const { error } = await supabase
        .from('expenses')
        .delete()
        .eq('id', showDeleteConfirm);
        
      if (error) throw error;
      
      // Refresh data
      await Promise.all([
        fetchExpenses(),
        fetchFinanceMetrics()
      ]);
      
      setShowDeleteConfirm(null);
    } catch (err) {
      console.error('Error deleting expense:', err);
      setError('Failed to delete expense. Please try again.');
    } finally {
      setDeleting(false);
    }
  };

  const handleDeleteCategory = async () => {
    if (!showDeleteCategoryConfirm) return;
    
    setDeleting(true);
    setError(null);
    
    try {
      // Check if category is in use
      const { count, error: countError } = await supabase
        .from('expenses')
        .select('id', { count: 'exact', head: true })
        .eq('category_id', showDeleteCategoryConfirm);
        
      if (countError) throw countError;
      
      if (count && count > 0) {
        throw new Error(`Cannot delete category that is used by ${count} expenses. Reassign expenses first.`);
      }
      
      const { error } = await supabase
        .from('expense_categories')
        .delete()
        .eq('id', showDeleteCategoryConfirm);
        
      if (error) throw error;
      
      // Refresh data
      await fetchCategories();
      
      setShowDeleteCategoryConfirm(null);
    } catch (err) {
      console.error('Error deleting category:', err);
      setError(err instanceof Error ? err.message : 'Failed to delete category. Please try again.');
    } finally {
      setDeleting(false);
    }
  };

  const handleDeleteRevenue = async () => {
    if (!showDeleteRevenueConfirm) return;
    
    setDeleting(true);
    setError(null);
    
    try {
      const { error } = await supabase
        .from('revenues')
        .delete()
        .eq('id', showDeleteRevenueConfirm);
        
      if (error) throw error;
      
      // Refresh data
      await Promise.all([
        fetchRevenues(),
        fetchFinanceMetrics(),
        fetchRevenueSources()
      ]);
      
      setShowDeleteRevenueConfirm(null);
    } catch (err) {
      console.error('Error deleting revenue:', err);
      setError('Failed to delete revenue. Please try again.');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Finance</h1>
        <div className="flex gap-3">
          <button
            onClick={() => setShowExportModal(true)}
            className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 flex items-center gap-2"
          >
            <Download className="w-5 h-5" />
            Export
          </button>
          <div className="relative group">
            <button
              onClick={() => setShowManageCategoriesModal(true)}
              className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 flex items-center gap-2"
            >
              <Edit className="w-5 h-5" />
              Categories
            </button>
          </div>
          <button
            onClick={() => setShowAddRevenueModal(true)}
            className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add Revenue
          </button>
          <button
            onClick={() => {
              setEditingExpenseId(null);
              setNewExpense({
                category_id: '',
                amount: '',
                date: new Date().toISOString().split('T')[0],
                description: '',
                is_subscription: false,
                subscription_frequency: 'monthly'
              });
              setShowAddModal(true);
            }}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add Expense
          </button>
        </div>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {/* Finance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-700">Revenue</h3>
            <DollarSign className="w-6 h-6 text-green-500" />
          </div>
          <p className="text-2xl font-bold text-gray-900">
            ${metrics.monthlyRevenue.toLocaleString()}
          </p>
          <p className="text-sm text-gray-500 mt-1">
            ${metrics.yearlyRevenue.toLocaleString()} this year
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-700">Expenses</h3>
            <Wallet className="w-6 h-6 text-red-500" />
          </div>
          <p className="text-2xl font-bold text-gray-900">
            ${metrics.monthlyExpenses.toLocaleString()}
          </p>
          <p className="text-sm text-gray-500 mt-1">
            ${metrics.yearlyExpenses.toLocaleString()} this year
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-700">Net Income</h3>
            {metrics.monthlyNetIncome >= 0 ? (
              <TrendingUp className="w-6 h-6 text-green-500" />
            ) : (
              <TrendingDown className="w-6 h-6 text-red-500" />
            )}
          </div>
          <p className={`text-2xl font-bold ${
            metrics.monthlyNetIncome >= 0 ? 'text-green-600' : 'text-red-600'
          }`}>
            ${Math.abs(metrics.monthlyNetIncome).toLocaleString()}
          </p>
          <p className="text-sm text-gray-500 mt-1">
            ${Math.abs(metrics.yearlyNetIncome).toLocaleString()} this year
          </p>
        </div>
      </div>

      {/* Monthly Trends */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-gray-900">Monthly Trends</h2>
          <Calendar className="w-5 h-5 text-gray-400" />
        </div>

        <div className="space-y-4">
          {monthlyMetrics.map((month) => (
            <div key={month.month} className="flex items-center justify-between">
              <div className="w-32">
                <div className="font-medium text-gray-900">{month.month}</div>
              </div>
              <div className="flex-1 px-4">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-gray-500">Revenue: ${month.revenue.toLocaleString()}</span>
                  <span className="text-sm text-gray-500">Expenses: ${month.expenses.toLocaleString()}</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      month.netIncome >= 0 ? 'bg-green-500' : 'bg-red-500'
                    }`}
                    style={{
                      width: `${Math.min(Math.abs(month.netIncome) / Math.max(...monthlyMetrics.map(m => Math.abs(m.netIncome) || 1)) * 100, 100)}%`
                    }}
                  />
                </div>
              </div>
              <div className="w-32 text-right">
                <span className={`font-medium ${
                  month.netIncome >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  ${Math.abs(month.netIncome).toLocaleString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Expense Categories */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-gray-900">Expense Categories</h2>
          <Wallet className="w-5 h-5 text-gray-400" />
        </div>

        <div className="space-y-4">
          {categoryMetrics.map((category) => (
            <div key={category.id} className="flex items-center justify-between">
              <div className="w-48">
                <div className="font-medium text-gray-900">
                  {category.name}
                  {category.account_number && (
                    <span className="ml-2 text-xs text-gray-500">
                      #{category.account_number}
                    </span>
                  )}
                </div>
                <div className="text-sm text-gray-500">{category.count} expenses</div>
              </div>
              <div className="flex-1 px-4">
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-500 rounded-full"
                    style={{
                      width: `${(category.total / Math.max(...categoryMetrics.map(c => c.total || 1))) * 100}%`
                    }}
                  />
                </div>
              </div>
              <div className="w-32 text-right">
                <span className="font-medium text-gray-900">
                  ${category.total.toLocaleString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Revenue List */}
      <div className="bg-white rounded-lg shadow mb-8">
        <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-900">Recent Revenues</h2>
          <button
            onClick={() => setShowManageRevenueSourcesModal(true)}
            className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
          >
            <Edit className="w-4 h-4" />
            Manage Sources
          </button>
        </div>

        <table className="min-w-full">
          <thead>
            <tr className="border-b">
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Source
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Account #
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Description
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Amount
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {revenues.map((revenue) => (
              <tr key={revenue.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {new Date(revenue.date).toLocaleDateString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {revenue.source}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {revenue.account_number || '-'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {revenue.description}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600 font-medium">
                  ${revenue.amount.toFixed(2)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  <div className="flex space-x-2">
                    <button
                      onClick={() => {
                        setEditingRevenue(revenue);
                      }}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      <Pencil className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => setShowDeleteRevenueConfirm(revenue.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {revenues.length === 0 && (
              <tr>
                <td colSpan={6} className="px-6 py-4 text-center text-gray-500">
                  No revenue entries found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Expense List */}
      <div className="bg-white rounded-lg shadow">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Recent Expenses</h2>
        </div>

        <table className="min-w-full">
          <thead>
            <tr className="border-b">
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Category
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Account #
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Description
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Amount
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Type
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {expenses.map((expense) => (
              <tr
                key={expense.id}
                className="hover:bg-gray-50 cursor-pointer"
                onClick={() => handleEditExpense(expense)}
              >
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {new Date(expense.date).toLocaleDateString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {expense.expense_categories?.name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {expense.expense_categories?.account_number || '-'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {expense.description}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  ${expense.amount.toFixed(2)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {expense.is_subscription ? (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      {expense.subscription_frequency} subscription
                    </span>
                  ) : (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                      one-time
                    </span>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setShowDeleteConfirm(expense.id);
                    }}
                    className="text-red-600 hover:text-red-800"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Expense Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900">
                {editingExpenseId ? 'Edit Expense' : 'Add Expense'}
              </h2>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setEditingExpenseId(null);
                  setNewExpense({
                    category_id: '',
                    amount: '',
                    date: new Date().toISOString().split('T')[0],
                    description: '',
                    is_subscription: false,
                    subscription_frequency: 'monthly'
                  });
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddExpense}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Category
                  </label>
                  <select
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newExpense.category_id}
                    onChange={(e) => setNewExpense({ ...newExpense, category_id: e.target.value })}
                    required
                  >
                    <option value="">Select a category</option>
                    {categories.map(category => (
                      <option key={category.id} value={category.id}>
                        {category.name} {category.account_number ? `(#${category.account_number})` : ''}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Amount
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newExpense.amount}
                    onChange={(e) => setNewExpense({ ...newExpense, amount: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Date
                  </label>
                  <input
                    type="date"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newExpense.date}
                    onChange={(e) => setNewExpense({ ...newExpense, date: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newExpense.description}
                    onChange={(e) => setNewExpense({ ...newExpense, description: e.target.value })}
                  />
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="is_subscription"
                    checked={newExpense.is_subscription}
                    onChange={(e) => setNewExpense({ ...newExpense, is_subscription: e.target.checked })}
                  />
                  <label htmlFor="is_subscription" className="text-sm font-medium text-gray-700">
                    Is this a subscription?
                  </label>
                </div>

                {newExpense.is_subscription && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Subscription Frequency
                    </label>
                    <select
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      value={newExpense.subscription_frequency}
                      onChange={(e) => setNewExpense({ 
                        ...newExpense, 
                        subscription_frequency: e.target.value as 'monthly' | 'yearly' 
                      })}
                    >
                      <option value="monthly">Monthly</option>
                      <option value="yearly">Yearly</option>
                    </select>
                  </div>
                )}
              </div>

              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setEditingExpenseId(null);
                    setNewExpense({
                      category_id: '',
                      amount: '',
                      date: new Date().toISOString().split('T')[0],
                      description: '',
                      is_subscription: false,
                      subscription_frequency: 'monthly'
                    });
                  }}
                  className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  {editingExpenseId ? 'Save Changes' : 'Add Expense'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Revenue Modal */}
      {showAddRevenueModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900">Add Revenue</h2>
              <button
                onClick={() => {
                  setShowAddRevenueModal(false);
                  setNewRevenue({
                    amount: '',
                    date: new Date().toISOString().split('T')[0],
                    description: '',
                    source: '',
                    account_number: ''
                  });
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddRevenue}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Amount *
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                    <input
                      type="number"
                      step="0.01"
                      className="w-full pl-7 border border-gray-300 rounded-lg px-3 py-2"
                      value={newRevenue.amount}
                      onChange={(e) => setNewRevenue({ ...newRevenue, amount: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newRevenue.date}
                    onChange={(e) => setNewRevenue({ ...newRevenue, date: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Source *
                  </label>
                  <select
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newRevenue.source}
                    onChange={(e) => setNewRevenue({ ...newRevenue, source: e.target.value })}
                    required
                  >
                    <option value="">Select a source</option>
                    {revenueSources.map(source => (
                      <option key={source} value={source}>{source}</option>
                    ))}
                    <option value="direct_payment">Direct Payment</option>
                    <option value="website">Website</option>
                    <option value="venmo">Venmo</option>
                    <option value="cash">Cash</option>
                    <option value="check">Check</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Account Number
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newRevenue.account_number}
                    onChange={(e) => setNewRevenue({ ...newRevenue, account_number: e.target.value })}
                    placeholder="Optional account number"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newRevenue.description}
                    onChange={(e) => setNewRevenue({ ...newRevenue, description: e.target.value })}
                    placeholder="Optional description"
                  />
                </div>
              </div>

              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddRevenueModal(false);
                    setNewRevenue({
                      amount: '',
                      date: new Date().toISOString().split('T')[0],
                      description: '',
                      source: '',
                      account_number: ''
                    });
                  }}
                  className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  Add Revenue
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Revenue Modal */}
      {editingRevenue && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900">Edit Revenue</h2>
              <button
                onClick={() => setEditingRevenue(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEditRevenue}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Amount *
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                    <input
                      type="number"
                      step="0.01"
                      className="w-full pl-7 border border-gray-300 rounded-lg px-3 py-2"
                      value={editingRevenue.amount}
                      onChange={(e) => setEditingRevenue({ 
                        ...editingRevenue, 
                        amount: parseFloat(e.target.value) 
                      })}
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={editingRevenue.date.split('T')[0]}
                    onChange={(e) => setEditingRevenue({ 
                      ...editingRevenue, 
                      date: e.target.value 
                    })}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Source *
                  </label>
                  <select
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={editingRevenue.source}
                    onChange={(e) => setEditingRevenue({ ...editingRevenue, source: e.target.value })}
                    required
                  >
                    <option value="">Select a source</option>
                    {revenueSources.map(source => (
                      <option key={source} value={source}>{source}</option>
                    ))}
                    <option value="direct_payment">Direct Payment</option>
                    <option value="website">Website</option>
                    <option value="venmo">Venmo</option>
                    <option value="cash">Cash</option>
                    <option value="check">Check</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Account Number
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={editingRevenue.account_number || ''}
                    onChange={(e) => setEditingRevenue({ 
                      ...editingRevenue, 
                      account_number: e.target.value 
                    })}
                    placeholder="Optional account number"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={editingRevenue.description}
                    onChange={(e) => setEditingRevenue({ 
                      ...editingRevenue, 
                      description: e.target.value 
                    })}
                    placeholder="Optional description"
                  />
                </div>
              </div>

              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setEditingRevenue(null)}
                  className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Category Modal */}
      {showCategoryModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900">Add Category</h2>
              <button
                onClick={() => {
                  setShowCategoryModal(false);
                  setNewCategory({
                    name: '',
                    description: '',
                    is_subscription: false,
                    account_number: ''
                  });
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddCategory}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Name
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newCategory.name}
                    onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Account Number
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newCategory.account_number}
                    onChange={(e) => setNewCategory({ ...newCategory, account_number: e.target.value })}
                    placeholder="Optional account number"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={newCategory.description || ''}
                    onChange={(e) => setNewCategory({ ...newCategory, description: e.target.value })}
                  />
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="category_is_subscription"
                    checked={newCategory.is_subscription}
                    onChange={(e) => setNewCategory({ ...newCategory, is_subscription: e.target.checked })}
                  />
                  <label htmlFor="category_is_subscription" className="text-sm font-medium text-gray-700">
                    Is this a subscription category?
                  </label>
                </div>
              </div>

              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowCategoryModal(false);
                    setNewCategory({
                      name: '',
                      description: '',
                      is_subscription: false,
                      account_number: ''
                    });
                  }}
                  className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Add Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Category Modal */}
      {showEditCategoryModal && editingCategory && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900">Edit Category</h2>
              <button
                onClick={() => {
                  setShowEditCategoryModal(false);
                  setEditingCategory(null);
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEditCategory}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Name
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={editingCategory.name}
                    onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Account Number
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={editingCategory.account_number || ''}
                    onChange={(e) => setEditingCategory({ ...editingCategory, account_number: e.target.value })}
                    placeholder="Optional account number"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    value={editingCategory.description || ''}
                    onChange={(e) => setEditingCategory({ ...editingCategory, description: e.target.value })}
                  />
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="edit_category_is_subscription"
                    checked={editingCategory.is_subscription}
                    onChange={(e) => setEditingCategory({ ...editingCategory, is_subscription: e.target.checked })}
                  />
                  <label htmlFor="edit_category_is_subscription" className="text-sm font-medium text-gray-700">
                    Is this a subscription category?
                  </label>
                </div>
              </div>

              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowEditCategoryModal(false);
                    setEditingCategory(null);
                  }}
                  className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Manage Categories Modal */}
      {showManageCategoriesModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-3xl max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900">Manage Expense Categories</h2>
              <button
                onClick={() => setShowManageCategoriesModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mb-4 flex justify-between items-center">
              <p className="text-gray-600">Manage your expense categories and account numbers.</p>
              <button
                onClick={() => setShowCategoryModal(true)}
                className="px-3 py-1 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-1"
              >
                <Plus className="w-4 h-4" />
                Add Category
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Account #</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {categories.map((category) => (
                    <tr key={category.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {category.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {category.account_number || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {category.description || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {category.is_subscription ? 'Subscription' : 'Regular'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex space-x-2">
                          <button
                            onClick={() => {
                              setEditingCategory(category);
                              setShowEditCategoryModal(true);
                            }}
                            className="text-blue-600 hover:text-blue-900"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setShowDeleteCategoryConfirm(category.id)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {categories.length === 0 && (
                    <tr>
                      <td colSpan={5} className="px-6 py-4 text-center text-gray-500">
                        No categories found. Add your first category to get started.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowManageCategoriesModal(false)}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Manage Revenue Sources Modal */}
      {showManageRevenueSourcesModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900">Manage Revenue Sources</h2>
              <button
                onClick={() => setShowManageRevenueSourcesModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mb-4">
              <p className="text-gray-600">View and edit your revenue entries.</p>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Source</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Account #</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {revenues.map((revenue) => (
                    <tr key={revenue.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {new Date(revenue.date).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {revenue.source}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {revenue.account_number || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-green-600">
                        ${revenue.amount.toFixed(2)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex space-x-2">
                          <button
                            onClick={() => {
                              setEditingRevenue(revenue);
                              setShowManageRevenueSourcesModal(false);
                            }}
                            className="text-blue-600 hover:text-blue-900"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              setShowDeleteRevenueConfirm(revenue.id);
                              setShowManageRevenueSourcesModal(false);
                            }}
                            className="text-red-600 hover:text-red-900"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {revenues.length === 0 && (
                    <tr>
                      <td colSpan={5} className="px-6 py-4 text-center text-gray-500">
                        No revenue entries found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="mt-6 flex justify-between">
              <button
                onClick={() => {
                  setShowAddRevenueModal(true);
                  setShowManageRevenueSourcesModal(false);
                }}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Add Revenue
              </button>
              <button
                onClick={() => setShowManageRevenueSourcesModal(false)}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Export Modal */}
      {showExportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900">Export Expenses</h2>
              <button
                onClick={() => setShowExportModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Date Range
                </label>
                <select
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  value={exportRange}
                  onChange={(e) => setExportRange(e.target.value)}
                >
                  <option value="all">All Time</option>
                  <option value="month">This Month</option>
                  <option value="last_month">Last Month</option>
                  <option value="year">This Year</option>
                  <option value="last_year">Last Year</option>
                  <option value="custom">Custom Range</option>
                </select>
              </div>

              {exportRange === 'custom' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Start Date
                    </label>
                    <input
                      type="date"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      value={customDateRange.start}
                      onChange={(e) => setCustomDateRange({ 
                        ...customDateRange, 
                        start: e.target.value 
                      })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      End Date
                    </label>
                    <input
                      type="date"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      value={customDateRange.end}
                      onChange={(e) => setCustomDateRange({ 
                        ...customDateRange, 
                        end: e.target.value 
                      })}
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="mt-6 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowExportModal(false)}
                className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
              >
                Cancel
              </button>
              <button
                onClick={handleExport}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
                disabled={exporting}
              >
                {exporting ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                    Exporting...
                  </>
                ) : (
                  <>
                    <Download className="w-5 h-5" />
                    Export
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Expense Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900">Delete Expense</h2>
              <button
                onClick={() => setShowDeleteConfirm(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this expense? This action cannot be undone.
            </p>

            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(null)}
                className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
                disabled={deleting}
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteExpense}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 flex items-center gap-2"
                disabled={deleting}
              >
                {deleting ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                    Deleting...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    Delete Expense
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Category Confirmation Modal */}
      {showDeleteCategoryConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900">Delete Category</h2>
              <button
                onClick={() => setShowDeleteCategoryConfirm(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this category? This action cannot be undone.
              <br /><br />
              <strong>Note:</strong> Categories that are used by expenses cannot be deleted.
            </p>

            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowDeleteCategoryConfirm(null)}
                className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
                disabled={deleting}
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteCategory}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 flex items-center gap-2"
                disabled={deleting}
              >
                {deleting ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                    Deleting...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    Delete Category
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Revenue Confirmation Modal */}
      {showDeleteRevenueConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900">Delete Revenue</h2>
              <button
                onClick={() => setShowDeleteRevenueConfirm(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this revenue entry? This action cannot be undone.
            </p>

            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowDeleteRevenueConfirm(null)}
                className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
                disabled={deleting}
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteRevenue}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 flex items-center gap-2"
                disabled={deleting}
              >
                {deleting ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                    Deleting...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    Delete Revenue
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}