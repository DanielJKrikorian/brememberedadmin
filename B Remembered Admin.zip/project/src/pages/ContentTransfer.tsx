import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { supabase } from '../lib/supabase';
import { 
  Send, Upload, Trash2, Clock, Mail, MessageSquare, 
  Calendar, User, File, X, AlertCircle, CheckCircle, 
  Link, Copy, Download, Eye, ExternalLink, Plus, Search
} from 'lucide-react';

interface TransferFile {
  id: string;
  name: string;
  size: number;
  type: string;
  url: string;
  uploaded: boolean;
  progress: number;
  file?: File;
}

interface Transfer {
  id: string;
  recipient_email: string;
  recipient_phone?: string;
  subject: string;
  message: string;
  expiration_date: string;
  access_code: string;
  notification_type: 'email' | 'sms' | 'both';
  status: 'active' | 'expired' | 'revoked';
  created_at: string;
  created_by: string;
  files: TransferFile[];
  views: number;
  downloads: number;
}

export default function ContentTransfer() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'create' | 'history'>('create');
  const [transfers, setTransfers] = useState<Transfer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  // New transfer form state
  const [recipientEmail, setRecipientEmail] = useState('');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [expirationDays, setExpirationDays] = useState(7);
  const [notificationType, setNotificationType] = useState<'email' | 'sms' | 'both'>('email');
  const [files, setFiles] = useState<TransferFile[]>([]);
  const [sending, setSending] = useState(false);
  
  // Transfer details modal
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [selectedTransfer, setSelectedTransfer] = useState<Transfer | null>(null);
  const [showRevokeConfirm, setShowRevokeConfirm] = useState(false);
  const [showResendConfirm, setShowResendConfirm] = useState(false);
  
  // Copy link state
  const [linkCopied, setLinkCopied] = useState(false);
  
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: handleFileDrop,
    multiple: true
  });
  
  useEffect(() => {
    if (activeTab === 'history') {
      fetchTransfers();
    }
  }, [activeTab]);
  
  async function fetchTransfers() {
    try {
      setLoading(true);
      
      // In a real implementation, you would fetch from your transfers table
      // For this example, we'll create some mock data
      const mockTransfers: Transfer[] = [
        {
          id: '1',
          recipient_email: 'client@example.com',
          recipient_phone: '+15551234567',
          subject: 'Wedding Photos',
          message: 'Here are your wedding photos as promised!',
          expiration_date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
          access_code: 'ABC123',
          notification_type: 'both',
          status: 'active',
          created_at: new Date().toISOString(),
          created_by: 'admin',
          files: [
            { id: '1', name: 'wedding_photo1.jpg', size: 2500000, type: 'image/jpeg', url: 'https://example.com/files/1', uploaded: true, progress: 100 },
            { id: '2', name: 'wedding_photo2.jpg', size: 3200000, type: 'image/jpeg', url: 'https://example.com/files/2', uploaded: true, progress: 100 }
          ],
          views: 3,
          downloads: 2
        },
        {
          id: '2',
          recipient_email: 'vendor@example.com',
          subject: 'Contract Documents',
          message: 'Please find attached the contract documents for review.',
          expiration_date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
          access_code: 'XYZ789',
          notification_type: 'email',
          status: 'expired',
          created_at: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
          created_by: 'admin',
          files: [
            { id: '3', name: 'contract.pdf', size: 1200000, type: 'application/pdf', url: 'https://example.com/files/3', uploaded: true, progress: 100 }
          ],
          views: 1,
          downloads: 1
        }
      ];
      
      setTransfers(mockTransfers);
    } catch (err) {
      console.error('Error fetching transfers:', err);
      setError('Failed to load transfer history');
    } finally {
      setLoading(false);
    }
  }
  
  function handleFileDrop(acceptedFiles: File[]) {
    const newFiles = acceptedFiles.map(file => ({
      id: Math.random().toString(36).substring(7),
      name: file.name,
      size: file.size,
      type: file.type,
      url: '',
      uploaded: false,
      progress: 0,
      file
    }));
    
    setFiles([...files, ...newFiles]);
  }
  
  function removeFile(fileId: string) {
    setFiles(files.filter(file => file.id !== fileId));
  }
  
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    
    if (files.length === 0) {
      setError('Please add at least one file to transfer');
      return;
    }
    
    setSending(true);
    setError(null);
    
    try {
      // Upload files
      const uploadedFiles = await Promise.all(
        files.map(async (file) => {
          if (!file.file) return file;
          
          // In a real implementation, you would upload to Supabase storage
          // For this example, we'll simulate an upload
          return await simulateFileUpload(file);
        })
      );
      
      // Generate access code
      const accessCode = Math.random().toString(36).substring(2, 8).toUpperCase();
      
      // Calculate expiration date
      const expirationDate = new Date();
      expirationDate.setDate(expirationDate.getDate() + expirationDays);
      
      // Create transfer record
      const newTransfer: Transfer = {
        id: Math.random().toString(36).substring(2, 10),
        recipient_email: recipientEmail,
        recipient_phone: notificationType !== 'email' ? recipientPhone : undefined,
        subject,
        message,
        expiration_date: expirationDate.toISOString(),
        access_code: accessCode,
        notification_type: notificationType,
        status: 'active',
        created_at: new Date().toISOString(),
        created_by: 'admin',
        files: uploadedFiles,
        views: 0,
        downloads: 0
      };
      
      // In a real implementation, you would save to your database
      // For this example, we'll just add it to our local state
      setTransfers([newTransfer, ...transfers]);
      
      // Show success message
      setSuccess('Content transfer created successfully! Notifications have been sent to the recipient.');
      
      // Reset form
      setRecipientEmail('');
      setRecipientPhone('');
      setSubject('');
      setMessage('');
      setExpirationDays(7);
      setNotificationType('email');
      setFiles([]);
      
      // Switch to history tab after a delay
      setTimeout(() => {
        setActiveTab('history');
        setSuccess(null);
      }, 3000);
    } catch (err) {
      console.error('Error creating transfer:', err);
      setError('Failed to create content transfer');
    } finally {
      setSending(false);
    }
  }
  
  async function simulateFileUpload(file: TransferFile): Promise<TransferFile> {
    return new Promise((resolve) => {
      let progress = 0;
      const interval = setInterval(() => {
        progress += 10;
        setFiles(prevFiles => 
          prevFiles.map(f => 
            f.id === file.id 
              ? { ...f, progress } 
              : f
          )
        );
        
        if (progress >= 100) {
          clearInterval(interval);
          const updatedFile = {
            ...file,
            uploaded: true,
            progress: 100,
            url: `https://example.com/files/${file.id}`
          };
          resolve(updatedFile);
        }
      }, 300);
    });
  }
  
  function handleViewTransfer(transfer: Transfer) {
    setSelectedTransfer(transfer);
    setShowDetailsModal(true);
  }
  
  async function handleRevokeTransfer() {
    if (!selectedTransfer) return;
    
    try {
      // In a real implementation, you would update your database
      // For this example, we'll just update our local state
      setTransfers(transfers.map(t => 
        t.id === selectedTransfer.id 
          ? { ...t, status: 'revoked' } 
          : t
      ));
      
      setSelectedTransfer({
        ...selectedTransfer,
        status: 'revoked'
      });
      
      setShowRevokeConfirm(false);
      setSuccess('Transfer access has been revoked');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error revoking transfer:', err);
      setError('Failed to revoke transfer');
    }
  }
  
  async function handleResendNotification() {
    if (!selectedTransfer) return;
    
    try {
      // In a real implementation, you would send a new notification
      // For this example, we'll just show a success message
      setShowResendConfirm(false);
      setSuccess('Notification has been resent to the recipient');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error resending notification:', err);
      setError('Failed to resend notification');
    }
  }
  
  function copyTransferLink() {
    if (!selectedTransfer) return;
    
    // In a real implementation, this would be your actual transfer link
    const transferLink = `https://example.com/transfer/${selectedTransfer.id}`;
    
    navigator.clipboard.writeText(transferLink);
    setLinkCopied(true);
    setTimeout(() => setLinkCopied(false), 2000);
  }
  
  function formatBytes(bytes: number, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }
  
  function getFileIcon(fileType: string) {
    if (fileType.startsWith('image/')) {
      return <img src="/icons/image.svg" alt="Image" className="w-8 h-8" />;
    } else if (fileType.startsWith('video/')) {
      return <img src="/icons/video.svg" alt="Video" className="w-8 h-8" />;
    } else if (fileType.startsWith('audio/')) {
      return <img src="/icons/audio.svg" alt="Audio" className="w-8 h-8" />;
    } else if (fileType === 'application/pdf') {
      return <img src="/icons/pdf.svg" alt="PDF" className="w-8 h-8" />;
    } else if (fileType.includes('word') || fileType.includes('document')) {
      return <img src="/icons/doc.svg" alt="Document" className="w-8 h-8" />;
    } else if (fileType.includes('excel') || fileType.includes('spreadsheet')) {
      return <img src="/icons/xls.svg" alt="Spreadsheet" className="w-8 h-8" />;
    } else if (fileType.includes('powerpoint') || fileType.includes('presentation')) {
      return <img src="/icons/ppt.svg" alt="Presentation" className="w-8 h-8" />;
    } else {
      return <File className="w-8 h-8 text-gray-400" />;
    }
  }
  
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Content Transfer</h1>
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700 dark:bg-red-900/30 dark:border-red-800 dark:text-red-400">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}
      
      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700 dark:bg-green-900/30 dark:border-green-800 dark:text-green-400">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}
      
      {/* Tabs */}
      <div className="mb-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex space-x-8">
          <button
            onClick={() => setActiveTab('create')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'create'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            Create Transfer
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'history'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            Transfer History
          </button>
        </div>
      </div>
      
      {/* Create Transfer Form */}
      {activeTab === 'create' && (
        <div className="bg-white rounded-lg shadow-md p-6 dark:bg-gray-800">
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="space-y-6">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Recipient Information</h2>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                    Email Address *
                  </label>
                  <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500 dark:border-gray-600">
                    <Mail className="w-5 h-5 text-gray-400 ml-3 dark:text-gray-500" />
                    <input
                      type="email"
                      className="w-full px-3 py-2 focus:outline-none dark:bg-gray-800 dark:text-white"
                      value={recipientEmail}
                      onChange={(e) => setRecipientEmail(e.target.value)}
                      required
                      placeholder="recipient@example.com"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                    Phone Number {notificationType !== 'email' && '*'}
                  </label>
                  <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500 dark:border-gray-600">
                    <MessageSquare className="w-5 h-5 text-gray-400 ml-3 dark:text-gray-500" />
                    <input
                      type="tel"
                      className="w-full px-3 py-2 focus:outline-none dark:bg-gray-800 dark:text-white"
                      value={recipientPhone}
                      onChange={(e) => setRecipientPhone(e.target.value)}
                      required={notificationType !== 'email'}
                      placeholder="+1 (555) 123-4567"
                    />
                  </div>
                  <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                    Required for SMS notifications
                  </p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                    Subject *
                  </label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-800 dark:text-white"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    required
                    placeholder="Your files are ready"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                    Message
                  </label>
                  <textarea
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-800 dark:text-white"
                    rows={4}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Add a personal message to the recipient..."
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1 dark:text-gray-300">
                    Expiration
                  </label>
                  <select
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-800 dark:text-white"
                    value={expirationDays}
                    onChange={(e) => setExpirationDays(parseInt(e.target.value))}
                  >
                    <option value={1}>1 day</option>
                    <option value={3}>3 days</option>
                    <option value={7}>7 days</option>
                    <option value={14}>14 days</option>
                    <option value={30}>30 days</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 dark:text-gray-300">
                    Notification Method
                  </label>
                  <div className="space-y-2">
                    <label className="flex items-center">
                      <input
                        type="radio"
                        className="text-blue-600 focus:ring-blue-500"
                        checked={notificationType === 'email'}
                        onChange={() => setNotificationType('email')}
                      />
                      <span className="ml-2 text-gray-700 dark:text-gray-300">Email only</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="radio"
                        className="text-blue-600 focus:ring-blue-500"
                        checked={notificationType === 'sms'}
                        onChange={() => setNotificationType('sms')}
                      />
                      <span className="ml-2 text-gray-700 dark:text-gray-300">SMS only</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="radio"
                        className="text-blue-600 focus:ring-blue-500"
                        checked={notificationType === 'both'}
                        onChange={() => setNotificationType('both')}
                      />
                      <span className="ml-2 text-gray-700 dark:text-gray-300">Both Email and SMS</span>
                    </label>
                  </div>
                </div>
              </div>
              
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-4 dark:text-white">Files</h2>
                
                <div 
                  {...getRootProps()} 
                  className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors mb-4 ${
                    isDragActive 
                      ? 'border-blue-400 bg-blue-50 dark:border-blue-500 dark:bg-blue-900/20' 
                      : 'border-gray-300 hover:border-gray-400 dark:border-gray-600 dark:hover:border-gray-500'
                  }`}
                >
                  <input {...getInputProps()} />
                  <Upload className="w-12 h-12 text-gray-400 mx-auto mb-2 dark:text-gray-500" />
                  <p className="text-gray-600 dark:text-gray-300">
                    {isDragActive ? 'Drop files here' : 'Drag & drop files here, or click to select'}
                  </p>
                  <p className="text-sm text-gray-500 mt-1 dark:text-gray-400">
                    You can upload multiple files at once
                  </p>
                </div>
                
                {files.length > 0 && (
                  <div className="border border-gray-200 rounded-lg overflow-hidden dark:border-gray-700">
                    <div className="px-4 py-3 bg-gray-50 border-b border-gray-200 dark:bg-gray-800 dark:border-gray-700">
                      <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">Selected Files</h3>
                    </div>
                    <ul className="divide-y divide-gray-200 dark:divide-gray-700">
                      {files.map(file => (
                        <li key={file.id} className="px-4 py-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              {file.type ? (
                                getFileIcon(file.type)
                              ) : (
                                <File className="w-8 h-8 text-gray-400 dark:text-gray-500" />
                              )}
                              <div className="ml-3">
                                <p className="text-sm font-medium text-gray-900 dark:text-white">{file.name}</p>
                                <p className="text-xs text-gray-500 dark:text-gray-400">{formatBytes(file.size)}</p>
                              </div>
                            </div>
                            
                            <div className="flex items-center">
                              {file.progress > 0 && file.progress < 100 ? (
                                <div className="w-24 bg-gray-200 rounded-full h-2 mr-2 dark:bg-gray-700">
                                  <div 
                                    className="bg-blue-600 h-2 rounded-full" 
                                    style={{ width: `${file.progress}%` }}
                                  ></div>
                                </div>
                              ) : file.uploaded ? (
                                <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
                              ) : null}
                              
                              <button
                                type="button"
                                onClick={() => removeFile(file.id)}
                                className="text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400"
                              >
                                <Trash2 className="w-5 h-5" />
                              </button>
                            </div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                <div className="mt-6">
                  <button
                    type="submit"
                    className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 dark:bg-blue-700 dark:hover:bg-blue-600"
                    disabled={sending || files.length === 0}
                  >
                    {sending ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                        <span>Sending...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-5 h-5" />
                        <span>Send Transfer</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      )}
      
      {/* Transfer History */}
      {activeTab === 'history' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
            <div className="relative w-full sm:w-auto">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search transfers..."
                className="w-full sm:w-80 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-800 dark:text-white"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : transfers.length === 0 ? (
            <div className="bg-white rounded-lg shadow-md p-8 text-center dark:bg-gray-800">
              <Send className="w-12 h-12 text-gray-400 mx-auto mb-4 dark:text-gray-500" />
              <h3 className="text-lg font-medium text-gray-900 mb-2 dark:text-white">No Transfers Found</h3>
              <p className="text-gray-500 dark:text-gray-400">
                You haven't created any content transfers yet.
              </p>
              <button
                onClick={() => setActiveTab('create')}
                className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600"
              >
                Create Your First Transfer
              </button>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-md overflow-hidden dark:bg-gray-800">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Recipient</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Subject</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Files</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Expiration</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-700">
                    {transfers
                      .filter(transfer => 
                        transfer.recipient_email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        transfer.subject.toLowerCase().includes(searchTerm.toLowerCase())
                      )
                      .map(transfer => (
                        <tr key={transfer.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <User className="w-5 h-5 text-gray-400 mr-3 dark:text-gray-500" />
                              <div>
                                <div className="text-sm font-medium text-gray-900 dark:text-white">{transfer.recipient_email}</div>
                                {transfer.recipient_phone && (
                                  <div className="text-sm text-gray-500 dark:text-gray-400">{transfer.recipient_phone}</div>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900 dark:text-white">{transfer.subject}</div>
                            <div className="text-xs text-gray-500 dark:text-gray-400">
                              {new Date(transfer.created_at).toLocaleDateString()}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900 dark:text-white">{transfer.files.length} files</div>
                            <div className="text-xs text-gray-500 dark:text-gray-400">
                              {formatBytes(transfer.files.reduce((sum, file) => sum + file.size, 0))}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <Clock className="w-4 h-4 text-gray-400 mr-2 dark:text-gray-500" />
                              <span className="text-sm text-gray-900 dark:text-white">
                                {new Date(transfer.expiration_date).toLocaleDateString()}
                              </span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              transfer.status === 'active' 
                                ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' 
                                : transfer.status === 'expired'
                                ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400'
                                : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                            }`}>
                              {transfer.status.charAt(0).toUpperCase() + transfer.status.slice(1)}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button
                              onClick={() => handleViewTransfer(transfer)}
                              className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300"
                            >
                              Details
                            </button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
      
      {/* Transfer Details Modal */}
      {showDetailsModal && selectedTransfer && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto dark:bg-gray-800">
            <div className="flex justify-between items-center p-6 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">Transfer Details</h2>
              <button
                onClick={() => {
                  setShowDetailsModal(false);
                  setSelectedTransfer(null);
                }}
                className="text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-2 dark:text-gray-400">Recipient</h3>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Mail className="w-5 h-5 text-gray-400 mr-2 dark:text-gray-500" />
                      <span className="text-gray-900 dark:text-white">{selectedTransfer.recipient_email}</span>
                    </div>
                    {selectedTransfer.recipient_phone && (
                      <div className="flex items-center">
                        <MessageSquare className="w-5 h-5 text-gray-400 mr-2 dark:text-gray-500" />
                        <span className="text-gray-900 dark:text-white">{selectedTransfer.recipient_phone}</span>
                      </div>
                    )}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-2 dark:text-gray-400">Transfer Details</h3>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Calendar className="w-5 h-5 text-gray-400 mr-2 dark:text-gray-500" />
                      <span className="text-gray-900 dark:text-white">
                        Created: {new Date(selectedTransfer.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="w-5 h-5 text-gray-400 mr-2 dark:text-gray-500" />
                      <span className="text-gray-900 dark:text-white">
                        Expires: {new Date(selectedTransfer.expiration_date).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        selectedTransfer.status === 'active' 
                          ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' 
                          : selectedTransfer.status === 'expired'
                          ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400'
                          : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                      }`}>
                        {selectedTransfer.status.charAt(0).toUpperCase() + selectedTransfer.status.slice(1)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-500 mb-2 dark:text-gray-400">Message</h3>
                <div className="bg-gray-50 rounded-lg p-4 dark:bg-gray-700">
                  <h4 className="font-medium text-gray-900 mb-2 dark:text-white">{selectedTransfer.subject}</h4>
                  <p className="text-gray-700 whitespace-pre-line dark:text-gray-300">{selectedTransfer.message}</p>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-500 mb-2 dark:text-gray-400">Files</h3>
                <div className="border border-gray-200 rounded-lg overflow-hidden dark:border-gray-700">
                  <ul className="divide-y divide-gray-200 dark:divide-gray-700">
                    {selectedTransfer.files.map(file => (
                      <li key={file.id} className="px-4 py-3 flex items-center justify-between">
                        <div className="flex items-center">
                          {getFileIcon(file.type)}
                          <div className="ml-3">
                            <p className="text-sm font-medium text-gray-900 dark:text-white">{file.name}</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">{formatBytes(file.size)}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center">
                          <a
                            href={file.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:text-blue-800 mr-3 dark:text-blue-400 dark:hover:text-blue-300"
                          >
                            <Eye className="w-5 h-5" />
                          </a>
                          <a
                            href={file.url}
                            download
                            className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                          >
                            <Download className="w-5 h-5" />
                          </a>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-500 mb-2 dark:text-gray-400">Access Information</h3>
                <div className="bg-gray-50 rounded-lg p-4 space-y-3 dark:bg-gray-700">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Link className="w-5 h-5 text-gray-400 mr-2 dark:text-gray-500" />
                      <span className="text-gray-900 dark:text-white">Access Link</span>
                    </div>
                    <button
                      onClick={copyTransferLink}
                      className="flex items-center gap-1 px-2 py-1 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 dark:bg-gray-600 dark:text-gray-300 dark:hover:bg-gray-500"
                    >
                      <Copy className="w-4 h-4" />
                      <span>{linkCopied ? 'Copied!' : 'Copy'}</span>
                    </button>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Key className="w-5 h-5 text-gray-400 mr-2 dark:text-gray-500" />
                      <span className="text-gray-900 dark:text-white">Access Code</span>
                    </div>
                    <span className="font-mono text-gray-900 dark:text-white">{selectedTransfer.access_code}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Eye className="w-5 h-5 text-gray-400 mr-2 dark:text-gray-500" />
                      <span className="text-gray-900 dark:text-white">Views</span>
                    </div>
                    <span className="text-gray-900 dark:text-white">{selectedTransfer.views}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Download className="w-5 h-5 text-gray-400 mr-2 dark:text-gray-500" />
                      <span className="text-gray-900 dark:text-white">Downloads</span>
                    </div>
                    <span className="text-gray-900 dark:text-white">{selectedTransfer.downloads}</span>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-3 justify-end">
                <button
                  onClick={() => setShowResendConfirm(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600"
                  disabled={selectedTransfer.status !== 'active'}
                >
                  <Send className="w-5 h-5" />
                  Resend Notification
                </button>
                
                {selectedTransfer.status === 'active' && (
                  <button
                    onClick={() => setShowRevokeConfirm(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 dark:bg-red-700 dark:hover:bg-red-600"
                  >
                    <X className="w-5 h-5" />
                    Revoke Access
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Revoke Confirmation Modal */}
      {showRevokeConfirm && selectedTransfer && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full dark:bg-gray-800">
            <h2 className="text-xl font-bold text-gray-900 mb-4 dark:text-white">Revoke Access</h2>
            <p className="text-gray-600 mb-6 dark:text-gray-300">
              Are you sure you want to revoke access to this transfer? The recipient will no longer be able to access the files.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowRevokeConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700"
              >
                Cancel
              </button>
              <button
                onClick={handleRevokeTransfer}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 dark:bg-red-700 dark:hover:bg-red-600"
              >
                Revoke Access
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Resend Confirmation Modal */}
      {showResendConfirm && selectedTransfer && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full dark:bg-gray-800">
            <h2 className="text-xl font-bold text-gray-900 mb-4 dark:text-white">Resend Notification</h2>
            <p className="text-gray-600 mb-6 dark:text-gray-300">
              Are you sure you want to resend the notification to {selectedTransfer.recipient_email}?
              {selectedTransfer.notification_type !== 'email' && selectedTransfer.recipient_phone && 
                ` An SMS will also be sent to ${selectedTransfer.recipient_phone}.`
              }
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowResendConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700"
              >
                Cancel
              </button>
              <button
                onClick={handleResendNotification}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600"
              >
                Resend Notification
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Key icon component
function Key(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4" />
    </svg>
  );
}