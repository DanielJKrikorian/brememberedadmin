import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  ArrowLeft, Save, Plus, Minus, Trash2, X, Upload, FileText, Eye, 
  Check, Calendar, DollarSign, Clock, Mail, MessageSquare, Send
} from 'lucide-react';

interface ServiceVariant {
  id?: string;
  name: string;
  price: number;
  hours: number | null;
  description: string | null;
}

interface ServiceMedia {
  id: string;
  type: 'image' | 'video';
  url: string;
  thumbnail_url?: string;
  title?: string;
  description?: string;
}

interface Service {
  id: string;
  name: string;
  description: string;
  base_price: number;
}

interface QuoteService {
  id?: string;
  service_id: string;
  variant_id: string | null;
  quantity: number;
  start_time: string;
  price: number;
  notes: string | null;
}

interface Contract {
  id: string;
  name: string;
  content: string;
}

interface Quote {
  id: string;
  lead_id: string;
  vendor_id: string | null;
  amount: number;
  description: string;
  status: string;
  payment_link: string | null;
  expires_at: string;
  created_at: string;
  lead: {
    name: string;
    email: string;
  };
  vendor: {
    name: string;
  } | null;
  services: QuoteService[];
  contract_id?: string;
}

// Service fee amount in dollars
const SERVICE_FEE = 50;

export default function QuoteEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [services, setServices] = useState<Service[]>([]);
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [showContractModal, setShowContractModal] = useState(false);
  const [quote, setQuote] = useState<Quote>({
    id: '',
    lead_id: '',
    vendor_id: null,
    amount: 0,
    description: '',
    status: 'pending',
    payment_link: null,
    expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    created_at: new Date().toISOString(),
    lead: {
      name: '',
      email: '',
    },
    vendor: null,
    services: [],
  });

  const [showSendModal, setShowSendModal] = useState(false);
  const [sendMethod, setSendMethod] = useState<'email' | 'sms'>('email');
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (id !== 'new') {
      fetchQuote();
    }
    fetchServices();
    fetchContracts();
  }, [id]);

  async function fetchQuote() {
    try {
      const { data, error } = await supabase
        .from('quotes')
        .select(`
          *,
          lead:leads(name, email),
          vendor:vendors(name),
          services:quote_services(
            id,
            service_id,
            variant_id,
            quantity,
            start_time,
            price,
            notes
          )
        `)
        .eq('id', id)
        .single();

      if (error) throw error;
      if (data) {
        setQuote(data);
      }
    } catch (error) {
      console.error('Error fetching quote:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchServices() {
    try {
      const { data, error } = await supabase
        .from('services')
        .select(`
          *,
          variants:service_variants(*)
        `)
        .order('name');

      if (error) throw error;
      setServices(data || []);
    } catch (error) {
      console.error('Error fetching services:', error);
    }
  }

  async function fetchContracts() {
    try {
      const { data, error } = await supabase
        .from('contracts')
        .select('*')
        .order('name');

      if (error) throw error;
      setContracts(data || []);
    } catch (error) {
      console.error('Error fetching contracts:', error);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);

    try {
      let quoteId = id;

      if (id === 'new') {
        const { data, error } = await supabase
          .from('quotes')
          .insert({
            lead_id: quote.lead_id,
            vendor_id: quote.vendor_id,
            amount: quote.amount,
            description: quote.description,
            status: quote.status,
            expires_at: quote.expires_at,
            contract_id: quote.contract_id,
          })
          .select()
          .single();

        if (error) throw error;
        quoteId = data.id;
      } else {
        const { error } = await supabase
          .from('quotes')
          .update({
            vendor_id: quote.vendor_id,
            amount: quote.amount,
            description: quote.description,
            status: quote.status,
            expires_at: quote.expires_at,
            contract_id: quote.contract_id,
          })
          .eq('id', id);

        if (error) throw error;

        await supabase
          .from('quote_services')
          .delete()
          .eq('quote_id', id);
      }

      if (quote.services.length > 0) {
        const { error: servicesError } = await supabase
          .from('quote_services')
          .insert(
            quote.services.map(service => ({
              ...service,
              quote_id: quoteId,
            }))
          );

        if (servicesError) throw servicesError;
      }

      navigate('/quotes');
    } catch (error) {
      console.error('Error saving quote:', error);
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    try {
      const { error } = await supabase
        .from('quotes')
        .delete()
        .eq('id', id);

      if (error) throw error;
      navigate('/quotes');
    } catch (error) {
      console.error('Error deleting quote:', error);
    }
  }

  const addService = () => {
    if (services.length === 0) return;

    const firstService = services[0];
    const firstVariant = firstService.variants[0];

    setQuote({
      ...quote,
      services: [
        ...quote.services,
        {
          service_id: firstService.id,
          variant_id: firstVariant?.id || null,
          quantity: 1,
          start_time: new Date().toISOString(),
          price: firstVariant?.price || firstService.base_price,
          notes: '',
        },
      ],
    });
  };

  const removeService = (index: number) => {
    setQuote({
      ...quote,
      services: quote.services.filter((_, i) => i !== index),
    });
  };

  const updateService = (index: number, field: keyof QuoteService, value: any) => {
    const newServices = [...quote.services];
    newServices[index] = { ...newServices[index], [field]: value };

    if (field === 'service_id' || field === 'variant_id' || field === 'quantity') {
      const service = services.find(s => s.id === newServices[index].service_id);
      if (service) {
        const variant = service.variants.find(v => v.id === newServices[index].variant_id);
        const basePrice = variant ? variant.price : service.base_price;
        newServices[index].price = basePrice * newServices[index].quantity;
      }
    }

    setQuote({
      ...quote,
      services: newServices,
      amount: newServices.reduce((sum, s) => sum + s.price, 0),
    });
  };

  const handleSend = async () => {
    setSending(true);
    try {
      alert(`Quote will be sent via ${sendMethod}`);
      setShowSendModal(false);
    } catch (error) {
      console.error('Error sending quote:', error);
    } finally {
      setSending(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/quotes')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">
            {id === 'new' ? 'New Quote' : 'Edit Quote'}
          </h1>
        </div>
        <div className="flex items-center gap-3">
          {id !== 'new' && (
            <>
              <button
                onClick={() => setShowSendModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                <Send className="w-5 h-5" />
                Send Quote
              </button>
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="flex items-center gap-2 px-4 py-2 text-red-600 hover:text-red-700"
              >
                <Trash2 className="w-5 h-5" />
                Delete Quote
              </button>
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description
            </label>
            <textarea
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              rows={4}
              value={quote.description}
              onChange={(e) => setQuote({ ...quote, description: e.target.value })}
              required
            />
          </div>

          <div>
            <div className="flex justify-between items-center mb-4">
              <label className="block text-sm font-medium text-gray-700">
                Contract
              </label>
              <button
                type="button"
                onClick={() => setShowContractModal(true)}
                className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
              >
                <FileText className="w-4 h-4" />
                {quote.contract_id ? 'Change Contract' : 'Add Contract'}
              </button>
            </div>
            {quote.contract_id && (
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-medium text-gray-900">
                      {contracts.find(c => c.id === quote.contract_id)?.name}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setQuote({ ...quote, contract_id: undefined })}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Services
            </label>
            <div className="space-y-4">
              {quote.services.map((quoteService, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-sm font-medium text-gray-700">Service {index + 1}</h3>
                    <button
                      type="button"
                      onClick={() => removeService(index)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="space-y-3">
                    <select
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={quoteService.service_id}
                      onChange={(e) => updateService(index, 'service_id', e.target.value)}
                      required
                    >
                      {services.map((service) => (
                        <option key={service.id} value={service.id}>
                          {service.name}
                        </option>
                      ))}
                    </select>

                    {services.find(s => s.id === quoteService.service_id)?.variants.length > 0 && (
                      <select
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={quoteService.variant_id || ''}
                        onChange={(e) => updateService(index, 'variant_id', e.target.value || null)}
                        required
                      >
                        {services
                          .find(s => s.id === quoteService.service_id)
                          ?.variants.map((variant) => (
                            <option key={variant.id} value={variant.id}>
                              {variant.name} - ${variant.price}
                            </option>
                          ))}
                      </select>
                    )}

                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="number"
                        min="1"
                        placeholder="Quantity"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={quoteService.quantity}
                        onChange={(e) => updateService(index, 'quantity', parseInt(e.target.value))}
                        required
                      />

                      <input
                        type="datetime-local"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={new Date(quoteService.start_time).toISOString().slice(0, 16)}
                        onChange={(e) => updateService(index, 'start_time', new Date(e.target.value).toISOString())}
                        required
                      />
                    </div>

                    <textarea
                      placeholder="Notes (optional)"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      rows={2}
                      value={quoteService.notes || ''}
                      onChange={(e) => updateService(index, 'notes', e.target.value)}
                    />

                    <div className="text-right text-sm font-medium text-gray-900">
                      Price: ${quoteService.price.toFixed(2)}
                    </div>
                  </div>
                </div>
              ))}

              <button
                type="button"
                onClick={addService}
                className="w-full py-2 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-gray-400 hover:text-gray-700 transition-colors flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Add Service
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Status
              </label>
              <select
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={quote.status}
                onChange={(e) => setQuote({ ...quote, status: e.target.value })}
                required
              >
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
                <option value="expired">Expired</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Expires At
              </label>
              <input
                type="date"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={new Date(quote.expires_at).toISOString().split('T')[0]}
                onChange={(e) => setQuote({ ...quote, expires_at: new Date(e.target.value).toISOString() })}
                required
              />
            </div>
          </div>

          <div className="pt-6 border-t border-gray-200">
            <div className="flex justify-between items-center mb-2">
              <span className="text-lg font-medium text-gray-900">Quote Amount</span>
              <span className="text-2xl font-bold text-gray-900">
                ${quote.amount.toFixed(2)}
              </span>
            </div>
            
            <div className="flex justify-between items-center mb-2 text-sm text-gray-600">
              <span>Service Fee</span>
              <span>${SERVICE_FEE.toFixed(2)}</span>
            </div>
            
            <div className="flex justify-between items-center pt-2 border-t border-gray-200">
              <span className="text-lg font-medium text-gray-900">Total Amount</span>
              <span className="text-2xl font-bold text-gray-900">
                ${(quote.amount + SERVICE_FEE).toFixed(2)}
              </span>
            </div>

            <div className="flex justify-end gap-3 mt-4">
              <button
                type="button"
                onClick={() => navigate('/quotes')}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                disabled={saving}
              >
                {saving ? 'Saving...' : (id === 'new' ? 'Create Quote' : 'Save Changes')}
              </button>
            </div>
          </div>
        </form>

        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="mb-8">
            <img
              src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png"
              alt="B. Remembered Logo"
              className="h-16 w-auto"
            />
          </div>

          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Service Quote</h2>
            <p className="text-gray-600">
              Prepared for: {quote.lead?.name}
              <br />
              Date: {formatDate(quote.created_at)}
              <br />
              Valid until: {formatDate(quote.expires_at)}
            </p>
          </div>

          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Services</h3>
            <div className="space-y-4">
              {quote.services.map((service, index) => {
                const serviceDetails = services.find(s => s.id === service.service_id);
                const variantDetails = serviceDetails?.variants.find(v => v.id === service.variant_id);
                
                return (
                  <div key={index} className="border-b border-gray-200 pb-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium text-gray-900">
                          {serviceDetails?.name}
                          {variantDetails && ` - ${variantDetails.name}`}
                        </h4>
                        <p className="text-sm text-gray-600">
                          {formatDate(service.start_time)}
                          {variantDetails?.hours && ` • ${variantDetails.hours} hours`}
                        </p>
                        {service.notes && (
                          <p className="text-sm text-gray-600 mt-1">{service.notes}</p>
                        )}
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-gray-900">
                          {formatCurrency(service.price)}
                        </p>
                        {service.quantity > 1 && (
                          <p className="text-sm text-gray-600">
                            {service.quantity} × {formatCurrency(service.price / service.quantity)}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="border-t border-gray-200 pt-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-600">Quote Amount:</span>
              <span className="text-gray-900 font-medium">${quote.amount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-600">Service Fee:</span>
              <span className="text-gray-900 font-medium">${SERVICE_FEE.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center pt-2 border-t border-gray-200">
              <span className="text-lg font-medium text-gray-900">Total Amount</span>
              <span className="text-xl font-bold text-gray-900">
                ${(quote.amount + SERVICE_FEE).toFixed(2)}
              </span>
            </div>
          </div>

          <div className="mt-8 text-sm text-gray-600">
            <p className="mb-2">Terms & Conditions:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>This quote is valid until {formatDate(quote.expires_at)}</li>
              <li>A 50% deposit is required to secure the booking</li>
              <li>Final payment is due 14 days before the event</li>
              <li>Prices include all applicable taxes</li>
              <li>A $50 service fee will be added to the total at checkout</li>
            </ul>
          </div>
        </div>
      </div>

      {showContractModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900">Select Contract</h2>
              <button
                onClick={() => setShowContractModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 max-h-96 overflow-y-auto">
              {contracts.map((contract) => (
                <button
                  key={contract.id}
                  onClick={() => {
                    setQuote({ ...quote, contract_id: contract.id });
                    setShowContractModal(false);
                  }}
                  className="w-full p-4 text-left border rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <h3 className="font-medium text-gray-900">{contract.name}</h3>
                </button>
              ))}
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowContractModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {showSendModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Send Quote</h2>
            
            <div className="space-y-4">
              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => setSendMethod('email')}
                  className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg border ${
                    sendMethod === 'email'
                      ? 'border-blue-600 bg-blue-50 text-blue-600'
                      : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Mail className="w-5 h-5" />
                  Email
                </button>
                <button
                  type="button"
                  onClick={() => setSendMethod('sms')}
                  className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg border ${
                    sendMethod === 'sms'
                      ? 'border-blue-600 bg-blue-50 text-blue-600'
                      : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <MessageSquare className="w-5 h-5" />
                  SMS
                </button>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Recipient
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={sendMethod === 'email' ? quote.lead?.email : ''}
                  readOnly
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Message (Optional)
                </label>
                <textarea
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={3}
                  placeholder="Add a personal message..."
                />
              </div>
              
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-blue-800">
                  A $50 service fee will be added to the total amount at checkout.
                </p>
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowSendModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleSend}
                disabled={sending}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                {sending ? 'Sending...' : 'Send Quote'}
              </button>
            </div>
          </div>
        </div>
      )}

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Delete Quote</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this quote? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Delete Quote
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}