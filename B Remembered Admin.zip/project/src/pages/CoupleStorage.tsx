import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { supabase } from '../lib/supabase';
import { 
  Folder, File, Download, Search, ArrowLeft, 
  Upload, AlertCircle, CheckCircle, Info, 
  CreditCard, Clock, Users, Eye, X, Lock
} from 'lucide-react';

interface FolderShare {
  id: string;
  folder_id: string;
  lead_id: string;
  access_level: 'view' | 'download' | 'upload';
  status: 'pending' | 'active' | 'expired';
  expiration_date: string | null;
  access_code: string | null;
  price_monthly: number;
  created_at: string;
  updated_at: string;
  folder: {
    name: string;
    description: string | null;
    vendor: {
      id: string;
      name: string;
    };
  };
  subscription: {
    id: string;
    status: 'active' | 'canceled' | 'expired';
    current_period_end: string;
  } | null;
}

interface StorageFile {
  id: string;
  folder_id: string;
  vendor_id: string;
  name: string;
  description: string | null;
  file_type: string;
  file_size: number;
  storage_path: string;
  public_url: string | null;
  created_at: string;
}

interface Lead {
  id: string;
  name: string;
  email: string;
}

export default function CoupleStorage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  
  // Current user/lead state
  const [currentLeadId, setCurrentLeadId] = useState<string | null>(null);
  const [currentLead, setCurrentLead] = useState<Lead | null>(null);
  
  // Shared folders state
  const [sharedFolders, setSharedFolders] = useState<FolderShare[]>([]);
  const [currentShare, setCurrentShare] = useState<FolderShare | null>(null);
  const [files, setFiles] = useState<StorageFile[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Subscription state
  const [showSubscribeModal, setShowSubscribeModal] = useState(false);
  const [activatingShare, setActivatingShare] = useState<string | null>(null);
  
  // Access code state
  const [showAccessCodeModal, setShowAccessCodeModal] = useState(false);
  const [accessCode, setAccessCode] = useState('');
  
  // File upload state
  const [uploadProgress, setUploadProgress] = useState<{[key: string]: number}>({});
  
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: handleFileDrop,
    noClick: !currentShare || currentShare.access_level !== 'upload',
    disabled: !currentShare || currentShare.access_level !== 'upload'
  });
  
  useEffect(() => {
    fetchLeadId();
  }, []);
  
  useEffect(() => {
    if (currentLeadId) {
      fetchLeadDetails();
      fetchSharedFolders();
    }
  }, [currentLeadId]);
  
  useEffect(() => {
    if (currentShare) {
      fetchFiles();
    }
  }, [currentShare]);
  
  async function fetchLeadId() {
    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');
      
      // For this example, we'll just use the first lead
      // In a real app, you'd have proper lead selection or association
      const { data: leads, error: leadsError } = await supabase
        .from('leads')
        .select('id')
        .limit(1);
        
      if (leadsError) throw leadsError;
      
      if (leads && leads.length > 0) {
        setCurrentLeadId(leads[0].id);
      } else {
        throw new Error('No leads found');
      }
    } catch (err) {
      console.error('Error fetching lead ID:', err);
      setError('Failed to load user information');
    } finally {
      setLoading(false);
    }
  }
  
  async function fetchLeadDetails() {
    if (!currentLeadId) return;
    
    try {
      const { data, error } = await supabase
        .from('leads')
        .select('id, name, email')
        .eq('id', currentLeadId)
        .single();
        
      if (error) throw error;
      setCurrentLead(data);
    } catch (err) {
      console.error('Error fetching lead details:', err);
      setError('Failed to load user profile');
    }
  }
  
  async function fetchSharedFolders() {
    if (!currentLeadId) return;
    
    try {
      const { data, error } = await supabase
        .from('folder_shares')
        .select(`
          *,
          folder:storage_folders(
            name, 
            description,
            vendor:vendors(id, name)
          ),
          subscription:couple_storage_subscriptions(
            id,
            status,
            current_period_end
          )
        `)
        .eq('lead_id', currentLeadId);
        
      if (error) throw error;
      setSharedFolders(data || []);
    } catch (err) {
      console.error('Error fetching shared folders:', err);
      setError('Failed to load shared folders');
    }
  }
  
  async function fetchFiles() {
    if (!currentShare) return;
    
    try {
      const { data, error } = await supabase
        .from('storage_files')
        .select('*')
        .eq('folder_id', currentShare.folder_id);
        
      if (error) throw error;
      setFiles(data || []);
    } catch (err) {
      console.error('Error fetching files:', err);
      setError('Failed to load files');
    }
  }
  
  async function handleAccessCodeSubmit() {
    if (!currentShare || !accessCode) return;
    
    try {
      // Verify access code
      if (accessCode !== currentShare.access_code) {
        setError('Invalid access code');
        return;
      }
      
      // Update share status
      const { error } = await supabase
        .from('folder_shares')
        .update({ status: 'active' })
        .eq('id', currentShare.id);
        
      if (error) throw error;
      
      // Refresh shared folders
      fetchSharedFolders();
      
      // Close modal
      setShowAccessCodeModal(false);
      setAccessCode('');
      
      setSuccess('Access granted successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error verifying access code:', err);
      setError('Failed to verify access code');
    }
  }
  
  async function handleSubscribe() {
    if (!currentShare || !currentLeadId) return;
    
    try {
      setActivatingShare(currentShare.id);
      
      // In a real app, you would create a Stripe checkout session here
      // For this example, we'll just create the subscription directly
      
      // Calculate period end date (1 month from now)
      const now = new Date();
      const periodEnd = new Date(now);
      periodEnd.setMonth(periodEnd.getMonth() + 1);
      
      // Create subscription
      const { error } = await supabase
        .from('couple_storage_subscriptions')
        .insert({
          lead_id: currentLeadId,
          folder_share_id: currentShare.id,
          status: 'active',
          billing_cycle: 'monthly',
          current_period_start: now.toISOString(),
          current_period_end: periodEnd.toISOString()
        });
        
      if (error) throw error;
      
      // Update share status
      const { error: shareError } = await supabase
        .from('folder_shares')
        .update({ status: 'active' })
        .eq('id', currentShare.id);
        
      if (shareError) throw shareError;
      
      // Refresh shared folders
      fetchSharedFolders();
      
      // Close modal
      setShowSubscribeModal(false);
      
      setSuccess('Subscription activated successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error subscribing:', err);
      setError('Failed to activate subscription');
    } finally {
      setActivatingShare(null);
    }
  }
  
  async function handleFileDrop(acceptedFiles: File[]) {
    if (!currentShare || !currentLeadId || currentShare.access_level !== 'upload') return;
    
    // Upload files
    for (const file of acceptedFiles) {
      const fileId = Math.random().toString(36).substring(7);
      setUploadProgress(prev => ({ ...prev, [fileId]: 0 }));
      
      try {
        // Create storage path
        const vendorId = currentShare.folder.vendor.id;
        const storagePath = `vendors/${vendorId}/shared/${currentShare.folder_id}/${file.name}`;
        
        // Upload file to storage
        const { error: uploadError } = await supabase.storage
          .from('vendor-storage')
          .upload(storagePath, file, {
            onUploadProgress: (progress) => {
              const percent = (progress.loaded / progress.total) * 100;
              setUploadProgress(prev => ({ ...prev, [fileId]: percent }));
            }
          });
          
        if (uploadError) throw uploadError;
        
        // Get public URL
        const { data: { publicUrl } } = supabase.storage
          .from('vendor-storage')
          .getPublicUrl(storagePath);
        
        // Create file record
        const { error: fileError } = await supabase
          .from('storage_files')
          .insert({
            folder_id: currentShare.folder_id,
            vendor_id: vendorId,
            name: file.name,
            file_type: file.type,
            file_size: file.size,
            storage_path: storagePath,
            public_url: publicUrl,
            uploaded_by: null // Could be updated to track the lead who uploaded it
          });
          
        if (fileError) throw fileError;
        
        // Clean up progress indicator
        setUploadProgress(prev => {
          const newProgress = { ...prev };
          delete newProgress[fileId];
          return newProgress;
        });
        
        // Refresh file list
        fetchFiles();
      } catch (err) {
        console.error('Error uploading file:', err);
        setError(`Failed to upload ${file.name}`);
        
        // Clean up progress indicator
        setUploadProgress(prev => {
          const newProgress = { ...prev };
          delete newProgress[fileId];
          return newProgress;
        });
      }
    }
  }
  
  function formatBytes(bytes: number, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }
  
  function getFileIcon(fileType: string) {
    if (fileType.startsWith('image/')) {
      return <img src="/icons/image.svg" alt="Image" className="w-10 h-10" />;
    } else if (fileType.startsWith('video/')) {
      return <img src="/icons/video.svg" alt="Video" className="w-10 h-10" />;
    } else if (fileType.startsWith('audio/')) {
      return <img src="/icons/audio.svg" alt="Audio" className="w-10 h-10" />;
    } else if (fileType === 'application/pdf') {
      return <img src="/icons/pdf.svg" alt="PDF" className="w-10 h-10" />;
    } else if (fileType.includes('word') || fileType.includes('document')) {
      return <img src="/icons/doc.svg" alt="Document" className="w-10 h-10" />;
    } else if (fileType.includes('excel') || fileType.includes('spreadsheet')) {
      return <img src="/icons/xls.svg" alt="Spreadsheet" className="w-10 h-10" />;
    } else if (fileType.includes('powerpoint') || fileType.includes('presentation')) {
      return <img src="/icons/ppt.svg" alt="Presentation" className="w-10 h-10" />;
    } else {
      return <File className="w-10 h-10 text-gray-400" />;
    }
  }
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">
          {currentShare ? 'Shared Folder' : 'Shared Storage'}
        </h1>
        
        {currentShare && (
          <button
            onClick={() => setCurrentShare(null)}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Folders
          </button>
        )}
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          {error}
        </div>
      )}
      
      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700">
          <CheckCircle className="w-5 h-5" />
          {success}
        </div>
      )}
      
      {/* Folder View */}
      {!currentShare ? (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Shared Folders</h2>
          
          {sharedFolders.length === 0 ? (
            <div className="text-center py-12">
              <Folder className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Shared Folders</h3>
              <p className="text-gray-500">
                You don't have any shared folders yet. Vendors will share folders with you.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sharedFolders.map(share => (
                <div 
                  key={share.id} 
                  className="border border-gray-200 rounded-lg p-6 hover:border-gray-300 transition-colors"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center">
                      <Folder className="w-8 h-8 text-yellow-500 mr-3" />
                      <div>
                        <h3 className="font-medium text-gray-900">{share.folder.name}</h3>
                        <p className="text-sm text-gray-500">
                          Shared by {share.folder.vendor.name}
                        </p>
                      </div>
                    </div>
                    
                    <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                      share.status === 'active' 
                        ? 'bg-green-100 text-green-800' 
                        : share.status === 'pending' 
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {share.status.charAt(0).toUpperCase() + share.status.slice(1)}
                    </div>
                  </div>
                  
                  {share.folder.description && (
                    <p className="text-gray-600 mb-4">{share.folder.description}</p>
                  )}
                  
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center text-sm text-gray-600">
                      <Eye className="w-4 h-4 mr-2" />
                      <span>
                        Access Level: {share.access_level.charAt(0).toUpperCase() + share.access_level.slice(1)}
                      </span>
                    </div>
                    
                    {share.price_monthly > 0 && (
                      <div className="flex items-center text-sm text-gray-600">
                        <CreditCard className="w-4 h-4 mr-2" />
                        <span>${share.price_monthly.toFixed(2)} per month</span>
                      </div>
                    )}
                    
                    {share.expiration_date && (
                      <div className="flex items-center text-sm text-gray-600">
                        <Clock className="w-4 h-4 mr-2" />
                        <span>Expires on {new Date(share.expiration_date).toLocaleDateString()}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="mt-4">
                    {share.status === 'pending' && share.access_code && (
                      <button
                        onClick={() => {
                          setCurrentShare(share);
                          setShowAccessCodeModal(true);
                        }}
                        className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                      >
                        Enter Access Code
                      </button>
                    )}
                    
                    {share.status === 'pending' && share.price_monthly > 0 && !share.subscription && (
                      <button
                        onClick={() => {
                          setCurrentShare(share);
                          setShowSubscribeModal(true);
                        }}
                        className="w-full px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                      >
                        Subscribe for ${share.price_monthly.toFixed(2)}/month
                      </button>
                    )}
                    
                    {share.status === 'active' && (
                      <button
                        onClick={() => setCurrentShare(share)}
                        className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                      >
                        View Files
                      </button>
                    )}
                    
                    {share.status === 'expired' && (
                      <div className="text-center text-red-600 text-sm">
                        This share has expired
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        /* File Browser */
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {/* Toolbar */}
          <div className="p-4 border-b border-gray-200 flex flex-wrap gap-4 items-center justify-between">
            <div className="flex items-center gap-3">
              <Folder className="w-5 h-5 text-yellow-500" />
              <h2 className="font-medium text-gray-900">{currentShare.folder.name}</h2>
              <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                currentShare.access_level === 'view' 
                  ? 'bg-blue-100 text-blue-800' 
                  : currentShare.access_level === 'download' 
                  ? 'bg-green-100 text-green-800'
                  : 'bg-purple-100 text-purple-800'
              }`}>
                {currentShare.access_level.charAt(0).toUpperCase() + currentShare.access_level.slice(1)} Access
              </span>
            </div>
            
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Search files..."
                  className="pl-9 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </div>
          
          {/* File list */}
          <div 
            {...getRootProps()} 
            className={`p-6 ${
              isDragActive && currentShare.access_level === 'upload'
                ? 'bg-blue-50 border-2 border-dashed border-blue-300' 
                : ''
            }`}
          >
            <input {...getInputProps()} />
            
            {isDragActive && currentShare.access_level === 'upload' && (
              <div className="text-center py-12">
                <Upload className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                <p className="text-lg font-medium text-blue-700">Drop files here to upload</p>
              </div>
            )}
            
            {!isDragActive && (
              <>
                {files.length === 0 ? (
                  <div className="text-center py-12">
                    <File className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No Files</h3>
                    <p className="text-gray-500">
                      This folder doesn't contain any files yet.
                    </p>
                    
                    {currentShare.access_level === 'upload' && (
                      <p className="text-sm text-gray-500 mt-4">
                        Drag and drop files here to upload
                      </p>
                    )}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {files
                      .filter(file => 
                        file.name.toLowerCase().includes(searchTerm.toLowerCase())
                      )
                      .map(file => (
                        <div 
                          key={file.id} 
                          className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50"
                        >
                          <div className="flex flex-col items-center mb-2">
                            {getFileIcon(file.file_type)}
                            <h4 className="font-medium text-gray-900 text-center mt-2 truncate w-full">
                              {file.name}
                            </h4>
                          </div>
                          
                          <div className="text-sm text-gray-500 text-center mb-3">
                            {formatBytes(file.file_size)}
                          </div>
                          
                          {(currentShare.access_level === 'download' || currentShare.access_level === 'upload') && (
                            <div className="text-center">
                              <a
                                href={file.public_url || '#'}
                                download
                                className="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200"
                              >
                                <Download className="w-4 h-4" />
                                <span>Download</span>
                              </a>
                            </div>
                          )}
                        </div>
                      ))}
                  </div>
                )}
              </>
            )}
            
            {/* Upload progress indicators */}
            {Object.keys(uploadProgress).length > 0 && (
              <div className="fixed bottom-6 right-6 w-80 bg-white rounded-lg shadow-lg p-4 border border-gray-200">
                <h4 className="font-medium text-gray-900 mb-2">Uploading Files</h4>
                <div className="space-y-3">
                  {Object.entries(uploadProgress).map(([fileId, progress]) => (
                    <div key={fileId}>
                      <div className="flex justify-between text-sm text-gray-600 mb-1">
                        <span>Uploading...</span>
                        <span>{Math.round(progress)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      
      {/* Access Code Modal */}
      {showAccessCodeModal && currentShare && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Enter Access Code</h2>
            
            <div className="mb-6">
              <p className="text-gray-600">
                Please enter the access code provided by {currentShare.folder.vendor.name} to access this folder.
              </p>
            </div>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Access Code
              </label>
              <input
                type="text"
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
                value={accessCode}
                onChange={(e) => setAccessCode(e.target.value)}
                placeholder="Enter access code"
                autoFocus
              />
            </div>
            
            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowAccessCodeModal(false);
                  setAccessCode('');
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleAccessCodeSubmit}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                disabled={!accessCode.trim()}
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Subscribe Modal */}
      {showSubscribeModal && currentShare && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Subscribe to Folder</h2>
            
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-4">
                <Folder className="w-6 h-6 text-yellow-500" />
                <h3 className="font-medium text-gray-900">{currentShare.folder.name}</h3>
              </div>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                <div className="flex items-start">
                  <Info className="w-5 h-5 text-blue-500 mt-0.5 mr-3" />
                  <div>
                    <p className="text-blue-800">
                      You're about to subscribe to this folder for ${currentShare.price_monthly.toFixed(2)} per month.
                    </p>
                    <p className="text-sm text-blue-600 mt-1">
                      You can cancel your subscription at any time.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-medium text-gray-900">Monthly subscription</span>
                  <span className="text-xl font-bold text-gray-900">
                    ${currentShare.price_monthly.toFixed(2)}
                  </span>
                </div>
                
                <div className="text-sm text-gray-500">
                  Access to all files in this folder
                </div>
              </div>
            </div>
            
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowSubscribeModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleSubscribe}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                disabled={!!activatingShare}
              >
                {activatingShare === currentShare.id ? (
                  <>
                    <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
                    Processing...
                  </>
                ) : (
                  'Subscribe Now'
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}