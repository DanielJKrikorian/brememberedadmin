import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { PlusCircle, Search, Star, Phone, Globe, MapPin, Eye, Download, Upload, AlertCircle, CheckCircle, X } from 'lucide-react';
import * as Papa from 'papaparse';

interface Venue {
  id: string;
  name: string;
  address: string;
  coi_url: string | null;
  contact_name: string | null;
  contact_email: string | null;
  contact_phone: string | null;
  rating: number | null;
  service_type: string | null;
  phone_number: string | null;
  website: string | null;
  state: string | null;
  region: string | null;
  created_at: string;
  updated_at: string;
}

interface ImportProgress {
  total: number;
  current: number;
  status: 'processing' | 'complete' | 'error';
  error?: string;
  validationErrors?: Array<{
    id: string;
    row: number;
    errors: string[];
  }>;
}

interface CSVRow {
  Name?: string;
  Address?: string;
  'Service Type'?: string;
  Rating?: string;
  'Phone Number'?: string;
  Website?: string;
  State?: string;
  Region?: string;
  'Contact Name'?: string;
  'Contact Email'?: string;
  'Contact Phone'?: string;
  'COI URL'?: string;
}

export default function Venues() {
  const [venues, setVenues] = useState<Venue[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importProgress, setImportProgress] = useState<ImportProgress | null>(null);

  useEffect(() => {
    fetchVenues();
  }, []);

  async function fetchVenues() {
    try {
      const { data, error } = await supabase
        .from('venues')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setVenues(data || []);
    } catch (error) {
      console.error('Error fetching venues:', error);
    } finally {
      setLoading(false);
    }
  }

  const validateCSVRow = (row: CSVRow, rowIndex: number): string[] => {
    const errors: string[] = [];

    // Required fields
    if (!row.Name?.trim()) {
      errors.push('Name is required');
    }
    if (!row.Address?.trim()) {
      errors.push('Address is required');
    }

    // Email format validation
    if (row['Contact Email'] && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(row['Contact Email'])) {
      errors.push('Invalid email format');
    }

    // Website URL validation
    if (row.Website && !/^https?:\/\/.+/.test(row.Website)) {
      errors.push('Website must start with http:// or https://');
    }

    // Rating validation
    if (row.Rating) {
      const rating = parseFloat(row.Rating);
      if (isNaN(rating) || rating < 0 || rating > 5) {
        errors.push('Rating must be a number between 0 and 5');
      }
    }

    // Phone number format validation
    const phoneFields = ['Phone Number', 'Contact Phone'];
    phoneFields.forEach(field => {
      if (row[field as keyof CSVRow]) {
        const phone = row[field as keyof CSVRow]?.replace(/\D/g, '');
        if (phone && phone.length < 10) {
          errors.push(`${field} must have at least 10 digits`);
        }
      }
    });

    return errors;
  };

  const handleDismissError = (errorId: string) => {
    setImportProgress(prev => {
      if (!prev?.validationErrors) return prev;
      
      const newValidationErrors = prev.validationErrors.filter(error => error.id !== errorId);
      
      if (newValidationErrors.length === 0) {
        return null;
      }

      return {
        ...prev,
        validationErrors: newValidationErrors
      };
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        try {
          const venues = results.data as CSVRow[];
          
          // Validate all rows first
          const validationErrors: Array<{ id: string; row: number; errors: string[] }> = [];
          venues.forEach((row, index) => {
            const rowErrors = validateCSVRow(row, index);
            if (rowErrors.length > 0) {
              validationErrors.push({
                id: Math.random().toString(36).substring(7),
                row: index + 2, // Add 2 to account for header row and 1-based indexing
                errors: rowErrors
              });
            }
          });

          if (validationErrors.length > 0) {
            setImportProgress({
              total: venues.length,
              current: 0,
              status: 'error',
              validationErrors
            });
            return;
          }

          setImportProgress({
            total: venues.length,
            current: 0,
            status: 'processing'
          });

          // Process venues in batches of 10
          const batchSize = 10;
          for (let i = 0; i < venues.length; i += batchSize) {
            const batch = venues.slice(i, i + batchSize).map(row => ({
              name: row.Name?.trim(),
              address: row.Address?.trim(),
              service_type: row['Service Type']?.trim(),
              rating: row.Rating ? parseFloat(row.Rating) : null,
              phone_number: row['Phone Number']?.trim(),
              website: row.Website?.trim(),
              state: row.State?.trim(),
              region: row.Region?.trim(),
              contact_name: row['Contact Name']?.trim(),
              contact_email: row['Contact Email']?.trim(),
              contact_phone: row['Contact Phone']?.trim(),
              coi_url: row['COI URL']?.trim(),
            }));

            const { error } = await supabase
              .from('venues')
              .insert(batch);

            if (error) throw error;

            setImportProgress(prev => prev ? {
              ...prev,
              current: Math.min(prev.current + batch.length, prev.total)
            } : null);
          }

          setImportProgress(prev => prev ? {
            ...prev,
            status: 'complete'
          } : null);

          // Clear the progress after 3 seconds
          setTimeout(() => {
            setImportProgress(null);
          }, 3000);

          fetchVenues();
          if (fileInputRef.current) {
            fileInputRef.current.value = '';
          }
        } catch (error) {
          console.error('Error importing venues:', error);
          setImportProgress(prev => prev ? {
            ...prev,
            status: 'error',
            error: error instanceof Error ? error.message : 'Failed to import venues'
          } : null);
        }
      },
      error: (error) => {
        setImportProgress({
          total: 0,
          current: 0,
          status: 'error',
          error: `Failed to parse CSV file: ${error.message}`
        });
      }
    });
  };

  const exportVenues = () => {
    const csvData = venues.map(venue => ({
      'Name': venue.name,
      'Address': venue.address,
      'Service Type': venue.service_type || '',
      'Rating': venue.rating || '',
      'Phone Number': venue.phone_number || '',
      'Website': venue.website || '',
      'State': venue.state || '',
      'Region': venue.region || '',
      'Contact Name': venue.contact_name || '',
      'Contact Email': venue.contact_email || '',
      'Contact Phone': venue.contact_phone || '',
      'COI URL': venue.coi_url || '',
    }));

    const csv = Papa.unparse(csvData);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', `venues_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadTemplate = () => {
    const template = [
      {
        'Name': 'Example Venue',
        'Address': '123 Main St, City, State 12345',
        'Service Type': 'Wedding Venue',
        'Rating': '4.5',
        'Phone Number': '(555) 123-4567',
        'Website': 'https://example.com',
        'State': 'California',
        'Region': 'Bay Area',
        'Contact Name': 'John Doe',
        'Contact Email': 'john@example.com',
        'Contact Phone': '(555) 987-6543',
        'COI URL': 'https://example.com/coi.pdf'
      }
    ];

    const csv = Papa.unparse(template);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', 'venues_template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredVenues = venues.filter(venue =>
    venue.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    venue.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
    venue.service_type?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    venue.state?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    venue.region?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderRating = (rating: number | null) => {
    if (!rating) return 'Not rated';
    
    return (
      <div className="flex items-center gap-1">
        <span className="font-medium">{rating.toFixed(1)}</span>
        <Star className="w-4 h-4 text-yellow-400 fill-current" />
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Venues</h1>
        <div className="flex gap-3">
          <button
            onClick={downloadTemplate}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            <Download className="w-5 h-5" />
            Template
          </button>
          <button
            onClick={exportVenues}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            <Download className="w-5 h-5" />
            Export CSV
          </button>
          <label className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors cursor-pointer">
            <Upload className="w-5 h-5" />
            Import CSV
            <input
              type="file"
              className="hidden"
              accept=".csv"
              ref={fileInputRef}
              onChange={handleFileUpload}
            />
          </label>
          <button
            onClick={() => navigate('/venues/new')}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <PlusCircle className="w-5 h-5" />
            Add Venue
          </button>
        </div>
      </div>

      {importProgress && (
        <div className={`mb-6 p-4 rounded-lg ${
          importProgress.status === 'error' ? 'bg-red-50 border border-red-200' :
          importProgress.status === 'complete' ? 'bg-green-50 border border-green-200' :
          'bg-blue-50 border border-blue-200'
        }`}>
          {importProgress.status === 'error' && importProgress.validationErrors ? (
            <div className="text-red-700">
              <div className="flex items-center mb-2">
                <AlertCircle className="w-5 h-5 mr-2" />
                <h3 className="font-medium">CSV Validation Errors</h3>
              </div>
              <ul className="list-disc list-inside space-y-1 ml-2">
                {importProgress.validationErrors.map(({ id, row, errors }) => (
                  <li key={id} className="flex items-start justify-between group">
                    <div>
                      Row {row}:
                      <ul className="list-disc list-inside ml-4">
                        {errors.map((error, errorIndex) => (
                          <li key={errorIndex} className="text-sm">{error}</li>
                        ))}
                      </ul>
                    </div>
                    <button
                      onClick={() => handleDismissError(id)}
                      className="text-red-500 hover:text-red-700 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </li>
                ))}
              </ul>
              <p className="mt-2 text-sm">Please fix these errors and try again.</p>
            </div>
          ) : importProgress.status === 'error' ? (
            <div className="flex items-center text-red-700">
              <AlertCircle className="w-5 h-5 mr-2" />
              {importProgress.error}
            </div>
          ) : importProgress.status === 'complete' ? (
            <div className="flex items-center text-green-700">
              <CheckCircle className="w-5 h-5 mr-2" />
              Successfully imported {importProgress.total} venues
            </div>
          ) : (
            <div>
              <div className="flex justify-between text-sm text-blue-700 mb-1">
                <span>Importing venues...</span>
                <span>{Math.round((importProgress.current / importProgress.total) * 100)}%</span>
              </div>
              <div className="w-full bg-blue-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${(importProgress.current / importProgress.total) * 100}%` }}
                />
              </div>
            </div>
          )}
        </div>
      )}

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search venues..."
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service Type</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rating</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredVenues.map((venue) => (
                <tr key={venue.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-gray-900">{venue.name}</div>
                    {venue.website && (
                      <a
                        href={venue.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-sm text-blue-600 hover:text-blue-800 mt-1"
                      >
                        <Globe className="w-4 h-4" />
                        Website
                      </a>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900">{venue.service_type || '-'}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="space-y-1">
                      {venue.contact_name && (
                        <div className="text-sm text-gray-900">{venue.contact_name}</div>
                      )}
                      {venue.phone_number && (
                        <div className="flex items-center gap-1 text-sm text-gray-600">
                          <Phone className="w-4 h-4" />
                          {venue.phone_number}
                        </div>
                      )}
                      {venue.contact_email && (
                        <div className="text-sm text-gray-600">{venue.contact_email}</div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-start gap-2">
                      <MapPin className="w-4 h-4 text-gray-400 mt-1" />
                      <div>
                        <div className="text-sm text-gray-900">{venue.address}</div>
                        {(venue.state || venue.region) && (
                          <div className="text-sm text-gray-600">
                            {[venue.state, venue.region].filter(Boolean).join(' - ')}
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {renderRating(venue.rating)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      onClick={() => navigate(`/venues/${venue.id}`)}
                      className="text-blue-600 hover:text-blue-900 mr-4"
                    >
                      <Eye className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}