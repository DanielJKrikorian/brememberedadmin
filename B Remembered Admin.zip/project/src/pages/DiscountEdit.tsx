import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  ArrowLeft, Save, Trash2, AlertCircle, X, Tag,
  DollarSign, Percent, Calendar, Package
} from 'lucide-react';

interface Service {
  id: string;
  name: string;
  variants: Array<{
    id: string;
    name: string;
  }>;
}

interface Discount {
  id: string;
  name: string;
  code: string;
  type: 'percentage' | 'fixed';
  value: number;
  description: string | null;
  valid_from: string;
  valid_until: string | null;
  max_uses: number | null;
  used_count: number;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
  services: Array<{
    id: string;
    service_id: string | null;
    variant_id: string | null;
    service?: {
      name: string;
      variant?: {
        name: string;
      };
    };
  }>;
}

export default function DiscountEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [discount, setDiscount] = useState<Discount | null>(null);
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    fetchDiscount();
    fetchServices();
  }, [id]);

  async function fetchDiscount() {
    try {
      const { data, error } = await supabase
        .from('discounts')
        .select(`
          *,
          services:discount_services(
            id,
            service_id,
            variant_id,
            service:services(
              name,
              variant:service_variants(name)
            )
          )
        `)
        .eq('id', id)
        .single();

      if (error) throw error;
      setDiscount(data);
    } catch (err) {
      console.error('Error fetching discount:', err);
      setError('Failed to load discount');
    } finally {
      setLoading(false);
    }
  }

  async function fetchServices() {
    try {
      const { data, error } = await supabase
        .from('services')
        .select(`
          id,
          name,
          variants:service_variants(id, name)
        `)
        .eq('visibility', 'visible')
        .order('name');

      if (error) throw error;
      setServices(data || []);
    } catch (err) {
      console.error('Error fetching services:', err);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!discount) return;

    setSaving(true);
    setError(null);

    try {
      // Update discount
      const { error: discountError } = await supabase
        .from('discounts')
        .update({
          name: discount.name,
          code: discount.code,
          type: discount.type,
          value: discount.value,
          description: discount.description,
          valid_from: discount.valid_from,
          valid_until: discount.valid_until,
          max_uses: discount.max_uses,
          status: discount.status,
        })
        .eq('id', discount.id);

      if (discountError) throw discountError;

      // Update services
      await supabase
        .from('discount_services')
        .delete()
        .eq('discount_id', discount.id);

      if (discount.services.length > 0) {
        const { error: servicesError } = await supabase
          .from('discount_services')
          .insert(
            discount.services.map(service => ({
              discount_id: discount.id,
              service_id: service.service_id,
              variant_id: service.variant_id,
            }))
          );

        if (servicesError) throw servicesError;
      }

      navigate('/discounts');
    } catch (err) {
      console.error('Error updating discount:', err);
      setError(err instanceof Error ? err.message : 'Failed to update discount');
      setSaving(false);
    }
  }

  async function handleDelete() {
    if (!discount) return;

    try {
      const { error } = await supabase
        .from('discounts')
        .delete()
        .eq('id', discount.id);

      if (error) throw error;
      navigate('/discounts');
    } catch (err) {
      console.error('Error deleting discount:', err);
      setError(err instanceof Error ? err.message : 'Failed to delete discount');
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!discount) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-700">Discount not found</p>
        </div>
      </div>
    );
  }

  const isAppliedToAllServices = discount.services.length === 0;

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/discounts')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Edit Discount</h1>
        </div>
        <button
          onClick={() => setShowDeleteConfirm(true)}
          className="flex items-center gap-2 px-4 py-2 text-red-600 hover:text-red-700"
        >
          <Trash2 className="w-5 h-5" />
          Delete Discount
        </button>
      </div>

      <form onSubmit={handleSubmit} className="max-w-2xl space-y-6">
        {error && (
          <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
            <AlertCircle className="w-5 h-5" />
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Name
            </label>
            <input
              type="text"
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
              value={discount.name}
              onChange={(e) => setDiscount({ ...discount, name: e.target.value })}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Code
            </label>
            <input
              type="text"
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
              value={discount.code}
              onChange={(e) => setDiscount({ ...discount, code: e.target.value.toUpperCase() })}
              required
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Type
            </label>
            <select
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
              value={discount.type}
              onChange={(e) => setDiscount({ 
                ...discount, 
                type: e.target.value as 'percentage' | 'fixed'
              })}
              required
            >
              <option value="percentage">Percentage</option>
              <option value="fixed">Fixed Amount</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Value
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                {discount.type === 'percentage' ? '%' : '$'}
              </span>
              <input
                type="number"
                className="w-full pl-7 pr-3 py-2 border border-gray-300 rounded-lg"
                value={discount.value}
                onChange={(e) => setDiscount({ ...discount, value: parseFloat(e.target.value) })}
                min={0}
                max={discount.type === 'percentage' ? 100 : undefined}
                step={discount.type === 'percentage' ? 1 : 0.01}
                required
              />
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Description
          </label>
          <textarea
            className="w-full border border-gray-300 rounded-lg px-3 py-2"
            rows={3}
            value={discount.description || ''}
            onChange={(e) => setDiscount({ ...discount, description: e.target.value })}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Valid From
            </label>
            <input
              type="date"
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
              value={new Date(discount.valid_from).toISOString().split('T')[0]}
              onChange={(e) => setDiscount({ ...discount, valid_from: e.target.value })}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Valid Until
            </label>
            <input
              type="date"
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
              value={discount.valid_until ? new Date(discount.valid_until).toISOString().split('T')[0] : ''}
              onChange={(e) => setDiscount({ ...discount, valid_until: e.target.value || null })}
              min={new Date(discount.valid_from).toISOString().split('T')[0]}
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Maximum Uses
          </label>
          <input
            type="number"
            className="w-full border border-gray-300 rounded-lg px-3 py-2"
            value={discount.max_uses || ''}
            onChange={(e) => setDiscount({ 
              ...discount, 
              max_uses: e.target.value ? parseInt(e.target.value) : null 
            })}
            min={1}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Status
          </label>
          <div className="flex gap-4">
            <label className="flex items-center gap-2">
              <input
                type="radio"
                checked={discount.status === 'active'}
                onChange={() => setDiscount({ ...discount, status: 'active' })}
                className="text-blue-600 focus:ring-blue-500"
              />
              <span>Active</span>
            </label>
            <label className="flex items-center gap-2">
              <input
                type="radio"
                checked={discount.status === 'inactive'}
                onChange={() => setDiscount({ ...discount, status: 'inactive' })}
                className="text-blue-600 focus:ring-blue-500"
              />
              <span>Inactive</span>
            </label>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Apply To
          </label>
          <div className="space-y-2">
            <label className="flex items-center gap-2">
              <input
                type="radio"
                checked={isAppliedToAllServices}
                onChange={() => setDiscount({ ...discount, services: [] })}
                className="text-blue-600 focus:ring-blue-500"
              />
              <span>All Services</span>
            </label>
            <label className="flex items-center gap-2">
              <input
                type="radio"
                checked={!isAppliedToAllServices}
                onChange={() => {
                  if (isAppliedToAllServices) {
                    // Add first service as default when switching to specific
                    if (services.length > 0) {
                      setDiscount({
                        ...discount,
                        services: [{
                          id: '',
                          service_id: services[0].id,
                          variant_id: null
                        }]
                      });
                    }
                  }
                }}
                className="text-blue-600 focus:ring-blue-500"
              />
              <span>Specific Services</span>
            </label>
          </div>
        </div>

        {!isAppliedToAllServices && (
          <div className="space-y-4">
            {services.map((service) => (
              <div key={service.id} className="border border-gray-200 rounded-lg p-4">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={discount.services.some(s => s.service_id === service.id)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setDiscount({
                          ...discount,
                          services: [
                            ...discount.services,
                            { id: '', service_id: service.id, variant_id: null }
                          ]
                        });
                      } else {
                        setDiscount({
                          ...discount,
                          services: discount.services.filter(
                            s => s.service_id !== service.id
                          )
                        });
                      }
                    }}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <span className="font-medium">{service.name}</span>
                </label>

                {service.variants.length > 0 && 
                 discount.services.some(s => s.service_id === service.id) && (
                  <div className="mt-2 ml-6 space-y-2">
                    {service.variants.map((variant) => (
                      <label key={variant.id} className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={discount.services.some(
                            s => s.service_id === service.id && s.variant_id === variant.id
                          )}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setDiscount({
                                ...discount,
                                services: [
                                  ...discount.services,
                                  { id: '', service_id: service.id, variant_id: variant.id }
                                ]
                              });
                            } else {
                              setDiscount({
                                ...discount,
                                services: discount.services.filter(
                                  s => !(s.service_id === service.id && s.variant_id === variant.id)
                                )
                              });
                            }
                          }}
                          className="text-blue-600 focus:ring-blue-500"
                        />
                        <span>{variant.name}</span>
                      </label>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        <div className="pt-6 flex justify-end gap-3">
          <button
            type="button"
            onClick={() => navigate('/discounts')}
            className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            disabled={saving}
          >
            <Save className="w-5 h-5" />
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </form>

      {/* Usage Statistics */}
      <div className="mt-8 bg-white rounded-lg shadow-md p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Usage Statistics</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center gap-2 text-gray-700 mb-2">
              <Tag className="w-5 h-5" />
              <span className="font-medium">Code</span>
            </div>
            <p className="text-xl font-bold">{discount.code}</p>
          </div>
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center gap-2 text-gray-700 mb-2">
              <Calendar className="w-5 h-5" />
              <span className="font-medium">Created</span>
            </div>
            <p className="text-xl font-bold">{new Date(discount.created_at).toLocaleDateString()}</p>
          </div>
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center gap-2 text-gray-700 mb-2">
              <Package className="w-5 h-5" />
              <span className="font-medium">Used</span>
            </div>
            <p className="text-xl font-bold">
              {discount.used_count} {discount.max_uses ? `/ ${discount.max_uses}` : ''}
            </p>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Delete Discount</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this discount? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Delete Discount
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}