import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Calendar, MapPin, Clock, DollarSign, User, Building2, PlusCircle, Search, Phone, X, Heart } from 'lucide-react';

interface Lead {
  id: string;
  name: string;
  email: string;
  phone: string;
  partner_name: string | null;
  wedding_date: string | null;
  venue_id: string | null;
  venue_name: string | null;
  venue_address: string | null;
}

interface Service {
  id: string;
  name: string;
  description: string;
  base_price: number;
  variants: Array<{
    id: string;
    name: string;
    price: number;
    hours: number | null;
  }>;
}

interface Vendor {
  id: string;
  name: string;
  email: string;
  phone: string;
  status: string;
  approved: boolean;
}

interface Booking {
  id: string;
  lead_id: string;
  amount: number;
  start_date: string;
  end_date: string;
  vendor_id: string | null;
  status: string;
  service_id: string | null;
  variant_id: string | null;
  notes: string | null;
  lead: {
    name: string;
    email: string;
    phone: string;
    partner_name: string | null;
    venue_id: string | null;
    venue_name: string | null;
    venue_address: string | null;
  };
  vendor: {
    name: string;
  } | null;
  service: {
    name: string;
    variant: {
      name: string;
      hours: number;
    } | null;
  } | null;
}

export default function Bookings() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showNewBookingModal, setShowNewBookingModal] = useState(false);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedVariant, setSelectedVariant] = useState<string | null>(null);
  const [selectedVendor, setSelectedVendor] = useState<string | null>(null);
  const [startTime, setStartTime] = useState('09:00');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchBookings();
    fetchLeads();
    fetchServices();
    fetchVendors();
  }, []);

  async function fetchLeads() {
    try {
      const { data, error } = await supabase
        .from('leads')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setLeads(data || []);
    } catch (err) {
      console.error('Error fetching leads:', err);
    }
  }

  async function fetchServices() {
    try {
      const { data, error } = await supabase
        .from('services')
        .select(`
          *,
          variants:service_variants(*)
        `)
        .order('name');

      if (error) throw error;
      setServices(data || []);
    } catch (err) {
      console.error('Error fetching services:', err);
    }
  }

  async function fetchVendors() {
    try {
      const { data, error } = await supabase
        .from('vendors')
        .select('*')
        .eq('approved', true)
        .order('name');

      if (error) throw error;
      setVendors(data || []);
    } catch (err) {
      console.error('Error fetching vendors:', err);
    }
  }

  async function fetchBookings() {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(`
          *,
          lead:leads(
            name, 
            email,
            phone,
            partner_name,
            venue_id,
            venue_name,
            venue_address
          ),
          vendor:vendors(name),
          service:services(
            name,
            variant:service_variants(
              name,
              hours
            )
          )
        `)
        .order('start_date', { ascending: true });

      if (error) throw error;
      setBookings(data || []);
    } catch (error) {
      console.error('Error fetching bookings:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleCreateBooking() {
    if (!selectedLead || !selectedService || !selectedVariant) return;

    setSaving(true);
    setError(null);

    try {
      const variant = selectedService.variants.find(v => v.id === selectedVariant);
      if (!variant) throw new Error('Selected variant not found');

      const weddingDate = selectedLead.wedding_date 
        ? new Date(selectedLead.wedding_date) 
        : new Date();
      
      // Set the time from the selected start time
      const [hours, minutes] = startTime.split(':');
      weddingDate.setHours(parseInt(hours), parseInt(minutes));

      // Calculate end time based on variant hours
      const endDate = new Date(weddingDate);
      endDate.setHours(endDate.getHours() + (variant.hours || 1));

      const { error: bookingError } = await supabase
        .from('bookings')
        .insert({
          lead_id: selectedLead.id,
          service_id: selectedService.id,
          variant_id: variant.id,
          vendor_id: selectedVendor,
          start_date: weddingDate.toISOString(),
          end_date: endDate.toISOString(),
          amount: variant.price,
          status: 'pending',
          venue_id: selectedLead.venue_id,
        });

      if (bookingError) throw bookingError;

      setShowNewBookingModal(false);
      fetchBookings();
    } catch (err) {
      console.error('Error creating booking:', err);
      setError(err instanceof Error ? err.message : 'Failed to create booking');
    } finally {
      setSaving(false);
    }
  }

  const filteredBookings = bookings.filter(booking =>
    booking.lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    booking.lead.partner_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    booking.vendor?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    booking.lead.venue_name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Bookings</h1>
        <button
          onClick={() => setShowNewBookingModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <PlusCircle className="w-5 h-5" />
          New Booking
        </button>
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
        <input
          type="text"
          placeholder="Search bookings..."
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Client</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Vendor</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Venue</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredBookings.map((booking) => (
                  <tr key={booking.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="flex items-start">
                        <User className="w-4 h-4 text-gray-400 mr-2 mt-1" />
                        <div>
                          <div className="text-sm font-medium text-gray-900">{booking.lead.name}</div>
                          {booking.lead.partner_name && (
                            <div className="text-sm text-gray-600">& {booking.lead.partner_name}</div>
                          )}
                          <div className="text-sm text-gray-500">{booking.lead.email}</div>
                          {booking.lead.phone && (
                            <div className="flex items-center text-sm text-gray-500 mt-1">
                              <Phone className="w-3 h-3 mr-1" />
                              {booking.lead.phone}
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      {booking.service && (
                        <div className="text-sm text-gray-900">
                          {booking.service.name}
                          {booking.service.variant && (
                            <span className="text-gray-500">
                              {' - '}{booking.service.variant.name}
                            </span>
                          )}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center">
                        <Building2 className="w-4 h-4 text-gray-400 mr-2" />
                        <span className="text-sm text-gray-900">
                          {booking.vendor?.name || 'Unassigned'}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      {(booking.lead.venue_name || booking.lead.venue_address) && (
                        <div className="flex items-center">
                          <MapPin className="w-4 h-4 text-gray-400 mr-2" />
                          <div>
                            <div className="text-sm font-medium text-gray-900">
                              {booking.lead.venue_name}
                            </div>
                            <div className="text-sm text-gray-500">
                              {booking.lead.venue_address}
                            </div>
                          </div>
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 text-gray-400 mr-2" />
                        <div>
                          <div className="text-sm text-gray-900">
                            {new Date(booking.start_date).toLocaleDateString()}
                          </div>
                          <div className="text-sm text-gray-500">
                            {new Date(booking.start_date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center">
                        <DollarSign className="w-4 h-4 text-gray-400 mr-2" />
                        <span className="text-sm text-gray-900">
                          ${booking.amount.toLocaleString()}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        booking.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                        booking.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        booking.status === 'completed' ? 'bg-blue-100 text-blue-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm font-medium">
                      <button
                        onClick={() => navigate(`/bookings/${booking.id}`)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        Edit
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredBookings.length === 0 && (
            <div className="text-center py-12">
              <h3 className="text-lg font-medium text-gray-900">No bookings found</h3>
              <p className="text-gray-600 mt-2">
                {searchTerm ? 'Try adjusting your search terms' : 'Get started by creating your first booking'}
              </p>
            </div>
          )}
        </div>
      )}

      {/* New Booking Modal */}
      {showNewBookingModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-gray-900">New Booking</h2>
              <button
                onClick={() => setShowNewBookingModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
                {error}
              </div>
            )}

            <div className="space-y-6">
              {/* Lead Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select Customer
                </label>
                <select
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={selectedLead?.id || ''}
                  onChange={(e) => {
                    const lead = leads.find(l => l.id === e.target.value);
                    setSelectedLead(lead || null);
                  }}
                  required
                >
                  <option value="">Select a customer</option>
                  {leads.map((lead) => (
                    <option key={lead.id} value={lead.id}>
                      {lead.name} {lead.partner_name && `& ${lead.partner_name}`}
                    </option>
                  ))}
                </select>
              </div>

              {/* Selected Lead Details */}
              {selectedLead && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <User className="w-4 h-4 text-gray-400" />
                    <span className="font-medium">{selectedLead.name}</span>
                    {selectedLead.partner_name && (
                      <div className="flex items-center text-gray-600">
                        <Heart className="w-4 h-4 mx-1 text-pink-500" />
                        <span>{selectedLead.partner_name}</span>
                      </div>
                    )}
                  </div>
                  <div className="space-y-1 text-sm text-gray-600">
                    <p>{selectedLead.email}</p>
                    <p>{selectedLead.phone}</p>
                    {selectedLead.wedding_date && (
                      <p>Wedding Date: {new Date(selectedLead.wedding_date).toLocaleDateString()}</p>
                    )}
                    {(selectedLead.venue_name || selectedLead.venue_address) && (
                      <div className="flex items-start mt-2">
                        <MapPin className="w-4 h-4 text-gray-400 mr-2 mt-1" />
                        <div>
                          {selectedLead.venue_name && (
                            <p className="font-medium">{selectedLead.venue_name}</p>
                          )}
                          {selectedLead.venue_address && (
                            <p>{selectedLead.venue_address}</p>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Service Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select Service
                </label>
                <select
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={selectedService?.id || ''}
                  onChange={(e) => {
                    const service = services.find(s => s.id === e.target.value);
                    setSelectedService(service || null);
                    setSelectedVariant(null);
                  }}
                  required
                >
                  <option value="">Select a service</option>
                  {services.map((service) => (
                    <option key={service.id} value={service.id}>
                      {service.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Service Variant Selection */}
              {selectedService && selectedService.variants.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Select Package
                  </label>
                  <select
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={selectedVariant || ''}
                    onChange={(e) => setSelectedVariant(e.target.value)}
                    required
                  >
                    <option value="">Select a package</option>
                    {selectedService.variants.map((variant) => (
                      <option key={variant.id} value={variant.id}>
                        {variant.name} - ${variant.price} ({variant.hours}h)
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Vendor Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select Vendor
                </label>
                <select
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={selectedVendor || ''}
                  onChange={(e) => setSelectedVendor(e.target.value)}
                >
                  <option value="">Post to Job Board</option>
                  {vendors.map((vendor) => (
                    <option key={vendor.id} value={vendor.id}>
                      {vendor.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Start Time */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Start Time
                </label>
                <input
                  type="time"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  required
                />
              </div>

              <div className="flex justify-end gap-3 pt-6">
                <button
                  type="button"
                  onClick={() => setShowNewBookingModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleCreateBooking}
                  disabled={!selectedLead || !selectedService || !selectedVariant || saving}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  {saving ? 'Creating...' : 'Create Booking'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}