import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  Download, File, Lock, AlertCircle, CheckCircle, 
  Calendar, Clock, User, Mail, MessageSquare
} from 'lucide-react';

interface TransferFile {
  id: string;
  name: string;
  size: number;
  type: string;
  public_url: string;
}

interface Transfer {
  id: string;
  recipient_email: string;
  recipient_phone?: string;
  subject: string;
  message: string;
  expiration_date: string;
  access_code: string;
  notification_type: 'email' | 'sms' | 'both';
  status: 'active' | 'expired' | 'revoked';
  created_at: string;
  files: TransferFile[];
}

export default function PublicTransfer() {
  const { id } = useParams<{ id: string }>();
  const [transfer, setTransfer] = useState<Transfer | null>(null);
  const [accessCode, setAccessCode] = useState('');
  const [verified, setVerified] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [downloading, setDownloading] = useState<string | null>(null);

  useEffect(() => {
    // Check if there's a stored access code for this transfer
    const storedCode = localStorage.getItem(`transfer_access_${id}`);
    if (storedCode) {
      setAccessCode(storedCode);
      verifyAccess(storedCode);
    } else {
      setLoading(false);
    }
  }, [id]);

  async function verifyAccess(code: string) {
    setLoading(true);
    setError(null);
    
    try {
      // Call the edge function to verify access
      const response = await fetch('/functions/v1/verify-transfer-access', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          transferId: id,
          accessCode: code,
        }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to verify access');
      }
      
      setTransfer(data.transfer);
      setVerified(true);
      
      // Store the access code for future use
      localStorage.setItem(`transfer_access_${id}`, code);
    } catch (err) {
      console.error('Error verifying access:', err);
      setError(err instanceof Error ? err.message : 'Failed to verify access');
      setVerified(false);
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    verifyAccess(accessCode);
  }

  async function handleDownload(file: TransferFile) {
    setDownloading(file.id);
    setError(null);
    
    try {
      // Call the edge function to record the download
      const response = await fetch('/functions/v1/record-transfer-download', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          transferId: id,
          fileId: file.id,
        }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to download file');
      }
      
      // Trigger the download
      window.open(file.public_url, '_blank');
      
      setSuccess(`Downloading ${file.name}...`);
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Error downloading file:', err);
      setError(err instanceof Error ? err.message : 'Failed to download file');
    } finally {
      setDownloading(null);
    }
  }

  function formatBytes(bytes: number, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  function getFileIcon(fileType: string) {
    if (fileType.startsWith('image/')) {
      return <img src="/icons/image.svg" alt="Image" className="w-10 h-10" />;
    } else if (fileType.startsWith('video/')) {
      return <img src="/icons/video.svg" alt="Video" className="w-10 h-10" />;
    } else if (fileType.startsWith('audio/')) {
      return <img src="/icons/audio.svg" alt="Audio" className="w-10 h-10" />;
    } else if (fileType === 'application/pdf') {
      return <img src="/icons/pdf.svg" alt="PDF" className="w-10 h-10" />;
    } else if (fileType.includes('word') || fileType.includes('document')) {
      return <img src="/icons/doc.svg" alt="Document" className="w-10 h-10" />;
    } else if (fileType.includes('excel') || fileType.includes('spreadsheet')) {
      return <img src="/icons/xls.svg" alt="Spreadsheet" className="w-10 h-10" />;
    } else if (fileType.includes('powerpoint') || fileType.includes('presentation')) {
      return <img src="/icons/ppt.svg" alt="Presentation" className="w-10 h-10" />;
    } else {
      return <File className="w-10 h-10 text-gray-400" />;
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!verified) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-lg shadow-md p-8">
          <div className="text-center mb-6">
            <img 
              src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png" 
              alt="B. Remembered Logo" 
              className="h-16 mx-auto mb-4"
            />
            <h1 className="text-2xl font-bold text-gray-900">Secure Content</h1>
            <p className="mt-2 text-gray-600">
              Please enter the access code to view the content
            </p>
          </div>
          
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
              <AlertCircle className="w-5 h-5" />
              {error}
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Access Code
              </label>
              <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500">
                <Lock className="w-5 h-5 text-gray-400 ml-3" />
                <input
                  type="text"
                  className="w-full px-3 py-2 focus:outline-none"
                  value={accessCode}
                  onChange={(e) => setAccessCode(e.target.value.toUpperCase())}
                  placeholder="Enter access code"
                  autoFocus
                />
              </div>
            </div>
            
            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <Lock className="w-5 h-5" />
              Access Content
            </button>
          </form>
        </div>
      </div>
    );
  }

  if (!transfer) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-lg shadow-md p-8 text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Content Not Found</h1>
          <p className="text-gray-600">
            The content you're looking for is no longer available or has been removed.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <img 
            src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png" 
            alt="B. Remembered Logo" 
            className="h-16 mx-auto mb-8"
          />
          <h1 className="text-3xl font-bold text-gray-900">{transfer.subject}</h1>
          <div className="mt-2 flex items-center justify-center gap-2 text-gray-600">
            <Calendar className="w-5 h-5" />
            <span>Expires on {new Date(transfer.expiration_date).toLocaleDateString()}</span>
          </div>
        </div>
        
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
            <AlertCircle className="w-5 h-5" />
            {error}
          </div>
        )}
        
        {success && (
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700">
            <CheckCircle className="w-5 h-5" />
            {success}
          </div>
        )}
        
        <div className="bg-white shadow-lg rounded-lg overflow-hidden mb-8">
          <div className="p-6 sm:p-8">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
              <div>
                <div className="flex items-center gap-2 text-gray-600 mb-2">
                  <User className="w-5 h-5" />
                  <span>From: B. Remembered Weddings</span>
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <Mail className="w-5 h-5" />
                  <span>To: {transfer.recipient_email}</span>
                </div>
                {transfer.recipient_phone && (
                  <div className="flex items-center gap-2 text-gray-600 mt-1">
                    <MessageSquare className="w-5 h-5" />
                    <span>{transfer.recipient_phone}</span>
                  </div>
                )}
              </div>
              <div className="mt-4 sm:mt-0">
                <div className="flex items-center gap-2 text-gray-600">
                  <Clock className="w-5 h-5" />
                  <span>Shared on {new Date(transfer.created_at).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
            
            {transfer.message && (
              <div className="mb-8">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Message</h3>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-gray-700 whitespace-pre-line">{transfer.message}</p>
                </div>
              </div>
            )}
            
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Files</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {transfer.files.map(file => (
                  <div key={file.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        {getFileIcon(file.type)}
                        <div className="ml-3">
                          <p className="font-medium text-gray-900">{file.name}</p>
                          <p className="text-sm text-gray-500">{formatBytes(file.size)}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => handleDownload(file)}
                        className="flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200"
                        disabled={downloading === file.id}
                      >
                        {downloading === file.id ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-2 border-blue-700 border-t-transparent"></div>
                        ) : (
                          <Download className="w-4 h-4" />
                        )}
                        <span>Download</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="bg-gray-50 px-6 py-4 sm:px-8">
            <p className="text-sm text-gray-500">
              This content will be available until {new Date(transfer.expiration_date).toLocaleDateString()}.
              After that date, the files will no longer be accessible.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}