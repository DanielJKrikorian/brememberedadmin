import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import ReactCrop, { Crop, PixelCrop, centerCrop, makeAspectCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';
import { supabase } from '../lib/supabase';
import { 
  ArrowLeft, Upload, Trash2, Save, Building2, Mail, Phone, Globe, 
  Instagram, Facebook, Check, X, Package, DollarSign, Clock, Crop as CropIcon,
  Plus, CreditCard, AlertCircle, Image as ImageIcon, Video, Wallet, Calendar,
  MapPin, CheckCircle, XCircle, Clock3, ChevronRight, Settings, FileText, Shield
} from 'lucide-react';

interface ServiceVariant {
  id: string;
  name: string;
  price: number;
  hours: number | null;
  description: string | null;
}

interface Service {
  id: string;
  name: string;
  description: string;
  base_price: number;
  allows_custom_packages: boolean;
  variants: ServiceVariant[];
}

interface VendorMedia {
  id: string;
  type: 'image' | 'video';
  url: string;
  thumbnail_url?: string;
  title?: string;
  description?: string;
  created_at: string;
}

interface Payout {
  id: string;
  amount: number;
  status: string;
  description: string;
  created_at: string;
  stripe_transfer_id: string | null;
}

interface BackgroundCheck {
  id: string;
  status: 'pending' | 'approved' | 'rejected';
  document_url: string | null;
  notes: string | null;
  submitted_at: string;
  reviewed_at: string | null;
}

interface Vendor {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  status: string;
  onboarding_notes: string | null;
  rating: number | null;
  approved: boolean;
  accepts_custom_packages: boolean;
  background_check_required: boolean;
  background_check_status: string | null;
  stripe_account_id: string | null;
  stripe_onboarding_complete: boolean;
  stripe_onboarding_url: string | null;
  profile_image_url: string | null;
  bio: string | null;
  website: string | null;
  instagram: string | null;
  facebook: string | null;
  services: Service[];
  service_variants: string[];
  media: VendorMedia[];
  payouts: Payout[];
  background_checks: BackgroundCheck[];
}

interface Quote {
  id: string;
  amount: number;
  status: string;
  created_at: string;
  payouts: Payout[];
}

interface YearlyTotal {
  year: number;
  total: number;
  count: number;
}

interface MediaUpload {
  file: File;
  type: 'image' | 'video';
  progress: number;
}

interface Job {
  id: string;
  title: string;
  description: string;
  requirements: string | null;
  status: string;
  venue_id: string | null;
  date: string;
  budget: number | null;
  created_at: string;
  updated_at: string;
  venue?: {
    name: string;
    address: string;
  };
}

function centerAspectCrop(
  mediaWidth: number,
  mediaHeight: number,
  aspect: number,
) {
  return centerCrop(
    makeAspectCrop(
      {
        unit: '%',
        width: 90,
      },
      aspect,
      mediaWidth,
      mediaHeight,
    ),
    mediaWidth,
    mediaHeight,
  )
}

export default function VendorEdit() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [vendor, setVendor] = useState<Vendor | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [services, setServices] = useState<Service[]>([]);
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({});
  const [showCropModal, setShowCropModal] = useState(false);
  const [cropImage, setCropImage] = useState('');
  const [crop, setCrop] = useState<Crop>();
  const [completedCrop, setCompletedCrop] = useState<PixelCrop>();
  const imgRef = useRef<HTMLImageElement>(null);
  const [profileImageFile, setProfileImageFile] = useState<File | null>(null);
  const [profileImagePreview, setProfileImagePreview] = useState<string>('');
  const profileImageRef = useRef<HTMLInputElement>(null);
  const [payouts, setPayouts] = useState<Payout[]>([]);
  const [showPayoutModal, setShowPayoutModal] = useState(false);
  const [newPayout, setNewPayout] = useState({
    amount: 0,
    description: ''
  });
  const [mediaUploads, setMediaUploads] = useState<{ [key: string]: MediaUpload }>({});
  const [showMediaModal, setShowMediaModal] = useState(false);
  const [mediaTitle, setMediaTitle] = useState('');
  const [mediaDescription, setMediaDescription] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [yearlyTotals, setYearlyTotals] = useState<YearlyTotal[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [jobsFilter, setJobsFilter] = useState<'upcoming' | 'past' | 'all'>('upcoming');
  const [showBackgroundCheckModal, setShowBackgroundCheckModal] = useState(false);
  const [backgroundCheckFile, setBackgroundCheckFile] = useState<File | null>(null);
  const [backgroundCheckUploading, setBackgroundCheckUploading] = useState(false);
  const [backgroundCheckProgress, setBackgroundCheckProgress] = useState(0);

  const { getRootProps: getMediaRootProps, getInputProps: getMediaInputProps } = useDropzone({
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.gif'],
      'video/*': ['.mp4', '.webm']
    },
    onDrop: handleMediaDrop
  });

  const { getRootProps: getBackgroundCheckRootProps, getInputProps: getBackgroundCheckInputProps } = useDropzone({
    accept: {
      'application/pdf': ['.pdf'],
      'image/*': ['.jpeg', '.jpg', '.png']
    },
    maxFiles: 1,
    onDrop: handleBackgroundCheckDrop
  });

  useEffect(() => {
    if (id) {
      fetchVendor();
      fetchServices();
      fetchPayouts();
      fetchQuotes();
      fetchJobs();
    }
  }, [id]);

  async function fetchVendor() {
    try {
      const { data: vendorData, error: vendorError } = await supabase
        .from('vendors')
        .select(`
          *,
          services: vendor_services (
            service:services (
              *,
              variants:service_variants(*)
            )
          ),
          service_variants: vendor_service_variants (
            variant:service_variants(*)
          ),
          media: vendor_media(*),
          background_checks: vendor_background_checks(*)
        `)
        .eq('id', id)
        .single();

      if (vendorError) throw vendorError;

      // Transform the nested data structure
      const transformedVendor = {
        ...vendorData,
        accepts_custom_packages: vendorData.accepts_custom_packages || false,
        background_check_required: vendorData.background_check_required || false,
        services: vendorData.services.map((s: any) => ({
          ...s.service,
          variants: s.service.variants
        })),
        service_variants: vendorData.service_variants.map((sv: any) => sv.variant.id),
        background_checks: vendorData.background_checks || []
      };

      setVendor(transformedVendor);
    } catch (err) {
      console.error('Error fetching vendor:', err);
      setError('Failed to load vendor data');
    } finally {
      setLoading(false);
    }
  }

  async function fetchServices() {
    try {
      const { data, error } = await supabase
        .from('services')
        .select(`
          *,
          variants:service_variants(*)
        `)
        .order('name');

      if (error) throw error;
      setServices(data || []);
    } catch (err) {
      console.error('Error fetching services:', err);
      setError('Failed to load services');
    }
  }

  async function fetchPayouts() {
    try {
      const { data, error } = await supabase
        .from('payouts')
        .select('*')
        .eq('vendor_id', id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPayouts(data || []);
    } catch (err) {
      console.error('Error fetching payouts:', err);
    }
  }

  async function fetchQuotes() {
    if (!id) return;

    try {
      const { data, error } = await supabase
        .from('quotes')
        .select(`
          id,
          amount,
          status,
          created_at,
          payouts (
            id,
            amount,
            status,
            created_at
          )
        `)
        .eq('vendor_id', id)
        .eq('status', 'paid')
        .order('created_at', { ascending: false });

      if (error) throw error;

      setQuotes(data || []);

      // Calculate yearly totals
      const totals = (data || []).reduce((acc: YearlyTotal[], quote) => {
        const year = new Date(quote.created_at).getFullYear();
        const yearTotal = acc.find(t => t.year === year);
        
        if (yearTotal) {
          yearTotal.total += quote.amount;
          yearTotal.count += 1;
        } else {
          acc.push({ year, total: quote.amount, count: 1 });
        }
        
        return acc;
      }, []);

      setYearlyTotals(totals.sort((a, b) => b.year - a.year));
    } catch (err) {
      console.error('Error fetching quotes:', err);
    }
  }

  async function fetchJobs() {
    if (!id) return;

    try {
      // First get all venues associated with this vendor's bookings
      const { data: bookings, error: bookingsError } = await supabase
        .from('bookings')
        .select('venue_id')
        .eq('vendor_id', id)
        .not('venue_id', 'is', null);

      if (bookingsError) throw bookingsError;

      // Get unique venue IDs
      const venueIds = [...new Set(bookings?.map(b => b.venue_id) || [])];

      if (venueIds.length === 0) {
        setJobs([]);
        return;
      }

      // Then fetch jobs for these venues
      const { data, error } = await supabase
        .from('jobs')
        .select(`
          *,
          venue:venues(
            name,
            address
          )
        `)
        .in('venue_id', venueIds)
        .order('date', { ascending: true });

      if (error) throw error;
      setJobs(data || []);
    } catch (err) {
      console.error('Error fetching jobs:', err);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!vendor) return;

    setSaving(true);
    try {
      const { error: vendorError } = await supabase
        .from('vendors')
        .update({
          name: vendor.name,
          email: vendor.email,
          phone: vendor.phone,
          status: vendor.status,
          onboarding_notes: vendor.onboarding_notes,
          approved: vendor.approved,
          accepts_custom_packages: vendor.accepts_custom_packages,
          background_check_required: vendor.background_check_required,
          bio: vendor.bio,
          website: vendor.website,
          instagram: vendor.instagram,
          facebook: vendor.facebook,
          stripe_account_id: vendor.stripe_account_id,
        })
        .eq('id', vendor.id);

      if (vendorError) throw vendorError;

      // Update services
      await supabase
        .from('vendor_services')
        .delete()
        .eq('vendor_id', vendor.id);

      if (vendor.services.length > 0) {
        await supabase
          .from('vendor_services')
          .insert(
            vendor.services.map(service => ({
              vendor_id: vendor.id,
              service_id: service.id
            }))
          );
      }

      // Update service variants
      await supabase
        .from('vendor_service_variants')
        .delete()
        .eq('vendor_id', vendor.id);

      if (vendor.service_variants.length > 0) {
        await supabase
          .from('vendor_service_variants')
          .insert(
            vendor.service_variants.map(variantId => ({
              vendor_id: vendor.id,
              variant_id: variantId
            }))
          );
      }

      navigate('/vendors');
    } catch (err) {
      console.error('Error saving vendor:', err);
      setError('Failed to save vendor');
    } finally {
      setSaving(false);
    }
  }

  async function handleProfileImageChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !vendor) return;

    try {
      setProfileImageFile(file);
      setProfileImagePreview(URL.createObjectURL(file));
      setShowCropModal(true);
    } catch (err) {
      console.error('Error handling profile image:', err);
      setError('Failed to process profile image');
    }
  }

  async function handleCropComplete() {
    if (!profileImageFile || !vendor || !completedCrop) return;

    try {
      const filePath = `${vendor.id}/profile/${profileImageFile.name}`;
      const { error: uploadError } = await supabase.storage
        .from('vendor-media')
        .upload(filePath, profileImageFile);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('vendor-media')
        .getPublicUrl(filePath);

      const { error: updateError } = await supabase
        .from('vendors')
        .update({ profile_image_url: publicUrl })
        .eq('id', vendor.id);

      if (updateError) throw updateError;

      setVendor({ ...vendor, profile_image_url: publicUrl });
      setShowCropModal(false);
      setProfileImageFile(null);
      setProfileImagePreview('');
    } catch (err) {
      console.error('Error uploading profile image:', err);
      setError('Failed to upload profile image');
    }
  }

  async function handleMediaDrop(acceptedFiles: File[]) {
    const file = acceptedFiles[0];
    if (!file) return;

    setSelectedFile(file);
    setShowMediaModal(true);
  }

  async function handleMediaUpload() {
    if (!selectedFile || !vendor) return;

    const fileId = Math.random().toString(36).substring(7);
    const fileType = selectedFile.type.startsWith('image/') ? 'image' : 'video';

    setMediaUploads(prev => ({
      ...prev,
      [fileId]: {
        file: selectedFile,
        type: fileType,
        progress: 0
      }
    }));

    try {
      const filePath = `${vendor.id}/media/${selectedFile.name}`;
      const { error: uploadError } = await supabase.storage
        .from('vendor-media')
        .upload(filePath, selectedFile, {
          onUploadProgress: (progress) => {
            const percent = (progress.loaded / progress.total) * 100;
            setMediaUploads(prev => ({
              ...prev,
              [fileId]: {
                ...prev[fileId],
                progress: percent
              }
            }));
          }
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('vendor-media')
        .getPublicUrl(filePath);

      const { error: mediaError } = await supabase
        .from('vendor_media')
        .insert({
          vendor_id: vendor.id,
          type: fileType,
          url: publicUrl,
          title: mediaTitle,
          description: mediaDescription
        });

      if (mediaError) throw mediaError;

      // Refresh vendor data to get updated media
      fetchVendor();

      setShowMediaModal(false);
      setSelectedFile(null);
      setMediaTitle('');
      setMediaDescription('');
      setMediaUploads(prev => {
        const newUploads = { ...prev };
        delete newUploads[fileId];
        return newUploads;
      });
    } catch (error) {
      console.error('Error uploading media:', error);
      setError('Failed to upload media');
    }
  }

  async function handleDeleteMedia(mediaId: string, url: string) {
    try {
      const filePath = new URL(url).pathname.split('/').pop();
      if (filePath) {
        await supabase.storage
          .from('vendor-media')
          .remove([`${vendor?.id}/media/${filePath}`]);
      }

      const { error } = await supabase
        .from('vendor_media')
        .delete()
        .eq('id', mediaId);

      if (error) throw error;

      fetchVendor();
    } catch (error) {
      console.error('Error deleting media:', error);
      setError('Failed to delete media');
    }
  }

  async function handleBackgroundCheckDrop(acceptedFiles: File[]) {
    const file = acceptedFiles[0];
    if (!file || !vendor) return;
    
    setBackgroundCheckFile(file);
  }

  async function handleBackgroundCheckUpload() {
    if (!backgroundCheckFile || !vendor) return;
    
    setBackgroundCheckUploading(true);
    
    try {
      // Upload the file to storage
      const filePath = `${vendor.id}/background-checks/${backgroundCheckFile.name}`;
      const { error: uploadError } = await supabase.storage
        .from('vendor-documents')
        .upload(filePath, backgroundCheckFile, {
          onUploadProgress: (progress) => {
            const percent = (progress.loaded / progress.total) * 100;
            setBackgroundCheckProgress(percent);
          }
        });
        
      if (uploadError) throw uploadError;
      
      // Get the public URL
      const { data: { publicUrl } } = supabase.storage
        .from('vendor-documents')
        .getPublicUrl(filePath);
        
      // Create a background check record
      const { error: checkError } = await supabase
        .from('vendor_background_checks')
        .insert({
          vendor_id: vendor.id,
          status: 'pending',
          document_url: publicUrl,
          submitted_at: new Date().toISOString()
        });
        
      if (checkError) throw checkError;
      
      // Update vendor's background check status
      const { error: vendorError } = await supabase
        .from('vendors')
        .update({
          background_check_status: 'pending'
        })
        .eq('id', vendor.id);
        
      if (vendorError) throw vendorError;
      
      // Refresh vendor data
      fetchVendor();
      
      // Close modal and reset state
      setShowBackgroundCheckModal(false);
      setBackgroundCheckFile(null);
      setBackgroundCheckProgress(0);
    } catch (err) {
      console.error('Error uploading background check:', err);
      setError('Failed to upload background check document');
    } finally {
      setBackgroundCheckUploading(false);
    }
  }

  const filteredJobs = jobs.filter(job => {
    const jobDate = new Date(job.date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    switch (jobsFilter) {
      case 'upcoming':
        return jobDate >= today;
      case 'past':
        return jobDate < today;
      default:
        return true;
    }
  });

  const latestBackgroundCheck = vendor?.background_checks?.length > 0 
    ? vendor.background_checks.sort((a, b) => 
        new Date(b.submitted_at).getTime() - new Date(a.submitted_at).getTime()
      )[0]
    : null;

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!vendor) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-700">Vendor not found</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/vendors')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Edit Vendor</h1>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6">
            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
                <AlertCircle className="w-5 h-5" />
                {error}
              </div>
            )}

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Name
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={vendor.name}
                  onChange={(e) => setVendor({ ...vendor, name: e.target.value })}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={vendor.email}
                  onChange={(e) => setVendor({ ...vendor, email: e.target.value })}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Phone
                </label>
                <input
                  type="tel"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={vendor.phone || ''}
                  onChange={(e) => setVendor({ ...vendor, phone: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Bio
                </label>
                <textarea
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={4}
                  value={vendor.bio || ''}
                  onChange={(e) => setVendor({ ...vendor, bio: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="w-full">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Website
                  </label>
                  <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500 overflow-hidden">
                    <Globe className="w-5 h-5 text-gray-400 ml-3 shrink-0" />
                    <input
                      type="url"
                      className="w-full px-3 py-2 focus:outline-none"
                      value={vendor.website || ''}
                      onChange={(e) => setVendor({ ...vendor, website: e.target.value })}
                    />
                  </div>
                </div>

                <div className="w-full">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Instagram
                  </label>
                  <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500 overflow-hidden">
                    <Instagram className="w-5 h-5 text-gray-400 ml-3 shrink-0" />
                    <input
                      type="text"
                      className="w-full px-3 py-2 focus:outline-none"
                      value={vendor.instagram || ''}
                      onChange={(e) => setVendor({ ...vendor, instagram: e.target.value })}
                    />
                  </div>
                </div>

                <div className="w-full">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Facebook
                  </label>
                  <div className="flex items-center border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-blue-500 overflow-hidden">
                    <Facebook className="w-5 h-5 text-gray-400 ml-3 shrink-0" />
                    <input
                      type="text"
                      className="w-full px-3 py-2 focus:outline-none"
                      value={vendor.facebook || ''}
                      onChange={(e) => setVendor({ ...vendor, facebook: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Status
                </label>
                <select
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={vendor.status}
                  onChange={(e) => setVendor({ ...vendor, status: e.target.value })}
                >
                  <option value="pending">Pending</option>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Onboarding Notes
                </label>
                <textarea
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={4}
                  value={vendor.onboarding_notes || ''}
                  onChange={(e) => setVendor({ ...vendor, onboarding_notes: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Stripe Connect Account ID
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={vendor.stripe_account_id || ''}
                  onChange={(e) => setVendor({ ...vendor, stripe_account_id: e.target.value })}
                  placeholder="Enter Stripe Connect Account ID"
                />
              </div>

              <div className="flex flex-col gap-3">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="approved"
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    checked={vendor.approved}
                    onChange={(e) => setVendor({ ...vendor, approved: e.target.checked })}
                  />
                  <span className="text-sm text-gray-700">Approved for booking</span>
                </label>
                
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="accepts_custom_packages"
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    checked={vendor.accepts_custom_packages}
                    onChange={(e) => setVendor({ ...vendor, accepts_custom_packages: e.target.checked })}
                  />
                  <div className="flex items-center gap-1">
                    <Settings className="w-4 h-4 text-gray-600" />
                    <span className="text-sm text-gray-700">Accepts custom packages</span>
                  </div>
                </label>
                <p className="text-xs text-gray-500 ml-6">
                  Enable this to allow this vendor to receive custom package requests from couples
                </p>

                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="background_check_required"
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    checked={vendor.background_check_required}
                    onChange={(e) => setVendor({ ...vendor, background_check_required: e.target.checked })}
                  />
                  <div className="flex items-center gap-1">
                    <Shield className="w-4 h-4 text-gray-600" />
                    <span className="text-sm text-gray-700">Background check required</span>
                  </div>
                </label>
                <p className="text-xs text-gray-500 ml-6">
                  Require this vendor to submit a background check before being approved
                </p>
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => navigate('/vendors')}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                disabled={saving}
              >
                <Save className="w-5 h-5" />
                {saving ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </form>

          {/* Background Check Section */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Background Check</h2>
              <button
                onClick={() => setShowBackgroundCheckModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Upload className="w-4 h-4" />
                Upload Background Check
              </button>
            </div>

            {latestBackgroundCheck ? (
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <FileText className="w-5 h-5 text-gray-500" />
                      <span className="font-medium text-gray-900">Background Check Document</span>
                    </div>
                    
                    <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                      <Calendar className="w-4 h-4" />
                      <span>Submitted: {new Date(latestBackgroundCheck.submitted_at).toLocaleDateString()}</span>
                    </div>
                    
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        latestBackgroundCheck.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        latestBackgroundCheck.status === 'approved' ? 'bg-green-100 text-green-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {latestBackgroundCheck.status.charAt(0).toUpperCase() + latestBackgroundCheck.status.slice(1)}
                      </span>
                    </div>
                    
                    {latestBackgroundCheck.notes && (
                      <div className="mt-2 text-sm text-gray-700">
                        <p className="font-medium">Notes:</p>
                        <p className="mt-1">{latestBackgroundCheck.notes}</p>
                      </div>
                    )}
                  </div>
                  
                  {latestBackgroundCheck.document_url && (
                    <a
                      href={latestBackgroundCheck.document_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 flex items-center gap-1"
                    >
                      <Eye className="w-4 h-4" />
                      <span>View Document</span>
                    </a>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <p>No background check has been submitted yet.</p>
                <button
                  onClick={() => setShowBackgroundCheckModal(true)}
                  className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Upload Background Check
                </button>
              </div>
            )}
          </div>

          {/* Gallery Section */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Gallery</h2>
              <div {...getMediaRootProps()}>
                <input {...getMediaInputProps()} />
                <button
                  type="button"
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  <Upload className="w-4 h-4" />
                  Add Media
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {vendor.media.map((media) => (
                <div key={media.id} className="relative group">
                  {media.type === 'image' ? (
                    <img
                      src={media.url}
                      alt={media.title || ''}
                      className="w-full h-48 object-cover rounded-lg"
                    />
                  ) : (
                    <video
                      src={media.url}
                      className="w-full h-48 object-cover rounded-lg"
                      controls
                    />
                  )}
                  <button
                    onClick={() => handleDeleteMedia(media.id, media.url)}
                    className="absolute top-2 right-2 p-1 bg-red-600 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-4 h-4" />
                  </button>
                  {media.title && (
                    <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white p-2 rounded-b-lg">
                      <p className="text-sm font-medium truncate">{media.title}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {Object.entries(mediaUploads).map(([id, upload]) => (
              <div key={id} className="mt-4">
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>Uploading {upload.file.name}...</span>
                  <span>{Math.round(upload.progress)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${upload.progress}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Jobs Section */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Jobs</h2>
              <div className="flex gap-2">
                <button
                  onClick={() => setJobsFilter('upcoming')}
                  className={`px-3 py-1 rounded-lg text-sm ${
                    jobsFilter === 'upcoming'
                      ? 'bg-blue-100 text-blue-800'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  Upcoming
                </button>
                <button
                  onClick={() => setJobsFilter('past')}
                  className={`px-3 py-1 rounded-lg text-sm ${
                    jobsFilter === 'past'
                      ? 'bg-blue-100 text-blue-800'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  Past
                </button>
                <button
                  onClick={() => setJobsFilter('all')}
                  className={`px-3 py-1 rounded-lg text-sm ${
                    jobsFilter === 'all'
                      ? 'bg-blue-100 text-blue-800'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  All
                </button>
              </div>
            </div>

            <div className="space-y-4">
              {filteredJobs.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-gray-500">No jobs found</p>
                </div>
              ) : (
                filteredJobs.map((job) => (
                  <div
                    key={job.id}
                    className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-medium text-gray-900">{job.title}</h3>
                        <p className="text-sm text-gray-500 mt-1">
                          {new Date(job.date).toLocaleDateString()}
                        </p>
                        {job.venue && (
                          <div className="flex items-center gap-1 text-sm text-gray-500 mt-2">
                            <MapPin className="w-4 h-4" />
                            <span>{job.venue.name}</span>
                          </div>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        {job.budget && (
                          <div className="flex items-center gap-1 text-gray-700">
                            <DollarSign className="w-4 h-4" />
                            <span>{job.budget}</span>
                          </div>
                        )}
                        <div
                          className={`px-2 py-1 rounded-full text-xs font-medium ${
                            job.status === 'open'
                              ? 'bg-green-100 text-green-800'
                              : job.status === 'closed'
                              ? 'bg-red-100 text-red-800'
                              : 'bg-gray-100 text-gray-800'
                          }`}
                        >
                          {job.status}
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        <div>
          {/* Profile Image */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Profile Image</h2>
            <div className="flex flex-col items-center">
              <div className="relative mb-4">
                {vendor.profile_image_url ? (
                  <img 
                    src={vendor.profile_image_url} 
                    alt={vendor.name} 
                    className="w-32 h-32 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center">
                    <Building2 className="w-16 h-16 text-gray-400" />
                  </div>
                )}
                <label className="absolute bottom-0 right-0 bg-blue-600 rounded-full p-2 cursor-pointer">
                  <input 
                    type="file" 
                    className="hidden" 
                    accept="image/*"
                    onChange={handleProfileImageChange}
                    ref={profileImageRef}
                  />
                  <Upload className="w-4 h-4 text-white" />
                </label>
              </div>
              <button
                type="button"
                onClick={() => profileImageRef.current?.click()}
                className="text-blue-600 hover:text-blue-800 text-sm"
              >
                Change Profile Image
              </button>
            </div>
          </div>

          {/* Services Section */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Services</h2>
            
            {services.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No services available</p>
            ) : (
              <div className="space-y-4">
                {services.map(service => (
                  <div key={service.id} className="border border-gray-200 rounded-lg p-4">
                    <label className="flex items-center justify-between">
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          checked={vendor.services.some(s => s.id === service.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setVendor({
                                ...vendor,
                                services: [...vendor.services, service]
                              });
                            } else {
                              setVendor({
                                ...vendor,
                                services: vendor.services.filter(s => s.id !== service.id),
                                service_variants: vendor.service_variants.filter(variantId => 
                                  !service.variants.some(v => v.id === variantId)
                                )
                              });
                            }
                          }}
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="ml-2 font-medium text-gray-900">{service.name}</span>
                      </div>
                      
                      {service.allows_custom_packages && (
                        <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full flex items-center">
                          <Settings className="w-3 h-3 mr-1" />
                          Custom Packages
                        </span>
                      )}
                    </label>
                    
                    {vendor.services.some(s => s.id === service.id) && service.variants.length > 0 && (
                      <div className="mt-3 ml-6 space-y-2">
                        <div className="text-sm font-medium text-gray-700">Service Options:</div>
                        {service.variants.map(variant => (
                          <label key={variant.id} className="flex items-center">
                            <input
                              type="checkbox"
                              checked={vendor.service_variants.includes(variant.id)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setVendor({
                                    ...vendor,
                                    service_variants: [...vendor.service_variants, variant.id]
                                  });
                                } else {
                                  setVendor({
                                    ...vendor,
                                    service_variants: vendor.service_variants.filter(id => id !== variant.id)
                                  });
                                }
                              }}
                              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                            />
                            <span className="ml-2 text-gray-700">{variant.name}</span>
                            <span className="ml-2 text-sm text-gray-500">
                              (${variant.price}{variant.hours ? `, ${variant.hours} hours` : ''})
                            </span>
                          </label>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Background Check Upload Modal */}
      {showBackgroundCheckModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Upload Background Check</h2>
            
            <div className="mb-6">
              <p className="text-gray-600">
                Please upload a background check document for this vendor. 
                Accepted formats: PDF, JPG, PNG.
              </p>
            </div>
            
            {backgroundCheckFile ? (
              <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <FileText className="w-5 h-5 text-gray-500 mr-2" />
                    <div>
                      <div className="font-medium text-gray-900">{backgroundCheckFile.name}</div>
                      <div className="text-sm text-gray-500">
                        {(backgroundCheckFile.size / 1024 / 1024).toFixed(2)} MB
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => setBackgroundCheckFile(null)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ) : (
              <div 
                {...getBackgroundCheckRootProps()} 
                className="mb-6 border-2 border-dashed border-gray-300 rounded-lg p-6 text-center cursor-pointer hover:border-gray-400"
              >
                <input {...getBackgroundCheckInputProps()} />
                <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-600">Drag & drop a file here, or click to select</p>
                <p className="text-sm text-gray-500 mt-1">PDF, JPG, or PNG (max 10MB)</p>
              </div>
            )}
            
            {backgroundCheckProgress > 0 && backgroundCheckProgress < 100 && (
              <div className="mb-6">
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>Uploading...</span>
                  <span>{Math.round(backgroundCheckProgress)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${backgroundCheckProgress}%` }}
                  />
                </div>
              </div>
            )}
            
            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowBackgroundCheckModal(false);
                  setBackgroundCheckFile(null);
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                disabled={backgroundCheckUploading}
              >
                Cancel
              </button>
              <button
                onClick={handleBackgroundCheckUpload}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                disabled={!backgroundCheckFile || backgroundCheckUploading}
              >
                {backgroundCheckUploading ? 'Uploading...' : 'Upload Document'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Media Upload Modal */}
      {showMediaModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Add Media</h2>
            
            {selectedFile && (
              <div className="mb-6">
                <div className="text-sm font-medium text-gray-700 mb-1">Selected File</div>
                <div className="flex items-center">
                  {selectedFile.type.startsWith('image/') ? (
                    <ImageIcon className="w-5 h-5 text-gray-500 mr-2" />
                  ) : (
                    <Video className="w-5 h-5 text-gray-500 mr-2" />
                  )}
                  <span className="text-gray-900">{selectedFile.name}</span>
                </div>
              </div>
            )}
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Title
                </label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  value={mediaTitle}
                  onChange={(e) => setMediaTitle(e.target.value)}
                  placeholder="Enter a title for this media"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  rows={3}
                  value={mediaDescription}
                  onChange={(e) => setMediaDescription(e.target.value)}
                  placeholder="Enter a description (optional)"
                />
              </div>
            </div>
            
            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowMediaModal(false);
                  setSelectedFile(null);
                  setMediaTitle('');
                  setMediaDescription('');
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleMediaUpload}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                disabled={!selectedFile}
              >
                Upload
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}