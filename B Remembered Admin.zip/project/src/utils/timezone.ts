// Timezone utilities for consistent date/time handling
export const TIME_ZONE = 'America/New_York';

// Format a date to EST
export function formatToEST(date: Date | string): string {
  return new Date(date).toLocaleString('en-US', {
    timeZone: TIME_ZONE,
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

// Format a time to EST
export function formatTimeToEST(date: Date | string): string {
  return new Date(date).toLocaleString('en-US', {
    timeZone: TIME_ZONE,
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
}

// Format a datetime to EST
export function formatDateTimeToEST(date: Date | string): string {
  return new Date(date).toLocaleString('en-US', {
    timeZone: TIME_ZONE,
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
}

// Convert a local date to EST for API submission
export function convertToEST(date: string, time?: string): string {
  const dateObj = time 
    ? new Date(`${date}T${time}`)
    : new Date(date);
  
  return dateObj.toLocaleString('en-US', {
    timeZone: TIME_ZONE,
  });
}

// Get current date in EST
export function getCurrentDateEST(): string {
  return new Date().toLocaleDateString('en-US', {
    timeZone: TIME_ZONE,
  });
}

// Get current time in EST (HH:mm format)
export function getCurrentTimeEST(): string {
  return new Date().toLocaleTimeString('en-US', {
    timeZone: TIME_ZONE,
    hour12: false,
    hour: '2-digit',
    minute: '2-digit',
  });
}

// Format a month and year to EST
export function formatMonthYearToEST(date: Date | string): string {
  return new Date(date).toLocaleString('en-US', {
    timeZone: TIME_ZONE,
    year: 'numeric',
    month: 'long',
  });
}

// Get start of month in EST
export function getStartOfMonthEST(): Date {
  const now = new Date();
  const estDate = new Date(now.toLocaleString('en-US', { timeZone: TIME_ZONE }));
  return new Date(estDate.getFullYear(), estDate.getMonth(), 1);
}

// Get start of year in EST
export function getStartOfYearEST(): Date {
  const now = new Date();
  const estDate = new Date(now.toLocaleString('en-US', { timeZone: TIME_ZONE }));
  return new Date(estDate.getFullYear(), 0, 1);
}

// Parse EST date string to Date object
export function parseESTDate(dateString: string): Date {
  return new Date(dateString + ' EST');
}