import { create } from 'zustand';
import { supabase } from '../lib/supabase';

interface AdminUser {
  id: string;
  email: string;
  role: string;
}

interface AuthState {
  user: any | null;
  adminData: AdminUser | null;
  session: any | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  initialize: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  adminData: null,
  session: null,
  loading: true,
  signIn: async (email, password) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) throw error;

    // Fetch admin user data
    const { data: adminData, error: adminError } = await supabase
      .from('admin_users')
      .select('*')
      .eq('id', data.user.id)
      .single();

    if (adminError) throw adminError;
    if (!adminData) throw new Error('Unauthorized access');

    set({ 
      user: data.user, 
      session: data.session,
      adminData
    });
  },
  signOut: async () => {
    await supabase.auth.signOut();
    set({ user: null, session: null, adminData: null });
  },
  initialize: async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session) {
        // Fetch admin user data
        const { data: adminData } = await supabase
          .from('admin_users')
          .select('*')
          .eq('id', session.user.id)
          .single();

        set({ 
          user: session?.user ?? null, 
          session,
          adminData: adminData ?? null
        });
      }
    } catch (error) {
      console.error('Error initializing auth:', error);
    } finally {
      set({ loading: false });
    }
  },
}));