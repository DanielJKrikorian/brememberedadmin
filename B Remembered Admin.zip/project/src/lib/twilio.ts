import { supabase } from './supabase';

// Twilio credentials
const TWILIO_SID = 'SKf09347962c409780b81070056c79be99';
const TWILIO_SECRET = 'QtMM8VqLABO0Yjz0SEDIZvh4CJOrP9tv';
const TWILIO_PHONE_NUMBER = '+18665747943'; // Updated Twilio phone number

// Function to replace variables in template
export function replaceTemplateVariables(content: string, variables: Record<string, string>) {
  let result = content;
  
  for (const [key, value] of Object.entries(variables)) {
    const regex = new RegExp(`{{${key}}}`, 'g');
    result = result.replace(regex, value);
  }
  
  return result;
}

// Function to get template content from database
export async function getTemplateById(templateId: string) {
  try {
    const { data, error } = await supabase
      .from('email_templates')
      .select('*')
      .eq('id', templateId)
      .single();
      
    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error fetching template:', error);
    throw error;
  }
}

// Function to send SMS using Twilio
export async function sendSMS(to: string, body: string) {
  try {
    const url = `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_SID}/Messages.json`;
    
    const formData = new URLSearchParams();
    formData.append('To', to);
    formData.append('From', TWILIO_PHONE_NUMBER);
    formData.append('Body', body);
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Basic ' + btoa(`${TWILIO_SID}:${TWILIO_SECRET}`)
      },
      body: formData
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || 'Failed to send SMS');
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error sending SMS:', error);
    throw error;
  }
}

// Function to send SMS using a template
export async function sendTemplatedSMS({
  templateId,
  to,
  variables
}: {
  templateId: string;
  to: string | string[];
  variables: Record<string, string>;
}) {
  try {
    // Get template content
    const template = await getTemplateById(templateId);
    
    if (!template || template.type !== 'sms') {
      throw new Error('Invalid template or template type');
    }
    
    // Replace variables
    const content = replaceTemplateVariables(template.content, variables);
    
    // Handle multiple recipients
    const recipients = Array.isArray(to) ? to : [to];
    
    // Send SMS to each recipient
    const results = await Promise.all(
      recipients.map(recipient => sendSMS(recipient, content))
    );
    
    return results;
  } catch (error) {
    console.error('Error sending templated SMS:', error);
    throw error;
  }
}

// Function to validate phone number format
export function validatePhoneNumber(phone: string): boolean {
  // Basic validation - can be enhanced based on requirements
  const phoneRegex = /^\+?[1-9]\d{1,14}$/;
  return phoneRegex.test(phone);
}

// Function to format phone number to E.164 format
export function formatPhoneNumber(phone: string): string {
  // Remove all non-digit characters
  const digits = phone.replace(/\D/g, '');
  
  // Check if the number already has a country code
  if (phone.startsWith('+')) {
    return phone;
  }
  
  // Add US country code (+1) if not present
  return `+1${digits}`;
}