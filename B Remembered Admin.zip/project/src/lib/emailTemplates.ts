import { Resend } from 'resend';

// Initialize Resend with API key
export const resend = new Resend(import.meta.env.VITE_RESEND_API_KEY || '');

// Function to get template content from database
export async function getTemplateContent(templateId: string) {
  // This would be replaced with a real database call
  // For now, we'll return a placeholder
  return {
    subject: 'Template Subject',
    content: '<p>Template content</p>'
  };
}

// Function to replace variables in template
export function replaceTemplateVariables(content: string, variables: Record<string, string>) {
  let result = content;
  
  for (const [key, value] of Object.entries(variables)) {
    const regex = new RegExp(`{{${key}}}`, 'g');
    result = result.replace(regex, value);
  }
  
  return result;
}

// Function to send an email using a template
export async function sendTemplatedEmail({
  templateId,
  to,
  variables,
  from = 'B. Remembered Weddings <noreply@b-remembered.com>'
}: {
  templateId: string;
  to: string | string[];
  variables: Record<string, string>;
  from?: string;
}) {
  try {
    // Get template content
    const template = await getTemplateContent(templateId);
    
    // Replace variables
    const subject = replaceTemplateVariables(template.subject, variables);
    const html = replaceTemplateVariables(template.content, variables);
    
    // Send email
    const { data, error } = await resend.emails.send({
      from,
      to,
      subject,
      html
    });
    
    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error sending templated email:', error);
    throw error;
  }
}

// Function to send an SMS using a template
export async function sendTemplatedSMS({
  templateId,
  to,
  variables
}: {
  templateId: string;
  to: string | string[];
  variables: Record<string, string>;
}) {
  try {
    // Get template content
    const template = await getTemplateContent(templateId);
    
    // Replace variables
    const content = replaceTemplateVariables(template.content, variables);
    
    // In a real implementation, you would use an SMS service like Twilio
    // For now, we'll just log the message
    console.log(`Sending SMS to ${to}: ${content}`);
    
    return { success: true };
  } catch (error) {
    console.error('Error sending templated SMS:', error);
    throw error;
  }
}