import { Resend } from 'resend';

// Initialize Resend with API key
export const resend = new Resend('re_789QctLP_NyajHL6uJJ9HAk2WQVHdWx9E');

// Email templates
export const emailTemplates = {
  // Welcome email template
  welcome: (name: string) => ({
    subject: 'Welcome to B. Remembered Weddings',
    html: `
      <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #333333;">
        <div style="text-align: center; margin-bottom: 30px;">
          <img src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png" alt="B. Remembered Logo" style="max-width: 200px; height: auto;">
        </div>
        <h1 style="color: #333333; font-size: 24px; margin-bottom: 20px;">Welcome, ${name || 'there'}!</h1>
        <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">Thank you for joining B. Remembered Weddings. We're excited to help make your special day unforgettable.</p>
        <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">If you have any questions, please don't hesitate to reach out to our team.</p>
        <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eeeeee;">
          <p style="font-size: 14px; color: #777777;">© 2025 B. Remembered Weddings. All rights reserved.</p>
        </div>
      </div>
    `
  }),
  
  // Quote notification template
  quoteNotification: (recipientName: string, quoteLink: string) => ({
    subject: 'Your Quote from B. Remembered Weddings',
    html: `
      <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #333333;">
        <div style="text-align: center; margin-bottom: 30px;">
          <img src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png" alt="B. Remembered Logo" style="max-width: 200px; height: auto;">
        </div>
        <h1 style="color: #333333; font-size: 24px; margin-bottom: 20px;">Hello, ${recipientName || 'there'}!</h1>
        <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">Your quote from B. Remembered Weddings is ready to view.</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${quoteLink}" style="display: inline-block; background-color: #9e8a78; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-size: 16px;">View Your Quote</a>
        </div>
        <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">If you have any questions, please don't hesitate to contact us.</p>
        <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eeeeee;">
          <p style="font-size: 14px; color: #777777;">© 2025 B. Remembered Weddings. All rights reserved.</p>
        </div>
      </div>
    `
  }),
  
  // Content transfer notification template
  contentTransferNotification: (recipientName: string, transferLink: string, accessCode: string) => ({
    subject: 'Files Shared with You - B. Remembered Weddings',
    html: `
      <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #333333;">
        <div style="text-align: center; margin-bottom: 30px;">
          <img src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png" alt="B. Remembered Logo" style="max-width: 200px; height: auto;">
        </div>
        <h1 style="color: #333333; font-size: 24px; margin-bottom: 20px;">Hello, ${recipientName || 'there'}!</h1>
        <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">Files have been shared with you from B. Remembered Weddings.</p>
        <div style="background-color: #f8f8f8; padding: 20px; border-radius: 5px; margin-bottom: 20px;">
          <p style="margin-bottom: 10px; font-size: 16px; font-weight: bold;">Access Code: ${accessCode}</p>
          <p style="font-size: 14px; color: #666;">You'll need this code to access your files.</p>
        </div>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${transferLink}" style="display: inline-block; background-color: #9e8a78; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-size: 16px;">Access Your Files</a>
        </div>
        <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">If you have any questions, please don't hesitate to contact us.</p>
        <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eeeeee;">
          <p style="font-size: 14px; color: #777777;">© 2025 B. Remembered Weddings. All rights reserved.</p>
        </div>
      </div>
    `
  }),
  
  // Rental booking confirmation template
  rentalBookingConfirmation: (recipientName: string, itemName: string, startDate: string, endDate: string) => ({
    subject: 'Your Rental Booking Confirmation - B. Remembered Weddings',
    html: `
      <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #333333;">
        <div style="text-align: center; margin-bottom: 30px;">
          <img src="https://tgufhzfafqjbgdbhnrjk.supabase.co/storage/v1/object/public/public-1//2023_B%20Remembered%20Weddings_Refresh.png" alt="B. Remembered Logo" style="max-width: 200px; height: auto;">
        </div>
        <h1 style="color: #333333; font-size: 24px; margin-bottom: 20px;">Hello, ${recipientName || 'there'}!</h1>
        <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">Your rental booking has been confirmed.</p>
        <div style="background-color: #f8f8f8; padding: 20px; border-radius: 5px; margin-bottom: 20px;">
          <h2 style="font-size: 18px; margin-bottom: 15px;">Booking Details</h2>
          <p style="margin-bottom: 10px; font-size: 16px;"><strong>Item:</strong> ${itemName}</p>
          <p style="margin-bottom: 10px; font-size: 16px;"><strong>Start Date:</strong> ${startDate}</p>
          <p style="margin-bottom: 10px; font-size: 16px;"><strong>End Date:</strong> ${endDate}</p>
        </div>
        <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5;">If you have any questions, please don't hesitate to contact us.</p>
        <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eeeeee;">
          <p style="font-size: 14px; color: #777777;">© 2025 B. Remembered Weddings. All rights reserved.</p>
        </div>
      </div>
    `
  }),
  
  // Newsletter template (base template that will be customized)
  newsletter: (content: string) => ({
    subject: 'Newsletter from B. Remembered Weddings',
    html: content
  })
};

// Helper function to send an email
export async function sendEmail({
  to,
  subject,
  html,
  from = 'B. Remembered Weddings <noreply@b-remembered.com>'
}: {
  to: string;
  subject: string;
  html: string;
  from?: string;
}) {
  try {
    const { data, error } = await resend.emails.send({
      from,
      to,
      subject,
      html
    });

    if (error) {
      console.error('Error sending email:', error);
      throw error;
    }

    return data;
  } catch (error) {
    console.error('Error sending email:', error);
    throw error;
  }
}