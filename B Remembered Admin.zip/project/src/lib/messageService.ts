import { supabase } from './supabase';
import { resend } from './resend';
import { sendSMS, replaceTemplateVariables } from './twilio';

// Function to get template content from database
export async function getTemplateById(templateId: string) {
  try {
    const { data, error } = await supabase
      .from('email_templates')
      .select('*')
      .eq('id', templateId)
      .single();
      
    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error fetching template:', error);
    throw error;
  }
}

// Function to send a message using a template
export async function sendTemplatedMessage({
  templateId,
  to,
  variables,
  from = 'B. Remembered Weddings <noreply@b-remembered.com>'
}: {
  templateId: string;
  to: string | string[];
  variables: Record<string, string>;
  from?: string;
}) {
  try {
    // Get template content
    const template = await getTemplateById(templateId);
    
    if (!template) {
      throw new Error('Template not found');
    }
    
    // Replace variables
    const content = replaceTemplateVariables(template.content, variables);
    
    // Send based on template type
    if (template.type === 'email') {
      const subject = replaceTemplateVariables(template.subject || '', variables);
      
      const { data, error } = await resend.emails.send({
        from,
        to,
        subject,
        html: content
      });
      
      if (error) throw error;
      return { success: true, data };
    } else if (template.type === 'sms') {
      // For SMS, we need to ensure the recipient is a valid phone number
      const recipients = Array.isArray(to) ? to : [to];
      
      const results = await Promise.all(
        recipients.map(recipient => sendSMS(recipient, content))
      );
      
      return { success: true, data: results };
    } else {
      throw new Error(`Unsupported template type: ${template.type}`);
    }
  } catch (error) {
    console.error('Error sending templated message:', error);
    throw error;
  }
}

// Function to log message send in the database
export async function logMessageSend({
  templateId,
  recipient,
  type,
  status,
  error,
  messageId,
  leadId,
  vendorId,
  venueId
}: {
  templateId: string;
  recipient: string;
  type: 'email' | 'sms';
  status: 'sent' | 'failed';
  error?: string;
  messageId?: string;
  leadId?: string;
  vendorId?: string;
  venueId?: string;
}) {
  try {
    const { error: dbError } = await supabase
      .from('message_logs')
      .insert({
        template_id: templateId,
        recipient,
        type,
        status,
        error_message: error,
        external_message_id: messageId,
        lead_id: leadId,
        vendor_id: vendorId,
        venue_id: venueId
      });
      
    if (dbError) throw dbError;
    
    return { success: true };
  } catch (err) {
    console.error('Error logging message send:', err);
    // Don't throw here, just log the error
    return { success: false, error: err };
  }
}