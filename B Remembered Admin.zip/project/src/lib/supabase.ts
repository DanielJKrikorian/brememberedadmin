import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl) {
  throw new Error('Missing Supabase URL environment variable (VITE_SUPABASE_URL)');
}

if (!supabaseAnonKey) {
  throw new Error('Missing Supabase Anon Key environment variable (VITE_SUPABASE_ANON_KEY)');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
  global: {
    headers: {
      'x-application-name': 'wedding-management',
    },
  },
});

// Test the connection
try {
  supabase.from('leads').select('count', { count: 'exact', head: true })
    .then(() => {
      console.log('Successfully connected to Supabase');
    })
    .catch((error) => {
      console.error('Failed to connect to Supabase:', error.message);
    });
} catch (error) {
  console.error('Failed to initialize Supabase client:', error);
  throw error;
}